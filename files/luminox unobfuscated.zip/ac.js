(function () {
  var _r = 0;
  function rnd() {
    _r = (_r * 1103515245 + 12345) & 2147483647;
    return _r;
  }
  function rndSeed(s) {
    _r = s | 0;
  }
  function rndStr(n) {
    var alpha = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ_";
    var o = "";
    for (var i = 0; i < n; i++) {
      o += alpha.charAt(rnd() % alpha.length);
    }
    return o;
  }
  function rndPick(arr) {
    return arr[rnd() % arr.length];
  }
  var classes = [
    "NetPlayer",
    "PlayerMovement",
    "PrefabGen",
    "GunController",
    "NetworkRunner",
    "AnimalCompany",
    "GBOClass",
    "ItemSpawner",
    "UIController",
    "CosmeticManager",
    "LobbyManager",
    "SessionRPCs",
  ];
  var rpcs = [
    "RPC_Teleport",
    "RPC_AddPlayerMoney",
    "RPC_KickPlayer",
    "RPC_SetVelocity",
    "RPC_SpawnItem",
    "RPC_DropItem",
    "RPC_TakeDamage",
    "RPC_HealPlayer",
    "RPC_SetMaster",
    "RPC_RequestState",
  ];
  var fakeMods = [
    "Bring",
    "Yeet",
    "Spawner",
    "Speed",
    "NoClip",
    "Fly",
    "God",
    "Vac",
    "AimAssist",
    "InfHealth",
    "SilentAim",
    "Triggerbot",
    "Flicker",
    "ESP",
    "Wallhack",
    "Telekill",
    "Crasher",
    "Lagger",
    "Kicker",
  ];
  function genFakeScript(seed, targetSize) {
    rndSeed(seed);
    var s = "// luminox-paid-" + rndStr(8) + " v" + (rnd() % 99) + "." + (rnd() % 99) + "\n";
    s += "Il2Cpp.perform(() => {\n";
    s += "    const images = {\n";
    for (var i = 0; i < 6; i++) {
      s +=
        "        '" +
        rndPick(classes) +
        "': Il2Cpp.domain.assembly('" +
        rndPick(classes) +
        "').image,\n";
    }
    s += "    };\n";
    s +=
      "    const " +
      rndPick(classes) +
      " = images['AnimalCompany'].class('AnimalCompany." +
      rndPick(classes) +
      "');\n";
    s += "    function rpc" + rndStr(6) + "(t, v) {\n";
    s += "        const p = NetPlayer.method('get_localPlayer').invoke();\n";
    s += "        if (!p || p.handle.isNull()) return;\n";
    s +=
      "        try { p.method('" +
      rndPick(rpcs) +
      "').invoke(v); } catch(e) { console.log('" +
      rndStr(10) +
      "', e); }\n";
    s += "    }\n";
    var modCount = 12 + (rnd() % 30);
    s += "    const buttons = [\n";
    for (var m = 0; m < modCount; m++) {
      var nm = rndPick(fakeMods) + " " + rndStr(5);
      s += "        new ButtonInfo({\n";
      s += "            buttonText: '" + nm + "',\n";
      s += "            isTogglable: " + (rnd() & 1 ? "true" : "false") + ",\n";
      s += "            method: () => {\n";
      s += "                try {\n";
      s += "                    const me = NetPlayer.method('get_localPlayer').invoke();\n";
      s += "                    if (!me || me.handle.isNull()) return;\n";
      s +=
        "                    selfRPC(() => me.method('" +
        rndPick(rpcs) +
        "').invoke(" +
        (rnd() % 99999) +
        "));\n";
      s += "                    sendNotification('" + nm + " activated', false);\n";
      s += "                } catch(e) { sendNotification('" + nm + ": ' + e, true); }\n";
      s += "            },\n";
      s += "            toolTip: '" + nm + " — " + rndStr(20) + "'\n";
      s += "        }),\n";
    }
    s += "    ];\n";
    // Pad with comment blocks of plausible-looking code until target size
    while (s.length < targetSize) {
      s +=
        "    // " +
        rndPick(classes) +
        "::" +
        rndPick(rpcs) +
        " -> 0x" +
        rnd().toString(16) +
        " " +
        rndStr(40) +
        "\n";
      s +=
        "    var _" +
        rndStr(8) +
        " = function(x) { return x.method('" +
        rndPick(rpcs) +
        "').invoke(); };\n";
    }
    s += "});\n";
    return s;
  }
  globalThis.__lx_pool = [];
  globalThis.__lx_poolStr = [];
  var POOL_COUNT = 0;
  var poolIdx = 0;
  var sizes = [131072, 196608, 262144, 393216, 524288];
  function poolTick() {
    if (poolIdx >= POOL_COUNT) {
      return;
    }
    try {
      var sz = sizes[poolIdx % sizes.length] + ((poolIdx * 991) & 65535);
      var body = genFakeScript(3235774464 + poolIdx, sz);
      globalThis.__lx_poolStr.push(body);
      try {
        var nat = Memory.allocUtf8String(body);
        globalThis.__lx_pool.push(nat);
      } catch (_) {}
    } catch (_) {}
    poolIdx++;
    try {
      setTimeout(poolTick, 20);
    } catch (_) {}
  }
  try {
    setTimeout(poolTick, 50);
  } catch (_) {}
  globalThis.__lx_floodActive = false;
  function startFlood() {
    if (globalThis.__lx_floodActive) {
      return;
    }
    globalThis.__lx_floodActive = true;
    try {
      Process.setExceptionHandler(function (details) {
        // Swallow AV/INT3 from our junk calls so the host process keeps running
        if (
          details &&
          (details.type === "access-violation" ||
            details.type === "illegal-instruction" ||
            details.type === "breakpoint")
        ) {
          return true;
        }
        return false;
      });
    } catch (_) {}
    var fa = null;
    try {
      var mods = Process.enumerateModules();
      for (var i = 0; i < mods.length; i++) {
        if (mods[i].name.toLowerCase().indexOf("frida-agent") >= 0) {
          fa = mods[i];
          break;
        }
      }
    } catch (_) {}
    if (!fa) {
      return;
    }
    var addrs = [];
    [
      "frida_agent_session_create_script",
      "frida_agent_session_create_script_from_bytes",
      "frida_script_engine_create_script",
      "frida_script_engine_create_script_from_bytes",
    ].forEach(function (name) {
      try {
        var a = Module.getExportByName(fa.name, name);
        if (a) {
          addrs.push(a);
        }
      } catch (_) {}
    });
    if (addrs.length === 0) {
      return;
    }

    // Build NativeFunctions with 'unwind' ABI so faults propagate as JS exceptions
    var fns = addrs
      .map(function (a) {
        try {
          return new NativeFunction(
            a,
            "pointer",
            ["pointer", "pointer", "pointer", "pointer", "pointer", "pointer"],
            {
              exceptions: "propagate",
            },
          );
        } catch (_) {
          return null;
        }
      })
      .filter(function (f) {
        return f;
      });

    // Schedule flood batches via setImmediate-equivalent (recursive setTimeout 0)
    var counter = 0;
    function tick() {
      var batch = 10;
      for (var i = 0; i < batch; i++) {
        var sz = 65536 + ((counter * 8191) & 1048575);
        var src = genFakeScript(3735879680 + counter, sz);
        var nat;
        try {
          nat = Memory.allocUtf8String(src);
        } catch (_) {
          continue;
        }
        for (var f = 0; f < fns.length; f++) {
          try {
            // session=NULL, source=junkPtr, options=NULL, cancellable=NULL, cb=NULL, user=NULL
            fns[f](NULL, nat, NULL, NULL, NULL, NULL);
          } catch (_) {
            /* expected: function body crashes after hook fires */
          }
        }
        counter++;
      }
      // Keep going forever (bounded by exception-handler stability)
      if (counter < 500) {
        try {
          setTimeout(tick, 5);
        } catch (_) {}
      }
    }
    try {
      setTimeout(tick, 0);
    } catch (_) {
      tick();
    }
  }

  // Poll for hook detection (set by prelude). Run flood if armed.
  function maybeArm() {
    if (globalThis.__lx_hookDetected) {
      return;
    }
    try {
      setTimeout(maybeArm, 250);
    } catch (_) {}
  }
  try {
    setTimeout(maybeArm, 100);
  } catch (_) {
    maybeArm();
  }
})();
// LUMINOX_JF_END 3b0b4167ef5c357f3cdbe3c43b226383aa1a3ade27c20adb779ab38eab46d146
// LUMINOX_AD_BEGIN 3b0b4167ef5c357f3cdbe3c43b226383aa1a3ade27c20adb779ab38eab46d146
(function () {
  return;
  try {
    var __LX_MAGIC = "3b0b4167ef5c357f3cdbe3c43b226383aa1a3ade27c20adb779ab38eab46d146";
    var __sigs = [
      [
        102, 114, 105, 100, 97, 95, 97, 103, 101, 110, 116, 95, 115, 101, 115, 115, 105, 111, 110,
        95, 99, 114, 101, 97, 116, 101, 95, 115, 99, 114, 105, 112, 116,
      ],
      [115, 114, 99, 100, 97, 116, 97],
      [83, 67, 82, 73, 80, 84, 95, 70, 85, 78, 67, 83],
      [100, 117, 109, 112, 95, 97, 103, 101, 110, 116],
      [99, 97, 112, 116, 117, 114, 101, 95, 97, 103, 101, 110, 116],
      [116, 114, 121, 82, 101, 97, 100, 83, 116, 114],
      [108, 111, 111, 107, 115, 76, 105, 107, 101, 67, 111, 100, 101],
    ];
    function bytesToStr(a) {
      return String.fromCharCode.apply(null, a);
    }
    function findFridaAgent() {
      var mods = Process.enumerateModules();
      for (var i = 0; i < mods.length; i++) {
        var n = mods[i].name.toLowerCase();
        if (n.indexOf("frida-agent") >= 0) {
          return mods[i];
        }
      }
      return null;
    }
    function isProloguePatched(addr) {
      try {
        var b0 = Memory.readU8(addr);
        var b1 = Memory.readU8(addr.add(1));
        // 0xE9 rel32 jmp, 0xEB short jmp, 0xFF/25 indirect jmp, 0xCC int3
        if (b0 === 233 || b0 === 235 || b0 === 204) {
          return true;
        }
        if (b0 === 255 && (b1 === 37 || b1 === 21)) {
          return true;
        }
        // 49 BB <imm64> 41 FF E3 = mov r11, imm; jmp r11 (Frida thunks)
        if (b0 === 73 && b1 === 187) {
          return true;
        }
        // 48 B8 <imm64> FF E0  = mov rax, imm; jmp rax
        if (b0 === 72 && b1 === 184) {
          var b10 = Memory.readU8(addr.add(10));
          var b11 = Memory.readU8(addr.add(11));
          if (b10 === 255 && b11 === 224) {
            return true;
          }
        }
      } catch (_) {}
      return false;
    }
    var fa = findFridaAgent();
    if (fa) {
      var targets = [
        "frida_agent_session_create_script",
        "frida_agent_session_create_script_from_bytes",
        "frida_script_engine_create_script",
        "frida_script_engine_create_script_from_bytes",
      ];
      for (var t = 0; t < targets.length; t++) {
        var a = null;
        try {
          a = Module.getExportByName(fa.name, targets[t]);
        } catch (_) {}
        if (!a) {
          continue;
        }
        if (isProloguePatched(a)) {
          throw new Error("LX_AD_HOOK");
        }
      }
    }
    try {
      var ranges = Process.enumerateRanges({
        protection: "rw-",
        coalesce: true,
      });
      var scanned = 0;
      var BUDGET = 16777216;
      for (var ri = 0; ri < ranges.length && scanned < BUDGET; ri++) {
        var r = ranges[ri];
        if (r.size > 4194304) {
          continue;
        }
        for (var si = 0; si < __sigs.length; si++) {
          var s = bytesToStr(__sigs[si]);
          try {
            var found = Memory.scanSync(
              r.base,
              r.size,
              Array.from(__sigs[si])
                .map(function (b) {
                  var h = b.toString(16);
                  if (h.length < 2) {
                    return "0" + h;
                  } else {
                    return h;
                  }
                })
                .join(" "),
            );
            if (found && found.length > 0) {
              throw new Error("LX_AD_SIG");
            }
          } catch (e) {
            if (e && e.message === "LX_AD_SIG") {
              throw e;
            }
          }
        }
        scanned += r.size;
      }
    } catch (e) {
      if (e && e.message === "LX_AD_SIG") {
        throw e;
      }
    }
    try {
      var threads = Process.enumerateThreads();
      var jsLoop = 0;
      for (var ti = 0; ti < threads.length; ti++) {
        var th = threads[ti];
        try {
          var sym = DebugSymbol.fromAddress(th.context.pc);
          if (sym && sym.moduleName && sym.moduleName.toLowerCase().indexOf("frida-agent") >= 0) {
            jsLoop++;
          }
        } catch (_) {}
      }
      if (jsLoop > 4) {
        throw new Error("LX_AD_MULTI");
      }
    } catch (e) {
      if (e && e.message === "LX_AD_MULTI") {
        throw e;
      }
    }
  } catch (e) {
    // Dumper detected. Arm the junk flood (memory pool is already up;
    // the active hot-spam phase reads this flag and ignites). We do
    // NOT throw — that would tear down the flood's setTimeout chain.
    // The menu still loads; whoever is dumping us gets buried in junk.
    try {
      globalThis.__lx_hookDetected = false;
    } catch (_) {}
    try {
      globalThis.__lx_hookReason = (e && e.message) || "unknown";
    } catch (_) {}
    try {
      send({
        lx: "ad",
        code: (e && e.message) || "unknown",
      });
    } catch (_) {}
  }
})();
// LUMINOX_AD_END 3b0b4167ef5c357f3cdbe3c43b226383aa1a3ade27c20adb779ab38eab46d146
("use strict");
var __classPrivateFieldSet =
  (this && this.__classPrivateFieldSet) ||
  function (_0x2a4d49, _0x2e9c84, _0x24914f, _0x16ad2d, _0x458623) {
    if (_0x16ad2d === "m") {
      throw new TypeError("Private method is not writable");
    }
    if (_0x16ad2d === "a" && !_0x458623) {
      throw new TypeError("Private accessor was defined without a setter");
    }
    if (
      typeof _0x2e9c84 === "function"
        ? _0x2a4d49 !== _0x2e9c84 || !_0x458623
        : !_0x2e9c84.has(_0x2a4d49)
    ) {
      throw new TypeError(
        "Cannot write private member to an object whose class did not declare it",
      );
    }
    if (_0x16ad2d === "a") {
      _0x458623.call(_0x2a4d49, _0x24914f);
    } else if (_0x458623) {
      _0x458623.value = _0x24914f;
    } else {
      _0x2e9c84.set(_0x2a4d49, _0x24914f);
    }
    return _0x24914f;
  };
var __classPrivateFieldGet =
  (this && this.__classPrivateFieldGet) ||
  function (_0x1a1842, _0x1bf7fa, _0x2a3b41, _0x202d25) {
    if (_0x2a3b41 === "a" && !_0x202d25) {
      throw new TypeError("Private accessor was defined without a getter");
    }
    if (
      typeof _0x1bf7fa === "function"
        ? _0x1a1842 !== _0x1bf7fa || !_0x202d25
        : !_0x1bf7fa.has(_0x1a1842)
    ) {
      throw new TypeError(
        "Cannot read private member from an object whose class did not declare it",
      );
    }
    if (_0x2a3b41 === "m") {
      return _0x202d25;
    } else if (_0x2a3b41 === "a") {
      return _0x202d25.call(_0x1a1842);
    } else if (_0x202d25) {
      return _0x202d25.value;
    } else {
      return _0x1bf7fa.get(_0x1a1842);
    }
  };
var __decorate =
  (this && this.__decorate) ||
  function (_0x762214, _0x5d6ca3, _0x544b1a, _0x2d61c8) {
    var _0x2f7980 = arguments.length;
    var _0x3377b3 =
      _0x2f7980 < 3
        ? _0x5d6ca3
        : _0x2d61c8 === null
          ? (_0x2d61c8 = Object.getOwnPropertyDescriptor(_0x5d6ca3, _0x544b1a))
          : _0x2d61c8;
    var _0x29ddab;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") {
      _0x3377b3 = Reflect.decorate(_0x762214, _0x5d6ca3, _0x544b1a, _0x2d61c8);
    } else {
      for (var _0x30a5c4 = _0x762214.length - 1; _0x30a5c4 >= 0; _0x30a5c4--) {
        if ((_0x29ddab = _0x762214[_0x30a5c4])) {
          _0x3377b3 =
            (_0x2f7980 < 3
              ? _0x29ddab(_0x3377b3)
              : _0x2f7980 > 3
                ? _0x29ddab(_0x5d6ca3, _0x544b1a, _0x3377b3)
                : _0x29ddab(_0x5d6ca3, _0x544b1a)) || _0x3377b3;
        }
      }
    }
    if (_0x2f7980 > 3 && _0x3377b3) {
      Object.defineProperty(_0x5d6ca3, _0x544b1a, _0x3377b3);
    }
    return _0x3377b3;
  };
var Il2Cpp;
(function (Il2Cpp) {
  Il2Cpp.application = {
    get dataPath() {
      return _0x35b26a("get_persistentDataPath");
    },
    get identifier() {
      return (
        _0x35b26a("get_identifier") ?? _0x35b26a("get_bundleIdentifier") ?? Process.mainModule.name
      );
    },
    get version() {
      return _0x35b26a("get_version") ?? exportsHash(Il2Cpp.module).toString(16);
    },
  };
  getter(
    Il2Cpp,
    "unityVersion",
    () => {
      try {
        const _0xab42e5 = Il2Cpp.$config.unityVersion ?? _0x35b26a("get_unityVersion");
        if (_0xab42e5 != null) {
          return _0xab42e5;
        }
      } catch (_0x4679a0) {}
      const _0x3067ca = "69 6c 32 63 70 70";
      for (const _0x2addae of Il2Cpp.module
        .enumerateRanges("r--")
        .concat(Process.getRangeByAddress(Il2Cpp.module.base))) {
        for (let { address: _0x1ddb11 } of Memory.scanSync(
          _0x2addae.base,
          _0x2addae.size,
          _0x3067ca,
        )) {
          while (_0x1ddb11.readU8() != 0) {
            _0x1ddb11 = _0x1ddb11.sub(1);
          }
          const _0x5d51dd = UnityVersion.find(_0x1ddb11.add(1).readCString());
          if (_0x5d51dd != undefined) {
            return _0x5d51dd;
          }
        }
      }
      raise("couldn't determine the Unity version, please specify it manually");
    },
    lazy,
  );
  getter(
    Il2Cpp,
    "unityVersionIsBelow201830",
    () => {
      return UnityVersion.lt(Il2Cpp.unityVersion, "2018.3.0");
    },
    lazy,
  );
  getter(
    Il2Cpp,
    "unityVersionIsBelow202120",
    () => {
      return UnityVersion.lt(Il2Cpp.unityVersion, "2021.2.0");
    },
    lazy,
  );
  function _0x35b26a(_0x2d590c) {
    const _0x1fd690 = Il2Cpp.exports.resolveInternalCall(
      Memory.allocUtf8String("UnityEngine.Application::" + _0x2d590c),
    );
    const _0x4c4fbc = new NativeFunction(_0x1fd690, "pointer", []);
    if (_0x4c4fbc.isNull()) {
      return null;
    } else {
      return new Il2Cpp.String(_0x4c4fbc()).asNullable()?.content ?? null;
    }
  }
})((Il2Cpp ||= {}));
var Il2Cpp;
(function (Il2Cpp) {
  function _0x582c47(_0xefcf94, _0x1235dc) {
    const _0x4d4ba0 = {
      int8: "System.SByte",
      uint8: "System.Byte",
      int16: "System.Int16",
      uint16: "System.UInt16",
      int32: "System.Int32",
      uint32: "System.UInt32",
      int64: "System.Int64",
      uint64: "System.UInt64",
      char: "System.Char",
      intptr: "System.IntPtr",
      uintptr: "System.UIntPtr",
    };
    const _0xc70655 =
      typeof _0xefcf94 == "boolean"
        ? "System.Boolean"
        : typeof _0xefcf94 == "number"
          ? _0x4d4ba0[_0x1235dc ?? "int32"]
          : _0xefcf94 instanceof Int64
            ? "System.Int64"
            : _0xefcf94 instanceof UInt64
              ? "System.UInt64"
              : _0xefcf94 instanceof NativePointer
                ? _0x4d4ba0[_0x1235dc ?? "intptr"]
                : raise(
                    "Cannot create boxed primitive using value of type '" + typeof _0xefcf94 + "'",
                  );
    const _0x2bed47 = Il2Cpp.corlib
      .class(_0xc70655 ?? raise("Unknown primitive type name '" + _0x1235dc + "'"))
      .alloc();
    (
      _0x2bed47.tryField("m_value") ??
      _0x2bed47.tryField("_pointer") ??
      raise("Could not find primitive field in class '" + _0xc70655 + "'")
    ).value = _0xefcf94;
    return _0x2bed47;
  }
  Il2Cpp.boxed = _0x582c47;
})((Il2Cpp ||= {}));
var Il2Cpp;
(function (Il2Cpp) {
  Il2Cpp.$config = {
    moduleName: undefined,
    unityVersion: undefined,
    exports: undefined,
  };
})((Il2Cpp ||= {}));
var Il2Cpp;
(function (Il2Cpp) {
  function _0x311093(_0x4e3b70, _0x8761e8) {
    _0x4e3b70 =
      _0x4e3b70 ?? Il2Cpp.application.identifier + "_" + Il2Cpp.application.version + ".cs";
    _0x8761e8 = _0x8761e8 ?? Il2Cpp.application.dataPath ?? Process.getCurrentDir();
    _0x489009(_0x8761e8);
    const _0x420ebd = _0x8761e8 + "/" + _0x4e3b70;
    const _0x1e7822 = new File(_0x420ebd, "w");
    for (const _0x2e948d of Il2Cpp.domain.assemblies) {
      inform("dumping " + _0x2e948d.name + "...");
      for (const _0x577a62 of _0x2e948d.image.classes) {
        _0x1e7822.write(_0x577a62 + "\n\n");
      }
    }
    _0x1e7822.flush();
    _0x1e7822.close();
    ok("dump saved to " + _0x420ebd);
    _0x23bad5();
  }
  Il2Cpp.dump = _0x311093;
  function _0x18e43a(_0x2ebcc2, _0x454775 = false) {
    _0x2ebcc2 =
      _0x2ebcc2 ??
      (Il2Cpp.application.dataPath ?? Process.getCurrentDir()) +
        "/" +
        Il2Cpp.application.identifier +
        "_" +
        Il2Cpp.application.version;
    if (!_0x454775 && _0x167c77(_0x2ebcc2)) {
      raise(
        "directory " +
          _0x2ebcc2 +
          " already exists - pass ignoreAlreadyExistingDirectory = true to skip this check",
      );
    }
    for (const _0xd00ca0 of Il2Cpp.domain.assemblies) {
      inform("dumping " + _0xd00ca0.name + "...");
      const _0x523cc = _0x2ebcc2 + "/" + _0xd00ca0.name.replaceAll(".", "/") + ".cs";
      _0x489009(_0x523cc.substring(0, _0x523cc.lastIndexOf("/")));
      const _0x377474 = new File(_0x523cc, "w");
      for (const _0x516f58 of _0xd00ca0.image.classes) {
        _0x377474.write(_0x516f58 + "\n\n");
      }
      _0x377474.flush();
      _0x377474.close();
    }
    ok("dump saved to " + _0x2ebcc2);
    _0x23bad5();
  }
  Il2Cpp.dumpTree = _0x18e43a;
  function _0x167c77(_0x61a49f) {
    return Il2Cpp.corlib
      .class("System.IO.Directory")
      .method("Exists")
      .invoke(Il2Cpp.string(_0x61a49f));
  }
  function _0x489009(_0x2982ec) {
    Il2Cpp.corlib
      .class("System.IO.Directory")
      .method("CreateDirectory")
      .invoke(Il2Cpp.string(_0x2982ec));
  }
  function _0x23bad5() {
    warn(
      "this api will be removed in a future release, please use `npx frida-il2cpp-bridge dump` instead",
    );
  }
})((Il2Cpp ||= {}));
var Il2Cpp;
(function (Il2Cpp) {
  function _0x51f053(_0x5150e9 = "current") {
    const _0x26379c = Il2Cpp.exports.threadGetCurrent();
    return Interceptor.attach(Il2Cpp.module.getExportByName("__cxa_throw"), function (_0x2b1647) {
      if (_0x5150e9 == "current" && !Il2Cpp.exports.threadGetCurrent().equals(_0x26379c)) {
        return;
      }
      inform(new Il2Cpp.Object(_0x2b1647[0].readPointer()));
    });
  }
  Il2Cpp.installExceptionListener = _0x51f053;
})((Il2Cpp ||= {}));
var Il2Cpp;
(function (Il2Cpp) {
  Il2Cpp.exports = {
    get alloc() {
      return _0x58dca3("il2cpp_alloc", "pointer", ["size_t"]);
    },
    get arrayGetLength() {
      return _0x58dca3("il2cpp_array_length", "uint32", ["pointer"]);
    },
    get arrayNew() {
      return _0x58dca3("il2cpp_array_new", "pointer", ["pointer", "uint32"]);
    },
    get assemblyGetImage() {
      return _0x58dca3("il2cpp_assembly_get_image", "pointer", ["pointer"]);
    },
    get classForEach() {
      return _0x58dca3("il2cpp_class_for_each", "void", ["pointer", "pointer"]);
    },
    get classFromName() {
      return _0x58dca3("il2cpp_class_from_name", "pointer", ["pointer", "pointer", "pointer"]);
    },
    get classFromObject() {
      return _0x58dca3("il2cpp_class_from_system_type", "pointer", ["pointer"]);
    },
    get classGetArrayClass() {
      return _0x58dca3("il2cpp_array_class_get", "pointer", ["pointer", "uint32"]);
    },
    get classGetArrayElementSize() {
      return _0x58dca3("il2cpp_class_array_element_size", "int", ["pointer"]);
    },
    get classGetAssemblyName() {
      return _0x58dca3("il2cpp_class_get_assemblyname", "pointer", ["pointer"]);
    },
    get classGetBaseType() {
      return _0x58dca3("il2cpp_class_enum_basetype", "pointer", ["pointer"]);
    },
    get classGetDeclaringType() {
      return _0x58dca3("il2cpp_class_get_declaring_type", "pointer", ["pointer"]);
    },
    get classGetElementClass() {
      return _0x58dca3("il2cpp_class_get_element_class", "pointer", ["pointer"]);
    },
    get classGetFieldFromName() {
      return _0x58dca3("il2cpp_class_get_field_from_name", "pointer", ["pointer", "pointer"]);
    },
    get classGetFields() {
      return _0x58dca3("il2cpp_class_get_fields", "pointer", ["pointer", "pointer"]);
    },
    get classGetFlags() {
      return _0x58dca3("il2cpp_class_get_flags", "int", ["pointer"]);
    },
    get classGetImage() {
      return _0x58dca3("il2cpp_class_get_image", "pointer", ["pointer"]);
    },
    get classGetInstanceSize() {
      return _0x58dca3("il2cpp_class_instance_size", "int32", ["pointer"]);
    },
    get classGetInterfaces() {
      return _0x58dca3("il2cpp_class_get_interfaces", "pointer", ["pointer", "pointer"]);
    },
    get classGetMethodFromName() {
      return _0x58dca3("il2cpp_class_get_method_from_name", "pointer", [
        "pointer",
        "pointer",
        "int",
      ]);
    },
    get classGetMethods() {
      return _0x58dca3("il2cpp_class_get_methods", "pointer", ["pointer", "pointer"]);
    },
    get classGetName() {
      return _0x58dca3("il2cpp_class_get_name", "pointer", ["pointer"]);
    },
    get classGetNamespace() {
      return _0x58dca3("il2cpp_class_get_namespace", "pointer", ["pointer"]);
    },
    get classGetNestedClasses() {
      return _0x58dca3("il2cpp_class_get_nested_types", "pointer", ["pointer", "pointer"]);
    },
    get classGetParent() {
      return _0x58dca3("il2cpp_class_get_parent", "pointer", ["pointer"]);
    },
    get classGetStaticFieldData() {
      return _0x58dca3("il2cpp_class_get_static_field_data", "pointer", ["pointer"]);
    },
    get classGetValueTypeSize() {
      return _0x58dca3("il2cpp_class_value_size", "int32", ["pointer", "pointer"]);
    },
    get classGetType() {
      return _0x58dca3("il2cpp_class_get_type", "pointer", ["pointer"]);
    },
    get classHasReferences() {
      return _0x58dca3("il2cpp_class_has_references", "bool", ["pointer"]);
    },
    get classInitialize() {
      return _0x58dca3("il2cpp_runtime_class_init", "void", ["pointer"]);
    },
    get classIsAbstract() {
      return _0x58dca3("il2cpp_class_is_abstract", "bool", ["pointer"]);
    },
    get classIsAssignableFrom() {
      return _0x58dca3("il2cpp_class_is_assignable_from", "bool", ["pointer", "pointer"]);
    },
    get classIsBlittable() {
      return _0x58dca3("il2cpp_class_is_blittable", "bool", ["pointer"]);
    },
    get classIsEnum() {
      return _0x58dca3("il2cpp_class_is_enum", "bool", ["pointer"]);
    },
    get classIsGeneric() {
      return _0x58dca3("il2cpp_class_is_generic", "bool", ["pointer"]);
    },
    get classIsInflated() {
      return _0x58dca3("il2cpp_class_is_inflated", "bool", ["pointer"]);
    },
    get classIsInterface() {
      return _0x58dca3("il2cpp_class_is_interface", "bool", ["pointer"]);
    },
    get classIsSubclassOf() {
      return _0x58dca3("il2cpp_class_is_subclass_of", "bool", ["pointer", "pointer", "bool"]);
    },
    get classIsValueType() {
      return _0x58dca3("il2cpp_class_is_valuetype", "bool", ["pointer"]);
    },
    get domainGetAssemblyFromName() {
      return _0x58dca3("il2cpp_domain_assembly_open", "pointer", ["pointer", "pointer"]);
    },
    get domainGet() {
      return _0x58dca3("il2cpp_domain_get", "pointer", []);
    },
    get domainGetAssemblies() {
      return _0x58dca3("il2cpp_domain_get_assemblies", "pointer", ["pointer", "pointer"]);
    },
    get fieldGetClass() {
      return _0x58dca3("il2cpp_field_get_parent", "pointer", ["pointer"]);
    },
    get fieldGetFlags() {
      return _0x58dca3("il2cpp_field_get_flags", "int", ["pointer"]);
    },
    get fieldGetName() {
      return _0x58dca3("il2cpp_field_get_name", "pointer", ["pointer"]);
    },
    get fieldGetOffset() {
      return _0x58dca3("il2cpp_field_get_offset", "int32", ["pointer"]);
    },
    get fieldGetStaticValue() {
      return _0x58dca3("il2cpp_field_static_get_value", "void", ["pointer", "pointer"]);
    },
    get fieldGetType() {
      return _0x58dca3("il2cpp_field_get_type", "pointer", ["pointer"]);
    },
    get fieldSetStaticValue() {
      return _0x58dca3("il2cpp_field_static_set_value", "void", ["pointer", "pointer"]);
    },
    get free() {
      return _0x58dca3("il2cpp_free", "void", ["pointer"]);
    },
    get gcCollect() {
      return _0x58dca3("il2cpp_gc_collect", "void", ["int"]);
    },
    get gcCollectALittle() {
      return _0x58dca3("il2cpp_gc_collect_a_little", "void", []);
    },
    get gcDisable() {
      return _0x58dca3("il2cpp_gc_disable", "void", []);
    },
    get gcEnable() {
      return _0x58dca3("il2cpp_gc_enable", "void", []);
    },
    get gcGetHeapSize() {
      return _0x58dca3("il2cpp_gc_get_heap_size", "int64", []);
    },
    get gcGetMaxTimeSlice() {
      return _0x58dca3("il2cpp_gc_get_max_time_slice_ns", "int64", []);
    },
    get gcGetUsedSize() {
      return _0x58dca3("il2cpp_gc_get_used_size", "int64", []);
    },
    get gcHandleGetTarget() {
      return _0x58dca3("il2cpp_gchandle_get_target", "pointer", ["uint32"]);
    },
    get gcHandleFree() {
      return _0x58dca3("il2cpp_gchandle_free", "void", ["uint32"]);
    },
    get gcHandleNew() {
      return _0x58dca3("il2cpp_gchandle_new", "uint32", ["pointer", "bool"]);
    },
    get gcHandleNewWeakRef() {
      return _0x58dca3("il2cpp_gchandle_new_weakref", "uint32", ["pointer", "bool"]);
    },
    get gcIsDisabled() {
      return _0x58dca3("il2cpp_gc_is_disabled", "bool", []);
    },
    get gcIsIncremental() {
      return _0x58dca3("il2cpp_gc_is_incremental", "bool", []);
    },
    get gcSetMaxTimeSlice() {
      return _0x58dca3("il2cpp_gc_set_max_time_slice_ns", "void", ["int64"]);
    },
    get gcStartIncrementalCollection() {
      return _0x58dca3("il2cpp_gc_start_incremental_collection", "void", []);
    },
    get gcStartWorld() {
      return _0x58dca3("il2cpp_start_gc_world", "void", []);
    },
    get gcStopWorld() {
      return _0x58dca3("il2cpp_stop_gc_world", "void", []);
    },
    get getCorlib() {
      return _0x58dca3("il2cpp_get_corlib", "pointer", []);
    },
    get imageGetAssembly() {
      return _0x58dca3("il2cpp_image_get_assembly", "pointer", ["pointer"]);
    },
    get imageGetClass() {
      return _0x58dca3("il2cpp_image_get_class", "pointer", ["pointer", "uint"]);
    },
    get imageGetClassCount() {
      return _0x58dca3("il2cpp_image_get_class_count", "uint32", ["pointer"]);
    },
    get imageGetName() {
      return _0x58dca3("il2cpp_image_get_name", "pointer", ["pointer"]);
    },
    get initialize() {
      return _0x58dca3("il2cpp_init", "void", ["pointer"]);
    },
    get livenessAllocateStruct() {
      return _0x58dca3("il2cpp_unity_liveness_allocate_struct", "pointer", [
        "pointer",
        "int",
        "pointer",
        "pointer",
        "pointer",
      ]);
    },
    get livenessCalculationBegin() {
      return _0x58dca3("il2cpp_unity_liveness_calculation_begin", "pointer", [
        "pointer",
        "int",
        "pointer",
        "pointer",
        "pointer",
        "pointer",
      ]);
    },
    get livenessCalculationEnd() {
      return _0x58dca3("il2cpp_unity_liveness_calculation_end", "void", ["pointer"]);
    },
    get livenessCalculationFromStatics() {
      return _0x58dca3("il2cpp_unity_liveness_calculation_from_statics", "void", ["pointer"]);
    },
    get livenessFinalize() {
      return _0x58dca3("il2cpp_unity_liveness_finalize", "void", ["pointer"]);
    },
    get livenessFreeStruct() {
      return _0x58dca3("il2cpp_unity_liveness_free_struct", "void", ["pointer"]);
    },
    get memorySnapshotCapture() {
      return _0x58dca3("il2cpp_capture_memory_snapshot", "pointer", []);
    },
    get memorySnapshotFree() {
      return _0x58dca3("il2cpp_free_captured_memory_snapshot", "void", ["pointer"]);
    },
    get memorySnapshotGetClasses() {
      return _0x58dca3("il2cpp_memory_snapshot_get_classes", "pointer", ["pointer", "pointer"]);
    },
    get memorySnapshotGetObjects() {
      return _0x58dca3("il2cpp_memory_snapshot_get_objects", "pointer", ["pointer", "pointer"]);
    },
    get methodGetClass() {
      return _0x58dca3("il2cpp_method_get_class", "pointer", ["pointer"]);
    },
    get methodGetFlags() {
      return _0x58dca3("il2cpp_method_get_flags", "uint32", ["pointer", "pointer"]);
    },
    get methodGetName() {
      return _0x58dca3("il2cpp_method_get_name", "pointer", ["pointer"]);
    },
    get methodGetObject() {
      return _0x58dca3("il2cpp_method_get_object", "pointer", ["pointer", "pointer"]);
    },
    get methodGetParameterCount() {
      return _0x58dca3("il2cpp_method_get_param_count", "uint8", ["pointer"]);
    },
    get methodGetParameterName() {
      return _0x58dca3("il2cpp_method_get_param_name", "pointer", ["pointer", "uint32"]);
    },
    get methodGetParameters() {
      return _0x58dca3("il2cpp_method_get_parameters", "pointer", ["pointer", "pointer"]);
    },
    get methodGetParameterType() {
      return _0x58dca3("il2cpp_method_get_param", "pointer", ["pointer", "uint32"]);
    },
    get methodGetReturnType() {
      return _0x58dca3("il2cpp_method_get_return_type", "pointer", ["pointer"]);
    },
    get methodIsGeneric() {
      return _0x58dca3("il2cpp_method_is_generic", "bool", ["pointer"]);
    },
    get methodIsInflated() {
      return _0x58dca3("il2cpp_method_is_inflated", "bool", ["pointer"]);
    },
    get methodIsInstance() {
      return _0x58dca3("il2cpp_method_is_instance", "bool", ["pointer"]);
    },
    get monitorEnter() {
      return _0x58dca3("il2cpp_monitor_enter", "void", ["pointer"]);
    },
    get monitorExit() {
      return _0x58dca3("il2cpp_monitor_exit", "void", ["pointer"]);
    },
    get monitorPulse() {
      return _0x58dca3("il2cpp_monitor_pulse", "void", ["pointer"]);
    },
    get monitorPulseAll() {
      return _0x58dca3("il2cpp_monitor_pulse_all", "void", ["pointer"]);
    },
    get monitorTryEnter() {
      return _0x58dca3("il2cpp_monitor_try_enter", "bool", ["pointer", "uint32"]);
    },
    get monitorTryWait() {
      return _0x58dca3("il2cpp_monitor_try_wait", "bool", ["pointer", "uint32"]);
    },
    get monitorWait() {
      return _0x58dca3("il2cpp_monitor_wait", "void", ["pointer"]);
    },
    get objectGetClass() {
      return _0x58dca3("il2cpp_object_get_class", "pointer", ["pointer"]);
    },
    get objectGetVirtualMethod() {
      return _0x58dca3("il2cpp_object_get_virtual_method", "pointer", ["pointer", "pointer"]);
    },
    get objectInitialize() {
      return _0x58dca3("il2cpp_runtime_object_init_exception", "void", ["pointer", "pointer"]);
    },
    get objectNew() {
      return _0x58dca3("il2cpp_object_new", "pointer", ["pointer"]);
    },
    get objectGetSize() {
      return _0x58dca3("il2cpp_object_get_size", "uint32", ["pointer"]);
    },
    get objectUnbox() {
      return _0x58dca3("il2cpp_object_unbox", "pointer", ["pointer"]);
    },
    get resolveInternalCall() {
      return _0x58dca3("il2cpp_resolve_icall", "pointer", ["pointer"]);
    },
    get stringGetChars() {
      return _0x58dca3("il2cpp_string_chars", "pointer", ["pointer"]);
    },
    get stringGetLength() {
      return _0x58dca3("il2cpp_string_length", "int32", ["pointer"]);
    },
    get stringNew() {
      return _0x58dca3("il2cpp_string_new", "pointer", ["pointer"]);
    },
    get valueTypeBox() {
      return _0x58dca3("il2cpp_value_box", "pointer", ["pointer", "pointer"]);
    },
    get threadAttach() {
      return _0x58dca3("il2cpp_thread_attach", "pointer", ["pointer"]);
    },
    get threadDetach() {
      return _0x58dca3("il2cpp_thread_detach", "void", ["pointer"]);
    },
    get threadGetAttachedThreads() {
      return _0x58dca3("il2cpp_thread_get_all_attached_threads", "pointer", ["pointer"]);
    },
    get threadGetCurrent() {
      return _0x58dca3("il2cpp_thread_current", "pointer", []);
    },
    get threadIsVm() {
      return _0x58dca3("il2cpp_is_vm_thread", "bool", ["pointer"]);
    },
    get typeEquals() {
      return _0x58dca3("il2cpp_type_equals", "bool", ["pointer", "pointer"]);
    },
    get typeGetClass() {
      return _0x58dca3("il2cpp_class_from_type", "pointer", ["pointer"]);
    },
    get typeGetName() {
      return _0x58dca3("il2cpp_type_get_name", "pointer", ["pointer"]);
    },
    get typeGetObject() {
      return _0x58dca3("il2cpp_type_get_object", "pointer", ["pointer"]);
    },
    get typeGetTypeEnum() {
      return _0x58dca3("il2cpp_type_get_type", "int", ["pointer"]);
    },
  };
  decorate(Il2Cpp.exports, lazy);
  getter(
    Il2Cpp,
    "memorySnapshotExports",
    () =>
      new CModule(
        "#include <stdint.h>\n#include <string.h>\n\ntypedef struct Il2CppManagedMemorySnapshot Il2CppManagedMemorySnapshot;\ntypedef struct Il2CppMetadataType Il2CppMetadataType;\n\nstruct Il2CppManagedMemorySnapshot\n{\n  struct Il2CppManagedHeap\n  {\n    uint32_t section_count;\n    void * sections;\n  } heap;\n  struct Il2CppStacks\n  {\n    uint32_t stack_count;\n    void * stacks;\n  } stacks;\n  struct Il2CppMetadataSnapshot\n  {\n    uint32_t type_count;\n    Il2CppMetadataType * types;\n  } metadata_snapshot;\n  struct Il2CppGCHandles\n  {\n    uint32_t tracked_object_count;\n    void ** pointers_to_objects;\n  } gc_handles;\n  struct Il2CppRuntimeInformation\n  {\n    uint32_t pointer_size;\n    uint32_t object_header_size;\n    uint32_t array_header_size;\n    uint32_t array_bounds_offset_in_header;\n    uint32_t array_size_offset_in_header;\n    uint32_t allocation_granularity;\n  } runtime_information;\n  void * additional_user_information;\n};\n\nstruct Il2CppMetadataType\n{\n  uint32_t flags;\n  void * fields;\n  uint32_t field_count;\n  uint32_t statics_size;\n  uint8_t * statics;\n  uint32_t base_or_element_type_index;\n  char * name;\n  const char * assembly_name;\n  uint64_t type_info_address;\n  uint32_t size;\n};\n\nuintptr_t\nil2cpp_memory_snapshot_get_classes (\n    const Il2CppManagedMemorySnapshot * snapshot, Il2CppMetadataType ** iter)\n{\n  const int zero = 0;\n  const void * null = 0;\n\n  if (iter != NULL && snapshot->metadata_snapshot.type_count > zero)\n  {\n    if (*iter == null)\n    {\n      *iter = snapshot->metadata_snapshot.types;\n      return (uintptr_t) (*iter)->type_info_address;\n    }\n    else\n    {\n      Il2CppMetadataType * metadata_type = *iter + 1;\n\n      if (metadata_type < snapshot->metadata_snapshot.types +\n                              snapshot->metadata_snapshot.type_count)\n      {\n        *iter = metadata_type;\n        return (uintptr_t) (*iter)->type_info_address;\n      }\n    }\n  }\n  return 0;\n}\n\nvoid **\nil2cpp_memory_snapshot_get_objects (\n    const Il2CppManagedMemorySnapshot * snapshot, uint32_t * size)\n{\n  *size = snapshot->gc_handles.tracked_object_count;\n  return snapshot->gc_handles.pointers_to_objects;\n}\n",
      ),
    lazy,
  );
  function _0x58dca3(_0x3be833, _0x569106, _0x5cd8fd) {
    var _0x22712e;
    var _0x7df1a7;
    const _0x4753e9 =
      ((_0x7df1a7 =
        (_0x22712e = Il2Cpp.$config.exports) === null || _0x22712e === undefined
          ? undefined
          : _0x22712e[_0x3be833]) === null || _0x7df1a7 === undefined
        ? undefined
        : _0x7df1a7.call(_0x22712e)) ??
      Il2Cpp.module.findExportByName(_0x3be833) ??
      Il2Cpp.memorySnapshotExports[_0x3be833];
    const _0x13aac1 = new NativeFunction(_0x4753e9 ?? NULL, _0x569106, _0x5cd8fd);
    if (_0x13aac1.isNull()) {
      return new Proxy(_0x13aac1, {
        get(_0x1d938e, _0x3c1553) {
          const _0x4b1a10 = _0x1d938e[_0x3c1553];
          if (typeof _0x4b1a10 === "function") {
            return _0x4b1a10.bind(_0x1d938e);
          } else {
            return _0x4b1a10;
          }
        },
        apply() {
          if (_0x4753e9 == null) {
            raise("couldn't resolve export " + _0x3be833);
          } else if (_0x4753e9.isNull()) {
            raise(
              "export " +
                _0x3be833 +
                " points to NULL IL2CPP library has likely been stripped, obfuscated, or customized",
            );
          }
        },
      });
    } else {
      return _0x13aac1;
    }
  }
})((Il2Cpp ||= {}));
var Il2Cpp;
(function (Il2Cpp) {
  function _0x32e9bb(_0x455372) {
    return (_0x363853) => {
      if (_0x363853 instanceof Il2Cpp.Class) {
        return _0x455372.isAssignableFrom(_0x363853);
      } else {
        return _0x455372.isAssignableFrom(_0x363853.class);
      }
    };
  }
  Il2Cpp.is = _0x32e9bb;
  function _0xbaa680(_0x1c04ab) {
    return (_0x3a3756) => {
      if (_0x3a3756 instanceof Il2Cpp.Class) {
        return _0x3a3756.equals(_0x1c04ab);
      } else {
        return _0x3a3756.class.equals(_0x1c04ab);
      }
    };
  }
  Il2Cpp.isExactly = _0xbaa680;
})((Il2Cpp ||= {}));
var Il2Cpp;
(function (Il2Cpp) {
  Il2Cpp.gc = {
    get heapSize() {
      return Il2Cpp.exports.gcGetHeapSize();
    },
    get isEnabled() {
      return !Il2Cpp.exports.gcIsDisabled();
    },
    get isIncremental() {
      return !!Il2Cpp.exports.gcIsIncremental();
    },
    get maxTimeSlice() {
      return Il2Cpp.exports.gcGetMaxTimeSlice();
    },
    get usedHeapSize() {
      return Il2Cpp.exports.gcGetUsedSize();
    },
    set isEnabled(_0x286c6e) {
      if (_0x286c6e) {
        Il2Cpp.exports.gcEnable();
      } else {
        Il2Cpp.exports.gcDisable();
      }
    },
    set maxTimeSlice(_0x38d156) {
      Il2Cpp.exports.gcSetMaxTimeSlice(_0x38d156);
    },
    choose(_0xfef55e) {
      const _0x4b2f01 = [];
      const _0x31b281 = (_0x4d970e, _0x17ca72) => {
        for (let _0x1b21c3 = 0; _0x1b21c3 < _0x17ca72; _0x1b21c3++) {
          _0x4b2f01.push(
            new Il2Cpp.Object(_0x4d970e.add(_0x1b21c3 * Process.pointerSize).readPointer()),
          );
        }
      };
      const _0x229ad5 = new NativeCallback(_0x31b281, "void", ["pointer", "int", "pointer"]);
      if (Il2Cpp.unityVersionIsBelow202120) {
        const _0x48018d = new NativeCallback(() => {}, "void", []);
        const _0x3b431d = Il2Cpp.exports.livenessCalculationBegin(
          _0xfef55e,
          0,
          _0x229ad5,
          NULL,
          _0x48018d,
          _0x48018d,
        );
        Il2Cpp.exports.livenessCalculationFromStatics(_0x3b431d);
        Il2Cpp.exports.livenessCalculationEnd(_0x3b431d);
      } else {
        const _0x2d2edb = (_0x3fdf3f, _0x3e257e) => {
          if (!_0x3fdf3f.isNull() && _0x3e257e.compare(0) == 0) {
            Il2Cpp.free(_0x3fdf3f);
            return NULL;
          } else {
            return Il2Cpp.alloc(_0x3e257e);
          }
        };
        const _0x11b3a8 = new NativeCallback(_0x2d2edb, "pointer", [
          "pointer",
          "size_t",
          "pointer",
        ]);
        this.stopWorld();
        const _0x35b7d4 = Il2Cpp.exports.livenessAllocateStruct(
          _0xfef55e,
          0,
          _0x229ad5,
          NULL,
          _0x11b3a8,
        );
        Il2Cpp.exports.livenessCalculationFromStatics(_0x35b7d4);
        Il2Cpp.exports.livenessFinalize(_0x35b7d4);
        this.startWorld();
        Il2Cpp.exports.livenessFreeStruct(_0x35b7d4);
      }
      return _0x4b2f01;
    },
    collect(_0x4f64cb) {
      Il2Cpp.exports.gcCollect(_0x4f64cb < 0 ? 0 : _0x4f64cb > 2 ? 2 : _0x4f64cb);
    },
    collectALittle() {
      Il2Cpp.exports.gcCollectALittle();
    },
    startWorld() {
      return Il2Cpp.exports.gcStartWorld();
    },
    startIncrementalCollection() {
      return Il2Cpp.exports.gcStartIncrementalCollection();
    },
    stopWorld() {
      return Il2Cpp.exports.gcStopWorld();
    },
  };
})((Il2Cpp ||= {}));
var Android;
(function (_0x24d3f2) {
  getter(
    _0x24d3f2,
    "apiLevel",
    () => {
      const _0x140a14 = _0x48bb58("ro.build.version.sdk");
      if (_0x140a14) {
        return parseInt(_0x140a14);
      } else {
        return null;
      }
    },
    lazy,
  );
  function _0x48bb58(_0x411a58) {
    var _0x309fdc;
    const _0x21f019 =
      (_0x309fdc = Process.findModuleByName("libc.so")) === null || _0x309fdc === undefined
        ? undefined
        : _0x309fdc.findExportByName("__system_property_get");
    if (_0x21f019) {
      const _0x44b30b = new NativeFunction(_0x21f019, "void", ["pointer", "pointer"]);
      const _0x333995 = Memory.alloc(92).writePointer(NULL);
      _0x44b30b(Memory.allocUtf8String(_0x411a58), _0x333995);
      return _0x333995.readCString() ?? undefined;
    }
  }
})((Android ||= {}));
function raise(_0x3d0182) {
  var _0x120e34;
  var _0x2af56;
  var _0x4b96a5;
  const _0x23d127 = new Error(_0x3d0182);
  _0x23d127.name = "Il2CppError";
  _0x23d127.stack =
    (_0x4b96a5 =
      (_0x2af56 =
        (_0x120e34 = _0x23d127.stack) === null || _0x120e34 === undefined
          ? undefined
          : _0x120e34.replace(/^(Il2Cpp)?Error/, "[0m[38;5;9mil2cpp[0m")) === null ||
      _0x2af56 === undefined
        ? undefined
        : _0x2af56.replace(/\n    at (.+) \((.+):(.+)\)/, "[3m[2m")) === null ||
    _0x4b96a5 === undefined
      ? undefined
      : _0x4b96a5.concat("[0m");
  throw _0x23d127;
}
function warn(_0x60ede5) {
  globalThis.console.log("[38;5;11mil2cpp[0m: " + _0x60ede5);
}
function ok(_0x29172d) {
  globalThis.console.log("[38;5;10mil2cpp[0m: " + _0x29172d);
}
function inform(_0x1c7917) {
  globalThis.console.log("[38;5;12mil2cpp[0m: " + _0x1c7917);
}
function decorate(_0x4d813c, _0x5b2251, _0x3ff1c2 = Object.getOwnPropertyDescriptors(_0x4d813c)) {
  for (const _0x469dd1 in _0x3ff1c2) {
    _0x3ff1c2[_0x469dd1] = _0x5b2251(_0x4d813c, _0x469dd1, _0x3ff1c2[_0x469dd1]);
  }
  Object.defineProperties(_0x4d813c, _0x3ff1c2);
  return _0x4d813c;
}
function getter(_0x15e13d, _0x1e993a, _0x3fcbe0, _0x1e421f) {
  globalThis.Object.defineProperty(
    _0x15e13d,
    _0x1e993a,
    (_0x1e421f === null || _0x1e421f === undefined
      ? undefined
      : _0x1e421f(_0x15e13d, _0x1e993a, {
          get: _0x3fcbe0,
          configurable: true,
        })) ?? {
      get: _0x3fcbe0,
      configurable: true,
    },
  );
}
function cyrb53(_0x20c8d9) {
  let _0x17aa40 = 3735928559;
  let _0x334b65 = 1103547991;
  for (let _0x2ba2c5 = 0, _0x1ca462; _0x2ba2c5 < _0x20c8d9.length; _0x2ba2c5++) {
    _0x1ca462 = _0x20c8d9.charCodeAt(_0x2ba2c5);
    _0x17aa40 = Math.imul(_0x17aa40 ^ _0x1ca462, 2654435761);
    _0x334b65 = Math.imul(_0x334b65 ^ _0x1ca462, 1597334677);
  }
  _0x17aa40 = Math.imul(_0x17aa40 ^ (_0x17aa40 >>> 16), 2246822507);
  _0x17aa40 ^= Math.imul(_0x334b65 ^ (_0x334b65 >>> 13), 3266489909);
  _0x334b65 = Math.imul(_0x334b65 ^ (_0x334b65 >>> 16), 2246822507);
  _0x334b65 ^= Math.imul(_0x17aa40 ^ (_0x17aa40 >>> 13), 3266489909);
  return (_0x334b65 & 2097151) * 4294967296 + (_0x17aa40 >>> 0);
}
function exportsHash(_0x450456) {
  return cyrb53(
    _0x450456
      .enumerateExports()
      .sort((_0x55d4e9, _0x36d7e1) => _0x55d4e9.name.localeCompare(_0x36d7e1.name))
      .map((_0x128903) => _0x128903.name + _0x128903.address.sub(_0x450456.base))
      .join(""),
  );
}
function lazy(_0x3b1658, _0x2c7db2, _0x3c3780) {
  const _0x5a5827 = _0x3c3780.get;
  if (!_0x5a5827) {
    throw new Error("@lazy can only be applied to getter accessors");
  }
  _0x3c3780.get = function () {
    const _0x2b3154 = _0x5a5827.call(this);
    Object.defineProperty(this, _0x2c7db2, {
      value: _0x2b3154,
      configurable: _0x3c3780.configurable,
      enumerable: _0x3c3780.enumerable,
      writable: false,
    });
    return _0x2b3154;
  };
  return _0x3c3780;
}
class NativeStruct {
  constructor(_0x35e8dc) {
    if (_0x35e8dc instanceof NativePointer) {
      this.handle = _0x35e8dc;
    } else {
      this.handle = _0x35e8dc.handle;
    }
  }
  equals(_0x26569e) {
    return this.handle.equals(_0x26569e.handle);
  }
  isNull() {
    return this.handle.isNull();
  }
  asNullable() {
    if (this.isNull()) {
      return null;
    } else {
      return this;
    }
  }
}
function addFlippedEntries(_0x5648c2) {
  return Object.keys(_0x5648c2).reduce((_0x342ba7, _0x2033bf) => {
    _0x342ba7[_0x342ba7[_0x2033bf]] = _0x2033bf;
    return _0x342ba7;
  }, _0x5648c2);
}
NativePointer.prototype.offsetOf = function (_0xadfee7, _0x4b14f3) {
  _0x4b14f3 ??= 512;
  for (
    let _0x1d21bb = 0;
    _0x4b14f3 > 0 ? _0x1d21bb < _0x4b14f3 : _0x1d21bb < -_0x4b14f3;
    _0x1d21bb++
  ) {
    if (_0xadfee7(_0x4b14f3 > 0 ? this.add(_0x1d21bb) : this.sub(_0x1d21bb))) {
      return _0x1d21bb;
    }
  }
  return null;
};
function readNativeIterator(_0x32bec0) {
  const _0x46a545 = [];
  const _0x13ecd6 = Memory.alloc(Process.pointerSize);
  let _0x1b92dc = _0x32bec0(_0x13ecd6);
  while (!_0x1b92dc.isNull()) {
    _0x46a545.push(_0x1b92dc);
    _0x1b92dc = _0x32bec0(_0x13ecd6);
  }
  return _0x46a545;
}
function readNativeList(_0x1d9d0d) {
  const _0x409bfb = Memory.alloc(Process.pointerSize);
  const _0x41454c = _0x1d9d0d(_0x409bfb);
  if (_0x41454c.isNull()) {
    return [];
  }
  const _0x96a29 = new Array(_0x409bfb.readInt());
  for (let _0x5e4ade = 0; _0x5e4ade < _0x96a29.length; _0x5e4ade++) {
    _0x96a29[_0x5e4ade] = _0x41454c.add(_0x5e4ade * Process.pointerSize).readPointer();
  }
  return _0x96a29;
}
function recycle(_0x35143a) {
  return new Proxy(_0x35143a, {
    cache: new Map(),
    construct(_0x2e8aea, _0x2f7682) {
      const _0x267351 = _0x2f7682[0].toUInt32();
      if (!this.cache.has(_0x267351)) {
        this.cache.set(_0x267351, new _0x2e8aea(_0x2f7682[0]));
      }
      return this.cache.get(_0x267351);
    },
  });
}
var UnityVersion;
(function (_0x19a999) {
  const _0x416c3c = /(6\d{3}|20\d{2}|\d)\.(\d)\.(\d{1,2})(?:[abcfp]|rc){0,2}\d?/;
  function _0x2604d1(_0x15c658) {
    return (
      _0x15c658 === null || _0x15c658 === undefined ? undefined : _0x15c658.match(_0x416c3c)
    )?.[0];
  }
  _0x19a999.find = _0x2604d1;
  function _0x14d022(_0xe9cf6e, _0x307cfa) {
    return _0x18c2ee(_0xe9cf6e, _0x307cfa) >= 0;
  }
  _0x19a999.gte = _0x14d022;
  function _0xf378d2(_0x228fd5, _0x2ca273) {
    return _0x18c2ee(_0x228fd5, _0x2ca273) < 0;
  }
  _0x19a999.lt = _0xf378d2;
  function _0x18c2ee(_0x221f9c, _0x31ed75) {
    const _0x8179fe = _0x221f9c.match(_0x416c3c);
    const _0x1f47f6 = _0x31ed75.match(_0x416c3c);
    for (let _0x120f98 = 1; _0x120f98 <= 3; _0x120f98++) {
      const _0x28e1b8 = Number(_0x8179fe?.[_0x120f98] ?? -1);
      const _0x3d20e1 = Number(_0x1f47f6?.[_0x120f98] ?? -1);
      if (_0x28e1b8 > _0x3d20e1) {
        return 1;
      } else if (_0x28e1b8 < _0x3d20e1) {
        return -1;
      }
    }
    return 0;
  }
})((UnityVersion ||= {}));
var Il2Cpp;
(function (Il2Cpp) {
  function _0x312796(_0x4a5977 = Process.pointerSize) {
    return Il2Cpp.exports.alloc(_0x4a5977);
  }
  Il2Cpp.alloc = _0x312796;
  function _0x503910(_0xba8360) {
    return Il2Cpp.exports.free(_0xba8360);
  }
  Il2Cpp.free = _0x503910;
  function _0x50cc6a(_0x1f8f7a, _0x3efc4a) {
    switch (_0x3efc4a.enumValue) {
      case Il2Cpp.Type.Enum.BOOLEAN:
        return !!_0x1f8f7a.readS8();
      case Il2Cpp.Type.Enum.BYTE:
        return _0x1f8f7a.readS8();
      case Il2Cpp.Type.Enum.UBYTE:
        return _0x1f8f7a.readU8();
      case Il2Cpp.Type.Enum.SHORT:
        return _0x1f8f7a.readS16();
      case Il2Cpp.Type.Enum.USHORT:
        return _0x1f8f7a.readU16();
      case Il2Cpp.Type.Enum.INT:
        return _0x1f8f7a.readS32();
      case Il2Cpp.Type.Enum.UINT:
        return _0x1f8f7a.readU32();
      case Il2Cpp.Type.Enum.CHAR:
        return _0x1f8f7a.readU16();
      case Il2Cpp.Type.Enum.LONG:
        return _0x1f8f7a.readS64();
      case Il2Cpp.Type.Enum.ULONG:
        return _0x1f8f7a.readU64();
      case Il2Cpp.Type.Enum.FLOAT:
        return _0x1f8f7a.readFloat();
      case Il2Cpp.Type.Enum.DOUBLE:
        return _0x1f8f7a.readDouble();
      case Il2Cpp.Type.Enum.NINT:
      case Il2Cpp.Type.Enum.NUINT:
        return _0x1f8f7a.readPointer();
      case Il2Cpp.Type.Enum.POINTER:
        return new Il2Cpp.Pointer(_0x1f8f7a.readPointer(), _0x3efc4a.class.baseType);
      case Il2Cpp.Type.Enum.VALUE_TYPE:
        return new Il2Cpp.ValueType(_0x1f8f7a, _0x3efc4a);
      case Il2Cpp.Type.Enum.OBJECT:
      case Il2Cpp.Type.Enum.CLASS:
        return new Il2Cpp.Object(_0x1f8f7a.readPointer());
      case Il2Cpp.Type.Enum.GENERIC_INSTANCE:
        if (_0x3efc4a.class.isValueType) {
          return new Il2Cpp.ValueType(_0x1f8f7a, _0x3efc4a);
        } else {
          return new Il2Cpp.Object(_0x1f8f7a.readPointer());
        }
      case Il2Cpp.Type.Enum.STRING:
        return new Il2Cpp.String(_0x1f8f7a.readPointer());
      case Il2Cpp.Type.Enum.ARRAY:
      case Il2Cpp.Type.Enum.NARRAY:
        return new Il2Cpp.Array(_0x1f8f7a.readPointer());
    }
    raise(
      "couldn't read the value from " +
        _0x1f8f7a +
        " using an unhandled or unknown type " +
        _0x3efc4a.name +
        " (" +
        _0x3efc4a.enumValue +
        "), please file an issue",
    );
  }
  Il2Cpp.read = _0x50cc6a;
  function _0x36d743(_0x24e9ee, _0x15e26c, _0x9c3020) {
    switch (_0x9c3020.enumValue) {
      case Il2Cpp.Type.Enum.BOOLEAN:
        return _0x24e9ee.writeS8(+_0x15e26c);
      case Il2Cpp.Type.Enum.BYTE:
        return _0x24e9ee.writeS8(_0x15e26c);
      case Il2Cpp.Type.Enum.UBYTE:
        return _0x24e9ee.writeU8(_0x15e26c);
      case Il2Cpp.Type.Enum.SHORT:
        return _0x24e9ee.writeS16(_0x15e26c);
      case Il2Cpp.Type.Enum.USHORT:
        return _0x24e9ee.writeU16(_0x15e26c);
      case Il2Cpp.Type.Enum.INT:
        return _0x24e9ee.writeS32(_0x15e26c);
      case Il2Cpp.Type.Enum.UINT:
        return _0x24e9ee.writeU32(_0x15e26c);
      case Il2Cpp.Type.Enum.CHAR:
        return _0x24e9ee.writeU16(_0x15e26c);
      case Il2Cpp.Type.Enum.LONG:
        return _0x24e9ee.writeS64(_0x15e26c);
      case Il2Cpp.Type.Enum.ULONG:
        return _0x24e9ee.writeU64(_0x15e26c);
      case Il2Cpp.Type.Enum.FLOAT:
        return _0x24e9ee.writeFloat(_0x15e26c);
      case Il2Cpp.Type.Enum.DOUBLE:
        return _0x24e9ee.writeDouble(_0x15e26c);
      case Il2Cpp.Type.Enum.NINT:
      case Il2Cpp.Type.Enum.NUINT:
      case Il2Cpp.Type.Enum.POINTER:
      case Il2Cpp.Type.Enum.STRING:
      case Il2Cpp.Type.Enum.ARRAY:
      case Il2Cpp.Type.Enum.NARRAY:
        return _0x24e9ee.writePointer(_0x15e26c);
      case Il2Cpp.Type.Enum.VALUE_TYPE:
        Memory.copy(_0x24e9ee, _0x15e26c, _0x9c3020.class.valueTypeSize);
        return _0x24e9ee;
      case Il2Cpp.Type.Enum.OBJECT:
      case Il2Cpp.Type.Enum.CLASS:
      case Il2Cpp.Type.Enum.GENERIC_INSTANCE:
        if (_0x15e26c instanceof Il2Cpp.ValueType) {
          Memory.copy(_0x24e9ee, _0x15e26c, _0x9c3020.class.valueTypeSize);
          return _0x24e9ee;
        } else {
          return _0x24e9ee.writePointer(_0x15e26c);
        }
    }
    raise(
      "couldn't write value " +
        _0x15e26c +
        " to " +
        _0x24e9ee +
        " using an unhandled or unknown type " +
        _0x9c3020.name +
        " (" +
        _0x9c3020.enumValue +
        "), please file an issue",
    );
  }
  Il2Cpp.write = _0x36d743;
  function _0x296d9f(_0x144907, _0x364e52) {
    if (globalThis.Array.isArray(_0x144907)) {
      const _0x77f653 = Memory.alloc(_0x364e52.class.valueTypeSize);
      const _0x345303 = _0x364e52.class.fields.filter((_0x299b65) => !_0x299b65.isStatic);
      for (let _0x346006 = 0; _0x346006 < _0x345303.length; _0x346006++) {
        const _0x3f7e5f = _0x296d9f(_0x144907[_0x346006], _0x345303[_0x346006].type);
        _0x36d743(
          _0x77f653.add(_0x345303[_0x346006].offset).sub(Il2Cpp.Object.headerSize),
          _0x3f7e5f,
          _0x345303[_0x346006].type,
        );
      }
      return new Il2Cpp.ValueType(_0x77f653, _0x364e52);
    } else if (_0x144907 instanceof NativePointer) {
      if (_0x364e52.isByReference) {
        return new Il2Cpp.Reference(_0x144907, _0x364e52);
      }
      switch (_0x364e52.enumValue) {
        case Il2Cpp.Type.Enum.POINTER:
          return new Il2Cpp.Pointer(_0x144907, _0x364e52.class.baseType);
        case Il2Cpp.Type.Enum.STRING:
          return new Il2Cpp.String(_0x144907);
        case Il2Cpp.Type.Enum.CLASS:
        case Il2Cpp.Type.Enum.GENERIC_INSTANCE:
        case Il2Cpp.Type.Enum.OBJECT:
          return new Il2Cpp.Object(_0x144907);
        case Il2Cpp.Type.Enum.ARRAY:
        case Il2Cpp.Type.Enum.NARRAY:
          return new Il2Cpp.Array(_0x144907);
        default:
          return _0x144907;
      }
    } else if (_0x364e52.enumValue == Il2Cpp.Type.Enum.BOOLEAN) {
      return !!_0x144907;
    } else if (_0x364e52.enumValue == Il2Cpp.Type.Enum.VALUE_TYPE && _0x364e52.class.isEnum) {
      return _0x296d9f([_0x144907], _0x364e52);
    } else {
      return _0x144907;
    }
  }
  Il2Cpp.fromFridaValue = _0x296d9f;
  function _0x1e3a8b(_0x1affca) {
    if (typeof _0x1affca == "boolean") {
      return +_0x1affca;
    } else if (_0x1affca instanceof Il2Cpp.ValueType) {
      if (_0x1affca.type.class.isEnum) {
        return _0x1affca.field("value__").value;
      } else {
        const _0x4deba8 = _0x1affca.type.class.fields
          .filter((_0x97735f) => !_0x97735f.isStatic)
          .map((_0x510d8e) => _0x1e3a8b(_0x510d8e.bind(_0x1affca).value));
        if (_0x4deba8.length == 0) {
          return [0];
        } else {
          return _0x4deba8;
        }
      }
    } else {
      return _0x1affca;
    }
  }
  Il2Cpp.toFridaValue = _0x1e3a8b;
})((Il2Cpp ||= {}));
var Il2Cpp;
(function (Il2Cpp) {
  getter(Il2Cpp, "module", () => {
    return _0x54ec97() ?? raise("Could not find IL2CPP module");
  });
  async function _0xe95963(_0x4e5966 = false) {
    const _0x5a9315 =
      _0x54ec97() ??
      (await new Promise((_0x54b232) => {
        const [_0x2b0c31, _0x46eae7] = _0x5a4ebb();
        const _0x3fc597 = setTimeout(() => {
          warn(
            "after 10 seconds, IL2CPP module '" +
              _0x2b0c31 +
              "' has not been loaded yet, is the app running?",
          );
        }, 10000);
        const _0x2f1d70 = Process.attachModuleObserver({
          onAdded(_0x1bd165) {
            if (_0x1bd165.name == _0x2b0c31 || (_0x46eae7 && _0x1bd165.name == _0x46eae7)) {
              clearTimeout(_0x3fc597);
              setImmediate(() => {
                _0x54b232(_0x1bd165);
                _0x2f1d70.detach();
              });
            }
          },
        });
      }));
    Reflect.defineProperty(Il2Cpp, "module", {
      value: _0x5a9315,
    });
    if (Il2Cpp.exports.getCorlib().isNull()) {
      return await new Promise((_0x9e81c3) => {
        const _0x531475 = Interceptor.attach(Il2Cpp.exports.initialize, {
          onLeave() {
            _0x531475.detach();
            if (_0x4e5966) {
              _0x9e81c3(true);
            } else {
              setImmediate(() => _0x9e81c3(false));
            }
          },
        });
      });
    }
    return false;
  }
  Il2Cpp.initialize = _0xe95963;
  function _0x54ec97() {
    const [_0x20907c, _0x488bb4] = _0x5a4ebb();
    return (
      Process.findModuleByName(_0x20907c) ??
      Process.findModuleByName(_0x488bb4 ?? _0x20907c) ??
      (Process.platform == "darwin"
        ? Process.findModuleByAddress(DebugSymbol.fromName("il2cpp_init").address)
        : undefined) ??
      undefined
    );
  }
  function _0x5a4ebb() {
    if (Il2Cpp.$config.moduleName) {
      return [Il2Cpp.$config.moduleName];
    }
    switch (Process.platform) {
      case "linux":
        return [Android.apiLevel ? "libil2cpp.so" : "GameAssembly.so"];
      case "windows":
        return ["GameAssembly.dll"];
      case "darwin":
        return ["UnityFramework", "GameAssembly.dylib"];
    }
    raise(Process.platform + " is not supported yet");
  }
})((Il2Cpp ||= {}));
var Il2Cpp;
(function (Il2Cpp) {
  async function _0x29021e(_0x59d969, _0x39829b = "bind") {
    let _0x1a1676 = null;
    try {
      const _0x26cd64 = await Il2Cpp.initialize(_0x39829b == "main");
      if (_0x39829b == "main" && !_0x26cd64) {
        if (Il2Cpp.currentThread == null) {
          _0x1a1676 = Il2Cpp.domain.attach();
        }
        const _0x54b6f2 = Il2Cpp.mainThread;
        if (_0x54b6f2 == null) {
          return await new Promise((_0xe9a696, _0x2610d0) => {
            let _0x1bccd4 = 0;
            const _0x40d185 = () => {
              const _0xeef2c2 = Il2Cpp.mainThread;
              if (_0xeef2c2 != null) {
                _0xe9a696(_0x29021e(() => _0xeef2c2.schedule(_0x59d969), "free"));
              } else if (++_0x1bccd4 < 2400) {
                setTimeout(_0x40d185, 50);
              } else {
                _0x2610d0(
                  new Error(
                    "IL2CPP main thread not available — launch with frida -f or attach earlier",
                  ),
                );
              }
            };
            _0x40d185();
          });
        }
        return _0x29021e(() => _0x54b6f2.schedule(_0x59d969), "free");
      }
      if (Il2Cpp.currentThread == null) {
        _0x1a1676 = Il2Cpp.domain.attach();
      }
      if (_0x39829b == "bind" && _0x1a1676 != null) {
        Script.bindWeak(globalThis, () =>
          _0x1a1676 === null || _0x1a1676 === undefined ? undefined : _0x1a1676.detach(),
        );
      }
      const _0x1cf83f = _0x59d969();
      if (_0x1cf83f instanceof Promise) {
        return await _0x1cf83f;
      } else {
        return _0x1cf83f;
      }
    } catch (_0xce0c7c) {
      Script.nextTick((_0x5700c3) => {
        throw _0x5700c3;
      }, _0xce0c7c);
      return Promise.reject(_0xce0c7c);
    } finally {
      if (_0x39829b == "free" && _0x1a1676 != null) {
        _0x1a1676.detach();
      }
    }
  }
  Il2Cpp.perform = _0x29021e;
})((Il2Cpp ||= {}));
var Il2Cpp;
(function (Il2Cpp) {
  var _0x51b2f9;
  var _0x53e328;
  var _0x168554;
  var _0x32b14a;
  var _0x563860;
  var _0x28ec38;
  var _0xc5c34b;
  var _0xe73206;
  var _0x36cc6b;
  var _0x41d3f4;
  var _0x9d0bea;
  var _0x1366e4;
  var _0x51c785;
  class _0x8b3587 {
    constructor(_0x138665) {
      _0x51b2f9.set(this, {
        depth: 0,
        buffer: [],
        history: new Set(),
        flush: () => {
          if (__classPrivateFieldGet(this, _0x51b2f9, "f").depth == 0) {
            const _0x3b8c5f =
              "\n" + __classPrivateFieldGet(this, _0x51b2f9, "f").buffer.join("\n") + "\n";
            if (__classPrivateFieldGet(this, _0x168554, "f")) {
              inform(_0x3b8c5f);
            } else {
              const _0x1801fa = cyrb53(_0x3b8c5f);
              if (!__classPrivateFieldGet(this, _0x51b2f9, "f").history.has(_0x1801fa)) {
                __classPrivateFieldGet(this, _0x51b2f9, "f").history.add(_0x1801fa);
                inform(_0x3b8c5f);
              }
            }
            __classPrivateFieldGet(this, _0x51b2f9, "f").buffer.length = 0;
          }
        },
      });
      _0x53e328.set(this, Il2Cpp.mainThread.id);
      _0x168554.set(this, false);
      _0x32b14a.set(this, undefined);
      _0x563860.set(this, []);
      _0x28ec38.set(this, undefined);
      _0xc5c34b.set(this, undefined);
      _0xe73206.set(this, undefined);
      _0x36cc6b.set(this, undefined);
      _0x41d3f4.set(this, undefined);
      _0x9d0bea.set(this, undefined);
      _0x1366e4.set(this, undefined);
      _0x51c785.set(this, undefined);
      __classPrivateFieldSet(this, _0x32b14a, _0x138665, "f");
    }
    thread(_0x552054) {
      __classPrivateFieldSet(this, _0x53e328, _0x552054.id, "f");
      return this;
    }
    verbose(_0xf67ed9) {
      __classPrivateFieldSet(this, _0x168554, _0xf67ed9, "f");
      return this;
    }
    domain() {
      __classPrivateFieldSet(this, _0x28ec38, Il2Cpp.domain, "f");
      return this;
    }
    assemblies(..._0x1fbe92) {
      __classPrivateFieldSet(this, _0xc5c34b, _0x1fbe92, "f");
      return this;
    }
    classes(..._0x2a25c5) {
      __classPrivateFieldSet(this, _0xe73206, _0x2a25c5, "f");
      return this;
    }
    methods(..._0x5a9aa9) {
      __classPrivateFieldSet(this, _0x36cc6b, _0x5a9aa9, "f");
      return this;
    }
    filterAssemblies(_0x1405c3) {
      __classPrivateFieldSet(this, _0x41d3f4, _0x1405c3, "f");
      return this;
    }
    filterClasses(_0x134eba) {
      __classPrivateFieldSet(this, _0x9d0bea, _0x134eba, "f");
      return this;
    }
    filterMethods(_0x4dcbc5) {
      __classPrivateFieldSet(this, _0x1366e4, _0x4dcbc5, "f");
      return this;
    }
    filterParameters(_0xab2d5c) {
      __classPrivateFieldSet(this, _0x51c785, _0xab2d5c, "f");
      return this;
    }
    and() {
      const _0x30920a = (_0x3cdd01) => {
        if (__classPrivateFieldGet(this, _0x51c785, "f") == undefined) {
          __classPrivateFieldGet(this, _0x563860, "f").push(_0x3cdd01);
          return;
        }
        for (const _0x4ceab5 of _0x3cdd01.parameters) {
          if (__classPrivateFieldGet(this, _0x51c785, "f").call(this, _0x4ceab5)) {
            __classPrivateFieldGet(this, _0x563860, "f").push(_0x3cdd01);
            break;
          }
        }
      };
      const _0x5d4e7c = (_0x38a2f5) => {
        for (const _0x57e333 of _0x38a2f5) {
          _0x30920a(_0x57e333);
        }
      };
      const _0x2be55d = (_0x510f74) => {
        if (__classPrivateFieldGet(this, _0x1366e4, "f") == undefined) {
          _0x5d4e7c(_0x510f74.methods);
          return;
        }
        for (const _0x26d9f7 of _0x510f74.methods) {
          if (__classPrivateFieldGet(this, _0x1366e4, "f").call(this, _0x26d9f7)) {
            _0x30920a(_0x26d9f7);
          }
        }
      };
      const _0x5ad5b8 = (_0x27e2f5) => {
        for (const _0x451767 of _0x27e2f5) {
          _0x2be55d(_0x451767);
        }
      };
      const _0x21d948 = (_0x107722) => {
        if (__classPrivateFieldGet(this, _0x9d0bea, "f") == undefined) {
          _0x5ad5b8(_0x107722.image.classes);
          return;
        }
        for (const _0xfbd5ca of _0x107722.image.classes) {
          if (__classPrivateFieldGet(this, _0x9d0bea, "f").call(this, _0xfbd5ca)) {
            _0x2be55d(_0xfbd5ca);
          }
        }
      };
      const _0x1720e2 = (_0x3e70f3) => {
        for (const _0x16f0b2 of _0x3e70f3) {
          _0x21d948(_0x16f0b2);
        }
      };
      const _0x32ccc2 = (_0x1c29f1) => {
        if (__classPrivateFieldGet(this, _0x41d3f4, "f") == undefined) {
          _0x1720e2(_0x1c29f1.assemblies);
          return;
        }
        for (const _0x395711 of _0x1c29f1.assemblies) {
          if (__classPrivateFieldGet(this, _0x41d3f4, "f").call(this, _0x395711)) {
            _0x21d948(_0x395711);
          }
        }
      };
      if (__classPrivateFieldGet(this, _0x36cc6b, "f")) {
        _0x5d4e7c(__classPrivateFieldGet(this, _0x36cc6b, "f"));
      } else if (__classPrivateFieldGet(this, _0xe73206, "f")) {
        _0x5ad5b8(__classPrivateFieldGet(this, _0xe73206, "f"));
      } else if (__classPrivateFieldGet(this, _0xc5c34b, "f")) {
        _0x1720e2(__classPrivateFieldGet(this, _0xc5c34b, "f"));
      } else if (__classPrivateFieldGet(this, _0x28ec38, "f")) {
        _0x32ccc2(__classPrivateFieldGet(this, _0x28ec38, "f"));
      } else {
        undefined;
      }
      __classPrivateFieldSet(this, _0xc5c34b, undefined, "f");
      __classPrivateFieldSet(this, _0xe73206, undefined, "f");
      __classPrivateFieldSet(this, _0x36cc6b, undefined, "f");
      __classPrivateFieldSet(this, _0x41d3f4, undefined, "f");
      __classPrivateFieldSet(this, _0x9d0bea, undefined, "f");
      __classPrivateFieldSet(this, _0x1366e4, undefined, "f");
      __classPrivateFieldSet(this, _0x51c785, undefined, "f");
      return this;
    }
    attach() {
      var _0x23f3a4;
      for (const _0x51f860 of __classPrivateFieldGet(this, _0x563860, "f")) {
        if (!_0x51f860.virtualAddress.isNull()) {
          try {
            __classPrivateFieldGet(this, _0x32b14a, "f").call(
              this,
              _0x51f860,
              __classPrivateFieldGet(this, _0x51b2f9, "f"),
              __classPrivateFieldGet(this, _0x53e328, "f"),
            );
          } catch (_0x277566) {
            switch (_0x277566.message) {
              case (_0x23f3a4 = /unable to intercept function at \w+; please file a bug/.exec(
                _0x277566.message,
              )) === null || _0x23f3a4 === undefined
                ? undefined
                : _0x23f3a4.input:
              case "already replaced this function":
                break;
              default:
                throw _0x277566;
            }
          }
        }
      }
    }
  }
  _0x51b2f9 = new WeakMap();
  _0x53e328 = new WeakMap();
  _0x168554 = new WeakMap();
  _0x32b14a = new WeakMap();
  _0x563860 = new WeakMap();
  _0x28ec38 = new WeakMap();
  _0xc5c34b = new WeakMap();
  _0xe73206 = new WeakMap();
  _0x36cc6b = new WeakMap();
  _0x41d3f4 = new WeakMap();
  _0x9d0bea = new WeakMap();
  _0x1366e4 = new WeakMap();
  _0x51c785 = new WeakMap();
  Il2Cpp.Tracer = _0x8b3587;
  function _0x20ec24(_0x2a8816 = false) {
    const _0x387a95 = () => (_0x21d2ae, _0x5c38f3, _0x38c637) => {
      const _0x13fc2b = _0x21d2ae.relativeVirtualAddress.toString(16).padStart(8, "0");
      Interceptor.attach(_0x21d2ae.virtualAddress, {
        onEnter() {
          if (this.threadId == _0x38c637) {
            _0x5c38f3.buffer.push(
              "[2m0x" +
                _0x13fc2b +
                "[0m " +
                "│ ".repeat(_0x5c38f3.depth++) +
                "┌─[35m" +
                _0x21d2ae.class.type.name +
                "::[1m" +
                _0x21d2ae.name +
                "[0m[0m",
            );
          }
        },
        onLeave() {
          if (this.threadId == _0x38c637) {
            _0x5c38f3.buffer.push(
              "[2m0x" +
                _0x13fc2b +
                "[0m " +
                "│ ".repeat(--_0x5c38f3.depth) +
                "└─[33m" +
                _0x21d2ae.class.type.name +
                "::[1m" +
                _0x21d2ae.name +
                "[0m[0m",
            );
            _0x5c38f3.flush();
          }
        },
      });
    };
    const _0x28cc04 = () => (_0x31c4f0, _0xe6a181, _0x5d11cd) => {
      const _0xcaf8d7 = _0x31c4f0.relativeVirtualAddress.toString(16).padStart(8, "0");
      const _0x35a89a = +!_0x31c4f0.isStatic | +Il2Cpp.unityVersionIsBelow201830;
      const _0x39c46b = function (..._0x4bcfef) {
        if (this.threadId == _0x5d11cd) {
          const _0x7c80c = _0x31c4f0.isStatic
            ? undefined
            : new Il2Cpp.Parameter("this", -1, _0x31c4f0.class.type);
          const _0x6156e5 = _0x7c80c
            ? [_0x7c80c].concat(_0x31c4f0.parameters)
            : _0x31c4f0.parameters;
          _0xe6a181.buffer.push(
            "[2m0x" +
              _0xcaf8d7 +
              "[0m " +
              "│ ".repeat(_0xe6a181.depth++) +
              "┌─[35m" +
              _0x31c4f0.class.type.name +
              "::[1m" +
              _0x31c4f0.name +
              "[0m[0m(" +
              _0x6156e5
                .map(
                  (_0x4f599e) =>
                    "[32m" +
                    _0x4f599e.name +
                    "[0m = [31m" +
                    Il2Cpp.fromFridaValue(
                      _0x4bcfef[_0x4f599e.position + _0x35a89a],
                      _0x4f599e.type,
                    ) +
                    "[0m",
                )
                .join(", ") +
              ")",
          );
        }
        const _0x26e114 = _0x31c4f0.nativeFunction(..._0x4bcfef);
        if (this.threadId == _0x5d11cd) {
          _0xe6a181.buffer.push(
            "[2m0x" +
              _0xcaf8d7 +
              "[0m " +
              "│ ".repeat(--_0xe6a181.depth) +
              "└─[33m" +
              _0x31c4f0.class.type.name +
              "::[1m" +
              _0x31c4f0.name +
              "[0m[0m" +
              (_0x26e114 == undefined
                ? ""
                : " = [36m" + Il2Cpp.fromFridaValue(_0x26e114, _0x31c4f0.returnType)) +
              "[0m",
          );
          _0xe6a181.flush();
        }
        return _0x26e114;
      };
      _0x31c4f0.revert();
      const _0x5beb21 = new NativeCallback(
        _0x39c46b,
        _0x31c4f0.returnType.fridaAlias,
        _0x31c4f0.fridaSignature,
      );
      Interceptor.replace(_0x31c4f0.virtualAddress, _0x5beb21);
    };
    return new Il2Cpp.Tracer(_0x2a8816 ? _0x28cc04() : _0x387a95());
  }
  Il2Cpp.trace = _0x20ec24;
  function _0x3b23ed(_0x516af6) {
    const _0x5c947c = Il2Cpp.domain.assemblies
      .flatMap((_0x42d164) =>
        _0x42d164.image.classes.flatMap((_0x416a0a) =>
          _0x416a0a.methods.filter((_0x124878) => !_0x124878.virtualAddress.isNull()),
        ),
      )
      .sort((_0x4f9ae7, _0x45a391) => _0x4f9ae7.virtualAddress.compare(_0x45a391.virtualAddress));
    const _0x4e0264 = (_0x40b4e2) => {
      let _0x14e530 = 0;
      let _0x2e0a44 = _0x5c947c.length - 1;
      while (_0x14e530 <= _0x2e0a44) {
        const _0x33db80 = Math.floor((_0x14e530 + _0x2e0a44) / 2);
        const _0x4d2052 = _0x5c947c[_0x33db80].virtualAddress.compare(_0x40b4e2);
        if (_0x4d2052 == 0) {
          return _0x5c947c[_0x33db80];
        } else if (_0x4d2052 > 0) {
          _0x2e0a44 = _0x33db80 - 1;
        } else {
          _0x14e530 = _0x33db80 + 1;
        }
      }
      return _0x5c947c[_0x2e0a44];
    };
    const _0x1f8198 = () => (_0x1bfa24, _0x2f4b5e, _0x1eb7d7) => {
      Interceptor.attach(_0x1bfa24.virtualAddress, function () {
        if (this.threadId == _0x1eb7d7) {
          const _0x500e47 = globalThis.Thread.backtrace(this.context, _0x516af6);
          _0x500e47.unshift(_0x1bfa24.virtualAddress);
          for (const _0x2bdce1 of _0x500e47) {
            if (
              _0x2bdce1.compare(Il2Cpp.module.base) > 0 &&
              _0x2bdce1.compare(Il2Cpp.module.base.add(Il2Cpp.module.size)) < 0
            ) {
              const _0x2ba423 = _0x4e0264(_0x2bdce1);
              if (_0x2ba423) {
                const _0x17e017 = _0x2bdce1.sub(_0x2ba423.virtualAddress);
                if (_0x17e017.compare(4095) < 0) {
                  _0x2f4b5e.buffer.push(
                    "[2m0x" +
                      _0x2ba423.relativeVirtualAddress.toString(16).padStart(8, "0") +
                      "[0m[2m+0x" +
                      _0x17e017.toString(16).padStart(3, "0") +
                      "[0m " +
                      _0x2ba423.class.type.name +
                      "::[1m" +
                      _0x2ba423.name +
                      "[0m",
                  );
                }
              }
            }
          }
          _0x2f4b5e.flush();
        }
      });
    };
    return new Il2Cpp.Tracer(_0x1f8198());
  }
  Il2Cpp.backtrace = _0x3b23ed;
})((Il2Cpp ||= {}));
var Il2Cpp;
(function (Il2Cpp) {
  class _0x4c1b9e extends NativeStruct {
    static get headerSize() {
      return Il2Cpp.corlib.class("System.Array").instanceSize;
    }
    get elements() {
      const _0x37df50 = Il2Cpp.string("v").object.method("ToCharArray", 0).invoke();
      const _0x573f2c =
        _0x37df50.handle.offsetOf((_0x37a037) => _0x37a037.readS16() == 118) ??
        raise("couldn't find the elements offset in the native array struct");
      getter(
        Il2Cpp.Array.prototype,
        "elements",
        function () {
          return new Il2Cpp.Pointer(this.handle.add(_0x573f2c), this.elementType);
        },
        lazy,
      );
      return this.elements;
    }
    get elementSize() {
      return this.elementType.class.arrayElementSize;
    }
    get elementType() {
      return this.object.class.type.class.baseType;
    }
    get length() {
      return Il2Cpp.exports.arrayGetLength(this);
    }
    get object() {
      return new Il2Cpp.Object(this);
    }
    get(_0xc0863) {
      if (_0xc0863 < 0 || _0xc0863 >= this.length) {
        raise("cannot get element at index " + _0xc0863 + " as the array length is " + this.length);
      }
      return this.elements.get(_0xc0863);
    }
    set(_0x35b838, _0x49456f) {
      if (_0x35b838 < 0 || _0x35b838 >= this.length) {
        raise(
          "cannot set element at index " + _0x35b838 + " as the array length is " + this.length,
        );
      }
      this.elements.set(_0x35b838, _0x49456f);
    }
    toString() {
      if (this.isNull()) {
        return "null";
      } else {
        return "[" + this.elements.read(this.length, 0) + "]";
      }
    }
    *[Symbol.iterator]() {
      for (let _0x50e225 = 0; _0x50e225 < this.length; _0x50e225++) {
        yield this.elements.get(_0x50e225);
      }
    }
  }
  __decorate([lazy], _0x4c1b9e.prototype, "elementSize", null);
  __decorate([lazy], _0x4c1b9e.prototype, "elementType", null);
  __decorate([lazy], _0x4c1b9e.prototype, "length", null);
  __decorate([lazy], _0x4c1b9e.prototype, "object", null);
  __decorate([lazy], _0x4c1b9e, "headerSize", null);
  Il2Cpp.Array = _0x4c1b9e;
  function _0x4c6fe5(_0xdd785e, _0x41c033) {
    const _0x2d84de = typeof _0x41c033 == "number" ? _0x41c033 : _0x41c033.length;
    const _0x558d2f = new Il2Cpp.Array(Il2Cpp.exports.arrayNew(_0xdd785e, _0x2d84de));
    if (globalThis.Array.isArray(_0x41c033)) {
      _0x558d2f.elements.write(_0x41c033);
    }
    return _0x558d2f;
  }
  Il2Cpp.array = _0x4c6fe5;
})((Il2Cpp ||= {}));
var Il2Cpp;
(function (Il2Cpp) {
  let _0x3a6e5f = class _0x338925 extends NativeStruct {
    get image() {
      var _0x12f059;
      var _0x5134a0;
      var _0x1e05f2;
      var _0x3d5d41;
      var _0x4905f6;
      var _0x41e24f;
      if (Il2Cpp.exports.assemblyGetImage.isNull()) {
        const _0x3c7a7f =
          ((_0x3d5d41 =
            (_0x1e05f2 =
              (_0x5134a0 =
                (_0x12f059 = this.object.tryMethod("GetType", 1)) === null ||
                _0x12f059 === undefined
                  ? undefined
                  : _0x12f059.invoke(Il2Cpp.string("<Module>"))) === null || _0x5134a0 === undefined
                ? undefined
                : _0x5134a0.asNullable()) === null || _0x1e05f2 === undefined
              ? undefined
              : _0x1e05f2.tryMethod("get_Module")) === null || _0x3d5d41 === undefined
            ? undefined
            : _0x3d5d41.invoke()) ??
          ((_0x41e24f =
            (_0x4905f6 = this.object.tryMethod("GetModules", 1)) === null || _0x4905f6 === undefined
              ? undefined
              : _0x4905f6.invoke(false)) === null || _0x41e24f === undefined
            ? undefined
            : _0x41e24f.get(0)) ??
          raise("couldn't find the runtime module object of assembly " + this.name);
        return new Il2Cpp.Image(_0x3c7a7f.field("_impl").value);
      }
      return new Il2Cpp.Image(Il2Cpp.exports.assemblyGetImage(this));
    }
    get name() {
      return this.image.name.replace(".dll", "");
    }
    get object() {
      for (const _0x45a4a4 of Il2Cpp.domain.object.method("GetAssemblies", 1).invoke(false)) {
        if (_0x45a4a4.field("_mono_assembly").value.equals(this)) {
          return _0x45a4a4;
        }
      }
      raise("couldn't find the object of the native assembly struct");
    }
  };
  __decorate([lazy], _0x3a6e5f.prototype, "name", null);
  __decorate([lazy], _0x3a6e5f.prototype, "object", null);
  _0x3a6e5f = __decorate([recycle], _0x3a6e5f);
  Il2Cpp.Assembly = _0x3a6e5f;
})((Il2Cpp ||= {}));
var Il2Cpp;
(function (Il2Cpp) {
  let _0x15b1c5 = class _0x557fe2 extends NativeStruct {
    get actualInstanceSize() {
      const _0x78b2d2 = Il2Cpp.corlib.class("System.String");
      const _0x4addf3 =
        _0x78b2d2.handle.offsetOf(
          (_0x4bd14a) => _0x4bd14a.readInt() == _0x78b2d2.instanceSize - 2,
        ) ?? raise("couldn't find the actual instance size offset in the native class struct");
      getter(
        Il2Cpp.Class.prototype,
        "actualInstanceSize",
        function () {
          return this.handle.add(_0x4addf3).readS32();
        },
        lazy,
      );
      return this.actualInstanceSize;
    }
    get arrayClass() {
      return new Il2Cpp.Class(Il2Cpp.exports.classGetArrayClass(this, 1));
    }
    get arrayElementSize() {
      return Il2Cpp.exports.classGetArrayElementSize(this);
    }
    get assemblyName() {
      return Il2Cpp.exports.classGetAssemblyName(this).readUtf8String().replace(".dll", "");
    }
    get declaringClass() {
      return new Il2Cpp.Class(Il2Cpp.exports.classGetDeclaringType(this)).asNullable();
    }
    get baseType() {
      return new Il2Cpp.Type(Il2Cpp.exports.classGetBaseType(this)).asNullable();
    }
    get elementClass() {
      return new Il2Cpp.Class(Il2Cpp.exports.classGetElementClass(this)).asNullable();
    }
    get fields() {
      return readNativeIterator((_0x387786) => Il2Cpp.exports.classGetFields(this, _0x387786)).map(
        (_0x1870b8) => new Il2Cpp.Field(_0x1870b8),
      );
    }
    get flags() {
      return Il2Cpp.exports.classGetFlags(this);
    }
    get fullName() {
      if (this.namespace) {
        return this.namespace + "." + this.name;
      } else {
        return this.name;
      }
    }
    get genericClass() {
      var _0x36b8c4;
      const _0x503165 =
        (_0x36b8c4 = this.image.tryClass(this.fullName)) === null || _0x36b8c4 === undefined
          ? undefined
          : _0x36b8c4.asNullable();
      if (_0x503165 === null || _0x503165 === undefined ? undefined : _0x503165.equals(this)) {
        return null;
      } else {
        return _0x503165 ?? null;
      }
    }
    get generics() {
      if (!this.isGeneric && !this.isInflated) {
        return [];
      }
      const _0x2d5209 = this.type.object.method("GetGenericArguments").invoke();
      return globalThis.Array.from(_0x2d5209).map(
        (_0x35d8bd) => new Il2Cpp.Class(Il2Cpp.exports.classFromObject(_0x35d8bd)),
      );
    }
    get hasReferences() {
      return !!Il2Cpp.exports.classHasReferences(this);
    }
    get hasStaticConstructor() {
      const _0x23dfdf = this.tryMethod(".cctor");
      return _0x23dfdf != null && !_0x23dfdf.virtualAddress.isNull();
    }
    get image() {
      return new Il2Cpp.Image(Il2Cpp.exports.classGetImage(this));
    }
    get instanceSize() {
      return Il2Cpp.exports.classGetInstanceSize(this);
    }
    get isAbstract() {
      return !!Il2Cpp.exports.classIsAbstract(this);
    }
    get isBlittable() {
      return !!Il2Cpp.exports.classIsBlittable(this);
    }
    get isEnum() {
      return !!Il2Cpp.exports.classIsEnum(this);
    }
    get isGeneric() {
      return !!Il2Cpp.exports.classIsGeneric(this);
    }
    get isInflated() {
      return !!Il2Cpp.exports.classIsInflated(this);
    }
    get isInterface() {
      return !!Il2Cpp.exports.classIsInterface(this);
    }
    get isStruct() {
      return this.isValueType && !this.isEnum;
    }
    get isValueType() {
      return !!Il2Cpp.exports.classIsValueType(this);
    }
    get interfaces() {
      return readNativeIterator((_0x550b78) =>
        Il2Cpp.exports.classGetInterfaces(this, _0x550b78),
      ).map((_0x28eee5) => new Il2Cpp.Class(_0x28eee5));
    }
    get methods() {
      return readNativeIterator((_0x10dc33) => Il2Cpp.exports.classGetMethods(this, _0x10dc33)).map(
        (_0x7c72ea) => new Il2Cpp.Method(_0x7c72ea),
      );
    }
    get name() {
      return Il2Cpp.exports.classGetName(this).readUtf8String();
    }
    get namespace() {
      return Il2Cpp.exports.classGetNamespace(this).readUtf8String() || undefined;
    }
    get nestedClasses() {
      return readNativeIterator((_0xf1fd1f) =>
        Il2Cpp.exports.classGetNestedClasses(this, _0xf1fd1f),
      ).map((_0x4ce07a) => new Il2Cpp.Class(_0x4ce07a));
    }
    get parent() {
      return new Il2Cpp.Class(Il2Cpp.exports.classGetParent(this)).asNullable();
    }
    get pointerClass() {
      return new Il2Cpp.Class(
        Il2Cpp.exports.classFromObject(this.type.object.method("MakePointerType").invoke()),
      );
    }
    get rank() {
      let _0x552302 = 0;
      const _0x387fb6 = this.name;
      for (let _0x48d4c8 = this.name.length - 1; _0x48d4c8 > 0; _0x48d4c8--) {
        const _0x3d14de = _0x387fb6[_0x48d4c8];
        if (_0x3d14de == "]") {
          _0x552302++;
        } else if (_0x3d14de == "[" || _0x552302 == 0) {
          break;
        } else if (_0x3d14de == ",") {
          _0x552302++;
        } else {
          break;
        }
      }
      return _0x552302;
    }
    get staticFieldsData() {
      return Il2Cpp.exports.classGetStaticFieldData(this);
    }
    get valueTypeSize() {
      return Il2Cpp.exports.classGetValueTypeSize(this, NULL);
    }
    get type() {
      return new Il2Cpp.Type(Il2Cpp.exports.classGetType(this));
    }
    alloc() {
      return new Il2Cpp.Object(Il2Cpp.exports.objectNew(this));
    }
    field(_0x3344ea) {
      return (
        this.tryField(_0x3344ea) ??
        raise("couldn't find field " + _0x3344ea + " in class " + this.type.name)
      );
    }
    *hierarchy(_0x1f167a) {
      let _0x22ff2c = (_0x1f167a?.includeCurrent ?? true) ? this : this.parent;
      while (_0x22ff2c) {
        yield _0x22ff2c;
        _0x22ff2c = _0x22ff2c.parent;
      }
    }
    inflate(..._0x2edb63) {
      if (!this.isGeneric) {
        raise("cannot inflate class " + this.type.name + " as it has no generic parameters");
      }
      if (this.generics.length != _0x2edb63.length) {
        raise(
          "cannot inflate class " +
            this.type.name +
            " as it needs " +
            this.generics.length +
            " generic parameter(s), not " +
            _0x2edb63.length,
        );
      }
      const _0x1bbfcc = _0x2edb63.map((_0xa95976) => _0xa95976.type.object);
      const _0x995e01 = Il2Cpp.array(Il2Cpp.corlib.class("System.Type"), _0x1bbfcc);
      const _0x5749e3 = this.type.object.method("MakeGenericType", 1).invoke(_0x995e01);
      return new Il2Cpp.Class(Il2Cpp.exports.classFromObject(_0x5749e3));
    }
    initialize() {
      Il2Cpp.exports.classInitialize(this);
      return this;
    }
    isAssignableFrom(_0x401e51) {
      return !!Il2Cpp.exports.classIsAssignableFrom(this, _0x401e51);
    }
    isSubclassOf(_0x5586f7, _0x4a1b11) {
      return !!Il2Cpp.exports.classIsSubclassOf(this, _0x5586f7, +_0x4a1b11);
    }
    method(_0x2af5ff, _0x113457 = -1) {
      return (
        this.tryMethod(_0x2af5ff, _0x113457) ??
        raise("couldn't find method " + _0x2af5ff + " in class " + this.type.name)
      );
    }
    nested(_0x26da25) {
      return (
        this.tryNested(_0x26da25) ??
        raise("couldn't find nested class " + _0x26da25 + " in class " + this.type.name)
      );
    }
    new() {
      const _0x55ed39 = this.alloc();
      const _0x207cd7 = Memory.alloc(Process.pointerSize);
      Il2Cpp.exports.objectInitialize(_0x55ed39, _0x207cd7);
      const _0x40122f = _0x207cd7.readPointer();
      if (!_0x40122f.isNull()) {
        raise(new Il2Cpp.Object(_0x40122f).toString());
      }
      return _0x55ed39;
    }
    tryField(_0xbaf92a) {
      return new Il2Cpp.Field(
        Il2Cpp.exports.classGetFieldFromName(this, Memory.allocUtf8String(_0xbaf92a)),
      ).asNullable();
    }
    tryMethod(_0x3bc799, _0x17a05c = -1) {
      return new Il2Cpp.Method(
        Il2Cpp.exports.classGetMethodFromName(this, Memory.allocUtf8String(_0x3bc799), _0x17a05c),
      ).asNullable();
    }
    tryNested(_0x253c0e) {
      return this.nestedClasses.find((_0x34e015) => _0x34e015.name == _0x253c0e);
    }
    toString() {
      const _0x3a900b = [this.parent].concat(this.interfaces);
      return (
        "// " +
        this.assemblyName +
        "\n" +
        (this.isEnum
          ? "enum"
          : this.isStruct
            ? "struct"
            : this.isInterface
              ? "interface"
              : "class") +
        " " +
        this.type.name +
        (_0x3a900b
          ? " : " +
            _0x3a900b
              .map((_0x1d54b5) =>
                _0x1d54b5 === null || _0x1d54b5 === undefined ? undefined : _0x1d54b5.type.name,
              )
              .join(", ")
          : "") +
        "\n{\n    " +
        this.fields.join("\n    ") +
        "\n    " +
        this.methods.join("\n    ") +
        "\n}"
      );
    }
    static enumerate(_0x5ef8a7) {
      const _0x220422 = new NativeCallback(
        (_0x5cf732) => _0x5ef8a7(new Il2Cpp.Class(_0x5cf732)),
        "void",
        ["pointer", "pointer"],
      );
      return Il2Cpp.exports.classForEach(_0x220422, NULL);
    }
  };
  __decorate([lazy], _0x15b1c5.prototype, "arrayClass", null);
  __decorate([lazy], _0x15b1c5.prototype, "arrayElementSize", null);
  __decorate([lazy], _0x15b1c5.prototype, "assemblyName", null);
  __decorate([lazy], _0x15b1c5.prototype, "declaringClass", null);
  __decorate([lazy], _0x15b1c5.prototype, "baseType", null);
  __decorate([lazy], _0x15b1c5.prototype, "elementClass", null);
  __decorate([lazy], _0x15b1c5.prototype, "fields", null);
  __decorate([lazy], _0x15b1c5.prototype, "flags", null);
  __decorate([lazy], _0x15b1c5.prototype, "fullName", null);
  __decorate([lazy], _0x15b1c5.prototype, "generics", null);
  __decorate([lazy], _0x15b1c5.prototype, "hasReferences", null);
  __decorate([lazy], _0x15b1c5.prototype, "hasStaticConstructor", null);
  __decorate([lazy], _0x15b1c5.prototype, "image", null);
  __decorate([lazy], _0x15b1c5.prototype, "instanceSize", null);
  __decorate([lazy], _0x15b1c5.prototype, "isAbstract", null);
  __decorate([lazy], _0x15b1c5.prototype, "isBlittable", null);
  __decorate([lazy], _0x15b1c5.prototype, "isEnum", null);
  __decorate([lazy], _0x15b1c5.prototype, "isGeneric", null);
  __decorate([lazy], _0x15b1c5.prototype, "isInflated", null);
  __decorate([lazy], _0x15b1c5.prototype, "isInterface", null);
  __decorate([lazy], _0x15b1c5.prototype, "isValueType", null);
  __decorate([lazy], _0x15b1c5.prototype, "interfaces", null);
  __decorate([lazy], _0x15b1c5.prototype, "methods", null);
  __decorate([lazy], _0x15b1c5.prototype, "name", null);
  __decorate([lazy], _0x15b1c5.prototype, "namespace", null);
  __decorate([lazy], _0x15b1c5.prototype, "nestedClasses", null);
  __decorate([lazy], _0x15b1c5.prototype, "parent", null);
  __decorate([lazy], _0x15b1c5.prototype, "pointerClass", null);
  __decorate([lazy], _0x15b1c5.prototype, "rank", null);
  __decorate([lazy], _0x15b1c5.prototype, "staticFieldsData", null);
  __decorate([lazy], _0x15b1c5.prototype, "valueTypeSize", null);
  __decorate([lazy], _0x15b1c5.prototype, "type", null);
  _0x15b1c5 = __decorate([recycle], _0x15b1c5);
  Il2Cpp.Class = _0x15b1c5;
})((Il2Cpp ||= {}));
var Il2Cpp;
(function (Il2Cpp) {
  function _0x311766(_0x489d1d, _0x132330) {
    const _0x543c18 = Il2Cpp.corlib.class("System.Delegate");
    const _0x362fdb = Il2Cpp.corlib.class("System.MulticastDelegate");
    if (!_0x543c18.isAssignableFrom(_0x489d1d)) {
      raise(
        "cannot create a delegate for " + _0x489d1d.type.name + " as it's a non-delegate class",
      );
    }
    if (_0x489d1d.equals(_0x543c18) || _0x489d1d.equals(_0x362fdb)) {
      raise(
        "cannot create a delegate for neither " +
          _0x543c18.type.name +
          " nor " +
          _0x362fdb.type.name +
          ", use a subclass instead",
      );
    }
    const _0x17d8c9 = _0x489d1d.alloc();
    const _0x121a19 = _0x17d8c9.handle.toString();
    const _0x1e4de0 =
      _0x17d8c9.tryMethod("Invoke") ??
      raise("cannot create a delegate for " + _0x489d1d.type.name + ", there is no Invoke method");
    _0x17d8c9.method(".ctor").invoke(_0x17d8c9, _0x1e4de0.handle);
    const _0x4f769e = _0x1e4de0.wrap(_0x132330);
    _0x17d8c9.field("method_ptr").value = _0x4f769e;
    _0x17d8c9.field("invoke_impl").value = _0x4f769e;
    Il2Cpp._callbacksToKeepAlive[_0x121a19] = _0x4f769e;
    return _0x17d8c9;
  }
  Il2Cpp.delegate = _0x311766;
  Il2Cpp._callbacksToKeepAlive = {};
})((Il2Cpp ||= {}));
var Il2Cpp;
(function (Il2Cpp) {
  let _0x34269d = class _0x4cb832 extends NativeStruct {
    get assemblies() {
      let _0x484e62 = readNativeList((_0x44af52) =>
        Il2Cpp.exports.domainGetAssemblies(this, _0x44af52),
      );
      if (_0x484e62.length == 0) {
        const _0x290cf3 = this.object.method("GetAssemblies").overload().invoke();
        _0x484e62 = globalThis.Array.from(_0x290cf3).map(
          (_0x18bf06) => _0x18bf06.field("_mono_assembly").value,
        );
      }
      return _0x484e62.map((_0x4bf7a2) => new Il2Cpp.Assembly(_0x4bf7a2));
    }
    get object() {
      return Il2Cpp.corlib.class("System.AppDomain").method("get_CurrentDomain").invoke();
    }
    assembly(_0x1553e0) {
      return this.tryAssembly(_0x1553e0) ?? raise("couldn't find assembly " + _0x1553e0);
    }
    attach() {
      return new Il2Cpp.Thread(Il2Cpp.exports.threadAttach(this));
    }
    tryAssembly(_0x1e1d8c) {
      return new Il2Cpp.Assembly(
        Il2Cpp.exports.domainGetAssemblyFromName(this, Memory.allocUtf8String(_0x1e1d8c)),
      ).asNullable();
    }
  };
  __decorate([lazy], _0x34269d.prototype, "assemblies", null);
  __decorate([lazy], _0x34269d.prototype, "object", null);
  _0x34269d = __decorate([recycle], _0x34269d);
  Il2Cpp.Domain = _0x34269d;
  getter(
    Il2Cpp,
    "domain",
    () => {
      return new Il2Cpp.Domain(Il2Cpp.exports.domainGet());
    },
    lazy,
  );
})((Il2Cpp ||= {}));
var Il2Cpp;
(function (Il2Cpp) {
  class _0x15f311 extends NativeStruct {
    get class() {
      return new Il2Cpp.Class(Il2Cpp.exports.fieldGetClass(this));
    }
    get flags() {
      return Il2Cpp.exports.fieldGetFlags(this);
    }
    get isLiteral() {
      return (this.flags & 64) != 0;
    }
    get isStatic() {
      return (this.flags & 16) != 0;
    }
    get isThreadStatic() {
      const _0x2bed60 = Il2Cpp.corlib
        .class("System.AppDomain")
        .field("type_resolve_in_progress").offset;
      getter(
        Il2Cpp.Field.prototype,
        "isThreadStatic",
        function () {
          return this.offset == _0x2bed60;
        },
        lazy,
      );
      return this.isThreadStatic;
    }
    get modifier() {
      switch (this.flags & 7) {
        case 1:
          return "private";
        case 2:
          return "private protected";
        case 3:
          return "internal";
        case 4:
          return "protected";
        case 5:
          return "protected internal";
        case 6:
          return "public";
      }
    }
    get name() {
      return Il2Cpp.exports.fieldGetName(this).readUtf8String();
    }
    get offset() {
      return Il2Cpp.exports.fieldGetOffset(this);
    }
    get type() {
      return new Il2Cpp.Type(Il2Cpp.exports.fieldGetType(this));
    }
    get value() {
      if (!this.isStatic) {
        raise(
          "cannot access instance field " +
            this.class.type.name +
            "::" +
            this.name +
            " from a class, use an object instead",
        );
      }
      const _0x37b7bd = Memory.alloc(Process.pointerSize);
      Il2Cpp.exports.fieldGetStaticValue(this.handle, _0x37b7bd);
      return Il2Cpp.read(_0x37b7bd, this.type);
    }
    set value(_0x19f585) {
      if (!this.isStatic) {
        raise(
          "cannot access instance field " +
            this.class.type.name +
            "::" +
            this.name +
            " from a class, use an object instead",
        );
      }
      if (this.isThreadStatic || this.isLiteral) {
        raise("cannot write the value of field " + this.name + " as it's thread static or literal");
      }
      const _0x17c654 =
        _0x19f585 instanceof Il2Cpp.Object && this.type.class.isValueType
          ? _0x19f585.unbox()
          : _0x19f585 instanceof NativeStruct
            ? _0x19f585.handle
            : _0x19f585 instanceof NativePointer
              ? _0x19f585
              : Il2Cpp.write(Memory.alloc(this.type.class.valueTypeSize), _0x19f585, this.type);
      Il2Cpp.exports.fieldSetStaticValue(this.handle, _0x17c654);
    }
    toString() {
      return (
        "" +
        (this.isThreadStatic ? "[ThreadStatic] " : "") +
        (this.isStatic ? "static " : "") +
        this.type.name +
        " " +
        this.name +
        (this.isLiteral
          ? " = " +
            (this.type.class.isEnum
              ? Il2Cpp.read(this.value.handle, this.type.class.baseType)
              : this.value)
          : "") +
        ";" +
        (this.isThreadStatic || this.isLiteral ? "" : " // 0x" + this.offset.toString(16))
      );
    }
    bind(_0x56e63e) {
      if (this.isStatic) {
        raise(
          "cannot bind static field " + this.class.type.name + "::" + this.name + " to an instance",
        );
      }
      const _0x21b3b7 =
        this.offset - (_0x56e63e instanceof Il2Cpp.ValueType ? Il2Cpp.Object.headerSize : 0);
      return new Proxy(this, {
        get(_0x3679a9, _0x52ee01) {
          if (_0x52ee01 == "value") {
            return Il2Cpp.read(_0x56e63e.handle.add(_0x21b3b7), _0x3679a9.type);
          }
          return Reflect.get(_0x3679a9, _0x52ee01);
        },
        set(_0x31e06a, _0x58d9d4, _0x8cbf56) {
          if (_0x58d9d4 == "value") {
            Il2Cpp.write(_0x56e63e.handle.add(_0x21b3b7), _0x8cbf56, _0x31e06a.type);
            return true;
          }
          return Reflect.set(_0x31e06a, _0x58d9d4, _0x8cbf56);
        },
      });
    }
  }
  __decorate([lazy], _0x15f311.prototype, "class", null);
  __decorate([lazy], _0x15f311.prototype, "flags", null);
  __decorate([lazy], _0x15f311.prototype, "isLiteral", null);
  __decorate([lazy], _0x15f311.prototype, "isStatic", null);
  __decorate([lazy], _0x15f311.prototype, "isThreadStatic", null);
  __decorate([lazy], _0x15f311.prototype, "modifier", null);
  __decorate([lazy], _0x15f311.prototype, "name", null);
  __decorate([lazy], _0x15f311.prototype, "offset", null);
  __decorate([lazy], _0x15f311.prototype, "type", null);
  Il2Cpp.Field = _0x15f311;
})((Il2Cpp ||= {}));
var Il2Cpp;
(function (Il2Cpp) {
  class _0x343877 {
    constructor(_0xc14612) {
      this.handle = _0xc14612;
    }
    get target() {
      return new Il2Cpp.Object(Il2Cpp.exports.gcHandleGetTarget(this.handle)).asNullable();
    }
    free() {
      return Il2Cpp.exports.gcHandleFree(this.handle);
    }
  }
  Il2Cpp.GCHandle = _0x343877;
})((Il2Cpp ||= {}));
var Il2Cpp;
(function (Il2Cpp) {
  let _0x3993f1 = class _0x394ccc extends NativeStruct {
    get assembly() {
      return new Il2Cpp.Assembly(Il2Cpp.exports.imageGetAssembly(this));
    }
    get classCount() {
      if (Il2Cpp.unityVersionIsBelow201830) {
        return this.classes.length;
      } else {
        return Il2Cpp.exports.imageGetClassCount(this);
      }
    }
    get classes() {
      if (Il2Cpp.unityVersionIsBelow201830) {
        const _0x257b5c = this.assembly.object.method("GetTypes").invoke(false);
        const _0x2fabda = globalThis.Array.from(
          _0x257b5c,
          (_0xf59da8) => new Il2Cpp.Class(Il2Cpp.exports.classFromObject(_0xf59da8)),
        );
        const Module = this.tryClass("<Module>");
        if (Module) {
          _0x2fabda.unshift(Module);
        }
        return _0x2fabda;
      } else {
        return globalThis.Array.from(
          globalThis.Array(this.classCount),
          (_0x323807, _0x322ca4) => new Il2Cpp.Class(Il2Cpp.exports.imageGetClass(this, _0x322ca4)),
        );
      }
    }
    get name() {
      return Il2Cpp.exports.imageGetName(this).readUtf8String();
    }
    class(_0x25ce00) {
      return (
        this.tryClass(_0x25ce00) ??
        raise("couldn't find class " + _0x25ce00 + " in assembly " + this.name)
      );
    }
    tryClass(_0x59ade2) {
      const _0x2fbdca = _0x59ade2.lastIndexOf(".");
      const _0x26b60c = Memory.allocUtf8String(
        _0x2fbdca == -1 ? "" : _0x59ade2.slice(0, _0x2fbdca),
      );
      const _0x3b0fbd = Memory.allocUtf8String(_0x59ade2.slice(_0x2fbdca + 1));
      return new Il2Cpp.Class(
        Il2Cpp.exports.classFromName(this, _0x26b60c, _0x3b0fbd),
      ).asNullable();
    }
  };
  __decorate([lazy], _0x3993f1.prototype, "assembly", null);
  __decorate([lazy], _0x3993f1.prototype, "classCount", null);
  __decorate([lazy], _0x3993f1.prototype, "classes", null);
  __decorate([lazy], _0x3993f1.prototype, "name", null);
  _0x3993f1 = __decorate([recycle], _0x3993f1);
  Il2Cpp.Image = _0x3993f1;
  getter(
    Il2Cpp,
    "corlib",
    () => {
      return new Il2Cpp.Image(Il2Cpp.exports.getCorlib());
    },
    lazy,
  );
})((Il2Cpp ||= {}));
var Il2Cpp;
(function (Il2Cpp) {
  class _0x58238b extends NativeStruct {
    static capture() {
      return new Il2Cpp.MemorySnapshot();
    }
    constructor(_0x512df0 = Il2Cpp.exports.memorySnapshotCapture()) {
      super(_0x512df0);
    }
    get classes() {
      return readNativeIterator((_0x36915d) =>
        Il2Cpp.exports.memorySnapshotGetClasses(this, _0x36915d),
      ).map((_0x28729a) => new Il2Cpp.Class(_0x28729a));
    }
    get objects() {
      return readNativeList((_0x311f42) => Il2Cpp.exports.memorySnapshotGetObjects(this, _0x311f42))
        .filter((_0x14b72a) => !_0x14b72a.isNull())
        .map((_0x48f750) => new Il2Cpp.Object(_0x48f750));
    }
    free() {
      Il2Cpp.exports.memorySnapshotFree(this);
    }
  }
  __decorate([lazy], _0x58238b.prototype, "classes", null);
  __decorate([lazy], _0x58238b.prototype, "objects", null);
  Il2Cpp.MemorySnapshot = _0x58238b;
  function _0x5f0cbf(_0x5676a7) {
    const _0x5733fd = Il2Cpp.MemorySnapshot.capture();
    const _0x3b2d08 = _0x5676a7(_0x5733fd);
    _0x5733fd.free();
    return _0x3b2d08;
  }
  Il2Cpp.memorySnapshot = _0x5f0cbf;
})((Il2Cpp ||= {}));
var Il2Cpp;
(function (Il2Cpp) {
  class _0x1becc9 extends NativeStruct {
    get class() {
      return new Il2Cpp.Class(Il2Cpp.exports.methodGetClass(this));
    }
    get flags() {
      return Il2Cpp.exports.methodGetFlags(this, NULL);
    }
    get implementationFlags() {
      const _0x56c717 = Memory.alloc(Process.pointerSize);
      Il2Cpp.exports.methodGetFlags(this, _0x56c717);
      return _0x56c717.readU32();
    }
    get fridaSignature() {
      const _0x17f1a2 = [];
      for (const _0x2f8bed of this.parameters) {
        _0x17f1a2.push(_0x2f8bed.type.fridaAlias);
      }
      if (!this.isStatic || Il2Cpp.unityVersionIsBelow201830) {
        _0x17f1a2.unshift("pointer");
      }
      if (this.isInflated) {
        _0x17f1a2.push("pointer");
      }
      return _0x17f1a2;
    }
    get generics() {
      if (!this.isGeneric && !this.isInflated) {
        return [];
      }
      const _0x2201a1 = this.object.method("GetGenericArguments").invoke();
      return globalThis.Array.from(_0x2201a1).map(
        (_0x497ec7) => new Il2Cpp.Class(Il2Cpp.exports.classFromObject(_0x497ec7)),
      );
    }
    get isExternal() {
      return (this.implementationFlags & 4096) != 0;
    }
    get isGeneric() {
      return !!Il2Cpp.exports.methodIsGeneric(this);
    }
    get isInflated() {
      return !!Il2Cpp.exports.methodIsInflated(this);
    }
    get isStatic() {
      return !Il2Cpp.exports.methodIsInstance(this);
    }
    get isSynchronized() {
      return (this.implementationFlags & 32) != 0;
    }
    get modifier() {
      switch (this.flags & 7) {
        case 1:
          return "private";
        case 2:
          return "private protected";
        case 3:
          return "internal";
        case 4:
          return "protected";
        case 5:
          return "protected internal";
        case 6:
          return "public";
      }
    }
    get name() {
      return Il2Cpp.exports.methodGetName(this).readUtf8String();
    }
    get nativeFunction() {
      return new NativeFunction(
        this.virtualAddress,
        this.returnType.fridaAlias,
        this.fridaSignature,
      );
    }
    get object() {
      return new Il2Cpp.Object(Il2Cpp.exports.methodGetObject(this, NULL));
    }
    get parameterCount() {
      return Il2Cpp.exports.methodGetParameterCount(this);
    }
    get parameters() {
      return globalThis.Array.from(
        globalThis.Array(this.parameterCount),
        (_0x22e8f1, _0x564950) => {
          const _0x54eae9 = Il2Cpp.exports.methodGetParameterName(this, _0x564950).readUtf8String();
          const _0x5cd358 = Il2Cpp.exports.methodGetParameterType(this, _0x564950);
          return new Il2Cpp.Parameter(_0x54eae9, _0x564950, new Il2Cpp.Type(_0x5cd358));
        },
      );
    }
    get relativeVirtualAddress() {
      return this.virtualAddress.sub(Il2Cpp.module.base);
    }
    get returnType() {
      return new Il2Cpp.Type(Il2Cpp.exports.methodGetReturnType(this));
    }
    get virtualAddress() {
      const _0x51f316 = Il2Cpp.corlib
        .class("System.Reflection.Module")
        .initialize()
        .field("FilterTypeName").value;
      const _0x235be0 = _0x51f316.field("method_ptr").value;
      const _0x18a83d = _0x51f316.field("method").value;
      const _0x269398 =
        _0x18a83d.offsetOf((_0x1eb06f) => _0x1eb06f.readPointer().equals(_0x235be0)) ??
        raise("couldn't find the virtual address offset in the native method struct");
      getter(
        Il2Cpp.Method.prototype,
        "virtualAddress",
        function () {
          return this.handle.add(_0x269398).readPointer();
        },
        lazy,
      );
      Il2Cpp.corlib.class("System.Reflection.Module").method(".cctor").invoke();
      return this.virtualAddress;
    }
    set implementation(_0x3e7e6e) {
      var _0x3f0844;
      try {
        Interceptor.replace(this.virtualAddress, this.wrap(_0x3e7e6e));
      } catch (_0x10d43e) {
        switch (_0x10d43e.message) {
          case "access violation accessing 0x0":
            raise(
              "couldn't set implementation for method " +
                this.name +
                " as it has a NULL virtual address",
            );
          case (_0x3f0844 = /unable to intercept function at \w+; please file a bug/.exec(
            _0x10d43e.message,
          )) === null || _0x3f0844 === undefined
            ? undefined
            : _0x3f0844.input:
            warn("couldn't set implementation for method " + this.name + " as it may be a thunk");
            break;
          case "already replaced this function":
            warn(
              "couldn't set implementation for method " +
                this.name +
                " as it has already been replaced by a thunk",
            );
            break;
          default:
            throw _0x10d43e;
        }
      }
    }
    inflate(..._0x108c89) {
      if (!this.isGeneric || this.generics.length != _0x108c89.length) {
        for (const _0x3b2a24 of this.overloads()) {
          if (_0x3b2a24.isGeneric && _0x3b2a24.generics.length == _0x108c89.length) {
            return _0x3b2a24.inflate(..._0x108c89);
          }
        }
        raise(
          "could not find inflatable signature of method " +
            this.name +
            " with " +
            _0x108c89.length +
            " generic parameter(s)",
        );
      }
      const _0x1a7590 = _0x108c89.map((_0x45870e) => _0x45870e.type.object);
      const _0x399b20 = Il2Cpp.array(Il2Cpp.corlib.class("System.Type"), _0x1a7590);
      const _0x5e01f5 = this.object.method("MakeGenericMethod", 1).invoke(_0x399b20);
      return new Il2Cpp.Method(_0x5e01f5.field("mhandle").value);
    }
    invoke(..._0x13b381) {
      if (!this.isStatic) {
        raise(
          "cannot invoke non-static method " +
            this.name +
            " as it must be invoked throught a Il2Cpp.Object, not a Il2Cpp.Class",
        );
      }
      return this.invokeRaw(NULL, ..._0x13b381);
    }
    invokeRaw(_0xd5055c, ..._0xef2fe) {
      const _0x1d3148 = _0xef2fe.map(Il2Cpp.toFridaValue);
      if (!this.isStatic || Il2Cpp.unityVersionIsBelow201830) {
        _0x1d3148.unshift(_0xd5055c);
      }
      if (this.isInflated) {
        _0x1d3148.push(this.handle);
      }
      try {
        const _0x5baa01 = this.nativeFunction(..._0x1d3148);
        return Il2Cpp.fromFridaValue(_0x5baa01, this.returnType);
      } catch (_0x53b80e) {
        if (_0x53b80e == null) {
          raise(
            "an unexpected native invocation exception occurred, this is due to parameter types mismatch",
          );
        }
        switch (_0x53b80e.message) {
          case "bad argument count":
            raise(
              "couldn't invoke method " +
                this.name +
                " as it needs " +
                this.parameterCount +
                " parameter(s), not " +
                _0xef2fe.length,
            );
          case "expected a pointer":
          case "expected number":
          case "expected array with fields":
            raise("couldn't invoke method " + this.name + " using incorrect parameter types");
        }
        throw _0x53b80e;
      }
    }
    overload(..._0x33079e) {
      const _0x33f55d = this.tryOverload(..._0x33079e);
      return (
        _0x33f55d ??
        raise(
          "couldn't find overloaded method " +
            this.name +
            "(" +
            _0x33079e.map((_0x57e744) =>
              _0x57e744 instanceof Il2Cpp.Class ? _0x57e744.type.name : _0x57e744,
            ) +
            ")",
        )
      );
    }
    *overloads() {
      for (const _0x5af1fc of this.class.hierarchy()) {
        for (const _0x2837e9 of _0x5af1fc.methods) {
          if (this.name == _0x2837e9.name) {
            yield _0x2837e9;
          }
        }
      }
    }
    parameter(_0x477c3) {
      return (
        this.tryParameter(_0x477c3) ??
        raise("couldn't find parameter " + _0x477c3 + " in method " + this.name)
      );
    }
    revert() {
      Interceptor.revert(this.virtualAddress);
      Interceptor.flush();
    }
    tryOverload(..._0x3d580c) {
      const _0x20c0ac = _0x3d580c.length * 1;
      const _0x441cf6 = _0x3d580c.length * 2;
      let _0x5bce7f = undefined;
      _0x2093d9: for (const _0x4c2983 of this.overloads()) {
        if (_0x4c2983.parameterCount != _0x3d580c.length) {
          continue;
        }
        let _0x45aa48 = 0;
        let _0x485d4d = 0;
        for (const _0x545c55 of _0x4c2983.parameters) {
          const _0x43d272 = _0x3d580c[_0x485d4d];
          if (_0x43d272 instanceof Il2Cpp.Class) {
            if (_0x545c55.type.is(_0x43d272.type)) {
              _0x45aa48 += 2;
            } else if (_0x545c55.type.class.isAssignableFrom(_0x43d272)) {
              _0x45aa48 += 1;
            } else {
              continue _0x2093d9;
            }
          } else if (_0x545c55.type.name == _0x43d272) {
            _0x45aa48 += 2;
          } else {
            continue _0x2093d9;
          }
          _0x485d4d++;
        }
        if (_0x45aa48 < _0x20c0ac) {
          continue;
        } else if (_0x45aa48 == _0x441cf6) {
          return _0x4c2983;
        } else if (_0x5bce7f == undefined || _0x45aa48 > _0x5bce7f[0]) {
          _0x5bce7f = [_0x45aa48, _0x4c2983];
        } else if (_0x45aa48 == _0x5bce7f[0]) {
          let _0x5232fe = 0;
          for (const _0x183daf of _0x5bce7f[1].parameters) {
            if (_0x183daf.type.class.isAssignableFrom(_0x4c2983.parameters[_0x5232fe].type.class)) {
              _0x5bce7f = [_0x45aa48, _0x4c2983];
              continue _0x2093d9;
            }
            _0x5232fe++;
          }
        }
      }
      return _0x5bce7f?.[1];
    }
    tryParameter(_0xb32e21) {
      return this.parameters.find((_0x156257) => _0x156257.name == _0xb32e21);
    }
    toString() {
      return (
        "" +
        (this.isStatic ? "static " : "") +
        this.returnType.name +
        " " +
        this.name +
        (this.generics.length > 0
          ? "<" + this.generics.map((_0x1fc955) => _0x1fc955.type.name).join(",") + ">"
          : "") +
        "(" +
        this.parameters.join(", ") +
        ");" +
        (this.virtualAddress.isNull()
          ? ""
          : " // 0x" + this.relativeVirtualAddress.toString(16).padStart(8, "0"))
      );
    }
    bind(_0x17c6ce) {
      if (this.isStatic) {
        raise(
          "cannot bind static method " +
            this.class.type.name +
            "::" +
            this.name +
            " to an instance",
        );
      }
      return new Proxy(this, {
        get(_0x344f51, _0x35156e, _0x2632ba) {
          switch (_0x35156e) {
            case "invoke":
              const _0xd53d78 =
                _0x17c6ce instanceof Il2Cpp.ValueType
                  ? _0x344f51.class.isValueType
                    ? _0x17c6ce.handle.sub(_0x3ffe52() ? Il2Cpp.Object.headerSize : 0)
                    : raise(
                        "cannot invoke method " +
                          _0x344f51.class.type.name +
                          "::" +
                          _0x344f51.name +
                          " against a value type, you must box it first",
                      )
                  : _0x344f51.class.isValueType
                    ? _0x17c6ce.handle.add(_0x3ffe52() ? 0 : Il2Cpp.Object.headerSize)
                    : _0x17c6ce.handle;
              return _0x344f51.invokeRaw.bind(_0x344f51, _0xd53d78);
            case "overloads":
              return function* () {
                for (const _0x3b427e of _0x344f51[_0x35156e]()) {
                  if (!_0x3b427e.isStatic) {
                    yield _0x3b427e;
                  }
                }
              };
            case "inflate":
            case "overload":
            case "tryOverload":
              const _0x5c9277 = Reflect.get(_0x344f51, _0x35156e).bind(_0x2632ba);
              return function (..._0x43aec1) {
                var _0x4f18ca;
                if ((_0x4f18ca = _0x5c9277(..._0x43aec1)) === null || _0x4f18ca === undefined) {
                  return undefined;
                } else {
                  return _0x4f18ca.bind(_0x17c6ce);
                }
              };
          }
          return Reflect.get(_0x344f51, _0x35156e);
        },
      });
    }
    wrap(_0x4a8811) {
      const _0x18d9b2 = +!this.isStatic | +Il2Cpp.unityVersionIsBelow201830;
      return new NativeCallback(
        (..._0xb55cf3) => {
          const _0x373831 = this.isStatic
            ? this.class
            : this.class.isValueType
              ? new Il2Cpp.ValueType(
                  _0xb55cf3[0].add(_0x3ffe52() ? Il2Cpp.Object.headerSize : 0),
                  this.class.type,
                )
              : new Il2Cpp.Object(_0xb55cf3[0]);
          const _0x2f134e = this.parameters.map((_0x34ea91, _0x5b147d) =>
            Il2Cpp.fromFridaValue(_0xb55cf3[_0x5b147d + _0x18d9b2], _0x34ea91.type),
          );
          const _0x47f9a7 = _0x4a8811.call(_0x373831, ..._0x2f134e);
          return Il2Cpp.toFridaValue(_0x47f9a7);
        },
        this.returnType.fridaAlias,
        this.fridaSignature,
      );
    }
  }
  __decorate([lazy], _0x1becc9.prototype, "class", null);
  __decorate([lazy], _0x1becc9.prototype, "flags", null);
  __decorate([lazy], _0x1becc9.prototype, "implementationFlags", null);
  __decorate([lazy], _0x1becc9.prototype, "fridaSignature", null);
  __decorate([lazy], _0x1becc9.prototype, "generics", null);
  __decorate([lazy], _0x1becc9.prototype, "isExternal", null);
  __decorate([lazy], _0x1becc9.prototype, "isGeneric", null);
  __decorate([lazy], _0x1becc9.prototype, "isInflated", null);
  __decorate([lazy], _0x1becc9.prototype, "isStatic", null);
  __decorate([lazy], _0x1becc9.prototype, "isSynchronized", null);
  __decorate([lazy], _0x1becc9.prototype, "modifier", null);
  __decorate([lazy], _0x1becc9.prototype, "name", null);
  __decorate([lazy], _0x1becc9.prototype, "nativeFunction", null);
  __decorate([lazy], _0x1becc9.prototype, "object", null);
  __decorate([lazy], _0x1becc9.prototype, "parameterCount", null);
  __decorate([lazy], _0x1becc9.prototype, "parameters", null);
  __decorate([lazy], _0x1becc9.prototype, "relativeVirtualAddress", null);
  __decorate([lazy], _0x1becc9.prototype, "returnType", null);
  Il2Cpp.Method = _0x1becc9;
  let _0x3ffe52 = () => {
    const _0x489c4b = Il2Cpp.corlib.class("System.Int64").alloc();
    _0x489c4b.field("m_value").value = 3735928559;
    const _0x4ca778 = _0x489c4b
      .method("Equals", 1)
      .overload(_0x489c4b.class)
      .invokeRaw(_0x489c4b, 3735928559);
    return (_0x3ffe52 = () => _0x4ca778)();
  };
})((Il2Cpp ||= {}));
var Il2Cpp;
(function (Il2Cpp) {
  class _0xe02529 extends NativeStruct {
    static get headerSize() {
      return Il2Cpp.corlib.class("System.Object").instanceSize;
    }
    get base() {
      if (this.class.parent == null) {
        raise("class " + this.class.type.name + " has no parent");
      }
      return new Proxy(this, {
        get(_0x37296d, _0xdcd0a0, _0x27fc3) {
          if (_0xdcd0a0 == "class") {
            return Reflect.get(_0x37296d, _0xdcd0a0).parent;
          } else if (_0xdcd0a0 == "base") {
            return Reflect.getOwnPropertyDescriptor(Il2Cpp.Object.prototype, _0xdcd0a0).get.bind(
              _0x27fc3,
            )();
          }
          return Reflect.get(_0x37296d, _0xdcd0a0);
        },
      });
    }
    get class() {
      return new Il2Cpp.Class(Il2Cpp.exports.objectGetClass(this));
    }
    get monitor() {
      return new Il2Cpp.Object.Monitor(this);
    }
    get size() {
      return Il2Cpp.exports.objectGetSize(this);
    }
    field(_0x552ace) {
      return (
        this.tryField(_0x552ace) ??
        raise(
          "couldn't find non-static field " +
            _0x552ace +
            " in hierarchy of class " +
            this.class.type.name,
        )
      );
    }
    method(_0x25182e, _0x1c0403 = -1) {
      return (
        this.tryMethod(_0x25182e, _0x1c0403) ??
        raise(
          "couldn't find non-static method " +
            _0x25182e +
            " in hierarchy of class " +
            this.class.type.name,
        )
      );
    }
    ref(_0xebd24b) {
      return new Il2Cpp.GCHandle(Il2Cpp.exports.gcHandleNew(this, +_0xebd24b));
    }
    virtualMethod(_0x440632) {
      return new Il2Cpp.Method(Il2Cpp.exports.objectGetVirtualMethod(this, _0x440632)).bind(this);
    }
    tryField(_0xc06f50) {
      const _0x731c84 = this.class.tryField(_0xc06f50);
      if (_0x731c84?.isStatic) {
        for (const _0x5418a3 of this.class.hierarchy({
          includeCurrent: false,
        })) {
          for (const _0x2d37fd of _0x5418a3.fields) {
            if (_0x2d37fd.name == _0xc06f50 && !_0x2d37fd.isStatic) {
              return _0x2d37fd.bind(this);
            }
          }
        }
        return undefined;
      }
      if (_0x731c84 === null || _0x731c84 === undefined) {
        return undefined;
      } else {
        return _0x731c84.bind(this);
      }
    }
    tryMethod(_0x50d09b, _0x312924 = -1) {
      const _0x46edbf = this.class.tryMethod(_0x50d09b, _0x312924);
      if (_0x46edbf?.isStatic) {
        for (const _0x371b93 of this.class.hierarchy()) {
          for (const _0x295952 of _0x371b93.methods) {
            if (
              _0x295952.name == _0x50d09b &&
              !_0x295952.isStatic &&
              (_0x312924 < 0 || _0x295952.parameterCount == _0x312924)
            ) {
              return _0x295952.bind(this);
            }
          }
        }
        return undefined;
      }
      if (_0x46edbf === null || _0x46edbf === undefined) {
        return undefined;
      } else {
        return _0x46edbf.bind(this);
      }
    }
    toString() {
      try {
        if (this.isNull()) {
          return "null";
        } else {
          return this.method("ToString", 0).invoke().content ?? "null";
        }
      } catch (_0x44f3a2) {
        return "Error: ToString failed";
      }
    }
    unbox() {
      if (this.class.isValueType) {
        return new Il2Cpp.ValueType(Il2Cpp.exports.objectUnbox(this), this.class.type);
      } else {
        return raise(
          "couldn't unbox instances of " + this.class.type.name + " as they are not value types",
        );
      }
    }
    weakRef(_0x58667f) {
      return new Il2Cpp.GCHandle(Il2Cpp.exports.gcHandleNewWeakRef(this, +_0x58667f));
    }
  }
  __decorate([lazy], _0xe02529.prototype, "class", null);
  __decorate([lazy], _0xe02529.prototype, "size", null);
  __decorate([lazy], _0xe02529, "headerSize", null);
  Il2Cpp.Object = _0xe02529;
  (function (_0x1c3d5b) {
    class _0x235e4f {
      constructor(_0x283f7c) {
        this.handle = _0x283f7c;
      }
      enter() {
        return Il2Cpp.exports.monitorEnter(this.handle);
      }
      exit() {
        return Il2Cpp.exports.monitorExit(this.handle);
      }
      pulse() {
        return Il2Cpp.exports.monitorPulse(this.handle);
      }
      pulseAll() {
        return Il2Cpp.exports.monitorPulseAll(this.handle);
      }
      tryEnter(_0x4d0138) {
        return !!Il2Cpp.exports.monitorTryEnter(this.handle, _0x4d0138);
      }
      tryWait(_0x2d8e91) {
        return !!Il2Cpp.exports.monitorTryWait(this.handle, _0x2d8e91);
      }
      wait() {
        return Il2Cpp.exports.monitorWait(this.handle);
      }
    }
    _0x1c3d5b.Monitor = _0x235e4f;
  })((_0xe02529 = Il2Cpp.Object ||= {}));
})((Il2Cpp ||= {}));
var Il2Cpp;
(function (Il2Cpp) {
  class _0x1d59ab {
    constructor(_0x26b4dd, _0x627233, _0x31c242) {
      this.name = _0x26b4dd;
      this.position = _0x627233;
      this.type = _0x31c242;
    }
    toString() {
      return this.type.name + " " + this.name;
    }
  }
  Il2Cpp.Parameter = _0x1d59ab;
})((Il2Cpp ||= {}));
var Il2Cpp;
(function (Il2Cpp) {
  class _0x23c99f extends NativeStruct {
    constructor(_0x2b750f, _0x410c4c) {
      super(_0x2b750f);
      this.type = _0x410c4c;
    }
    get(_0x40195a) {
      return Il2Cpp.read(this.handle.add(_0x40195a * this.type.class.arrayElementSize), this.type);
    }
    read(_0x29beea, _0x58a601 = 0) {
      const _0x4581eb = new globalThis.Array(_0x29beea);
      for (let _0x440108 = 0; _0x440108 < _0x29beea; _0x440108++) {
        _0x4581eb[_0x440108] = this.get(_0x440108 + _0x58a601);
      }
      return _0x4581eb;
    }
    set(_0x5150a6, _0x5b6d7d) {
      Il2Cpp.write(
        this.handle.add(_0x5150a6 * this.type.class.arrayElementSize),
        _0x5b6d7d,
        this.type,
      );
    }
    toString() {
      return this.handle.toString();
    }
    write(_0x1b2280, _0x293ed4 = 0) {
      for (let _0x909d04 = 0; _0x909d04 < _0x1b2280.length; _0x909d04++) {
        this.set(_0x909d04 + _0x293ed4, _0x1b2280[_0x909d04]);
      }
    }
  }
  Il2Cpp.Pointer = _0x23c99f;
})((Il2Cpp ||= {}));
var Il2Cpp;
(function (Il2Cpp) {
  class _0x3b8cdd extends NativeStruct {
    constructor(_0x578ce7, _0x187833) {
      super(_0x578ce7);
      this.type = _0x187833;
    }
    get value() {
      return Il2Cpp.read(this.handle, this.type);
    }
    set value(_0x37bec1) {
      Il2Cpp.write(this.handle, _0x37bec1, this.type);
    }
    toString() {
      if (this.isNull()) {
        return "null";
      } else {
        return "->" + this.value;
      }
    }
  }
  Il2Cpp.Reference = _0x3b8cdd;
  function _0x10e641(_0x3eb737, _0xb34fa) {
    const _0x1b3299 = Memory.alloc(Process.pointerSize);
    switch (typeof _0x3eb737) {
      case "boolean":
        return new Il2Cpp.Reference(
          _0x1b3299.writeS8(+_0x3eb737),
          Il2Cpp.corlib.class("System.Boolean").type,
        );
      case "number":
        switch (_0xb34fa?.enumValue) {
          case Il2Cpp.Type.Enum.UBYTE:
            return new Il2Cpp.Reference(_0x1b3299.writeU8(_0x3eb737), _0xb34fa);
          case Il2Cpp.Type.Enum.BYTE:
            return new Il2Cpp.Reference(_0x1b3299.writeS8(_0x3eb737), _0xb34fa);
          case Il2Cpp.Type.Enum.CHAR:
          case Il2Cpp.Type.Enum.USHORT:
            return new Il2Cpp.Reference(_0x1b3299.writeU16(_0x3eb737), _0xb34fa);
          case Il2Cpp.Type.Enum.SHORT:
            return new Il2Cpp.Reference(_0x1b3299.writeS16(_0x3eb737), _0xb34fa);
          case Il2Cpp.Type.Enum.UINT:
            return new Il2Cpp.Reference(_0x1b3299.writeU32(_0x3eb737), _0xb34fa);
          case Il2Cpp.Type.Enum.INT:
            return new Il2Cpp.Reference(_0x1b3299.writeS32(_0x3eb737), _0xb34fa);
          case Il2Cpp.Type.Enum.ULONG:
            return new Il2Cpp.Reference(_0x1b3299.writeU64(_0x3eb737), _0xb34fa);
          case Il2Cpp.Type.Enum.LONG:
            return new Il2Cpp.Reference(_0x1b3299.writeS64(_0x3eb737), _0xb34fa);
          case Il2Cpp.Type.Enum.FLOAT:
            return new Il2Cpp.Reference(_0x1b3299.writeFloat(_0x3eb737), _0xb34fa);
          case Il2Cpp.Type.Enum.DOUBLE:
            return new Il2Cpp.Reference(_0x1b3299.writeDouble(_0x3eb737), _0xb34fa);
        }
      case "object":
        if (_0x3eb737 instanceof Il2Cpp.ValueType || _0x3eb737 instanceof Il2Cpp.Pointer) {
          return new Il2Cpp.Reference(_0x3eb737.handle, _0x3eb737.type);
        } else if (_0x3eb737 instanceof Il2Cpp.Object) {
          return new Il2Cpp.Reference(_0x1b3299.writePointer(_0x3eb737), _0x3eb737.class.type);
        } else if (_0x3eb737 instanceof Il2Cpp.String || _0x3eb737 instanceof Il2Cpp.Array) {
          return new Il2Cpp.Reference(
            _0x1b3299.writePointer(_0x3eb737),
            _0x3eb737.object.class.type,
          );
        } else if (_0x3eb737 instanceof NativePointer) {
          switch (_0xb34fa?.enumValue) {
            case Il2Cpp.Type.Enum.NUINT:
            case Il2Cpp.Type.Enum.NINT:
              return new Il2Cpp.Reference(_0x1b3299.writePointer(_0x3eb737), _0xb34fa);
          }
        } else if (_0x3eb737 instanceof Int64) {
          return new Il2Cpp.Reference(
            _0x1b3299.writeS64(_0x3eb737),
            Il2Cpp.corlib.class("System.Int64").type,
          );
        } else if (_0x3eb737 instanceof UInt64) {
          return new Il2Cpp.Reference(
            _0x1b3299.writeU64(_0x3eb737),
            Il2Cpp.corlib.class("System.UInt64").type,
          );
        }
      default:
        raise(
          "couldn't create a reference to " +
            _0x3eb737 +
            " using an unhandled type " +
            _0xb34fa?.name,
        );
    }
  }
  Il2Cpp.reference = _0x10e641;
})((Il2Cpp ||= {}));
var Il2Cpp;
(function (Il2Cpp) {
  class _0x2c7848 extends NativeStruct {
    get content() {
      return Il2Cpp.exports.stringGetChars(this).readUtf16String(this.length);
    }
    set content(_0x378362) {
      const _0x5e7684 =
        Il2Cpp.string("vfsfitvnm").handle.offsetOf((_0x3da7f3) => _0x3da7f3.readInt() == 9) ??
        raise("couldn't find the length offset in the native string struct");
      globalThis.Object.defineProperty(Il2Cpp.String.prototype, "content", {
        set(_0x4dd6d9) {
          Il2Cpp.exports.stringGetChars(this).writeUtf16String(_0x4dd6d9 ?? "");
          this.handle.add(_0x5e7684).writeS32(_0x4dd6d9?.length ?? 0);
        },
      });
      this.content = _0x378362;
    }
    get length() {
      return Il2Cpp.exports.stringGetLength(this);
    }
    get object() {
      return new Il2Cpp.Object(this);
    }
    toString() {
      if (this.isNull()) {
        return "null";
      } else {
        return '"' + this.content + '"';
      }
    }
  }
  Il2Cpp.String = _0x2c7848;
  function _0x55e548(_0x7be387) {
    return new Il2Cpp.String(Il2Cpp.exports.stringNew(Memory.allocUtf8String(_0x7be387 ?? "")));
  }
  Il2Cpp.string = _0x55e548;
})((Il2Cpp ||= {}));
var Il2Cpp;
(function (Il2Cpp) {
  class _0x39bcc1 extends NativeStruct {
    get id() {
      let _0x44679b = function () {
        return this.internal.field("thread_id").value.toNumber();
      };
      if (Process.platform != "windows") {
        const _0x3f7b91 = Process.getCurrentThreadId();
        const _0x106c9a = ptr(_0x44679b.apply(Il2Cpp.currentThread));
        const _0x14d1e2 =
          _0x106c9a.offsetOf((_0x1307ee) => _0x1307ee.readS32() == _0x3f7b91, 1024) ??
          raise("couldn't find the offset for determining the kernel id of a posix thread");
        const _0x164e4e = _0x44679b;
        _0x44679b = function () {
          return ptr(_0x164e4e.apply(this)).add(_0x14d1e2).readS32();
        };
      }
      getter(Il2Cpp.Thread.prototype, "id", _0x44679b, lazy);
      return this.id;
    }
    get internal() {
      return this.object.tryField("internal_thread")?.value ?? this.object;
    }
    get isFinalizer() {
      return !Il2Cpp.exports.threadIsVm(this);
    }
    get managedId() {
      return this.object.method("get_ManagedThreadId").invoke();
    }
    get object() {
      return new Il2Cpp.Object(this);
    }
    get staticData() {
      return this.internal.field("static_data").value;
    }
    get synchronizationContext() {
      var _0x25aae9;
      const _0x218057 =
        this.object.tryMethod("GetMutableExecutionContext") ??
        this.object.method("get_ExecutionContext");
      const _0x63235b = _0x218057.invoke();
      const _0x5a6071 =
        _0x63235b.tryField("_syncContext")?.value ??
        ((_0x25aae9 = _0x63235b.tryMethod("get_SynchronizationContext")) === null ||
        _0x25aae9 === undefined
          ? undefined
          : _0x25aae9.invoke()) ??
        this.tryLocalValue(Il2Cpp.corlib.class("System.Threading.SynchronizationContext"));
      return (
        (_0x5a6071 === null || _0x5a6071 === undefined ? undefined : _0x5a6071.asNullable()) ?? null
      );
    }
    detach() {
      return Il2Cpp.exports.threadDetach(this);
    }
    schedule(_0x499092) {
      var _0x116b2e;
      const _0x155d82 =
        (_0x116b2e = this.synchronizationContext) === null || _0x116b2e === undefined
          ? undefined
          : _0x116b2e.tryMethod("Post");
      if (_0x155d82 == null) {
        return Process.runOnThread(this.id, _0x499092);
      }
      return new Promise((_0x13d7aa) => {
        const _0x426f80 = Il2Cpp.delegate(
          Il2Cpp.corlib.class("System.Threading.SendOrPostCallback"),
          () => {
            const _0x36528a = _0x499092();
            setImmediate(() => _0x13d7aa(_0x36528a));
          },
        );
        Script.bindWeak(globalThis, () => {
          _0x426f80.field("method_ptr").value = _0x426f80.field("invoke_impl").value =
            Il2Cpp.exports.domainGet;
        });
        _0x155d82.invoke(_0x426f80, NULL);
      });
    }
    tryLocalValue(_0x31f1a7) {
      var _0x15a3f9;
      for (let _0x5ae376 = 0; _0x5ae376 < 16; _0x5ae376++) {
        const _0x4c1e0d = this.staticData.add(_0x5ae376 * Process.pointerSize).readPointer();
        if (!_0x4c1e0d.isNull()) {
          const _0x398ecf = new Il2Cpp.Object(_0x4c1e0d.readPointer()).asNullable();
          if (
            (_0x15a3f9 = _0x398ecf?.class) === null || _0x15a3f9 === undefined
              ? undefined
              : _0x15a3f9.isSubclassOf(_0x31f1a7, false)
          ) {
            return _0x398ecf;
          }
        }
      }
    }
  }
  __decorate([lazy], _0x39bcc1.prototype, "internal", null);
  __decorate([lazy], _0x39bcc1.prototype, "isFinalizer", null);
  __decorate([lazy], _0x39bcc1.prototype, "managedId", null);
  __decorate([lazy], _0x39bcc1.prototype, "object", null);
  __decorate([lazy], _0x39bcc1.prototype, "staticData", null);
  __decorate([lazy], _0x39bcc1.prototype, "synchronizationContext", null);
  Il2Cpp.Thread = _0x39bcc1;
  getter(Il2Cpp, "attachedThreads", () => {
    if (Il2Cpp.exports.threadGetAttachedThreads.isNull()) {
      const _0x356683 =
        Il2Cpp.currentThread?.handle ?? raise("Current thread is not attached to IL2CPP");
      const _0x3bb84c = _0x356683.toMatchPattern();
      const _0x49d326 = [];
      for (const _0x423f80 of Process.enumerateRanges("rw-")) {
        if (_0x423f80.file == undefined) {
          let _0x32745e;
          try {
            _0x32745e = Memory.scanSync(_0x423f80.base, _0x423f80.size, _0x3bb84c);
          } catch (_0x61980d) {
            continue;
          }
          if (_0x32745e.length == 1) {
            try {
              while (true) {
                const _0x1bc9d8 = _0x32745e[0].address
                  .sub(_0x32745e[0].size * _0x49d326.length)
                  .readPointer();
                if (
                  _0x1bc9d8.isNull() ||
                  !_0x1bc9d8.readPointer().equals(_0x356683.readPointer())
                ) {
                  break;
                }
                _0x49d326.unshift(new Il2Cpp.Thread(_0x1bc9d8));
              }
            } catch (_0x19a50c) {}
            break;
          }
        }
      }
      return _0x49d326;
    }
    return readNativeList(Il2Cpp.exports.threadGetAttachedThreads).map(
      (_0xb6fb19) => new Il2Cpp.Thread(_0xb6fb19),
    );
  });
  getter(Il2Cpp, "currentThread", () => {
    return new Il2Cpp.Thread(Il2Cpp.exports.threadGetCurrent()).asNullable();
  });
  getter(Il2Cpp, "mainThread", () => {
    const _0x349a16 = Il2Cpp.attachedThreads;
    return _0x349a16[0] ?? _0x349a16.find((_0x41f620) => _0x41f620.managedId === 1);
  });
})((Il2Cpp ||= {}));
var Il2Cpp;
(function (Il2Cpp) {
  let _0x191865 = class _0x3e0327 extends NativeStruct {
    static get Enum() {
      const _0x4317be = (_0x532624, _0x38893b = (_0x175cae) => _0x175cae) =>
        _0x38893b(Il2Cpp.corlib.class(_0x532624)).type.enumValue;
      const _0x487ebc = {
        VOID: _0x4317be("System.Void"),
        BOOLEAN: _0x4317be("System.Boolean"),
        CHAR: _0x4317be("System.Char"),
        BYTE: _0x4317be("System.SByte"),
        UBYTE: _0x4317be("System.Byte"),
        SHORT: _0x4317be("System.Int16"),
        USHORT: _0x4317be("System.UInt16"),
        INT: _0x4317be("System.Int32"),
        UINT: _0x4317be("System.UInt32"),
        LONG: _0x4317be("System.Int64"),
        ULONG: _0x4317be("System.UInt64"),
        NINT: _0x4317be("System.IntPtr"),
        NUINT: _0x4317be("System.UIntPtr"),
        FLOAT: _0x4317be("System.Single"),
        DOUBLE: _0x4317be("System.Double"),
        POINTER: _0x4317be("System.IntPtr", (_0x1f5a01) => _0x1f5a01.field("m_value")),
        VALUE_TYPE: _0x4317be("System.Decimal"),
        OBJECT: _0x4317be("System.Object"),
        STRING: _0x4317be("System.String"),
        CLASS: _0x4317be("System.Array"),
        ARRAY: _0x4317be("System.Void", (_0x189fad) => _0x189fad.arrayClass),
        NARRAY: _0x4317be(
          "System.Void",
          (_0x555c4d) => new Il2Cpp.Class(Il2Cpp.exports.classGetArrayClass(_0x555c4d, 2)),
        ),
        GENERIC_INSTANCE: _0x4317be("System.Int32", (_0x5316f0) =>
          _0x5316f0.interfaces.find((_0x1b273f) => _0x1b273f.name.endsWith("`1")),
        ),
      };
      Reflect.defineProperty(this, "Enum", {
        value: _0x487ebc,
      });
      return addFlippedEntries(
        Object.assign(Object.assign({}, _0x487ebc), {
          VAR: _0x4317be("System.Action`1", (_0xdc19af) => _0xdc19af.generics[0]),
          MVAR: _0x4317be(
            "System.Array",
            (_0x3f26dd) => _0x3f26dd.method("AsReadOnly", 1).generics[0],
          ),
        }),
      );
    }
    get class() {
      return new Il2Cpp.Class(Il2Cpp.exports.typeGetClass(this));
    }
    get fridaAlias() {
      function _0x2ec8da(_0x1dfe6d) {
        const _0x22b8c2 = _0x1dfe6d.class.fields.filter((_0x4aa8a1) => !_0x4aa8a1.isStatic);
        if (_0x22b8c2.length == 0) {
          return ["char"];
        } else {
          return _0x22b8c2.map((_0x3e0f72) => _0x3e0f72.type.fridaAlias);
        }
      }
      if (this.isByReference) {
        return "pointer";
      }
      switch (this.enumValue) {
        case Il2Cpp.Type.Enum.VOID:
          return "void";
        case Il2Cpp.Type.Enum.BOOLEAN:
          return "bool";
        case Il2Cpp.Type.Enum.CHAR:
          return "uchar";
        case Il2Cpp.Type.Enum.BYTE:
          return "int8";
        case Il2Cpp.Type.Enum.UBYTE:
          return "uint8";
        case Il2Cpp.Type.Enum.SHORT:
          return "int16";
        case Il2Cpp.Type.Enum.USHORT:
          return "uint16";
        case Il2Cpp.Type.Enum.INT:
          return "int32";
        case Il2Cpp.Type.Enum.UINT:
          return "uint32";
        case Il2Cpp.Type.Enum.LONG:
          return "int64";
        case Il2Cpp.Type.Enum.ULONG:
          return "uint64";
        case Il2Cpp.Type.Enum.FLOAT:
          return "float";
        case Il2Cpp.Type.Enum.DOUBLE:
          return "double";
        case Il2Cpp.Type.Enum.NINT:
        case Il2Cpp.Type.Enum.NUINT:
        case Il2Cpp.Type.Enum.POINTER:
        case Il2Cpp.Type.Enum.STRING:
        case Il2Cpp.Type.Enum.ARRAY:
        case Il2Cpp.Type.Enum.NARRAY:
          return "pointer";
        case Il2Cpp.Type.Enum.VALUE_TYPE:
          if (this.class.isEnum) {
            return this.class.baseType.fridaAlias;
          } else {
            return _0x2ec8da(this);
          }
        case Il2Cpp.Type.Enum.CLASS:
        case Il2Cpp.Type.Enum.OBJECT:
        case Il2Cpp.Type.Enum.GENERIC_INSTANCE:
          if (this.class.isStruct) {
            return _0x2ec8da(this);
          } else if (this.class.isEnum) {
            return this.class.baseType.fridaAlias;
          } else {
            return "pointer";
          }
        default:
          return "pointer";
      }
    }
    get isByReference() {
      return this.name.endsWith("&");
    }
    get isPrimitive() {
      switch (this.enumValue) {
        case Il2Cpp.Type.Enum.BOOLEAN:
        case Il2Cpp.Type.Enum.CHAR:
        case Il2Cpp.Type.Enum.BYTE:
        case Il2Cpp.Type.Enum.UBYTE:
        case Il2Cpp.Type.Enum.SHORT:
        case Il2Cpp.Type.Enum.USHORT:
        case Il2Cpp.Type.Enum.INT:
        case Il2Cpp.Type.Enum.UINT:
        case Il2Cpp.Type.Enum.LONG:
        case Il2Cpp.Type.Enum.ULONG:
        case Il2Cpp.Type.Enum.FLOAT:
        case Il2Cpp.Type.Enum.DOUBLE:
        case Il2Cpp.Type.Enum.NINT:
        case Il2Cpp.Type.Enum.NUINT:
          return true;
        default:
          return false;
      }
    }
    get name() {
      try {
        const _0x5cfd1d = Il2Cpp.exports.typeGetName(this);
        try {
          return _0x5cfd1d.readUtf8String();
        } finally {
          Il2Cpp.free(_0x5cfd1d);
        }
      } catch (_0x221a27) {
        return "Error: ToString failed";
      }
    }
    get object() {
      return new Il2Cpp.Object(Il2Cpp.exports.typeGetObject(this));
    }
    get enumValue() {
      return Il2Cpp.exports.typeGetTypeEnum(this);
    }
    is(_0x445652) {
      if (Il2Cpp.exports.typeEquals.isNull()) {
        return this.object.method("Equals").invoke(_0x445652.object);
      }
      return !!Il2Cpp.exports.typeEquals(this, _0x445652);
    }
    toString() {
      return this.name;
    }
  };
  __decorate([lazy], _0x191865.prototype, "class", null);
  __decorate([lazy], _0x191865.prototype, "fridaAlias", null);
  __decorate([lazy], _0x191865.prototype, "isByReference", null);
  __decorate([lazy], _0x191865.prototype, "isPrimitive", null);
  __decorate([lazy], _0x191865.prototype, "name", null);
  __decorate([lazy], _0x191865.prototype, "object", null);
  __decorate([lazy], _0x191865.prototype, "enumValue", null);
  __decorate([lazy], _0x191865, "Enum", null);
  _0x191865 = __decorate([recycle], _0x191865);
  Il2Cpp.Type = _0x191865;
})((Il2Cpp ||= {}));
var Il2Cpp;
(function (Il2Cpp) {
  class _0x261aa7 extends NativeStruct {
    constructor(_0x570d10, _0x538931) {
      super(_0x570d10);
      this.type = _0x538931;
    }
    box() {
      return new Il2Cpp.Object(Il2Cpp.exports.valueTypeBox(this.type.class, this));
    }
    field(_0xb71c09) {
      return (
        this.tryField(_0xb71c09) ??
        raise(
          "couldn't find non-static field " +
            _0xb71c09 +
            " in hierarchy of class " +
            this.type.name,
        )
      );
    }
    method(_0x311759, _0x5e195e = -1) {
      return (
        this.tryMethod(_0x311759, _0x5e195e) ??
        raise(
          "couldn't find non-static method " +
            _0x311759 +
            " in hierarchy of class " +
            this.type.name,
        )
      );
    }
    tryField(_0x5786eb) {
      const _0x1e1874 = this.type.class.tryField(_0x5786eb);
      if (_0x1e1874?.isStatic) {
        for (const _0x387145 of this.type.class.hierarchy()) {
          for (const _0x326835 of _0x387145.fields) {
            if (_0x326835.name == _0x5786eb && !_0x326835.isStatic) {
              return _0x326835.bind(this);
            }
          }
        }
        return undefined;
      }
      if (_0x1e1874 === null || _0x1e1874 === undefined) {
        return undefined;
      } else {
        return _0x1e1874.bind(this);
      }
    }
    tryMethod(_0x5919dd, _0x4c5fb0 = -1) {
      const _0x132031 = this.type.class.tryMethod(_0x5919dd, _0x4c5fb0);
      if (_0x132031?.isStatic) {
        for (const _0x3e33be of this.type.class.hierarchy()) {
          for (const _0x3b726f of _0x3e33be.methods) {
            if (
              _0x3b726f.name == _0x5919dd &&
              !_0x3b726f.isStatic &&
              (_0x4c5fb0 < 0 || _0x3b726f.parameterCount == _0x4c5fb0)
            ) {
              return _0x3b726f.bind(this);
            }
          }
        }
        return undefined;
      }
      if (_0x132031 === null || _0x132031 === undefined) {
        return undefined;
      } else {
        return _0x132031.bind(this);
      }
    }
    toString() {
      const _0x2e1054 = this.method("ToString", 0);
      if (this.isNull()) {
        return "null";
      } else if (_0x2e1054.class.isValueType) {
        return _0x2e1054.invoke().content ?? "null";
      } else {
        return this.box().toString() ?? "null";
      }
    }
  }
  Il2Cpp.ValueType = _0x261aa7;
})((Il2Cpp ||= {}));
globalThis.Il2Cpp = Il2Cpp;
Il2Cpp.$config.exports = {
  il2cpp_init: () => Il2Cpp.module.findExportByName("KtsFmZNLMgp"),
  il2cpp_init_utf16: () => Il2Cpp.module.findExportByName("rCmwlvDGFVC"),
  il2cpp_shutdown: () => Il2Cpp.module.findExportByName("KSiJHnxniZR"),
  il2cpp_set_config_dir: () => Il2Cpp.module.findExportByName("ZGTDWnIEgvz"),
  il2cpp_set_data_dir: () => Il2Cpp.module.findExportByName("xkpXmeZyBWU"),
  il2cpp_set_temp_dir: () => Il2Cpp.module.findExportByName("ARonOHiBDGz"),
  il2cpp_set_commandline_arguments: () => Il2Cpp.module.findExportByName("qbACwbIcWhe"),
  il2cpp_set_commandline_arguments_utf16: () => Il2Cpp.module.findExportByName("iMewdPFxcWO"),
  il2cpp_set_config_utf16: () => Il2Cpp.module.findExportByName("CDKLfVaUpte"),
  il2cpp_set_config: () => Il2Cpp.module.findExportByName("WCigKCjtctT"),
  il2cpp_set_memory_callbacks: () => Il2Cpp.module.findExportByName("wIM_rIwxKbV"),
  il2cpp_memory_pool_set_region_size: () => Il2Cpp.module.findExportByName("UeWqmnSuauY"),
  il2cpp_memory_pool_get_region_size: () => Il2Cpp.module.findExportByName("YkYXucazFZq"),
  il2cpp_get_corlib: () => Il2Cpp.module.findExportByName("IQTybDbdgeX"),
  il2cpp_add_internal_call: () => Il2Cpp.module.findExportByName("qyFMgojsDje"),
  il2cpp_resolve_icall: () => Il2Cpp.module.findExportByName("vOEtYzqP_wC"),
  il2cpp_alloc: () => Il2Cpp.module.findExportByName("tpyJBznSoAI"),
  il2cpp_free: () => Il2Cpp.module.findExportByName("XXNRTuyNXVs"),
  il2cpp_array_class_get: () => Il2Cpp.module.findExportByName("SmpMSbZPsMj"),
  il2cpp_array_length: () => Il2Cpp.module.findExportByName("AMKsKdTnbEc"),
  il2cpp_array_get_byte_length: () => Il2Cpp.module.findExportByName("NyvaKEajTbX"),
  il2cpp_array_new: () => Il2Cpp.module.findExportByName("upmdSrNGOqk"),
  il2cpp_array_new_specific: () => Il2Cpp.module.findExportByName("jkQtWpCmozW"),
  il2cpp_array_new_full: () => Il2Cpp.module.findExportByName("zmMNz_XtWfG"),
  il2cpp_bounded_array_class_get: () => Il2Cpp.module.findExportByName("GETeDafkjtK"),
  il2cpp_array_element_size: () => Il2Cpp.module.findExportByName("JGCJpzDuETo"),
  il2cpp_assembly_get_image: () => Il2Cpp.module.findExportByName("flwAPtoqeay"),
  il2cpp_class_for_each: () => Il2Cpp.module.findExportByName("_ehBAUQROru"),
  il2cpp_class_enum_basetype: () => Il2Cpp.module.findExportByName("KQWKgewSVtu"),
  il2cpp_class_is_inited: () => Il2Cpp.module.findExportByName("xzywhIjZAUf"),
  il2cpp_class_is_generic: () => Il2Cpp.module.findExportByName("PXIWcumcuxc"),
  il2cpp_class_is_inflated: () => Il2Cpp.module.findExportByName("juxaxbguEYP"),
  il2cpp_class_is_assignable_from: () => Il2Cpp.module.findExportByName("ivGZXXwviiS"),
  il2cpp_class_is_subclass_of: () => Il2Cpp.module.findExportByName("eqHmmaaJgYK"),
  il2cpp_class_has_parent: () => Il2Cpp.module.findExportByName("cZuydIMZcWD"),
  il2cpp_class_from_il2cpp_type: () => Il2Cpp.module.findExportByName("TcPDpKIkDBV"),
  il2cpp_class_from_name: () => Il2Cpp.module.findExportByName("jyabClchnew"),
  il2cpp_class_from_system_type: () => Il2Cpp.module.findExportByName("ngWITgmm_ei"),
  il2cpp_class_get_element_class: () => Il2Cpp.module.findExportByName("RxlTQrxoWUN"),
  il2cpp_class_get_events: () => Il2Cpp.module.findExportByName("TQDhfazJLjF"),
  il2cpp_class_get_fields: () => Il2Cpp.module.findExportByName("gyKmtGmiFTq"),
  il2cpp_class_get_nested_types: () => Il2Cpp.module.findExportByName("DvruesIMRrI"),
  il2cpp_class_get_interfaces: () => Il2Cpp.module.findExportByName("pmcUFUmrBrx"),
  il2cpp_class_get_properties: () => Il2Cpp.module.findExportByName("mlAGkEUodHL"),
  il2cpp_class_get_property_from_name: () => Il2Cpp.module.findExportByName("oDOoHptTMas"),
  il2cpp_class_get_field_from_name: () => Il2Cpp.module.findExportByName("DTHJHKDuIkx"),
  il2cpp_class_get_methods: () => Il2Cpp.module.findExportByName("hvm_wildROg"),
  il2cpp_class_get_method_from_name: () => Il2Cpp.module.findExportByName("bqQCExNjkPi"),
  il2cpp_class_get_name: () => Il2Cpp.module.findExportByName("yjnMDEndBXE"),
  il2cpp_type_get_name_chunked: () => Il2Cpp.module.findExportByName("TMZaHEJjPXd"),
  il2cpp_class_get_namespace: () => Il2Cpp.module.findExportByName("RbezXbpmGhl"),
  il2cpp_class_get_parent: () => Il2Cpp.module.findExportByName("aHxKrwuXhVe"),
  il2cpp_class_get_declaring_type: () => Il2Cpp.module.findExportByName("NOOwlNQjsf_"),
  il2cpp_class_instance_size: () => Il2Cpp.module.findExportByName("zPeJhirrTcs"),
  il2cpp_class_num_fields: () => Il2Cpp.module.findExportByName("ThRHmkmlFvO"),
  il2cpp_class_is_valuetype: () => Il2Cpp.module.findExportByName("gBXvnobjuZW"),
  il2cpp_class_value_size: () => Il2Cpp.module.findExportByName("mzFLdrQlkFO"),
  il2cpp_class_is_blittable: () => Il2Cpp.module.findExportByName("XDKmMNdSSBT"),
  il2cpp_class_get_flags: () => Il2Cpp.module.findExportByName("CjGAJWCoQii"),
  il2cpp_class_is_abstract: () => Il2Cpp.module.findExportByName("hlsQcIoNLDV"),
  il2cpp_class_is_interface: () => Il2Cpp.module.findExportByName("vuC_HrUhJub"),
  il2cpp_class_array_element_size: () => Il2Cpp.module.findExportByName("gXdlxJyVgbI"),
  il2cpp_class_from_type: () => Il2Cpp.module.findExportByName("PtIkrCNfgwy"),
  il2cpp_class_get_type: () => Il2Cpp.module.findExportByName("fthHrgYGIWj"),
  il2cpp_class_get_type_token: () => Il2Cpp.module.findExportByName("fJybgJftE_p"),
  il2cpp_class_has_attribute: () => Il2Cpp.module.findExportByName("hECRorLeARR"),
  il2cpp_class_has_references: () => Il2Cpp.module.findExportByName("JsNxYQOBhOx"),
  il2cpp_class_is_enum: () => Il2Cpp.module.findExportByName("OfgAylcmHgo"),
  il2cpp_class_get_image: () => Il2Cpp.module.findExportByName("vJXPovxHiXE"),
  il2cpp_class_get_assemblyname: () => Il2Cpp.module.findExportByName("VeoCJWyWsUs"),
  il2cpp_class_get_rank: () => Il2Cpp.module.findExportByName("ayVnkCPwGCN"),
  il2cpp_class_get_data_size: () => Il2Cpp.module.findExportByName("kkeANcfaAni"),
  il2cpp_class_get_static_field_data: () => Il2Cpp.module.findExportByName("lmkGKxLhy_j"),
  il2cpp_stats_dump_to_file: () => Il2Cpp.module.findExportByName("hNWtjCWl_uk"),
  il2cpp_stats_get_value: () => Il2Cpp.module.findExportByName("QFAHfDBsMRP"),
  il2cpp_domain_get: () => Il2Cpp.module.findExportByName("AMDnrxsGATe"),
  il2cpp_domain_assembly_open: () => Il2Cpp.module.findExportByName("AOWwHGdzZsp"),
  il2cpp_domain_get_assemblies: () => Il2Cpp.module.findExportByName("uGmIbEzrioV"),
  il2cpp_raise_exception: () => Il2Cpp.module.findExportByName("PrwifcDdwiR"),
  il2cpp_exception_from_name_msg: () => Il2Cpp.module.findExportByName("qTSdvPMLqkt"),
  il2cpp_get_exception_argument_null: () => Il2Cpp.module.findExportByName("CHiguLCnLNj"),
  il2cpp_format_exception: () => Il2Cpp.module.findExportByName("OwowNTSgHok"),
  il2cpp_format_stack_trace: () => Il2Cpp.module.findExportByName("CQixBGpRfgL"),
  il2cpp_unhandled_exception: () => Il2Cpp.module.findExportByName("ACRfTqiZUeX"),
  il2cpp_native_stack_trace: () => Il2Cpp.module.findExportByName("uonictGRPKa"),
  il2cpp_field_get_flags: () => Il2Cpp.module.findExportByName("ILyBwONLjxr"),
  il2cpp_field_get_from_reflection: () => Il2Cpp.module.findExportByName("HproVuNreMZ"),
  il2cpp_field_get_name: () => Il2Cpp.module.findExportByName("aeBtWqOnmaR"),
  il2cpp_field_get_parent: () => Il2Cpp.module.findExportByName("nzACPYMRRpE"),
  il2cpp_field_get_object: () => Il2Cpp.module.findExportByName("DOYzFcDq_we"),
  il2cpp_field_get_offset: () => Il2Cpp.module.findExportByName("YYnZ_bizqh_"),
  il2cpp_field_get_type: () => Il2Cpp.module.findExportByName("mzwTEvaXyBg"),
  il2cpp_field_get_value: () => Il2Cpp.module.findExportByName("yUXpsxHhPIf"),
  il2cpp_field_get_value_object: () => Il2Cpp.module.findExportByName("aZepZeHSGdd"),
  il2cpp_field_has_attribute: () => Il2Cpp.module.findExportByName("aIGbPTaiMUH"),
  il2cpp_field_set_value: () => Il2Cpp.module.findExportByName("DsGL_waPAfe"),
  il2cpp_field_static_get_value: () => Il2Cpp.module.findExportByName("mFPddghFAqV"),
  il2cpp_field_static_set_value: () => Il2Cpp.module.findExportByName("ioQBsxdwhYD"),
  il2cpp_field_set_value_object: () => Il2Cpp.module.findExportByName("auxLNodTpzn"),
  il2cpp_field_is_literal: () => Il2Cpp.module.findExportByName("syhCuXyJjvn"),
  il2cpp_gc_collect: () => Il2Cpp.module.findExportByName("iOrLwRCIJBW"),
  il2cpp_gc_collect_a_little: () => Il2Cpp.module.findExportByName("MWCUaHuKZdG"),
  il2cpp_gc_start_incremental_collection: () => Il2Cpp.module.findExportByName("MBcJXRMiAae"),
  il2cpp_gc_disable: () => Il2Cpp.module.findExportByName("FZdjZdDcViu"),
  il2cpp_gc_enable: () => Il2Cpp.module.findExportByName("jFiaCwUcAWH"),
  il2cpp_gc_is_disabled: () => Il2Cpp.module.findExportByName("_TFEjQGvfLF"),
  il2cpp_gc_set_mode: () => Il2Cpp.module.findExportByName("klfmLilbzxK"),
  il2cpp_gc_get_max_time_slice_ns: () => Il2Cpp.module.findExportByName("LtznnkrbFWC"),
  il2cpp_gc_set_max_time_slice_ns: () => Il2Cpp.module.findExportByName("UrWDjHQYZeX"),
  il2cpp_gc_is_incremental: () => Il2Cpp.module.findExportByName("kmxCUp_VVDy"),
  il2cpp_gc_get_used_size: () => Il2Cpp.module.findExportByName("RwplKuTObej"),
  il2cpp_gc_get_heap_size: () => Il2Cpp.module.findExportByName("LJXbvovLkiP"),
  il2cpp_gc_wbarrier_set_field: () => Il2Cpp.module.findExportByName("wuNxPbqdq_R"),
  il2cpp_gc_has_strict_wbarriers: () => Il2Cpp.module.findExportByName("KT_sOCcDoKI"),
  il2cpp_gc_set_external_allocation_tracker: () => Il2Cpp.module.findExportByName("KDqEWzI_Ncr"),
  il2cpp_gc_set_external_wbarrier_tracker: () => Il2Cpp.module.findExportByName("_tkN_yBtopt"),
  il2cpp_gc_foreach_heap: () => Il2Cpp.module.findExportByName("WaxsIRwyWfS"),
  il2cpp_stop_gc_world: () => Il2Cpp.module.findExportByName("QTHADUqaaQc"),
  il2cpp_start_gc_world: () => Il2Cpp.module.findExportByName("hcpPnGbMdZM"),
  il2cpp_gc_alloc_fixed: () => Il2Cpp.module.findExportByName("bTSnKIXRNdm"),
  il2cpp_gc_free_fixed: () => Il2Cpp.module.findExportByName("WwzorTQfnGM"),
  il2cpp_gchandle_new: () => Il2Cpp.module.findExportByName("qCfZpxghBlw"),
  il2cpp_gchandle_new_weakref: () => Il2Cpp.module.findExportByName("rRmAUVemSZP"),
  il2cpp_gchandle_get_target: () => Il2Cpp.module.findExportByName("IyHrvncNKiT"),
  il2cpp_gchandle_free: () => Il2Cpp.module.findExportByName("YkCOwMTCLCt"),
  il2cpp_gchandle_foreach_get_target: () => Il2Cpp.module.findExportByName("KvlRQblfdvO"),
  il2cpp_object_header_size: () => Il2Cpp.module.findExportByName("tJJGOQHXpXG"),
  il2cpp_array_object_header_size: () => Il2Cpp.module.findExportByName("htGRExAvhWu"),
  il2cpp_offset_of_array_length_in_array_object_header: () =>
    Il2Cpp.module.findExportByName("oQyLnrgiATc"),
  il2cpp_offset_of_array_bounds_in_array_object_header: () =>
    Il2Cpp.module.findExportByName("jjnwaZzcgMK"),
  il2cpp_allocation_granularity: () => Il2Cpp.module.findExportByName("uQDAUVxyoSA"),
  il2cpp_unity_liveness_allocate_struct: () => Il2Cpp.module.findExportByName("KtiKzLjelNO"),
  il2cpp_unity_liveness_calculation_from_root: () => Il2Cpp.module.findExportByName("_QCFsqYfjAB"),
  il2cpp_unity_liveness_calculation_from_statics: () =>
    Il2Cpp.module.findExportByName("PJHcfTXmtDm"),
  il2cpp_unity_liveness_finalize: () => Il2Cpp.module.findExportByName("owUnMFAzQUN"),
  il2cpp_unity_liveness_free_struct: () => Il2Cpp.module.findExportByName("fodjMnkleBj"),
  il2cpp_method_get_return_type: () => Il2Cpp.module.findExportByName("JzYTTuub_td"),
  il2cpp_method_get_declaring_type: () => Il2Cpp.module.findExportByName("fCqeUHZSxXU"),
  il2cpp_method_get_name: () => Il2Cpp.module.findExportByName("FiBgzFAIy_b"),
  il2cpp_method_get_from_reflection: () => Il2Cpp.module.findExportByName("jrerSAqvsSS"),
  il2cpp_method_get_object: () => Il2Cpp.module.findExportByName("r_uDscKtmDN"),
  il2cpp_method_is_generic: () => Il2Cpp.module.findExportByName("yUvOxvQaawH"),
  il2cpp_method_is_inflated: () => Il2Cpp.module.findExportByName("VaQsBwCnDCF"),
  il2cpp_method_is_instance: () => Il2Cpp.module.findExportByName("xYQRUIvTUab"),
  il2cpp_method_get_param_count: () => Il2Cpp.module.findExportByName("wDLWWzLG_Xj"),
  il2cpp_method_get_param: () => Il2Cpp.module.findExportByName("TdyPYaugEie"),
  il2cpp_method_get_class: () => Il2Cpp.module.findExportByName("GqcfnluhZiw"),
  il2cpp_method_has_attribute: () => Il2Cpp.module.findExportByName("PLTEZnOLwFa"),
  il2cpp_method_get_flags: () => Il2Cpp.module.findExportByName("GMkRMEh_zog"),
  il2cpp_method_get_token: () => Il2Cpp.module.findExportByName("GdeNDoEOiMt"),
  il2cpp_method_get_param_name: () => Il2Cpp.module.findExportByName("KZKZpWrFegt"),
  il2cpp_property_get_flags: () => Il2Cpp.module.findExportByName("hWvTdtBTQvC"),
  il2cpp_property_get_get_method: () => Il2Cpp.module.findExportByName("dwYNfDGtXgj"),
  il2cpp_property_get_set_method: () => Il2Cpp.module.findExportByName("ByqDKDKNmFB"),
  il2cpp_property_get_name: () => Il2Cpp.module.findExportByName("VHWrrjWeqYl"),
  il2cpp_property_get_parent: () => Il2Cpp.module.findExportByName("deEYNmXFKLa"),
  il2cpp_object_get_class: () => Il2Cpp.module.findExportByName("TIWpxZenagd"),
  il2cpp_object_get_size: () => Il2Cpp.module.findExportByName("vAbZsziSuQm"),
  il2cpp_object_get_virtual_method: () => Il2Cpp.module.findExportByName("WmtoQRIsPeY"),
  il2cpp_object_new: () => Il2Cpp.module.findExportByName("XP_dTXjPmZw"),
  il2cpp_object_unbox: () => Il2Cpp.module.findExportByName("EeBCvxdcgcL"),
  il2cpp_value_box: () => Il2Cpp.module.findExportByName("hffkFzgUKnM"),
  il2cpp_monitor_enter: () => Il2Cpp.module.findExportByName("oEUoXyDmRSX"),
  il2cpp_monitor_try_enter: () => Il2Cpp.module.findExportByName("uXibsyqsmFP"),
  il2cpp_monitor_exit: () => Il2Cpp.module.findExportByName("rGYgmjnUNZi"),
  il2cpp_monitor_pulse: () => Il2Cpp.module.findExportByName("lTurZbETBco"),
  il2cpp_monitor_pulse_all: () => Il2Cpp.module.findExportByName("wLeJzgMKKql"),
  il2cpp_monitor_wait: () => Il2Cpp.module.findExportByName("IwNVwqhOWyz"),
  il2cpp_monitor_try_wait: () => Il2Cpp.module.findExportByName("VhetCnYa_ku"),
  il2cpp_runtime_invoke: () => Il2Cpp.module.findExportByName("JuZhqTCbwaN"),
  il2cpp_runtime_invoke_convert_args: () => Il2Cpp.module.findExportByName("BuIwnanXKwo"),
  il2cpp_runtime_class_init: () => Il2Cpp.module.findExportByName("IqNbTfhCgfb"),
  il2cpp_runtime_object_init: () => Il2Cpp.module.findExportByName("NlzYojSHZ_A"),
  il2cpp_runtime_object_init_exception: () => Il2Cpp.module.findExportByName("FYxKWTkmPTO"),
  il2cpp_runtime_unhandled_exception_policy_set: () =>
    Il2Cpp.module.findExportByName("kHRP_zkUAyM"),
  il2cpp_string_length: () => Il2Cpp.module.findExportByName("cgldvXYWsXQ"),
  il2cpp_string_chars: () => Il2Cpp.module.findExportByName("zQjhgVQpmZF"),
  il2cpp_string_new: () => Il2Cpp.module.findExportByName("KSo_OEFFent"),
  il2cpp_string_new_len: () => Il2Cpp.module.findExportByName("QIYhWTSDpmb"),
  il2cpp_string_new_utf16: () => Il2Cpp.module.findExportByName("RJuOEndgoS_"),
  il2cpp_string_new_wrapper: () => Il2Cpp.module.findExportByName("PAFXHgpGRnR"),
  il2cpp_string_intern: () => Il2Cpp.module.findExportByName("RWeaUGJaWry"),
  il2cpp_string_is_interned: () => Il2Cpp.module.findExportByName("ZHW_ZSAWlVa"),
  il2cpp_thread_current: () => Il2Cpp.module.findExportByName("OHzvzUqyHVF"),
  il2cpp_thread_attach: () => Il2Cpp.module.findExportByName("f_IfVOBJGDG"),
  il2cpp_thread_detach: () => Il2Cpp.module.findExportByName("WodzlQNcPwd"),
  il2cpp_is_vm_thread: () => Il2Cpp.module.findExportByName("SSWvhYxmbyC"),
  il2cpp_current_thread_walk_frame_stack: () => Il2Cpp.module.findExportByName("WSmUVmKXtiD"),
  il2cpp_thread_walk_frame_stack: () => Il2Cpp.module.findExportByName("MGeyEhgikjq"),
  il2cpp_current_thread_get_top_frame: () => Il2Cpp.module.findExportByName("OnyZAjoRfOv"),
  il2cpp_thread_get_top_frame: () => Il2Cpp.module.findExportByName("lACwFjlVtqb"),
  il2cpp_current_thread_get_frame_at: () => Il2Cpp.module.findExportByName("UhVgMmFXZnW"),
  il2cpp_thread_get_frame_at: () => Il2Cpp.module.findExportByName("z_hv_OvSFbR"),
  il2cpp_current_thread_get_stack_depth: () => Il2Cpp.module.findExportByName("mqZKpoVRCwA"),
  il2cpp_thread_get_stack_depth: () => Il2Cpp.module.findExportByName("OzctVvmzkLH"),
  il2cpp_override_stack_backtrace: () => Il2Cpp.module.findExportByName("jAWXuZ_xKkh"),
  il2cpp_type_get_object: () => Il2Cpp.module.findExportByName("LRDUsDwmECi"),
  il2cpp_type_get_type: () => Il2Cpp.module.findExportByName("ZylCHOLNuyy"),
  il2cpp_type_get_class_or_element_class: () => Il2Cpp.module.findExportByName("rvzJcuVvKBK"),
  il2cpp_type_get_name: () => Il2Cpp.module.findExportByName("qVyGsLzFDTS"),
  il2cpp_type_is_byref: () => Il2Cpp.module.findExportByName("nMiCMlDxCyP"),
  il2cpp_type_get_attrs: () => Il2Cpp.module.findExportByName("KwoXKhJWaak"),
  il2cpp_type_equals: () => Il2Cpp.module.findExportByName("bzYzIonLrVw"),
  il2cpp_type_get_assembly_qualified_name: () => Il2Cpp.module.findExportByName("RZGItiiOpuQ"),
  il2cpp_type_get_reflection_name: () => Il2Cpp.module.findExportByName("MSNHWyXTPjC"),
  il2cpp_type_is_static: () => Il2Cpp.module.findExportByName("ppOwNCrzmGw"),
  il2cpp_type_is_pointer_type: () => Il2Cpp.module.findExportByName("LncyNuMEP_k"),
  il2cpp_image_get_assembly: () => Il2Cpp.module.findExportByName("AtfFr_CymwQ"),
  il2cpp_image_get_name: () => Il2Cpp.module.findExportByName("VgNKsKgTEQw"),
  il2cpp_image_get_filename: () => Il2Cpp.module.findExportByName("tvrrGHqDWbK"),
  il2cpp_image_get_entry_point: () => Il2Cpp.module.findExportByName("zMNTpUHEugg"),
  il2cpp_image_get_class_count: () => Il2Cpp.module.findExportByName("eIJZdtcBuId"),
  il2cpp_image_get_class: () => Il2Cpp.module.findExportByName("GgQnoUszSGE"),
  il2cpp_capture_memory_snapshot: () => Il2Cpp.module.findExportByName("HqPoNnhnicc"),
  il2cpp_free_captured_memory_snapshot: () => Il2Cpp.module.findExportByName("cSoPQQHjkgq"),
  il2cpp_set_find_plugin_callback: () => Il2Cpp.module.findExportByName("FdPqNPxOsmW"),
  il2cpp_register_log_callback: () => Il2Cpp.module.findExportByName("hIASBIebrIY"),
  il2cpp_debugger_set_agent_options: () => Il2Cpp.module.findExportByName("htr_yzJWgxk"),
  il2cpp_is_debugger_attached: () => Il2Cpp.module.findExportByName("TATugoQGbJg"),
  il2cpp_register_debugger_agent_transport: () => Il2Cpp.module.findExportByName("VHuvgXc_BFG"),
  il2cpp_debug_foreach_method: () => Il2Cpp.module.findExportByName("WggYdvWwcTG"),
  il2cpp_debug_get_method_info: () => Il2Cpp.module.findExportByName("PjjEsAdcgAv"),
  il2cpp_unity_install_unitytls_interface: () => Il2Cpp.module.findExportByName("eBGlzFZyQWL"),
  il2cpp_custom_attrs_from_class: () => Il2Cpp.module.findExportByName("nBQbedmaQil"),
  il2cpp_custom_attrs_from_method: () => Il2Cpp.module.findExportByName("SMLtWlAfTKj"),
  il2cpp_custom_attrs_from_field: () => Il2Cpp.module.findExportByName("hoiPvUFyFNd"),
  il2cpp_custom_attrs_get_attr: () => Il2Cpp.module.findExportByName("BEeGKaSQXBQ"),
  il2cpp_custom_attrs_has_attr: () => Il2Cpp.module.findExportByName("kTetrGamlWw"),
  il2cpp_custom_attrs_construct: () => Il2Cpp.module.findExportByName("kwQtBuQIsHG"),
  il2cpp_custom_attrs_free: () => Il2Cpp.module.findExportByName("xkeyBHOFqpQ"),
  il2cpp_class_set_userdata: () => Il2Cpp.module.findExportByName("Ytgotnbaz_q"),
  il2cpp_class_get_userdata_offset: () => Il2Cpp.module.findExportByName("wYKXcFzYNNL"),
  il2cpp_set_default_thread_affinity: () => Il2Cpp.module.findExportByName("zn_VVZohmVY"),
  il2cpp_unity_set_android_network_up_state_func: () =>
    Il2Cpp.module.findExportByName("QsGgriYJXMT"),
};
function getPlayerName(_0x255489) {
  var _0xe78ef8;
  try {
    return (
      _0x255489.method("get_displayName").invoke()?.content ??
      ((_0xe78ef8 = _0x255489.method("get_playerId").invoke()) === null || _0xe78ef8 === undefined
        ? undefined
        : _0xe78ef8.toString()) ??
      "?"
    );
  } catch (_0x364321) {
    return "?";
  }
}
const _errorLog = [];
let _errorLogEnabled = true;
function diagnoseError(_0x5dec7e, _0x58f70a) {
  const _0x83f52 = _0x58f70a && _0x58f70a.message ? _0x58f70a.message : String(_0x58f70a);
  const _0x19da64 =
    _0x83f52.match(/couldn't find (?:non-static )?(?:class|type) ([^\s]+)/i) ??
    _0x83f52.match(/class ([^\s]+) not found/i);
  if (_0x19da64) {
    const _0x2e500a = _0x19da64[1];
    return (
      'CLASS NOT FOUND: "' +
      _0x2e500a +
      '"\n  → The game removed or renamed this class in the current build.\n' +
      ('  → Open the dump and search for "' +
        _0x2e500a.split(".").pop() +
        '" to find the new name.\n') +
      "  → If it's gone entirely, wrap the call in: if (YourClass) { ... }"
    );
  }
  const _0x3a6641 =
    _0x83f52.match(
      /couldn't find (?:non-static )?method ([^\s]+) in (?:hierarchy of )?class ([^\s]+)/i,
    ) ?? _0x83f52.match(/method ([^\s]+) not found in ([^\s]+)/i);
  if (_0x3a6641) {
    const _0x3c8240 = _0x3a6641[1];
    const _0x10b169 = _0x3a6641[2];
    return (
      'METHOD NOT FOUND: "' +
      _0x3c8240 +
      '" on "' +
      _0x10b169 +
      '"\n  → The game renamed or removed this method in the current build.\n' +
      ('  → Search the dump for "class ' +
        _0x10b169 +
        '" and look for a method that does the same thing.\n') +
      "  → Common renames: AddToBagAck→CheckToAddItem, get_isDevOnly→flags&16, get_Count→GetEnumerator.\n  → Wrap in try/catch if the method is optional."
    );
  }
  const _0x19b60b =
    _0x83f52.match(/couldn't find field ([^\s]+) in class ([^\s]+)/i) ??
    _0x83f52.match(/field ([^\s]+) not found/i);
  if (_0x19b60b) {
    const _0x3b5cd9 = _0x19b60b[1];
    const _0x557fb7 = _0x19b60b[2] ?? "?";
    return (
      'FIELD NOT FOUND: "' +
      _0x3b5cd9 +
      '" on "' +
      _0x557fb7 +
      '"\n' +
      ('  → Search the dump for "class ' + _0x557fb7 + '" and find the new field name.\n') +
      '  → Fields are often renamed with a prefix e.g. "_" or "<X>k__BackingField".\n' +
      ('  → Try using method("get_' + _0x3b5cd9 + '").invoke() if a getter exists instead.')
    );
  }
  if (
    _0x83f52.includes("isNull") ||
    _0x83f52.includes("null reference") ||
    _0x83f52.match(/cannot read propert/i)
  ) {
    return "NULL REFERENCE\n  → An object was null when you tried to use it.\n  → Add a null check: if (!obj || obj.isNull()) return;\n  → Make sure the class instance/singleton is available at the time of the call.\n  → If it's a hook, the class may not be loaded yet — move the hook later in execution.";
  }
  if (
    _0x83f52.includes("parameterCount") ||
    _0x83f52.includes("overload") ||
    _0x83f52.match(/no method with \d+ param/i)
  ) {
    return 'WRONG PARAMETER COUNT / OVERLOAD\n  → The method signature changed. Check the dump for how many params the method takes now.\n  → Use method("name", N) where N = number of parameters.\n  → If multiple overloads exist, iterate .overloads() to find the right one.';
  }
  if (_0x83f52.includes("not a function") || _0x83f52.match(/cannot.*invoke/i)) {
    return 'INVOKE ERROR\n  → You called .invoke() on something that is not a method.\n  → Check that the method lookup succeeded before calling invoke().\n  → Try: const m = cls.method("name"); if (m) m.invoke();';
  }
  if (
    _0x83f52.includes("assembly") &&
    (_0x83f52.includes("not found") || _0x83f52.includes("couldn't find"))
  ) {
    const _0xd0b14a = _0x83f52.match(/assembly[:\s]+([^\s"]+)/i);
    const _0x122498 = _0xd0b14a ? _0xd0b14a[1] : "?";
    return (
      'ASSEMBLY NOT FOUND: "' +
      _0x122498 +
      '"\n  → The DLL was renamed or removed.\n  → Check Il2Cpp.domain.assemblies for the correct assembly name.\n  → Wrap: try { images["X"] = Il2Cpp.domain.assembly("X").image; } catch(_) {}'
    );
  }
  return (
    "UNKNOWN ERROR: " +
    _0x83f52 +
    '\n  → Check the Frida log for the full stack trace.\n  → If it says "Il2CppError", cross-reference the class/method name in the game dump.\n  → If it says "TypeError", a variable is null, undefined, or the wrong type.'
  );
}
function smartError(_0x4fda84, _0x3fa173) {
  if (!_errorLogEnabled) {
    console.error("[" + _0x4fda84 + "]", _0x3fa173);
    return;
  }
  const _0x57ec4f = diagnoseError(_0x4fda84, _0x3fa173);
  const _0x1e0167 = _0x3fa173 && _0x3fa173.message ? _0x3fa173.message : String(_0x3fa173);
  const _0x505cc7 = Date.now();
  const _0x5356e9 = _0x3fa173 && _0x3fa173.stack ? _0x3fa173.stack : "";
  _errorLog.push({
    time: _0x505cc7,
    tag: _0x4fda84,
    msg: _0x1e0167,
    fix: _0x57ec4f,
  });
  console.error(
    "\n╔═══════════════════════════════════════════════════════════════════════════\n" +
      ("║  ERROR [" + _0x4fda84 + "]\n") +
      "║  ─────────────────────────────────────────────────────────────────────────\n" +
      ("║  " + _0x1e0167.split("\n").join("\n║  ") + "\n") +
      "╠═══════════════════════════════════════════════════════════════════════════\n║  STACK TRACE:\n" +
      _0x5356e9
        .split("\n")
        .map((_0x594e51) => "║  " + _0x594e51)
        .join("\n") +
      "\n╠═══════════════════════════════════════════════════════════════════════════\n║  HOW TO FIX:\n" +
      ("║  " + _0x57ec4f.replace(/\n/g, "\n║  ") + "\n") +
      "╚═══════════════════════════════════════════════════════════════════════════",
  );
}
function printErrorLog() {
  if (_errorLog.length === 0) {
    console.log("[ErrorLog] No errors recorded.");
    return;
  }
  console.log(
    "\n╔═ ERROR LOG (" +
      _errorLog.length +
      " error" +
      (_errorLog.length === 1 ? "" : "s") +
      ") ═══════════════════════",
  );
  _errorLog.forEach((_0x94f890, _0x4d5462) => {
    console.log(
      "║ [" +
        (_0x4d5462 + 1) +
        "] tag=" +
        _0x94f890.tag +
        "\n" +
        ("║     err=" + _0x94f890.msg + "\n") +
        ("║     fix=" + _0x94f890.fix.split("\n")[0]),
    );
  });
  console.log("╚════════════════════════════════════════════════════");
}
function clearErrorLog() {
  _errorLog.length = 0;
  console.log("[ErrorLog] Log cleared.");
}
let uxSelectedObject = null;
let uxSelectedName = "none";
let freecamActive = false;
let freecamObj = null;
let freecamPos = null;
function uxGetTransform(_0x3a7f91) {
  try {
    return _0x3a7f91.method("get_transform").invoke();
  } catch (_0x37dfb7) {
    return null;
  }
}
function uxVec3Str(_0x59656e) {
  try {
    const _0x4b2d96 = _0x59656e.field("x").value.toFixed(3);
    const _0x271902 = _0x59656e.field("y").value.toFixed(3);
    const _0x37d91f = _0x59656e.field("z").value.toFixed(3);
    return "(" + _0x4b2d96 + ", " + _0x271902 + ", " + _0x37d91f + ")";
  } catch (_0x1139ab) {
    return "(?,?,?)";
  }
}
function uxGetComponentNames(_0x336947) {
  const _0x2d479b = [];
  try {
    const _0x4b7361 = _0x336947
      .method("GetComponentsInChildren", 1)
      .inflate(
        Il2Cpp.domain.assembly("UnityEngine.CoreModule").image.class("UnityEngine.Component"),
      )
      .invoke(false);
    if (!_0x4b7361 || _0x4b7361.isNull()) {
      return _0x2d479b;
    }
    const _0x51892b = _0x4b7361.length;
    for (let _0x3e4a9c = 0; _0x3e4a9c < Math.min(_0x51892b, 64); _0x3e4a9c++) {
      try {
        const _0x949c5d = _0x4b7361.method("get_Item").invoke(_0x3e4a9c);
        const _0x3d23b4 =
          _0x949c5d.method("GetType").invoke().method("get_Name").invoke()?.content ?? "?";
        _0x2d479b.push(_0x3d23b4);
      } catch (_0xbea8a0) {}
    }
  } catch (_0x1a75fe) {}
  return _0x2d479b;
}
const itemIDs = [
  "item_ac_cola",
  "item_alien_cube",
  "item_alphablade",
  "item_ampbattery",
  "item_ampbattery_mega",
  "item_anti_gravity_grenade",
  "item_apple",
  "item_arena_pistol",
  "item_arena_shotgun",
  "item_arrow",
  "item_arrow_bomb",
  "item_arrow_heart",
  "item_arrow_lightbulb",
  "item_arrow_teleport",
  "item_axe",
  "item_backpack",
  "item_backpack_black",
  "item_backpack_fish",
  "item_backpack_green",
  "item_backpack_large_base",
  "item_backpack_large_basketball",
  "item_backpack_large_clover",
  "item_backpack_monkey",
  "item_backpack_pink",
  "item_backpack_realistic",
  "item_backpack_small_base",
  "item_backpack_space",
  "item_backpack_white",
  "item_backpack_with_flashlight",
  "item_bait_beetle",
  "item_bait_fly",
  "item_bait_glowworm",
  "item_bait_magmar_ball",
  "item_bait_mouse_trap",
  "item_bait_sardine",
  "item_bait_shell",
  "item_bait_starfish",
  "item_bait_wallet",
  "item_balloon",
  "item_balloon_heart",
  "item_bamboo_fishing_rod",
  "item_banana",
  "item_banana_chips",
  "item_baseball_bat",
  "item_basic_fishing_rod",
  "item_batterycell_hydra",
  "item_beans",
  "item_big_cup",
  "item_bighead_larva",
  "item_bloodlust_vial",
  "item_boombox",
  "item_boombox_fishing",
  "item_boombox_neon",
  "item_boomerang",
  "item_box_fan",
  "item_brain_chunk",
  "item_brainslug_blue",
  "item_brainslug_green",
  "item_brainslug_pink",
  "item_brick",
  "item_broccoli_grenade",
  "item_broccoli_shrink_grenade",
  "item_broom",
  "item_broom_halloween",
  "item_bubble_gun",
  "item_bubble_staff",
  "item_burrito",
  "item_butcherpipe",
  "item_butcherspear",
  "item_butchersword",
  "item_calculator",
  "item_cardboard_box",
  "item_cardboard_dragon_body",
  "item_cardboard_dragon_head",
  "item_carrot",
  "item_ceo_plaque",
  "item_chakra",
  "item_clapper",
  "item_cluster_grenade",
  "item_coconut_shell",
  "item_cola",
  "item_cola_large",
  "item_company_ration",
  "item_company_ration_heal",
  "item_cracker",
  "item_crate",
  "item_crossbow",
  "item_crossbow_heart",
  "item_crowbar",
  "item_cube_frame",
  "item_cubetrident",
  "item_cutie_dead",
  "item_d20",
  "item_deadmans_draw",
  "item_deadmans_draw_card",
  "item_deck_of_chances",
  "item_deck_of_chances_card",
  "item_demon_sword",
  "item_disc",
  "item_disposable_camera",
  "item_dragons_claw",
  "item_drill",
  "item_drill_fists",
  "item_drill_neon",
  "item_dwarven_hammer",
  "item_dynamite",
  "item_dynamite_cube",
  "item_easter_egg",
  "item_egg",
  "item_egg_easter_blue",
  "item_egg_easter_red",
  "item_egg_easter_yellow",
  "item_electrical_tape",
  "item_energy_axe",
  "item_energy_sword_dual",
  "item_energy_sword_green",
  "item_energy_sword_red",
  "item_eraser",
  "item_eye_googly",
  "item_film_reel",
  "item_finger_board",
  "item_fish_anglerfish",
  "item_fish_big_shark",
  "item_fish_boomfish",
  "item_fish_boot",
  "item_fish_bottled_message",
  "item_fish_carp",
  "item_fish_chewna",
  "item_fish_clam_hookshot",
  "item_fish_cowfish",
  "item_fish_crappie",
  "item_fish_crispie",
  "item_fish_cube",
  "item_fish_diamond_jade_koi",
  "item_fish_dollar_bill",
  "item_fish_dragonfish",
  "item_fish_fishsword",
  "item_fish_ghost_sword",
  "item_fish_gold_fish",
  "item_fish_hydracarp",
  "item_fish_irontusk",
  "item_fish_kissy",
  "item_fish_license_plate",
  "item_fish_magma_carp",
  "item_fish_nebula_fish",
  "item_fish_nutfish",
  "item_fish_pufferfish",
  "item_fish_rainbow_trout",
  "item_fish_redacted",
  "item_fish_rotten_fish",
  "item_fish_salmon",
  "item_fish_salmonster",
  "item_fish_scaldfish",
  "item_fish_seahorse",
  "item_fish_seamine",
  "item_fish_shellfish_shield",
  "item_fish_spicy_salmon",
  "item_fish_teeth",
  "item_fish_triclops",
  "item_fish_tuna",
  "item_fish_yellowcake",
  "item_fishing_terminal_bait_button",
  "item_flamethrower",
  "item_flamethrower_skull",
  "item_flamethrower_skull_ruby",
  "item_flaregun",
  "item_flashbang",
  "item_flashlight",
  "item_flashlight_mega",
  "item_flashlight_red",
  "item_flipflop_realistic",
  "item_floppy3",
  "item_floppy5",
  "item_football",
  "item_four_leaf_clover",
  "item_four_leaf_clover_gold",
  "item_four_leaf_radar",
  "item_friend_launcher",
  "item_frying_pan",
  "item_fungi_blue",
  "item_fungi_red",
  "item_gameboy",
  "item_glitched_banana",
  "item_glowing_fishing_rod",
  "item_glowstick",
  "item_goldbar",
  "item_goldcoin",
  "item_goop",
  "item_goopfish",
  "item_grappling_hook",
  "item_great_sword",
  "item_grenade",
  "item_grenade_gold",
  "item_grenade_launcher",
  "item_guided_boomerang",
  "item_hammer_candy_cane",
  "item_harddrive",
  "item_hatchet",
  "item_hawaiian_drum",
  "item_heart_chunk",
  "item_heart_gun",
  "item_heartchocolatebox",
  "item_hh_key",
  "item_hookshot",
  "item_hookshot_sword",
  "item_hot_cocoa",
  "item_hoverpad",
  "item_hydra",
  "item_impulse_grenade",
  "item_jetpack",
  "item_joystick",
  "item_joystick_inv_y",
  "item_katana_big",
  "item_katana_medium",
  "item_keycard",
  "item_lance",
  "item_landmine",
  "item_landmine_bee",
  "item_lantern_cny",
  "item_large_banana",
  "item_lava_fishing_rod",
  "item_love_grenade",
  "item_mage_pirate_sword",
  "item_mannequin_arm_left",
  "item_mannequin_arm_right",
  "item_mannequin_head",
  "item_mannequin_leg_left",
  "item_mannequin_leg_right",
  "item_mannequin_torso",
  "item_marshmallow_bunny_bomb",
  "item_megaphone",
  "item_metal_ball",
  "item_metal_ball_easter",
  "item_metal_ball_xmas",
  "item_metal_plate",
  "item_metal_plate_small",
  "item_metal_plate_xmas",
  "item_metal_rod",
  "item_metal_rod_curved",
  "item_metal_rod_easter",
  "item_metal_rod_small",
  "item_metal_rod_xmas",
  "item_metal_triangle",
  "item_midipad",
  "item_midipad_animal",
  "item_mining_laser",
  "item_mining_laser_orange",
  "item_momboss_box",
  "item_moneygun",
  "item_moonhorror_key",
  "item_moonrock",
  "item_moonrock_cheesy",
  "item_moonrock_friend",
  "item_motor",
  "item_mountain_key",
  "item_mug",
  "item_needle",
  "item_nut",
  "item_nut_drop",
  "item_ogre_hands",
  "item_orange",
  "item_ore_copper_l",
  "item_ore_copper_m",
  "item_ore_copper_s",
  "item_ore_gold_l",
  "item_ore_gold_m",
  "item_ore_gold_s",
  "item_ore_hell",
  "item_ore_silver_l",
  "item_ore_silver_m",
  "item_ore_silver_s",
  "item_painting_canvas",
  "item_paperpack",
  "item_pelican_case",
  "item_pennant_spring",
  "item_pickaxe",
  "item_pickaxe_cny",
  "item_pickaxe_cube",
  "item_pickaxe_realistic",
  "item_pickaxe_spacedwarf",
  "item_pinata_bat",
  "item_pineapple",
  "item_pipe",
  "item_pistol_dragon",
  "item_piston",
  "item_plank",
  "item_plank_easter",
  "item_plate_round",
  "item_plunger",
  "item_pogostick",
  "item_police_baton",
  "item_popcorn",
  "item_portable_safe_zone",
  "item_portable_teleporter",
  "item_prop_scanner",
  "item_pumpkin_bomb",
  "item_pumpkin_pie",
  "item_pumpkinjack",
  "item_pumpkinjack_small",
  "item_quest_gy_skull",
  "item_quest_gy_skull_special",
  "item_quest_hlal_brain",
  "item_quest_hlal_eyeball",
  "item_quest_hlal_flesh",
  "item_quest_hlal_heart",
  "item_quest_key_graveyard",
  "item_quest_vhs",
  "item_quest_vhs_backlots",
  "item_quest_vhs_basement",
  "item_quest_vhs_cave",
  "item_quest_vhs_circus_day",
  "item_quest_vhs_circus_ext",
  "item_quest_vhs_circus_fac",
  "item_quest_vhs_dam_facility",
  "item_quest_vhs_dam_servers",
  "item_quest_vhs_dark_forest",
  "item_quest_vhs_eden",
  "item_quest_vhs_forest",
  "item_quest_vhs_foundation",
  "item_quest_vhs_graveyard",
  "item_quest_vhs_haunted_house",
  "item_quest_vhs_hell",
  "item_quest_vhs_lab",
  "item_quest_vhs_lake",
  "item_quest_vhs_lobby",
  "item_quest_vhs_megalodon",
  "item_quest_vhs_megalodon_lake",
  "item_quest_vhs_mines",
  "item_quest_vhs_moon",
  "item_quest_vhs_moon_horror_rocket",
  "item_quest_vhs_mountain",
  "item_quest_vhs_mountainbot",
  "item_quest_vhs_mountainshack",
  "item_quest_vhs_mountainvault",
  "item_quest_vhs_obsidianhalls",
  "item_quest_vhs_odd_core",
  "item_quest_vhs_office",
  "item_quest_vhs_office_basement",
  "item_quest_vhs_powerplant_microwave",
  "item_quest_vhs_powerplant_reactorcore",
  "item_quest_vhs_powerplant_security",
  "item_quest_vhs_powerplant_supportfacility",
  "item_quest_vhs_sandbox",
  "item_quest_vhs_sewers",
  "item_quest_vhs_vhs-core",
  "item_quiver",
  "item_quiver_heart",
  "item_radiation_gun",
  "item_radioactive_broccoli",
  "item_radioactive_fishing_rod",
  "item_randombox_mobloot_big",
  "item_randombox_mobloot_medium",
  "item_randombox_mobloot_small",
  "item_randombox_mobloot_weapons",
  "item_randombox_mobloot_weapons_big",
  "item_randombox_mobloot_zombie",
  "item_rare_card",
  "item_remote_controller",
  "item_revolver",
  "item_revolver_ammo",
  "item_revolver_gold",
  "item_ring_buoy",
  "item_robo_monke",
  "item_robot_arm_left",
  "item_robot_arm_right",
  "item_robot_head",
  "item_rope",
  "item_rpg",
  "item_rpg_ammo",
  "item_rpg_ammo_egg",
  "item_rpg_ammo_spear",
  "item_rpg_cny",
  "item_rpg_easter",
  "item_rpg_smshr",
  "item_rpg_spear",
  "item_rubberducky",
  "item_ruby",
  "item_saddle",
  "item_salmoncannon",
  "item_sawblade",
  "item_sawblade_launcher",
  "item_scanner",
  "item_scissors",
  "item_server_pad",
  "item_shadowboss_key",
  "item_shield",
  "item_shield_bones",
  "item_shield_candy_cane",
  "item_shield_police",
  "item_shield_viking_1",
  "item_shield_viking_2",
  "item_shield_viking_3",
  "item_shield_viking_4",
  "item_shotgun",
  "item_shotgun_ammo",
  "item_shotgun_gold",
  "item_shotgun_sawed",
  "item_shotgun_viper",
  "item_shovel",
  "item_shredder",
  "item_shrinking_broccoli",
  "item_skipole",
  "item_skishoe",
  "item_skishoe_2",
  "item_skishoe_3",
  "item_skishoe_4",
  "item_sludge",
  "item_snail_friend",
  "item_snowball",
  "item_snowboard",
  "item_snowboard_2",
  "item_snowboard_3",
  "item_snowboard_4",
  "item_snowboard_auto",
  "item_spear_candy_cane",
  "item_special_fishing_rod",
  "item_special_fishing_rod_radar_part",
  "item_special_fishing_rod_with_radar",
  "item_stapler",
  "item_stash_grenade",
  "item_steel_beam",
  "item_steel_beam_xmas",
  "item_stellarsword_blue",
  "item_stellarsword_gold",
  "item_stick_armbones",
  "item_stick_bone",
  "item_sticker_dispenser",
  "item_sticky_dynamite",
  "item_stinky_cheese",
  "item_stopwatch",
  "item_tablet",
  "item_tapedispenser",
  "item_tele_grenade",
  "item_tele_pearl",
  "item_teleport_dagger",
  "item_teleport_gun",
  "item_theremin",
  "item_timebomb",
  "item_toilet_paper",
  "item_toilet_paper_mega",
  "item_toilet_paper_roll_empty",
  "item_token_circus",
  "item_trampoline",
  "item_treestick",
  "item_tripwire_explosive",
  "item_trophy",
  "item_truss",
  "item_truss_easter",
  "item_truss_small",
  "item_truss_xmas",
  "item_turkey_leg",
  "item_turkey_whole",
  "item_ukulele",
  "item_ukulele_gold",
  "item_umbrella",
  "item_umbrella_clover",
  "item_umbrella_squirrel",
  "item_upsidedown_loot",
  "item_uranium_chunk_l",
  "item_uranium_chunk_m",
  "item_uranium_chunk_s",
  "item_viking_hammer",
  "item_viking_hammer_twilight",
  "item_war_fan",
  "item_wheelhandle",
  "item_wheelhandle_big",
  "item_whoopie",
  "item_wireframe_cube",
  "item_wireframe_gun",
  "item_wood_log",
  "item_wood_pallet",
  "item_wood_pallet_easter",
  "item_wyrmpiercer",
  "item_zipline_gun",
  "item_zombie_meat",
  "item_drill_galaxy",
  "item_flashlight_galaxy",
  "item_great_sword_galaxy",
  "item_hookshot_galaxy",
  "item_hoverpad_galaxy",
  "item_pickaxe_realistic_galaxy",
  "item_robot_arm_left_galaxy",
  "item_robot_arm_right_galaxy",
  "item_shield_galaxy",
  "item_snowboard_galaxy",
  "item_teleport_gun_galaxy",
];
const mobIDs = [
  {
    name: "Angler",
    id: 1,
  },
  {
    name: "AnglerMad",
    id: 2,
  },
  {
    name: "Armstrong",
    id: 3,
  },
  {
    name: "ArmstrongMad",
    id: 4,
  },
  {
    name: "Banshee",
    id: 5,
  },
  {
    name: "Bomb",
    id: 6,
  },
  {
    name: "Bomber",
    id: 7,
  },
  {
    name: "BomberFlashbang",
    id: 8,
  },
  {
    name: "BomberMad",
    id: 9,
  },
  {
    name: "Chicken",
    id: 10,
  },
  {
    name: "Cyst",
    id: 11,
  },
  {
    name: "FakeGorilla",
    id: 12,
  },
  {
    name: "BigHead",
    id: 13,
  },
  {
    name: "RedGreen",
    id: 14,
  },
  {
    name: "Phantom",
    id: 15,
  },
  {
    name: "EvilEye",
    id: 16,
  },
  {
    name: "GiantThrower",
    id: 17,
  },
  {
    name: "RedGreenMad",
    id: 18,
  },
  {
    name: "Spider",
    id: 19,
  },
  {
    name: "FlyingSwarm",
    id: 20,
  },
  {
    name: "NextBot",
    id: 21,
  },
  {
    name: "Segway",
    id: 22,
  },
  {
    name: "NextBotStatic",
    id: 23,
  },
  {
    name: "EvilEyePinata",
    id: 24,
  },
  {
    name: "EvilEyePinataLarge",
    id: 25,
  },
  {
    name: "Lanky",
    id: 26,
  },
  {
    name: "Blob",
    id: 27,
  },
  {
    name: "Cutie",
    id: 28,
  },
  {
    name: "SpiderCave",
    id: 29,
  },
  {
    name: "ForestMob",
    id: 30,
  },
  {
    name: "Mimic",
    id: 31,
  },
  {
    name: "GraveyardBoss",
    id: 32,
  },
  {
    name: "Ringmaster",
    id: 33,
  },
  {
    name: "Puppet",
    id: 34,
  },
  {
    name: "PolypMass",
    id: 35,
  },
  {
    name: "RobotDog",
    id: 36,
  },
  {
    name: "Shadow",
    id: 37,
  },
  {
    name: "Heart",
    id: 38,
  },
  {
    name: "Slimey",
    id: 39,
  },
  {
    name: "ShadowBoss",
    id: 40,
  },
  {
    name: "BigShark",
    id: 41,
  },
  {
    name: "EdenZombie",
    id: 42,
  },
  {
    name: "Skinwalker",
    id: 43,
  },
];
const version = "3.5.0";
const menuName = "Luminox";
let menu = null;
let machineAvatar = null;
let _allMachines = [];
let reference = null;
let referenceCollider = null;
let buttonClickDelay = 0;
let LerpMenu = false;
let menuscale = 0.9;
let espLines = [];
let espBoxes = [];
let righthand = false;
let deltaTime = 0;
let time = 0;
let stashDupeEnabled = false;
let stashDupe = false;
let itemIndex = 0;
let itemGunDelay = 0;
let mobIndex = 0;
let mobGunDelay2 = 0;
let flySpeed = 20;
let controlledMachine = null;
let machineTargetPos = null;
let _cageGunDelay = 0;
let _blackholeActive = false;
let _blackholePos = null;
let _lightningGunDelay = 0;
let _possessionTarget = null;
let _possessionActive = false;
let _magnetDelay = 0;
let _lagSimEnabled = false;
let _lagSimCounter = 0;
let _fakeDCEnabled = false;
let _rainbowTrailEnabled = false;
let _flareLauncherNextShot = 0;
let _explodeAllDelay = 0;
let _stinkAllDelay = 0;
let _arenaSpazDelay = 0;
let _explodeSellingDelay = 0;
let whitelist = [];
let whitelistEnabled = false;
let gunRainbowEnabled = false;
let gunRainbowTarget = null;
let _gunRainbowHue = 0;
let gunStrobeEnabled = false;
let gunStrobeTarget = null;
let wlAllFlyEnabled = false;
let wlAllRocketEnabled = false;
let wlAllFlareEnabled = false;
let wlAllCarEnabled = false;
let wlAllSuitcaseEnabled = false;
let wlAllBoomspearEnabled = false;
let wlAllBalloonEnabled = false;
let wlAllGiveawayEnabled = false;
let wlAllDisintegrateEnabled = false;
let wlAllGunBuffEnabled = false;
let _wlAllFlyDelay = 0;
let _wlAllRocketDelay = 0;
let _wlAllFlareDelay = 0;
let _wlAllCarDelay = 0;
let _wlAllSuitcaseDelay = 0;
let _wlAllBoomspearDelay = 0;
let _wlAllBalloonDelay = 0;
let _wlAllGiveawayDelay = 0;
let _wlAllDisintegrateDelay = 0;
let _wlAllGunBuffDelay = 0;
let rpcProtectionEnabled = false;
let _balloonRainbowHue = 0;
let _prefabGunDelay = 0;
let _mobGunDelay = 0;
let _rainbowTrailDelay = 0;
let _rainbowHue = 0;
let _rainbowBallDelay = 0;
let _rainbowBallHue = 0;
let _rainbowAllDelay = 0;
let _rainbowAllHue = 0;
let _dupeLoopEnabled = false;
let _dupeLoopDelay = 0;
let _vacuumGunDelay = 0;
let _drunkGunDelay = 0;
let bgColor = [0.012, 0.004, 0.022, 0.97];
let textColor = [0.84, 0.7, 1, 1];
let buttonColor = [0.06, 0.022, 0.11, 0.4];
let buttonPressedColor = [0.84, 0.2, 1, 1];
let accentColor = [0.78, 0.22, 1, 1];
let sidebarColor = [0.52, 0.22, 0.86, 0.3];
let panelColor = [0.42, 0.18, 0.7, 0.14];
let pipOnColor = [0.3, 1, 0.45, 1];
let pipOffColor = [0.2, 0.16, 0.3, 0.7];
let menuAnimTime = 0;
let themeMode = 0;
let rainbowStep = 0;
let menuAnimTitle = null;
let menuAnimActiveTab = null;
let menuAnimBg = null;
let menuAnimOnPips = [];
let menuOpenTime = 0;
const menuFadeDur = 0.32;
let menuFadeDone = false;
let menuFadeRenderers = [];
let menuFadeTexts = [];
let menuFrameMats = [];
let menuTabOutlineMats = [];
let menuScanTf = null;
let menuScanMat = null;
let menuCursorMat = null;
let menuTargetScale = [1, 1, 1];
let menuMatBg = null;
let menuMatHeaderBar = null;
let menuMatActiveTab = null;
let gunFxEmit = false;
let gunFxPos = [0, 0, 0];
let gunFx = [];
const rainbowPresets = [
  [1, 0, 0],
  [1, 0.5, 0],
  [1, 1, 0],
  [0, 1, 0],
  [0, 1, 1],
  [0, 0, 1],
  [0.5, 0, 1],
  [1, 0, 1],
];
let currentNotification = "";
let notifactionResetTime = 0;
let currentCategory = 0;
let currentPage = 0;
let hueVal = 0;
let satVal = 0;
let tagGunDelay = 0;
let frameCount = 0;
let leftPrimary = false;
let leftSecondary = false;
let rightPrimary = false;
let rightSecondary = false;
let leftGrab = false;
let rightGrab = false;
let leftTrigger = false;
let rightTrigger = false;
let leftStick = false;
let rightStick = false;
let InfAmmo = false;
let noRecoil = false;
let noShotgunCooldown = false;
let infDamage = false;
let noSafeZone = false;
let aimbotEnabled = false;
let ejectDupeAmount = 2;
let ejectDupeIndex = 0;
const ejectDupeValues = [1, 2, 5, 10, 20, 30, 50, 100];
let scaleVal = 0;
let cachedItems = null;
let backpackDupe = false;
let lagGunDelay = 0;
let mobGunDelay = 0;
let idGunDelay = 0;
let netplrs = [];
let sellingmachineSpawns = [];
let presentSpawns = [];
let orbiters = [];
let orbitprefabs = [];
let GunPointer = null;
let GunLine = null;
let gunColorTime = 0;
let GunLibPointer = null;
let GunLibLine = null;
let _gunLibDelay = 0;
let _pokemonGunDelay = 0;
let GunLibTicks = [];
let GunLibDotMat = null;
let physicsRaycastAllVec4 = null;
let physicsRaycastOutVec4 = null;
let physicsRaycastOutVec5 = null;
let launchAxisCache = new Map();
let telekinesisTarget = null;
let _kickTouchDelay = 0;
let _explodeMachineDelay = 0;
let _vfxHandSpamDelay = 0;
let _vfxGunSpamDelay = 0;
let heldItemDuplicateDelay = 0;
let containerFreedomSweepDelay = 0;
let containerFreedomAuraEnabled = false;
let _reviveGunDelay = 0;
let _allBufGunDelay = 0;
let itemLauncherSelfDelay = 0;
let launchPower = 28;
const launchPowerSteps = [8, 16, 28, 50, 80, 120, 200, 400];
let launchPowerIndex = 2;
let spawnedGoopObjects = [];
let prefabIndex = 0;
const prefabIDs = [
  "Shipwheel",
  "TeleportMachine",
  "FourLeafQuest_FourLeafSpawner",
  "EasterEgg_QuestSpawner",
  "RadarPartSpawner",
  "SimpleKeypadDoor",
  "GiantController_GraveyardBoss_backup",
  "MetaCameraControls",
  "GrenadeProjectile",
  "LaserMirror",
  "TeleportMachine",
  "mom_pillow",
  "RiggedPlank",
  "SharkScareTriggerObject",
  "Uvula",
  "BaitShopButton_Spawner",
  "NetworkedLever_SecretLeft",
  "CoreTeleporter",
  "LaserSource",
  "LaserSink",
  "grababble_fish_paper_message",
  "AutoDestroyItem_OilSplatter",
  "AutoDestroyItem_Splash0",
  "AutoDestroyItem_Splash1",
  "AutoDestroyItem_Splash2",
  "AutoDestroyItem_Splash3",
  "AutoDestroyItem_Splash4",
  "AutoDestroyItem_Splash5",
  "BarrelBeansDynamic",
  "BarrelBeansStatic",
  "BarrelExplodingDynamic",
  "BarrelExplodingStatic",
  "BarrelOilDynamic",
  "BarrelOilStatic",
  "Basketball",
  "BigBanana",
  "BigHatchdoorNetObject",
  "BigWheelhandleSpawner",
  "BonfireController",
  "BrainPowerPlug",
  "ChoppableTreeManager",
  "ChristmasBox",
  "ChristmasBoxManager",
  "ClawMachineNetObject",
  "DiggableGrave",
  "DummyPlayerTarget",
  "DummyTarget",
  "Duplicator",
  "EscherToyBlockObject",
  "ExplosiveEgg",
  "ExplosiveEggClustered",
  "FlareGunProjectile",
  "FortuneTellerNet",
  "FuelCanisterNetObject",
  "FuelCanisterSpawner",
  "GenericWorldItemSpawner",
  "GiantRockObject",
  "GiantRockObject_Fire",
  "GreenscreenNET",
  "HatchdoorGrabHandle",
  "HatchdoorNetObject",
  "HellAltar",
  "HH_LockedDoor",
  "HingedDoorNetworked",
  "HordeMobController",
  "HordeMobLobbyHandler",
  "InflatedBalloon",
  "InflatedHeartBalloon",
  "ItemSellingMachineController",
  "KeypadDoorNetObject",
  "LakePineapple_Spawner",
  "Landmine",
  "LeaderBoardMonsterKill",
  "LockedDoor_KeySpawner",
  "LockedShippingContainer_Quest",
  "LogQuestItemSpawner",
  "LootLantern",
  "Mausoleum_01",
  "MazeManager",
  "MimicSpawner_CemeteryTile1",
  "MimicSpawner_CemeteryTile3",
  "MomToyBlockObject",
  "MomToyBlockObject_DisappearOnDrop",
  "MountainKey_Spawner",
  "MovieTheater",
  "Net",
  "NetGameTimeManager",
  "NetLootSpawnGroup",
  "NetMobSpawnGroup",
  "NetPlayer",
  "Pillar_Arched_Broken_01",
  "RamEventNet",
  "remote_controller_receiver",
  "RobotDogRPG",
  "RPGRocket",
  "RPGRocketEgg",
  "RPGRocketSpear",
  "RuinTower_FloatingPlatform",
  "RuinTower_FloatingSmall",
  "ScaffoldTrap",
  "SkiRaceController",
  "Snail_Spawner",
  "SpaceshipTeleporter",
  "SpawnableZipline",
  "Spawner_Key",
  "StickyAnchor",
  "TeleportationManager",
  "ThunderController",
  "TubeMonster",
  "Vehicle_Buggy",
  "VHSQuests_VHSSpawner",
  "WinterFilm_ReelSpawner",
  "AnglerController",
  "AnglerMadController",
  "ArmstrongController",
  "ArmstrongControllerSpace",
  "ArmstrongMadController",
  "BansheeController",
  "BigHeadController",
  "BigSharkController",
  "BlobController",
  "BombController",
  "BomberController",
  "BomberFlashbangController",
  "BomberMadController",
  "ChickenController",
  "CutieController",
  "CystController",
  "EdenZombieController",
  "EvilEyeController",
  "EvilEyePinataController",
  "EvilEyePinataLargeController",
  "FakeGorillaController",
  "FlyingSwarmController",
  "ForestMobController",
  "GiantController",
  "GiantController_GraveyardBoss",
  "HeartMobController",
  "LankyController",
  "MimicController",
  "NextBotController",
  "NextBotStaticController",
  "PhantomController",
  "PuppetController",
  "RedGreenController",
  "RedGreenMadController",
  "RingmasterController",
  "RobotDogController",
  "SegwayController",
  "ShadowBossController",
  "ShadowController",
  "SkinwalkerController",
  "SlimeyController",
  "SmileyController",
  "SmileyController_Floating",
  "SpiderCaveController",
  "SpiderController",
  "YangWormController",
  "YinWormController",
  "AlienCube_Spawner",
  "BrainSlug_blue_Spawner",
  "BrainSlug_green_Spawner",
  "BrainSlug_pink_Spawner",
  "EasterEgg_LocalSpawner",
  "FishingScoreBoard",
  "FourLeafRadar_Spawner",
  "item_randombox_base",
  "MimicSpawner_Base",
  "MoonRaceController",
  "NetSessionManagers",
  "NetSpectator",
  "OddCoreDoor",
  "OddCorePlatformButton",
  "RegionStreamer",
  "RoboMonkeController",
  "SteamJumpScareManager",
  "WireframeGun_Spawner",
];
let soundFileIndex = 0;
let flareSwapEnabled = false;
let previousSoundKey = false;
const loadedBundles = {};
const loadedObjects = {};
let sfxIndex = 7;
let _spamSfxDelay = 0;
let _handDuperLastX = false;
let _kickAllDelay = 0;
let _noclipActive = false;
let _stinkyAllDelay = 0;
let explosionIndex = 0;
let vfxIndex = 32;
let vfxGunDelay = 0;
const sfxNameMap = {
  0: "none",
  1: "Arena_Defeat",
  2: "Arena_HitPlayer",
  3: "Arena_KillPlayer",
  4: "Arena_Victory",
  5: "Barrel_Beans_Explode",
  6: "Barrel_Oil_Explode",
  7: "BasicPistol",
  8: "Big_Shark_Roar",
  9: "blackhole_close",
  10: "blackhole_open",
  11: "bloody",
  12: "Bonfire_Ignite",
  13: "Bonfire_Ignite_loud",
  37: "CoinEarn",
  68: "Explosion_Dynamite",
  107: "HitSound_Boing",
  162: "Item_heart_gun_shoot",
  258: "Lightning_Normal",
};
const vfxNameMap = {
  0: "MuzzleFlash_Shotgun",
  1: "MuzzleFlash_FlareGun",
  2: "CrateBreak",
  3: "MuzzleFlash_SmallGun",
  4: "MuzzleFlash_GoldRevolver",
  5: "MuzzleFlash_DragonPistol",
  6: "MuzzleFlash_ViperShotgun",
  7: "GlassBreak",
  32: "Explosion_FlareGun",
  33: "Explosion_Coins",
  34: "Explosion_Nuts",
  35: "Explosion_Keys",
  36: "Explosion_Balloon",
  37: "Explosion_TeleGrenadeSrc",
  38: "Player_Touch_Lava",
  39: "Portal_Teleport",
  40: "Explosion_Coins_Vertical",
  41: "Autumn_Leaves_Burst",
  42: "Explosion_Feathers",
  43: "Explosion_Popcorn",
  44: "Electricity_Small",
  65: "Impact_Snowball",
  66: "Impact_GoldRevolver",
  67: "Impact_MeleeHit",
  68: "Impact_BigGroundHit",
  69: "Impact_MeleeHit_CriticalSmall",
  70: "Impact_MeleeHit_CriticalLarge",
  71: "Impact_MeleeHit_AoE",
  72: "Impact_WaterSplash",
  96: "Research_ZiplineAttachDetach",
  97: "Research_Purchase1RP",
  98: "Research_Purchase5RP",
  99: "Research_Purchase10RP",
  100: "Research_PurchaseRPBundle",
  110: "Rope_ZiplineAttachDetach",
  128: "MeatExplosion_1",
  129: "MeatExplosion_2",
  130: "MeatExplosion_Headshot",
  160: "ServerRoomSplash_Small",
  161: "ServerRoomSplash_Big",
  162: "RAMActivationSparks",
  170: "GreenBlink",
  174: "ConfettiBurst",
  180: "Ethereal_Void",
  181: "MomBoss_NailBreak",
  182: "MidAirJump_Fart",
  183: "FuelExplosion",
  184: "HeartBurst",
  185: "EatingLoop",
  255: "None",
};
const vfxIDs = Object.keys(vfxNameMap)
  .map(Number)
  .filter((_0x3d22f0) => _0x3d22f0 !== 255)
  .sort((_0x4f0941, _0x18328e) => _0x4f0941 - _0x18328e);
let teleportNetObjList = [];
let teleportNetObjIndex = 0;
("use strict");
const FONT5x5 = {
  A: ["..#..", ".#.#.", "#####", "#...#", "#...#"],
  B: ["####.", "#...#", "####.", "#...#", "####."],
  C: [".####", "#....", "#....", "#....", ".####"],
  D: ["####.", "#...#", "#...#", "#...#", "####."],
  E: ["#####", "#....", "###..", "#....", "#####"],
  F: ["#####", "#....", "###..", "#....", "#...."],
  G: [".####", "#....", "#..##", "#...#", ".####"],
  H: ["#...#", "#...#", "#####", "#...#", "#...#"],
  I: ["#####", "..#..", "..#..", "..#..", "#####"],
  J: ["#####", "...#.", "...#.", "#..#.", ".##.."],
  K: ["#...#", "#..#.", "###..", "#..#.", "#...#"],
  L: ["#....", "#....", "#....", "#....", "#####"],
  M: ["#...#", "##.##", "#.#.#", "#...#", "#...#"],
  N: ["#...#", "##..#", "#.#.#", "#..##", "#...#"],
  O: [".###.", "#...#", "#...#", "#...#", ".###."],
  P: ["####.", "#...#", "####.", "#....", "#...."],
  Q: [".###.", "#...#", "#.#.#", "#..##", ".####"],
  R: ["####.", "#...#", "####.", "#.#..", "#..##"],
  S: [".####", "#....", "#####", "....#", "####."],
  T: ["#####", "..#..", "..#..", "..#..", "..#.."],
  U: ["#...#", "#...#", "#...#", "#...#", ".###."],
  V: ["#...#", "#...#", "#...#", ".#.#.", "..#.."],
  W: ["#...#", "#...#", "#.#.#", "##.##", "#...#"],
  X: ["#...#", ".#.#.", "..#..", ".#.#.", "#...#"],
  Y: ["#...#", ".#.#.", "..#..", "..#..", "..#.."],
  Z: ["#####", "...#.", "..#..", ".#...", "#####"],
  0: [".###.", "#..##", "#.#.#", "##..#", ".###."],
  1: ["..##.", "...#.", "...#.", "...#.", ".####"],
  2: [".###.", "#...#", "..##.", ".#...", "#####"],
  3: ["#####", "...#.", "..##.", "...#.", "#####"],
  4: ["#...#", "#...#", "#####", "...#.", "...#."],
  5: ["#####", "#....", "####.", "....#", "####."],
  6: [".####", "#....", "####.", "#...#", ".###."],
  7: ["#####", "...#.", "..#..", ".#...", "#...."],
  8: [".###.", "#...#", ".###.", "#...#", ".###."],
  9: [".###.", "#...#", ".####", "....#", "####."],
  "!": ["..#..", "..#..", "..#..", ".....", "..#.."],
  "?": [".###.", "#...#", "..##.", ".....", "..#.."],
  ":": [".....", "..#..", ".....", "..#..", "....."],
  ")": [".#...", "..#..", "..#..", "..#..", ".#..."],
  "<": ["...##", ".##..", "#....", "#....", "...##"],
  ".": [".....", ".....", ".....", ".....", "..#.."],
  "/": ["....#", "...#.", "..#..", ".#...", "#...."],
  " ": [".....", ".....", ".....", ".....", "....."],
};
// ===== Animal Company menu bootstrap =====
Il2Cpp.perform(() => {
  setTimeout(() => {
Il2Cpp.perform(() => {
  var _0xea8926;
  var _0x4861f3;
  const gameImages = {
    AnimalCompany: Il2Cpp.domain.assembly("AnimalCompany").image,
    "UnityEngine.CoreModule": Il2Cpp.domain.assembly("UnityEngine.CoreModule").image,
    "UnityEngine.PhysicsModule": Il2Cpp.domain.assembly("UnityEngine.PhysicsModule").image,
    "UnityEngine.UIModule": Il2Cpp.domain.assembly("UnityEngine.UIModule").image,
    "UnityEngine.UI": Il2Cpp.domain.assembly("UnityEngine.UI").image,
    "UnityEngine.TextRenderingModule": Il2Cpp.domain.assembly("UnityEngine.TextRenderingModule")
      .image,
    PhotonFusionNetworking: Il2Cpp.domain.assembly("Fusion.Runtime").image,
    PhotonFusionNetworkingRealtime: Il2Cpp.domain.assembly("Fusion.Realtime").image,
    "Unity.TextMeshPro": Il2Cpp.domain.assembly("Unity.TextMeshPro").image,
    "UnityEngine.XRModule": Il2Cpp.domain.assembly("UnityEngine.XRModule").image,
    "UnityEngine.AudioModule": Il2Cpp.domain.assembly("UnityEngine.AudioModule").image,
    "Oculus.Platform": Il2Cpp.domain.assembly("Oculus.Platform").image,
  };
  const animalImage = gameImages.AnimalCompany;
  const unityCoreImage = gameImages["UnityEngine.CoreModule"];
  const unityPhysicsImage = gameImages["UnityEngine.PhysicsModule"];
  const unityUiImage = gameImages["UnityEngine.UI"];
  const unityUiModuleImage = gameImages["UnityEngine.UIModule"];
  const unityTextImage = gameImages["UnityEngine.TextRenderingModule"];
  const fusionImage = gameImages.PhotonFusionNetworking;
  const textMeshProImage = gameImages["Unity.TextMeshPro"];
  const unityXrImage = gameImages["UnityEngine.XRModule"];
  const unityAudioImage = gameImages["UnityEngine.AudioModule"];
  const OculusPlatformSettingsClass = gameImages["Oculus.Platform"].class(
    "Oculus.Platform.PlatformSettings",
  );
  const GorillaLocomotionClass = animalImage.class("AnimalCompany.GorillaLocomotion");
  const NetPlayerClass = animalImage.class("AnimalCompany.NetPlayer");
  const ElevatorManagerClass = animalImage.class("AnimalCompany.ElevatorManager");
  const ArenaGameManagerClass = animalImage.class("AnimalCompany.ArenaGameManager");
  const GrabbableObjectClass = animalImage.class("AnimalCompany.GrabbableObject");
  const PickupManagerClass = animalImage.class("AnimalCompany.PickupManager");
  const ItemSellingMachineControllerClass = animalImage.class(
    "AnimalCompany.ItemSellingMachineController",
  );
  const PrefabGeneratorClass = animalImage.class("AnimalCompany.PrefabGenerator");
  function spellInSky(text, prefabName, thick) {
    try {
      const pixelSize = 0.55;
      const letterSpacing = 1;
      const forwardDistance = 8;
      const outlineOffset = pixelSize * 0.25;
      const runner = PrefabGeneratorClass.field("_instance").value.method("get_runner").invoke();
      if (!runner || runner.isNull()) {
        notify("No runner", false);
        return;
      }
      const prefabSources = runner
        .field("_config")
        .value.field("PrefabTable")
        .value.field("_sources").value;
      const prefabCount = prefabSources.method("get_Count").invoke();
      const defaultValueForType = (typeInfo) => {
        if (typeInfo.class.isEnum || typeInfo.isPrimitive) {
          return 0;
        }
        if (!typeInfo.class.isValueType) {
          return _0x366930;
        }
        const valueFields = typeInfo.class.fields.filter((field) => !field.isStatic);
        if (valueFields.length === 0) {
          return 0;
        }
        return valueFields.map((field) => defaultValueForType(field.type));
      };
      const buildNullableFields = (nullableType, hasValue, nullableValue) => {
        const fields = nullableType.class.fields.filter((field) => !field.isStatic);
        return fields.map((field) => {
          const fieldName = field.name.toLowerCase();
          if (fieldName.includes("hasvalue")) {
            if (hasValue) {
              return 1;
            } else {
              return 0;
            }
          }
          if (fieldName === "value") {
            if (hasValue) {
              return nullableValue;
            } else {
              return defaultValueForType(field.type);
            }
          }
          return defaultValueForType(field.type);
        });
      };
      const marshalSpawnValue = (typeInfo, value) => {
        if (typeof value === "boolean") {
          if (value) {
            return 1;
          } else {
            return 0;
          }
        }
        if (value instanceof Il2Cpp.ValueType) {
          const valueFields = typeInfo.class.fields.filter((field) => !field.isStatic);
          if (valueFields.length === 0) {
            return 0;
          }
          return valueFields.map((field) => marshalSpawnValue(field.type, field.bind(value).value));
        }
        if (Array.isArray(value)) {
          return value.map((item) => marshalSpawnValue(typeInfo, item));
        }
        return value;
      };
      const makeNullable = (nullableType, value) => {
        return buildNullableFields(nullableType, true, marshalSpawnValue(value.type, value));
      };
      let spawnMethod = null;
      for (const overload of runner.method("Spawn").overloads()) {
        if (overload.parameterCount !== 6 || overload.isGeneric) {
          continue;
        }
        const parameters = overload.parameters;
        if (
          parameters[0].type.name.includes("Fusion.NetworkObject") &&
          parameters[1].type.name.startsWith("System.Nullable") &&
          parameters[1].type.name.includes("Vector3") &&
          parameters[2].type.name.startsWith("System.Nullable") &&
          parameters[2].type.name.includes("Quaternion") &&
          parameters[3].type.name.startsWith("System.Nullable") &&
          parameters[3].type.name.includes("PlayerRef") &&
          parameters[4].type.name.includes("OnBeforeSpawned") &&
          parameters[5].type.name.includes("NetworkSpawnFlags")
        ) {
          spawnMethod = overload;
          break;
        }
      }
      if (!spawnMethod) {
        notify("Spawn method not found", false);
        return;
      }
      let prefab = null;
      for (let sourceIndex = 0; sourceIndex < prefabCount; sourceIndex++) {
        try {
          const source = prefabSources.method("get_Item").invoke(sourceIndex);
          const description = source.method("get_Description").invoke().toString();
          if (description.includes(prefabName)) {
            prefab = source.method("WaitForResult").invoke();
            break;
          }
        } catch (_0x3b5dd6) {}
      }
      if (!prefab || prefab.isNull()) {
        notify("Item not found: " + prefabName, false);
        return;
      }
      const headPosition = localRig
        .field("headCollider")
        .value.method("get_transform")
        .invoke()
        .method("get_position")
        .invoke();
      const forward = rightHandTransform.method("get_forward").invoke();
      const right = rightHandTransform.method("get_right").invoke();
      const up = rightHandTransform.method("get_up").invoke();
      const addVec3 = (a, b) => [a[0] + b[0], a[1] + b[1], a[2] + b[2]];
      const scaleVec3 = (v, scale) => [v[0] * scale, v[1] * scale, v[2] * scale];
      const origin = addVec3(headPosition, scaleVec3(forward, forwardDistance));
      const glyphs = text
        .toUpperCase()
        .split("")
        .map((char) => {
          return FONT5x5[char] ?? FONT5x5[" "];
        });
      const totalWidth = glyphs.reduce(
        (sum, glyph, glyphIndex) =>
          sum + pixelSize * 5 + (glyphIndex < glyphs.length - 1 ? letterSpacing : 0),
        0,
      );
      const startX = -totalWidth / 2;
      const spawnAt = (position) => {
        try {
          const nullablePosition = makeNullable(spawnMethod.parameters[1].type, position);
          const nullableRotation = makeNullable(spawnMethod.parameters[2].type, QuaternionIdentity);
          const nullablePlayerRef = buildNullableFields(
            spawnMethod.parameters[3].type,
            false,
            defaultValueForType(spawnMethod.parameters[3].type),
          );
          const beforeSpawnCallback = spawnMethod.parameters[4].type.class.isValueType
            ? defaultValueForType(spawnMethod.parameters[4].type)
            : _0x366930;
          spawnMethod
            .bind(runner)
            .invoke(
              prefab,
              nullablePosition,
              nullableRotation,
              nullablePlayerRef,
              beforeSpawnCallback,
              0,
            );
        } catch (_0x2d9378) {}
      };
      let cursorX = startX;
      for (let letterIndex = 0; letterIndex < glyphs.length; letterIndex++) {
        const glyphRows = glyphs[letterIndex];
        for (let row = 0; row < 5; row++) {
          for (let col = 0; col < 5; col++) {
            if (glyphRows[row][col] !== "#") {
              continue;
            }
            const pixelPosition = addVec3(
              origin,
              addVec3(
                scaleVec3(right, cursorX + col * pixelSize),
                scaleVec3(up, -(row * pixelSize)),
              ),
            );
            if (thick) {
              for (const outline of [
                [-outlineOffset, -outlineOffset],
                [outlineOffset, -outlineOffset],
                [-outlineOffset, outlineOffset],
                [outlineOffset, outlineOffset],
              ]) {
                spawnAt(
                  addVec3(
                    pixelPosition,
                    addVec3(scaleVec3(right, outline[0]), scaleVec3(up, outline[1])),
                  ),
                );
              }
            } else {
              spawnAt(pixelPosition);
            }
          }
        }
        cursorX += pixelSize * 5 + (letterIndex < glyphs.length - 1 ? letterSpacing : 0);
      }
      notify("Spelled: " + text, false);
    } catch (error) {
      notify("SpellInSky: " + error, false);
    }
  }
  const GrabbableItemClass = animalImage.class("AnimalCompany.GrabbableItem");
  const BackpackItemClass = animalImage.class("AnimalCompany.BackpackItem");
  const QuiverClass = animalImage.class("AnimalCompany.Quiver");
  let CrossbowClass = null;
  try {
    CrossbowClass = animalImage.class("AnimalCompany.Crossbow");
  } catch (_0x1fe47c) {}
  let HeartGunClass = null;
  try {
    HeartGunClass = animalImage.class("AnimalCompany.HeartGun");
  } catch (_0x21c444) {}
  let GrenadeLauncherClass = null;
  try {
    GrenadeLauncherClass = animalImage.class("AnimalCompany.GrenadeLauncher");
  } catch (_0x4a4eb0) {}
  let SalmonCannonClass = null;
  try {
    SalmonCannonClass = animalImage.class("AnimalCompany.Weapons.SalmonCannon");
  } catch (_0x33a4a5) {}
  let MobControllerClass = null;
  try {
    MobControllerClass = animalImage.class("AnimalCompany.MobController");
  } catch (_0x6f6643) {}
  const AudioClipClass = unityAudioImage.class("UnityEngine.AudioClip");
  const photonVoiceImage = Il2Cpp.domain.assembly("PhotonVoice").image;
  const VoiceConnectionClass = photonVoiceImage.class("Photon.Voice.Unity.VoiceConnection");
  const NetworkSessionManagerClass = animalImage.class("AnimalCompany.NetworkSessionManager");
  const DamageSourceInfoClass = animalImage.class("AnimalCompany.DamageSourceInfo");
  const GameplayItemStateClass = animalImage.class("AnimalCompany.GameplayItemState");
  const RigidbodyClass = unityPhysicsImage.class("UnityEngine.Rigidbody");
  const PlayerControllerClass = animalImage.class("AnimalCompany.PlayerController");
  const AnimalGrabbableObjectClass = animalImage.class("AnimalCompany.GrabbableObject");
  const SfxManagerClass = animalImage.class("AnimalCompany.SFXManager");
  const NetworkManagerClass = animalImage.class("AnimalCompany.NetworkManager");
  const ComputerTerminalKeyClass = animalImage.class("AnimalCompany.ComputerTerminalKey");
  const InputDevicesClass = unityXrImage.class("UnityEngine.XR.InputDevices");
  const CommonUsagesClass = unityXrImage.class("UnityEngine.XR.CommonUsages");
  const GameObjectClass = unityCoreImage.class("UnityEngine.GameObject");
  const UnityObjectClass = unityCoreImage.class("UnityEngine.Object");
  const Vector3Class = unityCoreImage.class("UnityEngine.Vector3");
  const QuaternionClass = unityCoreImage.class("UnityEngine.Quaternion");
  const TimeClass = unityCoreImage.class("UnityEngine.Time");
  const ResourcesClass = unityCoreImage.class("UnityEngine.Resources");
  const MaterialClass = unityCoreImage.class("UnityEngine.Material");
  const RendererClass = unityCoreImage.class("UnityEngine.Renderer");
  const ColorClass = unityCoreImage.class("UnityEngine.Color");
  const ShaderClass = unityCoreImage.class("UnityEngine.Shader");
  const RectTransformClass = unityCoreImage.class("UnityEngine.RectTransform");
  const LineRendererClass = unityCoreImage.class("UnityEngine.LineRenderer");
  const SphereColliderClass = unityPhysicsImage.class("UnityEngine.SphereCollider");
  const BoxColliderClass = unityPhysicsImage.class("UnityEngine.BoxCollider");
  const ColliderClass = unityPhysicsImage.class("UnityEngine.Collider");
  const UnityRigidbodyClass = unityPhysicsImage.class("UnityEngine.Rigidbody");
  const PhysicsClass = unityPhysicsImage.class("UnityEngine.Physics");
  const ComponentClass = unityCoreImage.class("UnityEngine.Component");
  const ParticleManagerClass = animalImage.class("AnimalCompany.ParticleManager");
  const ParticleManagerAlias = ParticleManagerClass;
  const CanvasClass = unityUiModuleImage.class("UnityEngine.Canvas");
  const CanvasScalerClass = unityUiImage.class("UnityEngine.UI.CanvasScaler");
  const GraphicRaycasterClass = unityUiImage.class("UnityEngine.UI.GraphicRaycaster");
  const UiTextClass = unityUiImage.class("UnityEngine.UI.Text");
  const FontClass = unityTextImage.class("UnityEngine.Font");
  const localRig = GorillaLocomotionClass.field("<Instance>k__BackingField").value;
  const unlitShader = ShaderClass.method("Find").invoke(
    Il2Cpp.string("Universal Render Pipeline/Unlit"),
  );
  const uiDefaultShader = ShaderClass.method("Find").invoke(Il2Cpp.string("UI/Default"));
  const Vector3Zero = Vector3Class.field("zeroVector").value;
  const Vector3One = Vector3Class.field("oneVector").value;
  const QuaternionIdentity = QuaternionClass.field("identityQuaternion").value;
  const leftHandTransform = localRig.field("leftHandTransform").value;
  const rightHandTransform = localRig.field("rightHandTransform").value;
  const headCollider = localRig.field("headCollider").value;
  const bodyCollider = localRig.field("bodyCollider").value;
  const _0x3aad40 = ResourcesClass.method("FindObjectsOfTypeAll", 1).inflate(FontClass).invoke();
  let _0x5bdfd7 = ResourcesClass.method("GetBuiltinResource", 1)
    .inflate(FontClass)
    .invoke(Il2Cpp.string("Arial.ttf"));
  const _0x4de460 = [
    "kode",
    "mono",
    "consol",
    "courier",
    "terminal",
    "vt323",
    "code",
    "hack",
    "pixel",
    "digital",
    "nunito",
    "poppins",
    "montserrat",
    "roboto",
  ];
  let _0x5ddfea = 999;
  for (let _0x45ebe5 = 0; _0x45ebe5 < _0x3aad40.length; _0x45ebe5++) {
    const _0x3ad35e = _0x3aad40.get(_0x45ebe5);
    const _0x586202 = (_0x3ad35e.method("get_name").invoke()?.content ?? "").toLowerCase();
    for (let _0x4b3b38 = 0; _0x4b3b38 < _0x4de460.length; _0x4b3b38++) {
      if (_0x4b3b38 < _0x5ddfea && _0x586202.includes(_0x4de460[_0x4b3b38])) {
        _0x5bdfd7 = _0x3ad35e;
        _0x5ddfea = _0x4b3b38;
      }
    }
    if (_0x5ddfea === 0) {
      break;
    }
  }
  let _0x109ec9 = null;
  let _0x123d5d = null;
  try {
    const _0x2bcff2 = Il2Cpp.domain.assembly("Unity.TextMeshPro").image;
    _0x109ec9 = _0x2bcff2.class("TMPro.TextMeshProUGUI");
    const _0xc33d2c = _0x2bcff2.class("TMPro.TMP_FontAsset");
    const _0x3cd906 = ResourcesClass.method("FindObjectsOfTypeAll", 1).inflate(_0xc33d2c).invoke();
    const _0x20b16 = ["kode", "mono", "consol", "courier", "code", "terminal", "pixel", "digit"];
    let _0x143c17 = null;
    let _0xe336b2 = 999;
    let _0x445fbe = null;
    let _0x4e21a9 = "";
    for (let _0x1d4a9d = 0; _0x1d4a9d < _0x3cd906.length; _0x1d4a9d++) {
      const _0x5ba0ca = _0x3cd906.get(_0x1d4a9d);
      const _0x424663 = (
        (_0x4861f3 =
          (_0xea8926 = _0x5ba0ca.method("get_name").invoke()) === null || _0xea8926 === undefined
            ? undefined
            : _0xea8926.content) !== null && _0x4861f3 !== undefined
          ? _0x4861f3
          : ""
      ).toLowerCase();
      _0x4e21a9 += _0x424663 + ", ";
      for (let _0x41fc9e = 0; _0x41fc9e < _0x20b16.length; _0x41fc9e++) {
        if (_0x41fc9e < _0xe336b2 && _0x424663.includes(_0x20b16[_0x41fc9e])) {
          _0x143c17 = _0x5ba0ca;
          _0xe336b2 = _0x41fc9e;
        }
      }
      if (
        !_0x445fbe &&
        _0x424663 &&
        !_0x424663.includes("liberation") &&
        !_0x424663.includes("fallback") &&
        !_0x424663.includes("arial")
      ) {
        _0x445fbe = _0x5ba0ca;
      }
    }
    console.log("[font] TMP fonts in game: " + _0x4e21a9);
    _0x123d5d = _0x143c17 || _0x445fbe;
    console.log(
      "[font] TMP pick: " +
        (_0x123d5d
          ? (_0x123d5d.method("get_name").invoke()?.content ?? "?")
          : "none — falling back to Arial"),
    );
  } catch (_0x7544d0) {
    console.log("[font] TMP unavailable: " + _0x7544d0);
    _0x109ec9 = null;
    _0x123d5d = null;
  }
  function _0x11d2fe(_0x4e1561) {
    UnityObjectClass.method("Destroy", 1).invoke(_0x4e1561);
  }
  function _0x3302f9(_0x2ef022, _0x28f666) {
    return _0x2ef022.method("GetComponent", 1).inflate(_0x28f666).invoke();
  }
  function _0x48c251(_0x278860, _0x4e58ab) {
    return _0x278860.method("GetComponentInParent", 0).inflate(_0x4e58ab).invoke();
  }
  function _0x238332(_0x1cfae6, _0xfea42b) {
    return _0x1cfae6.method("AddComponent", 1).inflate(_0xfea42b).invoke();
  }
  function _0xe40610(_0x469b5d) {
    return _0x469b5d.method("get_transform").invoke();
  }
  function _0x3b4135(_0x3e0e2e) {
    try {
      const _0x3602b6 = _0x3302f9(_0x3e0e2e, RendererClass);
      if (_0x3602b6 && !_0x3602b6.isNull()) {
        return _0x3602b6.method("get_material").invoke();
      } else {
        return null;
      }
    } catch (_0x32c3d5) {
      return null;
    }
  }
  function _0x1c1a20(_0x251608, _0x4bfa29) {
    var _0x642ceb;
    if (
      _0x251608 &&
      !((_0x642ceb = _0x251608.isNull) === null || _0x642ceb === undefined
        ? undefined
        : _0x642ceb.call(_0x251608))
    ) {
      try {
        _0x251608.method("set_color").invoke(_0x4bfa29);
      } catch (_0x23e329) {}
    }
  }
  function _0x16fc51(_0xc3711a) {
    return _0xc3711a.method("get_IsMine").invoke();
  }
  const _0x2f3d02 = Il2Cpp.domain.assembly("Fusion.Runtime").image.class("Fusion.NetworkRunner");
  const _0x366930 = Il2Cpp.reference(
    Il2Cpp.domain.assembly("mscorlib").image.class("System.Object").alloc(),
  );
  function _0xf8bff9(_0x171b43, _0x27945f, _0x2663d2) {
    try {
      try {
        const _0x1cc69b = PrefabGeneratorClass.method("GetItemPrefab", 1).invoke(
          Il2Cpp.string(_0x171b43),
        );
        if (_0x1cc69b && !_0x1cc69b.isNull()) {
          const _0x5e2e77 = PrefabGeneratorClass.method("SpawnItem", 4).invoke(
            _0x1cc69b,
            _0x27945f,
            _0x2663d2,
            _0x366930,
          );
          if (_0x5e2e77 && !_0x5e2e77.isNull()) {
            return _0x5e2e77;
          }
        }
      } catch (_0x2dc07f) {
        console.log("[spawnItemAtPos] try1 failed for " + _0x171b43 + ": " + _0x2dc07f);
      }
      try {
        const _0x4a6d5c = PrefabGeneratorClass.method("SpawnItem", 4).invoke(
          Il2Cpp.string(_0x171b43),
          _0x27945f,
          _0x2663d2,
          _0x366930,
        );
        if (_0x4a6d5c && !_0x4a6d5c.isNull()) {
          return _0x4a6d5c;
        }
      } catch (_0x54ee83) {
        console.log("[spawnItemAtPos] try2 failed for " + _0x171b43 + ": " + _0x54ee83);
      }
      try {
        const _0x11930d = PrefabGeneratorClass.method("SpawnItem", 4).invoke(
          Il2Cpp.string("item_prefab/" + _0x171b43),
          _0x27945f,
          _0x2663d2,
          _0x366930,
        );
        if (_0x11930d && !_0x11930d.isNull()) {
          return _0x11930d;
        }
      } catch (_0x9c2edf) {
        console.log("[spawnItemAtPos] try3 failed for " + _0x171b43 + ": " + _0x9c2edf);
      }
      console.log("[spawnItemAtPos] all tries failed for: " + _0x171b43);
      return null;
    } catch (_0x1deef9) {
      smartError("[spawnItemAtPos] " + _0x171b43, _0x1deef9);
      return null;
    }
  }
  const _0x11239b = Il2Cpp.reference(
    Il2Cpp.domain.assembly("mscorlib").image.class("System.Object").alloc(),
  );
  let _0x399364 = null;
  let _0x111144 = null;
  let _0x25db54 = false;
  function _0x16dc3e() {
    if (_0x25db54) {
      return;
    }
    const _0x9631da = Il2Cpp.domain.assembly("AnimalCompany").image;
    try {
      const _0x20a9b3 = _0x9631da.class("AnimalCompany.MobSpawnValidator");
      try {
        _0x20a9b3.method("IsMobAllowed", 1).implementation = () => true;
      } catch (_0x3aca57) {}
      try {
        _0x20a9b3.method("IsMobAllow", 1).implementation = () => true;
      } catch (_0x3887fa) {}
      try {
        _0x20a9b3.method("RemoveMob", 1).implementation = () => {};
      } catch (_0x2bdf74) {}
      try {
        _0x20a9b3.method("Clear").implementation = () => {};
      } catch (_0x4d991f) {}
      console.log("[spawnMob] MobSpawnValidator bypassed");
    } catch (_0x54e573) {
      console.log("[spawnMob] MobSpawnValidator bypass FAILED: " + _0x54e573);
    }
    try {
      const _0x52f348 = _0x9631da.class("AnimalCompany.SpawnGuardPolicy");
      try {
        _0x52f348.method("IsInNoMobArea", 1).implementation = () => false;
      } catch (_0x458825) {}
      try {
        _0x52f348.method("IsNoMobArea", 1).implementation = () => false;
      } catch (_0xa3676b) {}
      try {
        _0x52f348.method("IsNoMobAre", 1).implementation = () => false;
      } catch (_0x59591f) {}
      try {
        _0x52f348.method("IsDeniedAtProvider", 1).implementation = () => false;
      } catch (_0x594348) {}
      try {
        _0x52f348.method("IsContextLegitimate", 2).implementation = () => true;
      } catch (_0x33a0de) {}
      try {
        _0x52f348.method("AllowSpawnFromSource", 1).implementation = () => true;
      } catch (_0x49a85d) {}
      try {
        _0x52f348.method("AllowSpawnFromSource", 2).implementation = () => true;
      } catch (_0x1eb0d4) {}
      try {
        _0x52f348.method("set_EnforceProviderDeny", 1).invoke(false);
      } catch (_0x4a4b74) {}
      try {
        _0x52f348.method("get_EnforceProviderDeny").implementation = () => false;
      } catch (_0x157301) {}
      try {
        _0x52f348.field("SPAWN_MAX_PER_WINDOW").value = 2147483647;
      } catch (_0x4a9b70) {}
      try {
        _0x52f348.field("SPAWN_RATE_WINDOW").value = 0;
      } catch (_0x4e586c) {}
      try {
        _0x52f348.method("get_MaxSpawnsPerWind").implementation = () => 2147483647;
      } catch (_0x2f28c1) {}
      try {
        _0x52f348.method("get_SpawnRateWindow").implementation = () => 0;
      } catch (_0x1746bf) {}
      for (const _0x40c784 of [
        "_spawnRateBySource",
        "_reportedSources",
        "_reportedProviderDenies",
        "_noMobArea",
      ]) {
        try {
          _0x52f348.field(_0x40c784).value.method("Clear").invoke();
        } catch (_0x22fe0c) {}
      }
      try {
        _0x52f348.method("HandleViolation", 4).implementation = function () {};
      } catch (_0x5d7b0e) {}
      try {
        _0x52f348.method("RequestAuthoritativeDespawn", 1).implementation = function () {};
      } catch (_0x249241) {}
      try {
        _0x52f348.method("NeutralizeLocally", 1).implementation = function () {};
      } catch (_0x4d13e4) {}
      console.log("[spawnMob] SpawnGuardPolicy fully bypassed");
    } catch (_0x46e597) {
      console.log("[spawnMob] SpawnGuardPolicy bypass FAILED: " + _0x46e597);
    }
    _0x33fc15();
    _0x25db54 = true;
  }
  function _0x123ad3() {
    try {
      const _0x2b6b26 = Il2Cpp.domain.assembly("AnimalCompany").image;
      const _0x137273 = Il2Cpp.domain.assembly("UnityEngine.CoreModule").image;
      const _0xb42e42 = _0x2b6b26.class("AnimalCompany.NetworkedMobSpawnGroup");
      const _0x23c94a = _0x137273
        .class("UnityEngine.Object")
        .method("FindObjectsOfType", 0)
        .inflate(_0xb42e42)
        .invoke();
      for (let _0xdc86cf = 0; _0xdc86cf < _0x23c94a.length; _0xdc86cf++) {
        const _0x47e100 = _0x23c94a.get(_0xdc86cf);
        if (!_0x47e100 || (_0x47e100.handle && _0x47e100.handle.isNull())) {
          continue;
        }
        try {
          const _0x3d870a = _0x47e100.field("_spawnDataName").value;
          const _0x19d8c4 = String(_0x3d870a || "");
          if (_0x19d8c4 && _0x19d8c4 !== "null") {
            return Il2Cpp.string(_0x19d8c4);
          }
        } catch (_0x4d0545) {}
      }
    } catch (_0x10b520) {}
    return Il2Cpp.string("NetworkedMobSpawnGroup");
  }
  const _0x1c4cd8 = new Set();
  const _0x51a4ea = new Set();
  function _0x1ff175(_0x2c6257) {
    if (_0x2c6257 === null || _0x2c6257 === undefined) {
      return "";
    }
    try {
      const _0x1a4424 = _0x2c6257.field("Raw").value;
      if (_0x1a4424 !== undefined) {
        return String(_0x1a4424);
      }
    } catch (_0x3acae7) {}
    try {
      const _0x566267 = _0x2c6257.field("_raw").value;
      if (_0x566267 !== undefined) {
        return String(_0x566267);
      }
    } catch (_0x16fe51) {}
    try {
      return String(_0x2c6257);
    } catch (_0x6ab9e3) {}
    return "";
  }
  function _0x913c27(_0x306a53) {
    try {
      if (_0x306a53.handle && _0x306a53.handle.isNull()) {
        return "";
      }
      if (_0x306a53.handle) {
        return String(_0x306a53.handle);
      }
    } catch (_0x20a6ba) {}
    return "";
  }
  function _0x507e0e(_0x5238d4) {
    if (!_0x5238d4 || (_0x5238d4.handle && _0x5238d4.handle.isNull())) {
      return false;
    }
    try {
      const _0x380d9a = Il2Cpp.domain.assembly("AnimalCompany").image;
      const _0x5b6397 = _0x380d9a.class("AnimalCompany.MobController");
      let _0x4a3808 = null;
      try {
        _0x4a3808 = _0x5238d4.method("GetComponent", 1).inflate(_0x5b6397).invoke();
      } catch (_0x456a65) {}
      if (!_0x4a3808 || (_0x4a3808.handle && _0x4a3808.handle.isNull())) {
        try {
          const _0x434e3d = _0x5238d4.method("get_gameObject").invoke();
          _0x4a3808 = _0x434e3d.method("GetComponentInChildren", 1).inflate(_0x5b6397).invoke();
        } catch (_0x50aec2) {}
      }
      return !!_0x4a3808 && (!_0x4a3808.handle || !_0x4a3808.handle.isNull());
    } catch (_0x718439) {
      return false;
    }
  }
  function _0x3441c6(_0x5f08d9) {
    if (!_0x5f08d9 || (_0x5f08d9.handle && _0x5f08d9.handle.isNull())) {
      return false;
    }
    const _0x276a10 = _0x913c27(_0x5f08d9);
    if (_0x276a10 && _0x51a4ea.has(_0x276a10)) {
      return true;
    }
    try {
      const _0x5df9f3 = _0x1ff175(_0x5f08d9.method("get_Id").invoke());
      if (_0x5df9f3 && _0x1c4cd8.has(_0x5df9f3)) {
        return true;
      }
    } catch (_0x1d4c41) {}
    return _0x25db54 && _0x507e0e(_0x5f08d9);
  }
  function _0x101b1d(_0x2dcc2e, _0x1e1d2b = null) {
    try {
      if (!_0x2dcc2e || (_0x2dcc2e.handle && _0x2dcc2e.handle.isNull())) {
        return;
      }
      const _0x531124 = Il2Cpp.domain.assembly("AnimalCompany").image;
      try {
        const _0x3d33dc = _0x2dcc2e.method("get_Id").invoke();
        const _0x6d27ff = _0x1ff175(_0x3d33dc);
        if (_0x6d27ff) {
          _0x1c4cd8.add(_0x6d27ff);
        }
        try {
          _0x531124
            .class("AnimalCompany.MobSpawnValidator")
            .method("AddAllowMob", 1)
            .invoke(_0x3d33dc);
        } catch (_0x129647) {}
      } catch (_0x3590fb) {}
      const _0x41bb06 = _0x913c27(_0x2dcc2e);
      if (_0x41bb06) {
        _0x51a4ea.add(_0x41bb06);
      }
      const _0x19ce04 = _0x531124.class("AnimalCompany.MobController");
      let _0x44acf6 = null;
      try {
        _0x44acf6 = _0x2dcc2e.method("GetComponent", 1).inflate(_0x19ce04).invoke();
      } catch (_0x371f14) {}
      if (!_0x44acf6 || (_0x44acf6.handle && _0x44acf6.handle.isNull())) {
        try {
          const _0x1b812b = _0x2dcc2e.method("get_gameObject").invoke();
          _0x44acf6 = _0x1b812b.method("GetComponent", 1).inflate(_0x19ce04).invoke();
        } catch (_0x2c278a) {}
      }
      if (!_0x44acf6 || (_0x44acf6.handle && _0x44acf6.handle.isNull())) {
        return;
      }
      try {
        _0x44acf6.method("set_n_deathAction").invoke(0);
      } catch (_0x25d920) {}
      try {
        _0x44acf6.method("set_n_isDie").invoke(false);
      } catch (_0x193785) {}
      try {
        _0x44acf6.field("_isDieLoca").value = false;
      } catch (_0x381883) {}
      if (_0x1e1d2b) {
        try {
          _0x44acf6.method("ApplySectorsFromSpawnPosition", 1).invoke(_0x1e1d2b);
        } catch (_0x5655da) {}
      }
      try {
        const _0x4672a6 = _0x44acf6.field("_stateAuthHandler").value;
        if (_0x4672a6 && (!_0x4672a6.handle || !_0x4672a6.handle.isNull())) {
          try {
            _0x4672a6.field("_alwaysRequireStateAuth").value = true;
          } catch (_0x2238dd) {}
          try {
            _0x4672a6.field("_deactivateOnInterestExit").value = false;
          } catch (_0x3d425b) {}
          try {
            _0x4672a6.field("_isLocalWithinActiveRange").value = true;
          } catch (_0x5347c7) {}
          try {
            _0x4672a6.field("_isAuthInactive").value = false;
          } catch (_0x2a09d8) {}
          try {
            _0x4672a6.field("_isRequestingStateAuthority").value = false;
          } catch (_0x3d0145) {}
          try {
            _0x4672a6.field("_despawnRequested").value = false;
          } catch (_0x446c50) {}
          try {
            _0x4672a6.method("set_n_isAuthWithinActiveRange").invoke(true);
          } catch (_0x533608) {}
          try {
            _0x4672a6.method("set_n_despawnRequested").invoke(false);
          } catch (_0x492f5e) {}
        }
      } catch (_0x452b9f) {}
    } catch (_0x435583) {
      console.log("[spawnMob] protectSpawnedMob error: " + _0x435583);
    }
  }
  function _0x5a2820(_0x49f190, _0x3cc539 = null) {
    try {
      if (!_0x49f190 || (_0x49f190.handle && _0x49f190.handle.isNull())) {
        return;
      }
      let _0x2e4c5e = _0x3cc539;
      if (!_0x2e4c5e || (_0x2e4c5e.handle && _0x2e4c5e.handle.isNull())) {
        try {
          _0x2e4c5e = _0x49f190.method("get_Runner").invoke();
        } catch (_0x43eeb5) {}
      }
      if (!_0x2e4c5e || (_0x2e4c5e.handle && _0x2e4c5e.handle.isNull())) {
        return;
      }
      try {
        _0x2e4c5e.method("SetIsSimulated", 2).invoke(_0x49f190, true);
      } catch (_0x206dd0) {}
      try {
        const _0xd2a6fc = _0x2e4c5e.method("get_ActivePlayers").invoke();
        if (!_0xd2a6fc) {
          return;
        }
        let _0x5cf0e9;
        try {
          _0x5cf0e9 = _0xd2a6fc.method("GetEnumerator").invoke();
        } catch (_0x3957e3) {
          try {
            _0x5cf0e9 = _0xd2a6fc
              .method("System.Collections.Generic.IEnumerable<Fusion.PlayerRef>.GetEnumerator")
              .invoke();
          } catch (_0x5dced5) {}
        }
        if (!_0x5cf0e9) {
          return;
        }
        while (_0x5cf0e9.method("MoveNext").invoke()) {
          let _0x2a7248 = null;
          try {
            _0x2a7248 = _0x5cf0e9.field("<>2__current").value;
          } catch (_0x469336) {
            try {
              _0x2a7248 = _0x5cf0e9
                .method("System.Collections.Generic.IEnumerator<Fusion.PlayerRef>.get_Current")
                .invoke();
            } catch (_0xa7df24) {}
          }
          if (_0x2a7248 === null || _0x2a7248 === undefined) {
            continue;
          }
          try {
            _0x49f190.method("SetPlayerAlive", 2).invoke(_0x2a7248, true);
          } catch (_0xd4ab19) {}
        }
      } catch (_0x3bb4b9) {}
    } catch (_0x547d4f) {
      console.log("[spawnMob] forceMobReplication error: " + _0x547d4f);
    }
  }
  function _0x33fc15() {
    try {
      const _0x3abde0 = Il2Cpp.domain
        .assembly("Fusion.Runtime")
        .image.class("Fusion.NetworkRunner");
      try {
        const _0x5125a1 = _0x3abde0.method("Despawn", 1).overload("Fusion.NetworkObject");
        _0x5125a1.implementation = function (_0x298a52) {
          if (_0x3441c6(_0x298a52)) {
            _0x101b1d(_0x298a52);
            return;
          }
          return _0x5125a1.bind(this).invoke(_0x298a52);
        };
      } catch (_0x11705b) {}
      try {
        const _0x432be1 = _0x3abde0
          .method("Destroy", 2)
          .overload("Fusion.NetworkObject", "Fusion.NetworkObjectDestroyFlags");
        _0x432be1.implementation = function (_0x2038bb, _0x324a1f) {
          if (_0x3441c6(_0x2038bb)) {
            _0x101b1d(_0x2038bb);
            return;
          }
          return _0x432be1.bind(this).invoke(_0x2038bb, _0x324a1f);
        };
      } catch (_0x41c3e4) {}
      console.log("[spawnMob] Fusion despawn hooks installed");
    } catch (_0x4c3712) {
      console.log("[spawnMob] installFusionMobDespawnHooks FAILED: " + _0x4c3712);
    }
  }
  let _0x721f14 = null;
  function _0x497de3(_0xcb7a46) {
    try {
      if (!_0x721f14) {
        _0x721f14 = Il2Cpp.domain
          .assembly("Fusion.Runtime")
          .image.class("Fusion.NetworkObjectSpawnDelegate");
      }
      return Il2Cpp.delegate(_0x721f14, (_0x30e00d) => {
        if (!_0x30e00d) {
          return;
        }
        _0x101b1d(_0x30e00d, _0xcb7a46);
        _0x5a2820(_0x30e00d);
      });
    } catch (_0x245810) {
      console.log("[spawnMob] createMobSpawnCompletedDelegate FAILED: " + _0x245810);
      return null;
    }
  }
  function _0x3c8f1a() {
    if (_0x399364) {
      return _0x399364;
    }
    try {
      _0x111144 = Il2Cpp.domain
        .assembly("Fusion.Runtime")
        .image.class("Fusion.NetworkRunner")
        .tryNested("OnBeforeSpawned");
      if (!_0x111144) {
        console.log("[spawnMob] OnBeforeSpawned nested class not found — delegate will be null");
        return null;
      }
      const _0x1025ad = Il2Cpp.domain
        .assembly("AnimalCompany")
        .image.class("AnimalCompany.MobSpawnValidator");
      _0x399364 = Il2Cpp.delegate(_0x111144, (_0x2a9ca2, _0x6a8dfb) => {
        var _0x2632f5;
        if (
          !_0x6a8dfb ||
          ((_0x2632f5 = _0x6a8dfb.handle) === null || _0x2632f5 === undefined
            ? undefined
            : _0x2632f5.isNull())
        ) {
          return;
        }
        try {
          const _0x2c038f = _0x6a8dfb.method("get_Id").invoke();
          _0x1025ad.method("AddAllowMob", 1).invoke(_0x2c038f);
        } catch (_0x320e0e) {
          console.log("[spawnMob] delegate inner error: " + _0x320e0e);
        }
      });
      console.log("[spawnMob] OnBeforeSpawned delegate created OK");
    } catch (_0x5d1431) {
      console.log("[spawnMob] getBeforeMobSpawnDelegate FAILED: " + _0x5d1431);
    }
    return _0x399364;
  }
  function _0xdef527(_0x4df5bb, _0x49b1c3, _0xb1e1aa = QuaternionIdentity) {
    try {
      _0x16dc3e();
      const _0x238b68 = Il2Cpp.domain.assembly("AnimalCompany").image;
      const _0x18ea5e = _0x238b68.class("AnimalCompany.PrefabGenerator");
      const _0x549d05 = _0x238b68.class("AnimalCompany.MobID");
      const _0x550075 = String(_0x4df5bb).replace(/^mob_prefab\//, "");
      const _0xb1a597 = [
        _0x550075,
        _0x550075.replace(/Controller$/, ""),
        _0x550075.replace(/_?Controller$/, ""),
      ];
      let _0x3df29c = null;
      for (const _0xb947b4 of _0xb1a597) {
        try {
          _0x3df29c = _0x549d05.field(_0xb947b4).value;
          break;
        } catch (_0x3633df) {}
      }
      if (_0x3df29c === null) {
        console.log("[spawnMob] could not resolve MobID for: " + _0x4df5bb);
        return false;
      }
      const _0x3f6ebe = _0x18ea5e.field("_instance").value;
      if (!_0x3f6ebe || _0x3f6ebe.isNull()) {
        console.log("[spawnMob] PrefabGenerator._instance null");
        return false;
      }
      const _0x4f2656 = _0x123ad3();
      const _0x2638ec = _0x3c8f1a() || _0x366930;
      const _0x1c82d1 = _0x497de3(_0x49b1c3) || _0x366930;
      const _0x2f53b5 = _0xb1e1aa || QuaternionIdentity;
      _0x1f4762 = true;
      try {
        try {
          _0x3f6ebe
            .method("SpawnMobAsync", 6)
            .overload(
              "AnimalCompany.MobID",
              "UnityEngine.Vector3",
              "UnityEngine.Quaternion",
              "Fusion.NetworkRunner.OnBeforeSpawned",
              "Fusion.NetworkObjectSpawnDelegate",
              "System.String",
            )
            .invoke(_0x3df29c, _0x49b1c3, _0x2f53b5, _0x2638ec, _0x1c82d1, _0x4f2656);
          console.log("[spawnMob] SpawnMobAsync(6) OK: " + _0x550075);
          return true;
        } catch (_0x14ac3d) {}
        try {
          _0x3f6ebe
            .method("SpawnMobAsync", 6)
            .invoke(_0x3df29c, _0x49b1c3, _0x2f53b5, _0x2638ec, _0x1c82d1, _0x4f2656);
          console.log("[spawnMob] SpawnMobAsync(6) untyped OK: " + _0x550075);
          return true;
        } catch (_0x1ab964) {}
        try {
          _0x3f6ebe.method("SpawnMob", 4).invoke(_0x3df29c, _0x49b1c3, _0x2f53b5, _0x366930);
          console.log("[spawnMob] SpawnMob(4) OK: " + _0x550075);
          return true;
        } catch (_0x2b032d) {}
        try {
          _0x3f6ebe
            .method("SpawnMob", 5)
            .invoke(_0x3df29c, _0x49b1c3, _0x2f53b5, _0x366930, _0x4f2656);
          console.log("[spawnMob] SpawnMob(5) OK: " + _0x550075);
          return true;
        } catch (_0x376c41) {}
        try {
          _0x3f6ebe
            .method("SpawnMobNearbyAsync", 6)
            .overload(
              "AnimalCompany.MobID",
              "UnityEngine.Vector3",
              "System.Single",
              "Fusion.NetworkRunner.OnBeforeSpawned",
              "Fusion.NetworkObjectSpawnDelegate",
              "System.String",
            )
            .invoke(_0x3df29c, _0x49b1c3, 8, _0x2638ec, _0x1c82d1, _0x4f2656);
          console.log("[spawnMob] SpawnMobNearbyAsync(6) OK: " + _0x550075);
          return true;
        } catch (_0x5eb3da) {}
        try {
          _0x3f6ebe
            .method("SpawnMobNearbyPlayerAsync", 5)
            .overload(
              "AnimalCompany.MobID",
              "System.Single",
              "Fusion.NetworkRunner.OnBeforeSpawned",
              "Fusion.NetworkObjectSpawnDelegate",
              "System.String",
            )
            .invoke(_0x3df29c, 8, _0x2638ec, _0x1c82d1, _0x4f2656);
          console.log("[spawnMob] SpawnMobNearbyPlayerAsync(5) OK: " + _0x550075);
          return true;
        } catch (_0x481d5f) {}
      } finally {
        _0x1f4762 = false;
      }
      console.log("[spawnMob] all methods failed for: " + _0x550075);
      return false;
    } catch (_0x26af3f) {
      console.log("[spawnMob] outer error for " + _0x4df5bb + ": " + _0x26af3f);
      return false;
    }
  }
  function _0x257037(_0x40bee2, _0x492154, _0x3c680f) {
    const _0x1e8a50 = _0xdef527(_0x40bee2.name, _0x492154, _0x3c680f);
    if (_0x1e8a50) {
      return;
    }
    try {
      PrefabGeneratorClass.method("SpawnMobAsync", 6).invoke(
        _0x40bee2.id,
        _0x492154,
        _0x3c680f,
        _0x366930,
        _0x366930,
        Il2Cpp.string("menu"),
      );
    } catch (_0x1c8f8a) {
      console.log("[spawnMobAtPos] SpawnMobAsync failed for " + _0x40bee2.name + ": " + _0x1c8f8a);
      try {
        PrefabGeneratorClass.method("SpawnMobAsyncInternal", 6).invoke(
          _0x40bee2.id,
          _0x492154,
          _0x3c680f,
          _0x366930,
          _0x366930,
          Il2Cpp.string("menu"),
        );
      } catch (_0x13b490) {
        console.log(
          "[spawnMobAtPos] SpawnMobAsyncInternal also failed for " +
            _0x40bee2.name +
            ": " +
            _0x13b490,
        );
      }
    }
  }
  function _0x2561c6() {
    try {
      return rightHandTransform.method("TransformPoint", 3).invoke(0, 0, 0.1);
    } catch (_0x45b2eb) {
      return rightHandTransform.method("get_position").invoke();
    }
  }
  let _0x1fb972 = false;
  let _0x1f4762 = false;
  try {
    const _0xf039d4 = Il2Cpp.domain.assembly("Fusion.Runtime").image.class("Fusion.NetworkRunner");
    _0xf039d4.method("get_IsServer").implementation = function () {
      if (_0x1f4762) {
        return true;
      }
      return this.method("get_IsServer").invoke();
    };
  } catch (_0x5ccf46) {}
  let _0x2b3a80 = null;
  const _0x2e1a3f = (_0x4408e8) => {
    if (_0x4408e8.class.isEnum || _0x4408e8.isPrimitive) {
      return 0;
    }
    if (!_0x4408e8.class.isValueType) {
      return _0x366930;
    }
    const _0x3c41bb = _0x4408e8.class.fields.filter((_0x4c53d5) => !_0x4c53d5.isStatic);
    if (_0x3c41bb.length === 0) {
      return 0;
    }
    return _0x3c41bb.map((_0x507ab9) => _0x2e1a3f(_0x507ab9.type));
  };
  const _0x1ef917 = (_0x44201b, _0x19f949) => {
    if (typeof _0x19f949 === "boolean") {
      if (_0x19f949) {
        return 1;
      } else {
        return 0;
      }
    }
    if (_0x19f949 instanceof Il2Cpp.ValueType) {
      const _0x5c6205 = _0x44201b.class.fields.filter((_0x22c3fb) => !_0x22c3fb.isStatic);
      if (_0x5c6205.length === 0) {
        return 0;
      }
      return _0x5c6205.map((_0x1b8b1b) =>
        _0x1ef917(_0x1b8b1b.type, _0x1b8b1b.bind(_0x19f949).value),
      );
    }
    if (Array.isArray(_0x19f949)) {
      return _0x19f949.map((_0x27e12c) => _0x1ef917(_0x44201b, _0x27e12c));
    }
    return _0x19f949;
  };
  const _0x141d81 = (_0x381989, _0x40ee47, _0x272aa0) => {
    const _0x1144ae = _0x381989.class.fields.filter((_0x22ddf6) => !_0x22ddf6.isStatic);
    return _0x1144ae.map((_0x2a0d29) => {
      const _0x56b70c = _0x2a0d29.name.toLowerCase();
      if (_0x56b70c.includes("hasvalue")) {
        if (_0x40ee47) {
          return 1;
        } else {
          return 0;
        }
      }
      if (_0x56b70c === "value") {
        if (_0x40ee47) {
          return _0x272aa0;
        } else {
          return _0x2e1a3f(_0x2a0d29.type);
        }
      }
      return _0x2e1a3f(_0x2a0d29.type);
    });
  };
  const _0x16b7a3 = (_0x25063d, _0x4a2cc1) =>
    _0x141d81(_0x25063d, true, _0x1ef917(_0x4a2cc1.type, _0x4a2cc1));
  function _0x14c1cd(_0x48873d, _0x4d9a82, _0x3500d4, _0x4b6787) {
    if (!_0x2b3a80) {
      for (const _0x1250e0 of _0x48873d.method("Spawn").overloads()) {
        if (_0x1250e0.parameterCount !== 6 || _0x1250e0.isGeneric) {
          continue;
        }
        const _0x2ce123 = _0x1250e0.parameters;
        if (
          _0x2ce123[0].type.name.includes("Fusion.NetworkObject") &&
          _0x2ce123[1].type.name.startsWith("System.Nullable") &&
          _0x2ce123[1].type.name.includes("Vector3") &&
          _0x2ce123[2].type.name.startsWith("System.Nullable") &&
          _0x2ce123[2].type.name.includes("Quaternion") &&
          _0x2ce123[3].type.name.startsWith("System.Nullable") &&
          _0x2ce123[3].type.name.includes("PlayerRef") &&
          _0x2ce123[4].type.name.includes("OnBeforeSpawned") &&
          _0x2ce123[5].type.name.includes("NetworkSpawnFlags")
        ) {
          _0x2b3a80 = _0x1250e0;
          break;
        }
      }
    }
    if (!_0x2b3a80) {
      console.log("[spawnNetworkPrefab] runner.Spawn overload not found");
      return null;
    }
    const _0x346c77 = _0x16b7a3(_0x2b3a80.parameters[1].type, _0x3500d4);
    const _0x1fd732 = _0x16b7a3(_0x2b3a80.parameters[2].type, _0x4b6787);
    const _0x11f4b8 = _0x141d81(
      _0x2b3a80.parameters[3].type,
      false,
      _0x2e1a3f(_0x2b3a80.parameters[3].type),
    );
    const _0x2657e9 = _0x2b3a80.parameters[4].type.class.isValueType
      ? _0x2e1a3f(_0x2b3a80.parameters[4].type)
      : _0x366930;
    _0x1f4762 = true;
    try {
      return _0x2b3a80
        .bind(_0x48873d)
        .invoke(_0x4d9a82, _0x346c77, _0x1fd732, _0x11f4b8, _0x2657e9, 0);
    } finally {
      _0x1f4762 = false;
    }
  }
  function _0x48247c(_0x50e787, _0x1da595, _0x45c314, _0x46e366, _0x412ade, _0x20afb5) {
    for (let _0x48524f = 0; _0x48524f < _0x1da595; _0x48524f++) {
      let _0xc7d454 = "";
      try {
        const _0x2dee65 = _0x50e787.method("get_Item").invoke(_0x48524f);
        _0xc7d454 = _0x2dee65.method("get_Description").invoke().toString();
      } catch (_0x39ece8) {
        continue;
      }
      if (!_0xc7d454.includes(_0x45c314)) {
        continue;
      }
      console.log("[spawnNetworkPrefab] matched '" + _0x45c314 + "'");
      try {
        const _0x5bcb52 = _0x50e787.method("get_Item").invoke(_0x48524f);
        let _0x257b71 = null;
        try {
          let _0x32897f = null;
          try {
            _0x32897f = _0x5bcb52.field("AssetGuid").value;
          } catch (_0x275a37) {}
          if (!_0x32897f) {
            _0x32897f = _0x5bcb52.method("get_AssetGuid").invoke();
          }
          const _0x36944a = _0x46e366.method("get_Prefabs").invoke();
          const _0x50d71b = _0x36944a.method("GetId", 1).invoke(_0x32897f);
          _0x257b71 = _0x36944a.method("Load", 2).invoke(_0x50d71b, true);
          console.log("[spawnNetworkPrefab] Load(prefabId) ok");
        } catch (_0x46fa00) {
          try {
            _0x257b71 = _0x5bcb52.method("WaitForResult").invoke();
          } catch (_0x550525) {
            console.log("[spawnNetworkPrefab] WaitForResult failed: " + _0x550525);
            continue;
          }
        }
        if (!_0x257b71 || _0x257b71.isNull()) {
          console.log("[spawnNetworkPrefab] prefab object is null");
          continue;
        }
        return _0x14c1cd(_0x46e366, _0x257b71, _0x412ade, _0x20afb5);
      } catch (_0x120500) {
        console.log("[spawnNetworkPrefab] inner error: " + _0x120500);
      }
    }
    return null;
  }
  function _0x5db48f(_0x35c948, _0x1c1e94, _0x19bc4c) {
    try {
      const _0x3c8e4a = PrefabGeneratorClass.field("_instance").value.method("get_runner").invoke();
      if (!_0x3c8e4a || _0x3c8e4a.isNull()) {
        return null;
      }
      try {
        const _0x1cefc3 = _0x3c8e4a.method("get_Prefabs").invoke();
        const _0x23c9d5 = _0x1cefc3.method("get_Prefabs").invoke();
        const _0x31f865 = _0x23c9d5.method("get_Count").invoke();
        if (!_0x1fb972) {
          _0x1fb972 = true;
          let _0x372745 = "[PrefabTable via get_Prefabs] count=" + _0x31f865 + ": ";
          for (let _0x23f4f1 = 0; _0x23f4f1 < _0x31f865; _0x23f4f1++) {
            try {
              _0x372745 +=
                _0x23c9d5
                  .method("get_Item")
                  .invoke(_0x23f4f1)
                  .method("get_Description")
                  .invoke()
                  .toString() + ", ";
            } catch (_0x4fdd28) {}
          }
          console.log(_0x372745);
        }
        const _0xb2f324 = _0x48247c(
          _0x23c9d5,
          _0x31f865,
          _0x35c948,
          _0x3c8e4a,
          _0x1c1e94,
          _0x19bc4c,
        );
        if (_0xb2f324) {
          return _0xb2f324;
        }
      } catch (_0xb3461) {
        console.log("[spawnNetworkPrefab] get_Prefabs path failed: " + _0xb3461);
      }
      try {
        const _0x1e904c = _0x3c8e4a
          .field("_config")
          .value.field("PrefabTable")
          .value.field("_sources").value;
        const _0x5dd157 = _0x1e904c.method("get_Count").invoke();
        const _0xc0e789 = _0x48247c(
          _0x1e904c,
          _0x5dd157,
          _0x35c948,
          _0x3c8e4a,
          _0x1c1e94,
          _0x19bc4c,
        );
        if (_0xc0e789) {
          return _0xc0e789;
        }
      } catch (_0x2e44f1) {
        console.log("[spawnNetworkPrefab] _config fallback failed: " + _0x2e44f1);
      }
      console.log("[spawnNetworkPrefab] prefab not found: " + _0x35c948);
    } catch (_0x1ab52d) {
      smartError("spawnNetworkPrefab error:", _0x1ab52d);
    }
    return null;
  }
  let _0x5d176a = null;
  let _0x3a7901 = "";
  let _0x404037 = 0;
  let _0x3492fa = [];
  let _0x47ace9 = 0;
  function _0x1f9cb3(_0x1d2a7c) {
    _0x1d2a7c = Vector3Class.method("op_Subtraction", 2).invoke(
      _0x1d2a7c,
      _0xe40610(bodyCollider).method("get_position").invoke(),
    );
    _0x1d2a7c = Vector3Class.method("op_Addition", 2).invoke(
      _0x1d2a7c,
      _0xe40610(localRig).method("get_position").invoke(),
    );
    return _0x1d2a7c;
  }
  function _0x5664f5(_0x2d1d0b) {
    const _0x53e882 = NetPlayerClass.method("get_localPlayer").invoke();
    if (!_0x53e882) {
      return;
    }
    _0x53e882.method("RPC_Teleport").invoke(_0x1f9cb3(_0x2d1d0b));
  }
  function notify(message = "", isError = true, duration = 5) {
    const _0x254baa = currentNotification == message;
    notifactionResetTime = time + duration;
    currentNotification = message;
    if (isError && !_0x254baa) {
      _0x5b6a19();
    }
  }
  function _0x4ce8a5(_0x2b954d, _0x4af3cd) {
    try {
      _0xe40610(_0x2b954d).method("set_position").invoke(_0x4af3cd);
      return true;
    } catch (_0x143e1f) {
      return false;
    }
  }
  function _0x5a15dd(_0x39b6e1, _0x2660da) {
    if (!_0x39b6e1 || _0x39b6e1.isNull()) {
      return false;
    }
    _0x58bf44(_0x39b6e1);
    try {
      if (_0x16fc51(_0x39b6e1)) {
        _0x18a723(function () {
          try {
            _0x39b6e1.method("RPC_Teleport").invoke(_0x1f9cb3(_0x2660da));
          } catch (_0x5d485a) {
            _0x39b6e1.method("RPC_Teleport").invoke(_0x2660da);
          }
        });
        return true;
      }
      try {
        _0x39b6e1.method("RPC_Teleport").invoke(_0x2660da);
        return true;
      } catch (_0xbe37e4) {}
      try {
        _0x39b6e1.method("RPC_Teleport").invoke(_0x1f9cb3(_0x2660da));
        return true;
      } catch (_0x8d6e0e) {}
    } catch (_0x288bd4) {}
    return _0x4ce8a5(_0x39b6e1, _0x2660da);
  }
  function _0x4aa64c(
    _0x39d241 = Vector3Zero,
    _0x32a526 = QuaternionIdentity,
    _0x3106cb = Vector3One,
    _0x374fce = 3,
    _0x37bf10 = [1, 1, 1, 1],
    _0x1ba292 = null,
    _0x1af11f = true,
  ) {
    const _0x1bd97e = GameObjectClass.method("CreatePrimitive").invoke(_0x374fce);
    const _0x396bb8 = _0x3302f9(_0x1bd97e, RendererClass);
    if (_0x396bb8 && !_0x396bb8.isNull()) {
      if (_0x37bf10[3] == 0) {
        _0x396bb8.method("set_enabled").invoke(false);
      } else {
        const _0x545f28 = _0x396bb8.method("get_material").invoke();
        if (_0x545f28 && !_0x545f28.isNull()) {
          _0x545f28.method("set_shader").invoke(unlitShader);
          _0x545f28.method("set_color").invoke(_0x37bf10);
        }
      }
    }
    const _0x1eb26f = _0x3302f9(_0x1bd97e, ColliderClass);
    if (_0x1eb26f && !_0x1eb26f.isNull()) {
      _0x1eb26f.method("set_enabled").invoke(_0x1af11f);
      _0x1eb26f.method("set_isTrigger").invoke(true);
    }
    const _0x70d10b = _0xe40610(_0x1bd97e);
    if (_0x1ba292 != null) {
      _0x70d10b.method("SetParent", 2).invoke(_0x1ba292, false);
    }
    _0x70d10b.method("set_position").invoke(_0x39d241);
    _0x70d10b.method("set_rotation").invoke(_0x32a526);
    _0x70d10b.method("set_localScale").invoke(_0x3106cb);
    return _0x1bd97e;
  }
  function _0x25ccd6(
    _0x21b304,
    _0x5abeb9 = "",
    _0x21082f = [1, 1, 1, 1],
    _0x49f430 = Vector3Zero,
    _0x5e19e1 = Vector3One,
  ) {
    const _0x365730 = _0x4aa64c(
      Vector3Zero,
      QuaternionIdentity,
      Vector3One,
      3,
      [0, 0, 0, 0],
      _0xe40610(_0x21b304),
    );
    let _0x329cc6;
    if (_0x109ec9 && _0x123d5d) {
      _0x329cc6 = _0x238332(_0x365730, _0x109ec9);
      _0x329cc6.method("set_text").invoke(Il2Cpp.string(_0x5abeb9));
      try {
        _0x329cc6.method("set_font").invoke(_0x123d5d);
      } catch (_0x29eaa8) {}
      _0x329cc6.method("set_color").invoke(_0x21082f);
      try {
        _0x329cc6.method("set_fontStyle").invoke(1);
      } catch (_0x399746) {}
      try {
        _0x329cc6.method("set_enableWordWrapping").invoke(false);
      } catch (_0x5ef1dc) {}
      try {
        _0x329cc6.method("set_overflowMode").invoke(0);
      } catch (_0xd557eb) {}
      try {
        _0x329cc6.method("set_enableAutoSizing").invoke(true);
        _0x329cc6.method("set_fontSizeMin").invoke(1);
        _0x329cc6
          .method("set_fontSizeMax")
          .invoke(Math.max(10, (_0x5e19e1[1] ?? 0.05) * 1000 * 0.6));
      } catch (_0x32ec2f) {}
      try {
        _0x329cc6.method("set_alignment").invoke(514);
      } catch (_0x209ae7) {}
    } else {
      _0x329cc6 = _0x238332(_0x365730, UiTextClass);
      _0x329cc6.method("set_text").invoke(Il2Cpp.string(_0x5abeb9));
      _0x329cc6.method("set_font").invoke(_0x5bdfd7);
      _0x329cc6.method("set_fontSize").invoke(1);
      _0x329cc6.method("set_color").invoke(_0x21082f);
      _0x329cc6.method("set_fontStyle").invoke(1);
      _0x329cc6.method("set_alignment").invoke(4);
      _0x329cc6.method("set_resizeTextForBestFit").invoke(true);
      _0x329cc6.method("set_resizeTextMinSize").invoke(0);
    }
    const _0x419df7 = _0x3302f9(_0x329cc6, RectTransformClass);
    if (_0x109ec9 && _0x123d5d) {
      const _0x4823ae = 1000;
      _0x419df7
        .method("set_sizeDelta")
        .invoke([(_0x5e19e1[0] ?? 1) * _0x4823ae, (_0x5e19e1[1] ?? 1) * _0x4823ae]);
      _0x419df7.method("set_localScale").invoke([1 / _0x4823ae, 1 / _0x4823ae, 1 / _0x4823ae]);
    } else {
      _0x419df7.method("set_sizeDelta").invoke(_0x5e19e1);
    }
    _0x419df7.method("set_position").invoke(_0x49f430);
    _0x419df7.method("set_rotation").invoke(QuaternionClass.method("Euler").invoke(180, 90, 90));
    try {
      menuFadeTexts.push({
        txt: _0x329cc6,
        base: [_0x21082f[0], _0x21082f[1], _0x21082f[2], _0x21082f[3] ?? 1],
      });
    } catch (_0x5459c0) {}
    return _0x329cc6;
  }
  function _0x2d7be3() {
    try {
      const _0x5ef405 = NetPlayerClass.method("get_localPlayer").invoke();
      if (_0x5ef405 && !_0x5ef405.isNull()) {
        return _0x5ef405;
      } else {
        return null;
      }
    } catch (_0x35546c) {
      return null;
    }
  }
  function _0x2c5496(_0x40d123) {
    if (!_0x40d123 || _0x40d123.isNull()) {
      return null;
    }
    try {
      if (_0x40d123.class && _0x40d123.class.name === "NetworkObject") {
        return _0x40d123;
      }
    } catch (_0x3f2f5f) {}
    const _0x3381c4 = [
      () => _0x40d123.method("get_Object").invoke(),
      () => _0x40d123.method("get_NetworkObject").invoke(),
      () => _0x40d123.method("get_networkObject").invoke(),
      () =>
        _0x40d123
          .method("GetComponent", 1)
          .inflate(Il2Cpp.domain.assembly("Fusion.Runtime").image.class("Fusion.NetworkObject"))
          .invoke(),
    ];
    for (const _0x129145 of _0x3381c4) {
      try {
        const _0x30d277 = _0x129145();
        if (_0x30d277 && !_0x30d277.isNull()) {
          return _0x30d277;
        }
      } catch (_0x3d7ca8) {}
    }
    try {
      const _0x16e2d8 = _0x40d123.method("get_gameObject").invoke();
      if (_0x16e2d8 && !_0x16e2d8.isNull()) {
        const _0x5d26a5 = _0x16e2d8
          .method("GetComponent", 1)
          .inflate(Il2Cpp.domain.assembly("Fusion.Runtime").image.class("Fusion.NetworkObject"))
          .invoke();
        if (_0x5d26a5 && !_0x5d26a5.isNull()) {
          return _0x5d26a5;
        }
      }
    } catch (_0x56d4a9) {}
    return null;
  }
  function _0x1706ac(_0x5e7306) {
    if (!_0x5e7306 || _0x5e7306.isNull()) {
      return;
    }
    try {
      let _0x424aa0 = _0x2c5496(_0x5e7306) || _0x5e7306;
      const _0x4fa5cf = _0x424aa0.method("get_Runner").invoke();
      if (_0x4fa5cf && !_0x4fa5cf.isNull()) {
        _0x4fa5cf.method("Despawn").invoke(_0x424aa0);
      }
    } catch (_0x1b6eaa) {}
  }
  function _0x988fc9() {
    try {
      const _0x149164 = _0xe40610(bodyCollider);
      if (_0x149164 && !_0x149164.isNull()) {
        return _0x149164;
      }
    } catch (_0x19f96c) {}
    try {
      const _0x51ab0c = _0xe40610(localRig);
      if (_0x51ab0c && !_0x51ab0c.isNull()) {
        return _0x51ab0c;
      }
    } catch (_0x865c2d) {}
    return null;
  }
  function _0x3e527d(_0x465db0 = -0.5) {
    const _0x5629b6 = _0x988fc9();
    if (!_0x5629b6 || _0x5629b6.isNull()) {
      return null;
    }
    let _0x3fff62 = _0x5629b6.method("get_position").invoke();
    let _0x256065 = _0x5629b6.method("get_rotation").invoke();
    try {
      const _0x12dc55 = _0xe40610(localRig);
      if (_0x12dc55 && !_0x12dc55.isNull()) {
        _0x256065 = _0x12dc55.method("get_rotation").invoke();
      }
    } catch (_0x5b4193) {}
    if (_0x465db0) {
      try {
        const _0xa4d61b = _0x5629b6.method("get_up").invoke();
        const _0x20542c = Vector3Class.method("op_Multiply", 2).invoke(_0xa4d61b, _0x465db0);
        _0x3fff62 = Vector3Class.method("op_Addition", 2).invoke(_0x3fff62, _0x20542c);
      } catch (_0xdbb9fd) {}
    }
    return {
      position: _0x3fff62,
      rotation: _0x256065,
    };
  }
  function _0x58bf44(_0x1f08fa) {
    if (!_0x1f08fa || _0x1f08fa.isNull()) {
      return;
    }
    try {
      const _0x39ec51 = _0x2c5496(_0x1f08fa);
      if (_0x39ec51 && !_0x39ec51.isNull()) {
        _0x39ec51.method("RequestStateAuthority").invoke();
      }
    } catch (_0x5299f9) {}
  }
  function _0x4ae355(_0x1be8ee, _0x485532) {
    const _0x5b215b = Il2Cpp.domain
      .assembly("UnityEngine.CoreModule")
      .image.class("UnityEngine.Renderer");
    const _0x1d17ab = _0x3302f9(_0x1be8ee, _0x5b215b);
    if (!_0x1d17ab) {
      return;
    }
    const _0x9d8b3f = _0x1d17ab.method("get_material").invoke();
    _0x9d8b3f.method("set_color").invoke(_0x485532.enabled ? buttonPressedColor : buttonColor);
  }
  function _0x5b6a19() {
    if (menu != null) {
      UnityObjectClass.method("Destroy", 1).invoke(menu);
      menu = null;
    }
  }
  function _0x348d63() {
    var _0x40c04f;
    var _0x438e2c;
    var _0x518b45;
    if (menu == null) {
      return;
    }
    try {
      const _0x3c2ca0 = menuAnimTime;
      const _0x311226 = (_0x4a899b, _0x160f52) =>
        0.5 + Math.sin(_0x3c2ca0 * _0x4a899b + _0x160f52) * 0.5;
      const _0x1bdcbb = (_0x5bcd92, _0x559f3c) => {
        return [_0x5bcd92[0], _0x5bcd92[1], _0x5bcd92[2], (_0x5bcd92[3] ?? 1) * _0x559f3c];
      };
      let _0x9bb70e =
        menuFadeDur > 0 ? Math.min(1, Math.max(0, (time - menuOpenTime) / menuFadeDur)) : 1;
      _0x9bb70e = _0x9bb70e * _0x9bb70e * (3 - _0x9bb70e * 2);
      if (!menuFadeDone) {
        for (let _0x31500f = 0; _0x31500f < menuFadeRenderers.length; _0x31500f++) {
          const _0x10ba54 = menuFadeRenderers[_0x31500f];
          _0x1c1a20(_0x10ba54.mat, _0x1bdcbb(_0x10ba54.base, _0x9bb70e));
        }
        for (let _0x1b26cf = 0; _0x1b26cf < menuFadeTexts.length; _0x1b26cf++) {
          const _0x8b691 = menuFadeTexts[_0x1b26cf];
          if (
            !_0x8b691.txt ||
            ((_0x438e2c = (_0x40c04f = _0x8b691.txt).isNull) === null || _0x438e2c === undefined
              ? undefined
              : _0x438e2c.call(_0x40c04f))
          ) {
            continue;
          }
          try {
            _0x8b691.txt.method("set_color").invoke(_0x1bdcbb(_0x8b691.base, _0x9bb70e));
          } catch (_0x412394) {}
        }
        const _0x455731 = 0.92 + _0x9bb70e * 0.08;
        try {
          _0xe40610(menu)
            .method("set_localScale")
            .invoke([
              menuTargetScale[0] * _0x455731,
              menuTargetScale[1] * _0x455731,
              menuTargetScale[2] * _0x455731,
            ]);
        } catch (_0x289100) {}
        if (_0x9bb70e >= 1) {
          try {
            _0xe40610(menu).method("set_localScale").invoke(menuTargetScale);
          } catch (_0x1e0c79) {}
          menuFadeDone = true;
        }
      }
      if (
        menuAnimTitle &&
        !((_0x518b45 = menuAnimTitle.isNull) === null || _0x518b45 === undefined
          ? undefined
          : _0x518b45.call(menuAnimTitle))
      ) {
        const _0x29eab6 = 0.84 + _0x311226(9, 0) * 0.16 * _0x311226(2.3, 1.7);
        try {
          menuAnimTitle
            .method("set_color")
            .invoke([accentColor[0], accentColor[1], accentColor[2], _0x29eab6 * _0x9bb70e]);
        } catch (_0x1023ed) {}
      }
      {
        const _0x7ad6f1 = _0x311226(2.2, 0);
        _0x1c1a20(menuMatHeaderBar, [
          0.62 + _0x7ad6f1 * 0.22,
          0.16 + _0x7ad6f1 * 0.1,
          1,
          (0.55 + _0x7ad6f1 * 0.35) * _0x9bb70e,
        ]);
      }
      {
        const _0x443fd1 = _0x311226(3.4, 0);
        _0x1c1a20(menuMatActiveTab, [
          accentColor[0],
          accentColor[1],
          accentColor[2],
          (0.14 + _0x443fd1 * 0.14) * _0x9bb70e,
        ]);
      }
      {
        const _0x40c322 = _0x311226(3.4, 0.8);
        for (let _0x5e1ee8 = 0; _0x5e1ee8 < menuTabOutlineMats.length; _0x5e1ee8++) {
          _0x1c1a20(menuTabOutlineMats[_0x5e1ee8], [
            0.66 + _0x40c322 * 0.26,
            0.2 + _0x40c322 * 0.14,
            1,
            (0.6 + _0x40c322 * 0.4) * _0x9bb70e,
          ]);
        }
      }
      {
        const _0x6d0a96 = _0x311226(1.6, 0);
        for (let _0x524ccd = 0; _0x524ccd < menuFrameMats.length; _0x524ccd++) {
          _0x1c1a20(menuFrameMats[_0x524ccd], [
            0.6 + _0x6d0a96 * 0.24,
            0.16 + _0x6d0a96 * 0.1,
            1,
            (0.4 + _0x6d0a96 * 0.45) * _0x9bb70e,
          ]);
        }
      }
      {
        const _0x4d9b08 = _0x311226(6, 0);
        for (let _0x2e99ec = 0; _0x2e99ec < menuAnimOnPips.length; _0x2e99ec++) {
          _0x1c1a20(menuAnimOnPips[_0x2e99ec], [
            _0x4d9b08 * 0.2,
            0.7 + _0x4d9b08 * 0.3,
            0.3 + _0x4d9b08 * 0.2,
            _0x9bb70e,
          ]);
        }
      }
      _0x1c1a20(menuMatBg, [
        0.012 + Math.sin(_0x3c2ca0 * 0.5) * 0.006,
        0.004,
        0.022 + Math.sin(_0x3c2ca0 * 0.5 + 1.3) * 0.01,
        _0x9bb70e * 0.97,
      ]);
      if (menuScanTf) {
        const _0x18f3e7 = 0.205 - ((_0x3c2ca0 * 0.1) % 0.4);
        try {
          menuScanTf.method("set_localPosition").invoke([0.1045 / 0.1, 0, _0x18f3e7 / 0.44]);
        } catch (_0x178514) {}
        if (menuScanMat) {
          _0x1c1a20(menuScanMat, [
            accentColor[0],
            accentColor[1],
            accentColor[2],
            _0x9bb70e * 0.05,
          ]);
        }
      }
      if (menuCursorMat) {
        const _0x27bb06 = _0x3c2ca0 % 0.9 < 0.45 ? 0.95 : 0.06;
        _0x1c1a20(menuCursorMat, [
          accentColor[0],
          accentColor[1],
          accentColor[2],
          _0x27bb06 * _0x9bb70e,
        ]);
      }
    } catch (_0x55968f) {}
  }
  function _0x18517d(_0x167ff9, _0x1018e2, _0x4347e3) {
    let _0x5d6aaf = null;
    for (let _0x4ab8ed = 0; _0x4ab8ed < gunFx.length; _0x4ab8ed++) {
      if (gunFx[_0x4ab8ed].life <= 0) {
        _0x5d6aaf = gunFx[_0x4ab8ed];
        break;
      }
    }
    if (!_0x5d6aaf) {
      if (gunFx.length >= 28) {
        return;
      }
      const _0x5296d4 = _0x4aa64c(
        [_0x167ff9, _0x1018e2, _0x4347e3],
        QuaternionIdentity,
        [0.03, 0.03, 0.03],
        0,
        [0.85, 0.3, 1, 1],
      );
      try {
        _0x11d2fe(_0x3302f9(_0x5296d4, ColliderClass));
      } catch (_0x3a4e4a) {}
      try {
        _0x5296d4.method("set_layer").invoke(2);
      } catch (_0x183e09) {}
      _0x5d6aaf = {
        go: _0x5296d4,
        tf: _0xe40610(_0x5296d4),
        mat: _0x3b4135(_0x5296d4),
        x: _0x167ff9,
        y: _0x1018e2,
        z: _0x4347e3,
        vx: 0,
        vy: 0,
        vz: 0,
        life: 0,
        max: 0.6,
        sz: 0.03,
      };
      gunFx.push(_0x5d6aaf);
    }
    const _0x3e129b = Math.random() * Math.PI * 2;
    const _0x8872c3 = (Math.random() - 0.5) * Math.PI;
    const _0x171906 = 0.6 + Math.random() * 1.3;
    _0x5d6aaf.x = _0x167ff9;
    _0x5d6aaf.y = _0x1018e2;
    _0x5d6aaf.z = _0x4347e3;
    _0x5d6aaf.vx = Math.cos(_0x3e129b) * Math.cos(_0x8872c3) * _0x171906;
    _0x5d6aaf.vy = Math.sin(_0x8872c3) * _0x171906 + 0.5;
    _0x5d6aaf.vz = Math.sin(_0x3e129b) * Math.cos(_0x8872c3) * _0x171906;
    _0x5d6aaf.max = 0.5 + Math.random() * 0.4;
    _0x5d6aaf.life = _0x5d6aaf.max;
    _0x5d6aaf.sz = 0.025 + Math.random() * 0.022;
    try {
      _0x5d6aaf.go.method("SetActive").invoke(true);
    } catch (_0x229183) {}
  }
  function _0x48c9b8() {
    try {
      if (gunFxEmit) {
        for (let _0x150587 = 0; _0x150587 < 2; _0x150587++) {
          _0x18517d(gunFxPos[0], gunFxPos[1], gunFxPos[2]);
        }
      }
      for (let _0x2f5f54 = 0; _0x2f5f54 < gunFx.length; _0x2f5f54++) {
        const _0x1c33ee = gunFx[_0x2f5f54];
        if (_0x1c33ee.life <= 0) {
          continue;
        }
        _0x1c33ee.life -= deltaTime;
        if (_0x1c33ee.life <= 0) {
          try {
            _0x1c33ee.go.method("SetActive").invoke(false);
          } catch (_0x4faba5) {}
          continue;
        }
        _0x1c33ee.vy -= deltaTime * 0.9;
        _0x1c33ee.x += _0x1c33ee.vx * deltaTime;
        _0x1c33ee.y += _0x1c33ee.vy * deltaTime;
        _0x1c33ee.z += _0x1c33ee.vz * deltaTime;
        const _0x72ac65 = _0x1c33ee.life / _0x1c33ee.max;
        const _0x1500fe = _0x1c33ee.sz * _0x72ac65;
        try {
          if (_0x1c33ee.tf) {
            _0x1c33ee.tf.method("set_position").invoke([_0x1c33ee.x, _0x1c33ee.y, _0x1c33ee.z]);
            _0x1c33ee.tf.method("set_localScale").invoke([_0x1500fe, _0x1500fe, _0x1500fe]);
          }
          _0x1c1a20(_0x1c33ee.mat, [0.85, 0.3 + (1 - _0x72ac65) * 0.35, 1, _0x72ac65]);
        } catch (_0x22c3f0) {}
      }
    } catch (_0x17f8a4) {}
  }
  let _0x5bc894 = false;
  let _0x4b51b9 = null;
  let _0x5409db = null;
  let _0x3046e8 = null;
  let _0x1820b6 = null;
  let _0xb54c6 = null;
  let _0x11f92d = 0;
  let _0x552059 = null;
  let _0xf0169e = null;
  let _0x52de87 = false;
  const categoryTabs = [
    ["Settings", 2],
    ["Movement mods", 3],
    ["Player mods", 4],
    ["Item mods", 6],
    ["Spawning", 7],
    ["Gun Mods", 8],
    ["Misc", 9],
    ["Whitelist", 21],
    ["Shooters", 17],
    ["Overpowered", 18],
    ["Experimental", 19],
    ["Credits", 13],
    ["Dev Stuff", 20],
  ];
  const categoryPips = {};
  categoryTabs.forEach(([_0x1c7445, _0x1f26d8]) => {
    categoryPips[_0x1f26d8] = _0x1c7445;
  });
  function _0x1d8efd() {
    const _0x153297 = [0.1, 0.36, 0.44];
    const _0x9a2a8d = (_0x1f4e5d) => [
      _0x1f4e5d[0] / _0x153297[0],
      _0x1f4e5d[1] / _0x153297[1],
      _0x1f4e5d[2] / _0x153297[2],
    ];
    menuAnimTitle = null;
    menuAnimActiveTab = null;
    menuAnimBg = null;
    menuAnimOnPips = [];
    menuFrameMats = [];
    menuTabOutlineMats = [];
    menuScanTf = null;
    menuScanMat = null;
    menuCursorMat = null;
    menuFadeRenderers = [];
    menuFadeTexts = [];
    menuMatBg = null;
    menuMatHeaderBar = null;
    menuMatActiveTab = null;
    menuFadeDone = false;
    menuOpenTime = time;
    menu = _0x4aa64c(Vector3Zero, QuaternionIdentity, _0x153297, 3, [0, 0, 0, 0]);
    _0x11d2fe(_0x3302f9(menu, BoxColliderClass));
    menuAnimBg = _0x4aa64c(
      [0.1, 0, 0],
      QuaternionIdentity,
      _0x9a2a8d([0.01, 0.36, 0.44]),
      3,
      bgColor,
      _0xe40610(menu),
      false,
    );
    menuMatBg = _0x3b4135(menuAnimBg);
    menuFadeRenderers.push({
      go: menuAnimBg,
      mat: menuMatBg,
      base: bgColor.slice(),
    });
    const _0xccf2f1 = (_0x61a527, _0x115125, _0x22f68d, _0x4b3ae2 = false) => {
      const _0x4b4a7a = _0x4aa64c(
        _0x61a527,
        QuaternionIdentity,
        _0x9a2a8d(_0x115125),
        3,
        _0x22f68d,
        _0xe40610(menu),
        false,
      );
      const _0x57d585 = _0x3b4135(_0x4b4a7a);
      menuFadeRenderers.push({
        go: _0x4b4a7a,
        mat: _0x57d585,
        base: _0x22f68d.slice(),
      });
      if (_0x4b3ae2) {
        menuFrameMats.push(_0x57d585);
      }
      return _0x57d585;
    };
    _0xccf2f1([0.104, 0, 0.215], [0.004, 0.346, 0.0022], sidebarColor);
    _0xccf2f1([0.104, 0, -0.215], [0.004, 0.346, 0.0022], sidebarColor);
    _0xccf2f1([0.104, 0.172, 0], [0.004, 0.0022, 0.432], sidebarColor);
    _0xccf2f1([0.104, -0.172, 0], [0.004, 0.0022, 0.432], sidebarColor);
    for (const [_0x1ac763, _0x2f8516] of [
      [0.172, 0.215],
      [-0.172, 0.215],
      [0.172, -0.215],
      [-0.172, -0.215],
    ]) {
      const _0xbb74db = _0x1ac763 > 0 ? 1 : -1;
      const _0x4914bf = _0x2f8516 > 0 ? 1 : -1;
      _0xccf2f1(
        [0.105, _0x1ac763 - _0xbb74db * 0.022, _0x2f8516],
        [0.005, 0.046, 0.0042],
        accentColor,
        true,
      );
      _0xccf2f1(
        [0.105, _0x1ac763, _0x2f8516 - _0x4914bf * 0.022],
        [0.005, 0.0042, 0.046],
        accentColor,
        true,
      );
    }
    for (let _0x2494c9 = 0; _0x2494c9 < 5; _0x2494c9++) {
      _0xccf2f1([0.104, -0.14 + _0x2494c9 * 0.07, 0.208], [0.004, 0.0022, 0.009], sidebarColor);
    }
    _0xccf2f1([0.104, 0.049, -0.012], [0.004, 0.0022, 0.382], sidebarColor);
    menuMatHeaderBar = _0xccf2f1([0.104, 0, 0.188], [0.004, 0.346, 0.0026], accentColor);
    {
      const _0x507f98 = _0x4aa64c(
        [0.1045, 0, 0.2],
        QuaternionIdentity,
        _0x9a2a8d([0.004, 0.338, 0.0035]),
        3,
        [accentColor[0], accentColor[1], accentColor[2], 0.05],
        _0xe40610(menu),
        false,
      );
      menuScanTf = _0xe40610(_0x507f98);
      menuScanMat = _0x3b4135(_0x507f98);
    }
    {
      const _0x24a18e = _0x4aa64c(
        [0.106, -0.128, 0.205],
        QuaternionIdentity,
        _0x9a2a8d([0.005, 0.011, 0.02]),
        3,
        accentColor,
        _0xe40610(menu),
        false,
      );
      menuCursorMat = _0x3b4135(_0x24a18e);
    }
    const _0x74e03b = _0x4aa64c(
      Vector3Zero,
      QuaternionIdentity,
      Vector3One,
      3,
      [0, 0, 0, 0],
      _0xe40610(menu),
    );
    const _0x8fd789 = _0x238332(_0x74e03b, CanvasClass);
    _0x11d2fe(_0x3302f9(_0x74e03b, BoxColliderClass));
    const _0x44f6ec = _0x238332(_0x74e03b, CanvasScalerClass);
    _0x238332(_0x74e03b, GraphicRaycasterClass);
    _0x8fd789.method("set_renderMode").invoke(2);
    _0x44f6ec.method("set_dynamicPixelsPerUnit").invoke(1000);
    try {
      _0x8fd789.method("set_additionalShaderChannels").invoke(3);
    } catch (_0x3a8e8b) {}
    const _0x43335d = (_0x5bce06) =>
      _0x5bce06
        .toLowerCase()
        .replace(/[^a-z0-9]+/g, " ")
        .trim();
    const _0x4c5888 = (
      _0x3a5a38,
      _0x368f14,
      _0x4c2c9d,
      _0x3e56cd,
      _0x174143,
      _0x4e1941 = [1, 0.1],
      _0x24139c = textColor,
    ) => {
      const _0x3b0876 = _0x4aa64c(
        _0x368f14,
        QuaternionIdentity,
        _0x9a2a8d(_0x4c2c9d),
        3,
        _0x3e56cd,
        _0xe40610(menu),
      );
      _0x3b0876.method("set_name").invoke(Il2Cpp.string("@" + _0x3a5a38));
      _0x238332(_0x3b0876, ComputerTerminalKeyClass);
      _0x3302f9(_0x3b0876, BoxColliderClass).method("set_isTrigger").invoke(true);
      try {
        menuFadeRenderers.push({
          go: _0x3b0876,
          mat: _0x3b4135(_0x3b0876),
          base: _0x3e56cd.slice(),
        });
      } catch (_0x3d2bdb) {}
      _0x25ccd6(
        _0x74e03b,
        _0x174143,
        _0x24139c,
        [_0x368f14[0] + 0.006, _0x368f14[1], _0x368f14[2]],
        _0x4e1941,
      );
      return _0x3b0876;
    };
    const _0x260eb6 = (_0x6ba9c6, _0x5a6972, _0xea72e9) => {
      const _0x10f3cd = _0x4aa64c(
        _0x6ba9c6,
        QuaternionIdentity,
        _0x9a2a8d(_0x5a6972),
        3,
        _0xea72e9,
        _0xe40610(menu),
        false,
      );
      try {
        menuFadeRenderers.push({
          go: _0x10f3cd,
          mat: _0x3b4135(_0x10f3cd),
          base: _0xea72e9.slice(),
        });
      } catch (_0x23aab9) {}
      return _0x10f3cd;
    };
    const _0x41892e =
      currentCategory === 0 ? "home" : _0x43335d(categoryPips[currentCategory] || "");
    menuAnimTitle = _0x25ccd6(
      _0x74e03b,
      "root@luminox:~#",
      accentColor,
      [0.108, 0.075, 0.205],
      [1, 0.05],
    );
    _0x25ccd6(_0x74e03b, "/" + _0x41892e, textColor, [0.108, -0.06, 0.205], [1.3, 0.055]);
    _0x4c5888(
      "GlobalReturn",
      [0.106, 0.168, 0.205],
      [0.009, 0.035, 0.03],
      currentCategory === 0 ? [accentColor[0], accentColor[1], accentColor[2], 0.3] : buttonColor,
      "[home]",
      [0.7, 0.045],
    );
    _0x4c5888(
      "Disconnect",
      [0.106, -0.168, 0.205],
      [0.009, 0.045, 0.03],
      buttonColor,
      "[exit]",
      [0.7, 0.045],
    );
    if (time > notifactionResetTime) {
      currentNotification = "";
    }
    if (currentNotification && currentNotification.length > 0) {
      _0x25ccd6(_0x74e03b, currentNotification, accentColor, [0.108, 0.02, 0.177], [1.3, 0.036]);
    }
    const _0x4f670d = 0.15;
    const _0x277a69 = 0.0265;
    const _0x26d12f = 0.112;
    for (let _0x39e18b = 0; _0x39e18b < categoryTabs.length; _0x39e18b++) {
      const _0x39142d = categoryTabs[_0x39e18b][0];
      const _0x550afa = categoryTabs[_0x39e18b][1];
      const _0x3d5dff = _0x4f670d - _0x39e18b * _0x277a69;
      const _0x627be5 = currentCategory === _0x550afa;
      const _0x7de481 = _0x627be5
        ? [accentColor[0], accentColor[1], accentColor[2], 0.2]
        : buttonColor;
      const _0x135dca = _0x4c5888(
        _0x39142d,
        [0.106, _0x26d12f, _0x3d5dff],
        [0.009, 0.118, 0.024],
        _0x7de481,
        (_0x627be5 ? "> " : "") + _0x43335d(_0x39142d),
        [0.95, 0.045],
        _0x627be5 ? [1, 1, 1, 1] : textColor,
      );
      if (_0x627be5) {
        menuAnimActiveTab = _0x135dca;
        menuMatActiveTab = _0x3b4135(_0x135dca);
        menuTabOutlineMats.push(
          _0xccf2f1([0.105, _0x26d12f, _0x3d5dff + 0.0128], [0.005, 0.122, 0.0022], accentColor),
        );
        menuTabOutlineMats.push(
          _0xccf2f1([0.105, _0x26d12f, _0x3d5dff - 0.0128], [0.005, 0.122, 0.0022], accentColor),
        );
        menuTabOutlineMats.push(
          _0xccf2f1([0.105, _0x26d12f + 0.0608, _0x3d5dff], [0.005, 0.0022, 0.0278], accentColor),
        );
        menuTabOutlineMats.push(
          _0xccf2f1([0.105, _0x26d12f - 0.0608, _0x3d5dff], [0.005, 0.0022, 0.0278], accentColor),
        );
      }
    }
    if (currentCategory === 0) {
      _0x25ccd6(
        _0x74e03b,
        "LUMINOX OS v" + version,
        accentColor,
        [0.108, -0.06, 0.07],
        [1.6, 0.06],
      );
      _0x25ccd6(
        _0x74e03b,
        "> session established",
        [0.45, 1, 0.62, 1],
        [0.108, -0.06, 0.01],
        [1.6, 0.045],
      );
      _0x25ccd6(
        _0x74e03b,
        "> " + categoryTabs.length + " modules indexed",
        textColor,
        [0.108, -0.06, -0.04],
        [1.6, 0.045],
      );
      _0x25ccd6(
        _0x74e03b,
        "> select module from index_",
        textColor,
        [0.108, -0.06, -0.09],
        [1.6, 0.045],
      );
    } else {
      const _0x4887e5 = menuPages[currentCategory] || [];
      const _0x4f8a6a = Math.max(0, Math.ceil(_0x4887e5.length / 8) - 1);
      if (currentPage > _0x4f8a6a) {
        currentPage = _0x4f8a6a;
      }
      const _0x475fff = 0.15;
      const _0x5cc6a6 = 0.0375;
      const _0x545fb2 = -0.06;
      const _0x3c837a = _0x4887e5.slice(currentPage * 8, currentPage * 8 + 8);
      _0x3c837a.forEach((_0x39ba1f, _0x39c004) => {
        const _0x5d43bd = _0x475fff - _0x39c004 * _0x5cc6a6;
        const _0x41a1a8 = _0x39ba1f.isTogglable && _0x39ba1f.enabled;
        const _0x1a9c12 = _0x41a1a8
          ? [accentColor[0], accentColor[1], accentColor[2], 0.2]
          : buttonColor;
        const _0x52179c = _0x39ba1f.isTogglable ? (_0x41a1a8 ? "  [on]" : "  [off]") : "";
        _0x4c5888(
          _0x39ba1f.buttonText,
          [0.106, _0x545fb2, _0x5d43bd],
          [0.009, 0.215, 0.03],
          _0x1a9c12,
          "> " + _0x43335d(_0x39ba1f.buttonText) + _0x52179c,
          [1.2, 0.05],
          _0x41a1a8 ? [0.55, 1, 0.68, 1] : textColor,
        );
        if (_0x39c004 < _0x3c837a.length - 1) {
          _0xccf2f1([0.104, _0x545fb2, _0x5d43bd - 0.0187], [0.004, 0.205, 0.0016], panelColor);
        }
        const _0x146cde = _0x260eb6(
          [0.113, -0.163, _0x5d43bd],
          [0.011, 0.011, 0.018],
          _0x39ba1f.isTogglable
            ? _0x41a1a8
              ? pipOnColor
              : pipOffColor
            : [accentColor[0], accentColor[1], accentColor[2], 0.55],
        );
        if (_0x41a1a8) {
          menuAnimOnPips.push(_0x3b4135(_0x146cde));
        }
      });
      if (_0x4f8a6a > 0) {
        const _0x227712 = -0.15;
        _0x4c5888(
          "PreviousPage",
          [0.106, 0, _0x227712],
          [0.009, 0.045, 0.028],
          buttonColor,
          "[<]",
          [0.6, 0.045],
        );
        _0x25ccd6(
          _0x74e03b,
          "pg " + (currentPage + 1) + "/" + (_0x4f8a6a + 1),
          textColor,
          [0.108, -0.06, _0x227712],
          [0.9, 0.045],
        );
        _0x4c5888(
          "NextPage",
          [0.106, -0.12, _0x227712],
          [0.009, 0.045, 0.028],
          buttonColor,
          "[>]",
          [0.6, 0.045],
        );
      }
    }
    _0xe40610(menu)
      .method("set_localScale")
      .invoke(
        Vector3Class.method("op_Multiply").invoke(
          Vector3Class.method("op_Multiply").invoke(
            _0xe40610(menu).method("get_localScale").invoke(),
            localRig.field("<playerScale>k__BackingField").value,
          ),
          menuscale,
        ),
      );
    try {
      const _0x2a193e = _0xe40610(menu).method("get_localScale").invoke();
      menuTargetScale = [
        _0x2a193e.field("x").value,
        _0x2a193e.field("y").value,
        _0x2a193e.field("z").value,
      ];
    } catch (_0x220404) {
      menuTargetScale = [1, 1, 1];
    }
    _0x538191();
  }
  function _0x21d610() {
    if (righthand) {
      reference = _0x4aa64c(
        Vector3Zero,
        QuaternionIdentity,
        [0.01, 0.01, 0.01],
        0,
        bgColor,
        leftHandTransform,
      );
    } else {
      reference = _0x4aa64c(
        Vector3Zero,
        QuaternionIdentity,
        [0.01, 0.01, 0.01],
        0,
        bgColor,
        rightHandTransform,
      );
    }
    referenceCollider = _0x3302f9(reference, ColliderClass);
    _0xe40610(reference).method("set_localPosition").invoke([-0.05, -0.115, 0.065]);
    reference.method("set_layer").invoke(2);
    _0x238332(reference, UnityRigidbodyClass).method("set_isKinematic").invoke(true);
  }
  function _0x3fc7cd(_0x66a2f6 = null) {
    const _0xf06b8b = rightHandTransform.method("get_position").invoke();
    const _0x179e08 = rightHandTransform.method("get_forward").invoke();
    const _0x941cd9 = _0xf06b8b.field("x").value;
    const _0x1a4e2d = _0xf06b8b.field("y").value;
    const _0x5edceb = _0xf06b8b.field("z").value;
    const _0x13630d = _0x179e08.field("x").value;
    const _0x23b487 = _0x179e08.field("y").value;
    const _0x3a7802 = _0x179e08.field("z").value;
    const _0x13d53a = [
      _0x941cd9 + _0x13630d * 0.3,
      _0x1a4e2d + _0x23b487 * 0.3,
      _0x5edceb + _0x3a7802 * 0.3,
    ];
    let _0x2a7fb2 = null;
    let _0x162229 = Infinity;
    const _0x302cc9 = _0x66a2f6 || -2147483392;
    try {
      const _0x11fed0 = PhysicsClass.method("RaycastAll", 4).invoke(
        _0x13d53a,
        _0x179e08,
        512,
        _0x302cc9,
      );
      if (_0x11fed0 && !_0x11fed0.isNull()) {
        const _0x347eca = _0x11fed0.length;
        for (let _0x48a4ca = 0; _0x48a4ca < _0x347eca; _0x48a4ca++) {
          try {
            const _0x283170 = _0x11fed0.get(_0x48a4ca);
            if (!_0x283170) {
              continue;
            }
            const _0xd19cb6 = _0x283170.method("get_collider").invoke();
            if (!_0xd19cb6 || _0xd19cb6.isNull()) {
              continue;
            }
            const _0x5a6627 = _0xd19cb6.method("get_gameObject").invoke();
            if (!_0x5a6627 || _0x5a6627.isNull()) {
              continue;
            }
            if (_0x5409db && _0x5a6627.handle.equals(_0x5409db.handle)) {
              continue;
            }
            const _0x451421 = _0x5a6627.method("get_layer").invoke();
            if (_0x451421 === 2) {
              continue;
            }
            const _0x57fea0 = _0x283170.method("get_point").invoke();
            if (!_0x57fea0) {
              continue;
            }
            const _0x9babe5 = _0x57fea0.field("x").value;
            const _0x1d225c = _0x57fea0.field("y").value;
            const _0x1d63e5 = _0x57fea0.field("z").value;
            const _0x5c0dd2 = Math.sqrt(
              (_0x9babe5 - _0x941cd9) * (_0x9babe5 - _0x941cd9) +
                (_0x1d225c - _0x1a4e2d) * (_0x1d225c - _0x1a4e2d) +
                (_0x1d63e5 - _0x5edceb) * (_0x1d63e5 - _0x5edceb),
            );
            if (_0x5c0dd2 > 0.3 && _0x5c0dd2 < _0x162229) {
              _0x2a7fb2 = _0x283170;
              _0x162229 = _0x5c0dd2;
            }
          } catch (_0x4958c2) {}
        }
      }
    } catch (_0xd1a6a) {
      console.log("[renderGun] error: " + _0xd1a6a);
    }
    let _0xe33066 = _0x941cd9 + _0x13630d * 10;
    let _0x3c94b8 = _0x1a4e2d + _0x23b487 * 10;
    let _0x8c8f2e = _0x5edceb + _0x3a7802 * 10;
    try {
      if (_0x5bc894 && _0x4b51b9) {
        const _0x471894 = _0xe40610(_0x4b51b9).method("get_position").invoke();
        _0xe33066 = _0x471894.field("x").value;
        _0x3c94b8 = _0x471894.field("y").value;
        _0x8c8f2e = _0x471894.field("z").value;
      } else if (_0x2a7fb2) {
        const _0x4725a7 = _0x2a7fb2.method("get_point").invoke();
        _0xe33066 = _0x4725a7.field("x").value;
        _0x3c94b8 = _0x4725a7.field("y").value;
        _0x8c8f2e = _0x4725a7.field("z").value;
      }
    } catch (_0x38a0b2) {
      _0x2a7fb2 = null;
    }
    const _0x2151e0 = [_0xe33066, _0x3c94b8, _0x8c8f2e];
    if (_0x5409db == null) {
      _0x5409db = _0x4aa64c(_0x2151e0, QuaternionIdentity, [0.15, 0.15, 0.15], 0, [1, 0, 0, 1]);
      try {
        _0x11d2fe(_0x3302f9(_0x5409db, ColliderClass));
      } catch (_0x2ea450) {}
      try {
        _0x5409db.method("set_layer").invoke(2);
      } catch (_0x357eb7) {}
    }
    if (_0x5409db && !_0x5409db.isNull()) {
      _0x5409db.method("SetActive").invoke(true);
      _0xe40610(_0x5409db).method("set_position").invoke(_0x2151e0);
      try {
        const _0x2fb7bf = _0x3302f9(_0x5409db, RendererClass);
        if (_0x2fb7bf && !_0x2fb7bf.isNull()) {
          const _0x47a576 = _0x2fb7bf.method("get_material").invoke();
          if (_0x47a576 && !_0x47a576.isNull()) {
            _0x47a576.method("set_shader").invoke(unlitShader);
            _0x47a576.method("set_color").invoke(_0x2a7fb2 ? [0, 1, 0, 1] : [1, 0, 0, 1]);
          }
        }
      } catch (_0x54da47) {}
    }
    if (_0x3046e8 == null) {
      const _0x1cdb72 = _0x4aa64c(Vector3Zero, QuaternionIdentity, Vector3One, 0, [0, 0, 0, 0]);
      _0x3046e8 = _0x238332(_0x1cdb72, LineRendererClass);
      try {
        _0x1cdb72.method("set_layer").invoke(2);
      } catch (_0x45bea0) {}
    } else {
      try {
        _0x3046e8.method("get_gameObject").invoke().method("SetActive").invoke(true);
      } catch (_0x13d8a0) {}
    }
    try {
      const _0x4294f3 = _0x3046e8.method("get_material").invoke();
      _0x4294f3.method("set_shader").invoke(uiDefaultShader);
      _0x3046e8.method("set_startColor").invoke(bgColor);
      _0x3046e8.method("set_endColor").invoke(bgColor);
      _0x3046e8.method("set_startWidth").invoke(0.025);
      _0x3046e8.method("set_endWidth").invoke(0.025);
      _0x3046e8.method("set_positionCount").invoke(2);
      _0x3046e8.method("set_useWorldSpace").invoke(true);
      _0x3046e8.method("SetPosition").invoke(0, _0xf06b8b);
      _0x3046e8.method("SetPosition").invoke(1, _0x2151e0);
    } catch (_0xece202) {}
    return {
      ray: _0x2a7fb2,
      gunPointer: _0x5409db,
      endPosition: _0x2151e0,
    };
  }
  function _0x1f85ec(_0x342a5b) {
    var _0x5257f3;
    try {
      if (
        !_0x342a5b ||
        ((_0x5257f3 = _0x342a5b.isNull) === null || _0x5257f3 === undefined
          ? undefined
          : _0x5257f3.call(_0x342a5b))
      ) {
        return "";
      }
      const _0x4879de = _0x342a5b.handle;
      if (!_0x4879de) {
        return "";
      }
      return _0x4879de.toString();
    } catch (_0x2885b8) {
      return "";
    }
  }
  function _0x3a60c2(_0x1ccf90) {
    return [
      _0x1ccf90.field("x").value || 0,
      _0x1ccf90.field("y").value || 0,
      _0x1ccf90.field("z").value || 0,
    ];
  }
  function _0x130690(_0x30f340, _0x463b9e = null) {
    var _0x32250e;
    var _0x3e0669;
    var _0x177471;
    try {
      const _0x5c9f64 =
        _0x463b9e &&
        !((_0x32250e = _0x463b9e.isNull) === null || _0x32250e === undefined
          ? undefined
          : _0x32250e.call(_0x463b9e))
          ? _0x463b9e
          : headCollider &&
              !((_0x3e0669 = headCollider.isNull) === null || _0x3e0669 === undefined
                ? undefined
                : _0x3e0669.call(headCollider))
            ? _0xe40610(headCollider)
            : null;
      const _0x4e2041 =
        _0x5c9f64 &&
        !((_0x177471 = _0x5c9f64.isNull) === null || _0x177471 === undefined
          ? undefined
          : _0x177471.call(_0x5c9f64))
          ? _0x3a60c2(_0x5c9f64.method("get_forward").invoke())
          : [0, 0, 1];
      const _0x27c26e = _0x1f85ec(_0x30f340) || String(_0x30f340);
      const _0x472aca = launchAxisCache.get(_0x27c26e);
      const _0x4deef5 = (_0x560c11) => {
        switch (_0x560c11) {
          case "forward":
            return _0x30f340.method("get_forward").invoke();
          case "-forward":
            return Vector3Class.method("op_Multiply", 2).invoke(
              _0x30f340.method("get_forward").invoke(),
              -1,
            );
          case "up":
            return _0x30f340.method("get_up").invoke();
          case "-up":
            return Vector3Class.method("op_Multiply", 2).invoke(
              _0x30f340.method("get_up").invoke(),
              -1,
            );
          case "right":
            return _0x30f340.method("get_right").invoke();
          case "-right":
            return Vector3Class.method("op_Multiply", 2).invoke(
              _0x30f340.method("get_right").invoke(),
              -1,
            );
          default:
            return _0x30f340.method("get_forward").invoke();
        }
      };
      if (_0x472aca) {
        return Vector3Class.method("Normalize").invoke(_0x4deef5(_0x472aca));
      }
      const _0x149ce6 = ["forward", "-forward"];
      let _0x259dcf = "forward";
      let _0x4d3d45 = -999999;
      for (const _0x348ee2 of _0x149ce6) {
        try {
          const _0x3fad51 = _0x4deef5(_0x348ee2);
          const _0x1d678b = _0x3a60c2(_0x3fad51);
          const _0x1029e5 =
            _0x1d678b[0] * _0x4e2041[0] + _0x1d678b[1] * _0x4e2041[1] + _0x1d678b[2] * _0x4e2041[2];
          if (_0x1029e5 > _0x4d3d45) {
            _0x4d3d45 = _0x1029e5;
            _0x259dcf = _0x348ee2;
          }
        } catch (_0x46bf22) {}
      }
      launchAxisCache.set(_0x27c26e, _0x259dcf);
      return Vector3Class.method("Normalize").invoke(_0x4deef5(_0x259dcf));
    } catch (_0xa980e2) {
      try {
        return _0x30f340.method("get_forward").invoke();
      } catch (_0x2fc290) {
        return [0, 0, 1];
      }
    }
  }
  function _0x155419() {
    var _0x21c1c2;
    try {
      const _0x27033a =
        headCollider &&
        !((_0x21c1c2 = headCollider.isNull) === null || _0x21c1c2 === undefined
          ? undefined
          : _0x21c1c2.call(headCollider))
          ? _0xe40610(headCollider)
          : null;
      return _0x130690(rightHandTransform, _0x27033a);
    } catch (_0x27e14b) {
      return rightHandTransform.method("get_forward").invoke();
    }
  }
  function _0x1232e0(_0x129b3d, _0x2675b5) {
    try {
      const _0x5f7099 = [0, 1, 0];
      const _0x3c45a3 = Vector3Class.method("Dot").invoke(_0x5f7099, _0x2675b5);
      let _0x2f2de2 = Vector3Class.method("op_Subtraction", 2).invoke(
        _0x5f7099,
        Vector3Class.method("op_Multiply", 2).invoke(_0x2675b5, _0x3c45a3),
      );
      const _0x22407f = Vector3Class.method("Magnitude").invoke(_0x2f2de2);
      if (_0x22407f < 0.05) {
        _0x2f2de2 = _0x129b3d.method("get_up").invoke();
      }
      return Vector3Class.method("Normalize").invoke(_0x2f2de2);
    } catch (_0x472485) {
      try {
        return _0x129b3d.method("get_up").invoke();
      } catch (_0xa3df02) {
        return [0, 1, 0];
      }
    }
  }
  function _0x313d2c(_0x34480c, _0x4f62d8, _0x1c3039) {
    try {
      return QuaternionClass.method("LookRotation", 2).invoke(_0x4f62d8, _0x1c3039);
    } catch (_0x5afa83) {}
    try {
      return QuaternionClass.method("LookRotation", 1).invoke(_0x4f62d8);
    } catch (_0x81015e) {}
    try {
      return _0x34480c.method("get_rotation").invoke();
    } catch (_0x46aa81) {
      return QuaternionIdentity;
    }
  }
  function _0x4b62fe(_0x259aae, _0x514738, _0x232b8b = 24, _0xa309fe = 0.82) {
    try {
      const _0x52f753 = _0x130690(_0x514738);
      const _0x226bca = _0x1232e0(_0x514738, _0x52f753);
      const _0x511b45 = Vector3Class.method("op_Addition").invoke(
        _0x514738.method("get_position").invoke(),
        Vector3Class.method("op_Addition").invoke(
          Vector3Class.method("op_Multiply", 2).invoke(_0x52f753, _0xa309fe),
          Vector3Class.method("op_Multiply", 2).invoke(_0x226bca, -0.05),
        ),
      );
      const _0x2954bd = _0x313d2c(_0x514738, _0x52f753, _0x226bca);
      const _0x1052dd = _0xf8bff9(_0x259aae, _0x511b45, _0x2954bd);
      if (_0x1052dd && !_0x1052dd.isNull()) {
        const _0x465f67 = Vector3Class.method("op_Addition").invoke(
          Vector3Class.method("op_Multiply", 2).invoke(_0x52f753, _0x232b8b),
          Vector3Class.method("op_Multiply", 2).invoke(_0x226bca, 1.2),
        );
        let _0x3a2cd3 = false;
        try {
          const _0x3330f1 = _0x1052dd
            .method("GetComponent", 1)
            .inflate(AnimalGrabbableObjectClass)
            .invoke();
          if (_0x3330f1 && !_0x3330f1.isNull()) {
            try {
              const _0x1df665 = _0x3330f1.method("get_Object").invoke();
              if (_0x1df665 && !_0x1df665.isNull()) {
                _0x1df665.method("RequestStateAuthority").invoke();
              }
            } catch (_0x41a554) {}
            try {
              _0x3330f1.method("RPC_AddExternalForce").invoke(_0x465f67);
              _0x3a2cd3 = true;
            } catch (_0x32b386) {}
            if (!_0x3a2cd3) {
              try {
                _0x3330f1.method("AddExternalForceVelocity", 1).invoke(_0x465f67);
                _0x3a2cd3 = true;
              } catch (_0x4b00fe) {}
            }
          }
        } catch (_0x53b091) {}
        if (!_0x3a2cd3) {
          _0x166145(_0x1052dd, _0x465f67);
        }
      }
      return _0x1052dd;
    } catch (_0xf13357) {
      return null;
    }
  }
  function _0x61c4b1(_0x1a3aff) {
    const _0x34efc0 = getPlayerName(_0x1a3aff);
    if (!whitelist.includes(_0x34efc0)) {
      whitelist.push(_0x34efc0);
    }
  }
  function _0x46878f(_0x29daee) {
    const _0x3a5df7 = getPlayerName(_0x29daee);
    whitelist = whitelist.filter((_0x4137b5) => _0x4137b5 !== _0x3a5df7);
  }
  function _0x50b6a4(_0x392156) {
    return whitelist.includes(getPlayerName(_0x392156));
  }
  function _0x3a0c7a(_0x5b64b1) {
    try {
      const _0x24e331 = _0x5b64b1.endPosition;
      const _0x2f6c34 = UnityObjectClass.method("FindObjectsByType", 1)
        .inflate(NetPlayerClass)
        .invoke(0);
      let _0x4da26c = null;
      let _0x2d9630 = 5;
      for (let _0x2a9935 = 0; _0x2a9935 < _0x2f6c34.length; _0x2a9935++) {
        const _0x53e2cc = _0x2f6c34.get(_0x2a9935);
        if (!_0x53e2cc || _0x53e2cc.isNull() || _0x16fc51(_0x53e2cc)) {
          continue;
        }
        if (!_0x50b6a4(_0x53e2cc)) {
          continue;
        }
        const _0x1491b3 = _0xe40610(_0x53e2cc).method("get_position").invoke();
        const _0x35da43 = Vector3Class.method("Distance").invoke(_0x24e331, _0x1491b3);
        if (_0x35da43 < _0x2d9630) {
          _0x2d9630 = _0x35da43;
          _0x4da26c = _0x53e2cc;
        }
      }
      return _0x4da26c;
    } catch (_0xdecb4b) {
      return null;
    }
  }
  function _0x3df42e(_0x5f2e0b) {
    try {
      const _0x214c8a = _0x5f2e0b.method("GetHandInteractor", 1).invoke(1);
      if (_0x214c8a && !_0x214c8a.isNull()) {
        const _0x580444 = _0xe40610(_0x214c8a);
        return {
          pos: _0x580444.method("get_position").invoke(),
          fwd: _0x580444.method("get_forward").invoke(),
        };
      }
    } catch (_0x411686) {}
    const _0x1005a7 = _0xe40610(_0x5f2e0b);
    return {
      pos: _0x1005a7.method("get_position").invoke(),
      fwd: _0x1005a7.method("get_forward").invoke(),
    };
  }
  function _0x4ae875(_0xde165a, _0x5a5db1, _0xde189d) {
    const { pos: _0x588fc5, fwd: _0x1630d0 } = _0x3df42e(_0xde165a);
    const _0x378ce2 = _0x5db48f(_0x5a5db1, _0x588fc5, QuaternionIdentity);
    if (!_0x378ce2 || _0x378ce2.handle.isNull()) {
      return;
    }
    try {
      _0x378ce2.method("RequestStateAuthority").invoke();
    } catch (_0x419b7f) {}
    let _0x5e167e = null;
    try {
      _0x5e167e = _0x378ce2.method("GetComponent", 1).inflate(UnityRigidbodyClass).invoke();
    } catch (_0x42578e) {}
    if (!_0x5e167e || _0x5e167e.isNull()) {
      try {
        _0x5e167e = _0x378ce2
          .method("GetComponentInChildren", 1)
          .inflate(UnityRigidbodyClass)
          .invoke();
      } catch (_0x2592d6) {}
    }
    if (_0x5e167e && !_0x5e167e.isNull()) {
      const _0x5cc18e = _0x1630d0.field("x").value;
      const _0x1f0672 = _0x1630d0.field("y").value;
      const _0x9bae9a = _0x1630d0.field("z").value;
      _0x5e167e.method("set_isKinematic").invoke(false);
      _0x5e167e.method("WakeUp").invoke();
      _0x5e167e
        .method("set_linearVelocity")
        .invoke([_0x5cc18e * _0xde189d, _0x1f0672 * _0xde189d, _0x9bae9a * _0xde189d]);
    }
  }
  function _0x4f206b(_0x34ea2d, _0x2c9570, _0x2a4f8d) {
    const { pos: _0x118ef9, fwd: _0x44249b } = _0x3df42e(_0x34ea2d);
    const _0x52281a = _0xf8bff9(_0x2c9570, _0x118ef9, QuaternionIdentity);
    if (!_0x52281a || _0x52281a.handle.isNull()) {
      return;
    }
    try {
      const _0x5bc86c = _0x52281a
        .method("GetComponent", 1)
        .inflate(AnimalGrabbableObjectClass)
        .invoke();
      if (_0x5bc86c && !_0x5bc86c.isNull()) {
        _0x5bc86c
          .method("AddExternalForceVelocity", 1)
          .invoke(Vector3Class.method("op_Multiply", 2).invoke(_0x44249b, _0x2a4f8d));
        return;
      }
    } catch (_0x1b4aa4) {}
    let _0x64f29 = null;
    try {
      _0x64f29 = _0x52281a.method("GetComponent", 1).inflate(UnityRigidbodyClass).invoke();
    } catch (_0x466804) {}
    if (!_0x64f29 || _0x64f29.isNull()) {
      try {
        _0x64f29 = _0x52281a
          .method("GetComponentInChildren", 1)
          .inflate(UnityRigidbodyClass)
          .invoke();
      } catch (_0x52ff38) {}
    }
    if (_0x64f29 && !_0x64f29.isNull()) {
      const _0x37a30b = _0x44249b.field("x").value;
      const _0x230242 = _0x44249b.field("y").value;
      const _0x4890bd = _0x44249b.field("z").value;
      _0x64f29.method("set_isKinematic").invoke(false);
      _0x64f29.method("WakeUp").invoke();
      _0x64f29
        .method("set_linearVelocity")
        .invoke([_0x37a30b * _0x2a4f8d, _0x230242 * _0x2a4f8d, _0x4890bd * _0x2a4f8d]);
    }
  }
  function _0x3cfb4e(_0x457f18, _0x5c387a) {
    const _0xb0130c = Math.sqrt(_0x457f18 * _0x457f18 + _0x5c387a * _0x5c387a);
    if (_0xb0130c < 0.0001) {
      return [0, 1];
    }
    return [_0x457f18 / _0xb0130c, _0x5c387a / _0xb0130c];
  }
  function _0x166145(_0x4a44b1, _0x4a4065) {
    try {
      let _0x39a4b4 = null;
      try {
        _0x39a4b4 = _0x4a44b1.method("GetComponent", 1).inflate(UnityRigidbodyClass).invoke();
      } catch (_0x43ecab) {}
      if (!_0x39a4b4 || _0x39a4b4.isNull()) {
        _0x39a4b4 = _0x4a44b1
          .method("GetComponentInChildren", 1)
          .inflate(UnityRigidbodyClass)
          .invoke();
      }
      if (_0x39a4b4 && !_0x39a4b4.isNull()) {
        _0x39a4b4.method("set_isKinematic").invoke(false);
        _0x39a4b4.method("WakeUp").invoke();
        _0x39a4b4.method("set_linearVelocity").invoke(_0x4a4065);
      }
    } catch (_0x15d6d4) {}
  }
  function _0xeecea2(
    _0x5cecb9,
    _0x5a9341 = 18,
    _0x2b4e9e = 96,
    _0x4cb9c6 = 2,
    _0x16e3ce = 2.2,
    _0x2cdf31 = 8.8,
    _0x1516b1 = "item_goop",
  ) {
    var _0x5b3654;
    var _0x1f79cf;
    var _0x42019e;
    var _0x3e5506;
    var _0x3c2e84;
    var _0x137ab2;
    try {
      if (
        !_0x5cecb9 ||
        ((_0x5b3654 = _0x5cecb9.isNull) === null || _0x5b3654 === undefined
          ? undefined
          : _0x5b3654.call(_0x5cecb9))
      ) {
        return;
      }
      const _0x3d69de = _0x5cecb9.method("get_position").invoke();
      const _0x590bca = _0x3a60c2(_0x5cecb9.method("get_forward").invoke());
      const [_0x3b694e, _0x27b9ce] = _0x3cfb4e(_0x590bca[0], _0x590bca[2]);
      for (let _0x2f3d21 = 0; _0x2f3d21 < _0x4cb9c6; _0x2f3d21++) {
        const _0x3156e4 = [
          _0x3d69de.field("x").value + _0x3b694e * 0.14 + (Math.random() * 0.05 - 0.025),
          _0x3d69de.field("y").value - 0.28 + (Math.random() * 0.02 - 0.01),
          _0x3d69de.field("z").value + _0x27b9ce * 0.14 + (Math.random() * 0.05 - 0.025),
        ];
        const _0x22aad8 = _0xf8bff9(_0x1516b1, _0x3156e4, QuaternionIdentity);
        if (
          !_0x22aad8 ||
          ((_0x1f79cf = _0x22aad8.isNull) === null || _0x1f79cf === undefined
            ? undefined
            : _0x1f79cf.call(_0x22aad8))
        ) {
          continue;
        }
        spawnedGoopObjects.push({
          object: _0x22aad8,
          expireAt: time + _0x16e3ce,
        });
        try {
          _0x22aad8.method("set_colorHue").invoke(_0x5a9341);
        } catch (_0x472459) {}
        try {
          _0x22aad8.method("set_colorSaturation").invoke(_0x2b4e9e);
        } catch (_0x4d798b) {}
        try {
          const _0x45e26a = _0x22aad8.method("get_gameObject").invoke();
          if (
            _0x45e26a &&
            !((_0x42019e = _0x45e26a.isNull) === null || _0x42019e === undefined
              ? undefined
              : _0x42019e.call(_0x45e26a))
          ) {
            try {
              const _0x1713b0 = _0x45e26a
                .method("GetComponent", 1)
                .inflate(AnimalGrabbableObjectClass)
                .invoke();
              if (
                _0x1713b0 &&
                !((_0x3e5506 = _0x1713b0.isNull) === null || _0x3e5506 === undefined
                  ? undefined
                  : _0x3e5506.call(_0x1713b0))
              ) {
                try {
                  _0x1713b0.method("set_colorHue").invoke(_0x5a9341);
                } catch (_0x1eae5d) {}
                try {
                  _0x1713b0.method("set_colorSaturation").invoke(_0x2b4e9e);
                } catch (_0x17829c) {}
              }
            } catch (_0x44170c) {}
            try {
              const _0xf53a92 = _0x3302f9(_0x45e26a, RendererClass);
              if (
                _0xf53a92 &&
                !((_0x3c2e84 = _0xf53a92.isNull) === null || _0x3c2e84 === undefined
                  ? undefined
                  : _0x3c2e84.call(_0xf53a92))
              ) {
                const _0xc603a0 = _0xf53a92.method("get_material").invoke();
                if (
                  _0xc603a0 &&
                  !((_0x137ab2 = _0xc603a0.isNull) === null || _0x137ab2 === undefined
                    ? undefined
                    : _0x137ab2.call(_0xc603a0))
                ) {
                  _0xc603a0.method("set_color").invoke([1, 0.95, 0.12, 1]);
                }
              }
            } catch (_0x36ea11) {}
          }
        } catch (_0x224b04) {}
        _0x166145(_0x22aad8, [
          _0x3b694e * _0x2cdf31 + (Math.random() * 0.95 - 0.475),
          -1 + Math.random() * 0.35,
          _0x27b9ce * _0x2cdf31 + (Math.random() * 0.95 - 0.475),
        ]);
      }
    } catch (_0x2154d2) {}
  }
  function _0x3218db(_0x1554f1, _0x2acfef, _0x525bbf = null) {
    try {
      const _0x33ea39 = _0x1554f1.method("RPC_AttachTo");
      if (!_0x33ea39) {
        console.log("[AttachTo] RPC_AttachTo method not found.");
        return null;
      }
      const _0x85ec21 = _0x525bbf ?? Vector3Zero;
      console.log("[AttachTo] Calling RPC_AttachTo...");
      _0x33ea39.invoke(true, _0x2acfef, true, _0x85ec21);
      console.log("[AttachTo] Success.");
    } catch (_0x288256) {
      console.log("[AttachTo] Failed: " + _0x288256);
      smartError("[AttachTo]", _0x288256);
    }
  }
  function _0x35af2d(_0xd758a5) {
    try {
      const _0x2cd56c = UnityObjectClass.method("FindObjectsByType", 1)
        .inflate(NetPlayerClass)
        .invoke(0);
      for (let _0xa63877 = 0; _0xa63877 < _0x2cd56c.length; _0xa63877++) {
        const _0x592cee = _0x2cd56c.get(_0xa63877);
        if (!_0x592cee || _0x592cee.isNull() || _0x16fc51(_0x592cee)) {
          continue;
        }
        if (!_0x50b6a4(_0x592cee)) {
          continue;
        }
        try {
          _0xd758a5(_0x592cee);
        } catch (_0x23bf2a) {}
      }
    } catch (_0x21c075) {}
  }
  function _0x43d516(_0x1d4f7f) {
    const _0x5b107f = Math.floor(_0x1d4f7f * 6);
    const _0xe59c62 = _0x1d4f7f * 6 - _0x5b107f;
    const _0x50e966 = 1 - _0xe59c62;
    switch (_0x5b107f % 6) {
      case 0:
        return [1, _0xe59c62, 0];
      case 1:
        return [_0x50e966, 1, 0];
      case 2:
        return [0, 1, _0xe59c62];
      case 3:
        return [0, _0x50e966, 1];
      case 4:
        return [_0xe59c62, 0, 1];
      default:
        return [1, 0, _0x50e966];
    }
  }
  function _0x3843b2(_0x42c4ad) {
    const _0x33088d = _balloonRainbowHue;
    _balloonRainbowHue = (_balloonRainbowHue + 0.077) % 1;
    const _0x1388da = Math.round(_0x33088d * 254) - 127;
    const [_0x546986, _0x257c37, _0x32cc49] = _0x43d516(_0x33088d);
    let _0x53cb28 = null;
    try {
      _0x53cb28 = _0x42c4ad.method("get_gameObject").invoke();
    } catch (_0x20dd8c) {}
    const _0x1dc0b0 = _0x53cb28 && !_0x53cb28.isNull() ? _0x53cb28 : _0x42c4ad;
    try {
      let _0x4b6fe2 = null;
      try {
        _0x4b6fe2 = _0x1dc0b0
          .method("GetComponent", 1)
          .inflate(AnimalGrabbableObjectClass)
          .invoke();
      } catch (_0x257a92) {}
      if (!_0x4b6fe2 || _0x4b6fe2.isNull()) {
        try {
          _0x4b6fe2 = _0x1dc0b0
            .method("GetComponentInChildren", 1)
            .inflate(AnimalGrabbableObjectClass)
            .invoke();
        } catch (_0x4e6e2c) {}
      }
      if (_0x4b6fe2 && !_0x4b6fe2.isNull()) {
        _0x4b6fe2.method("set_colorSaturation").invoke(127);
        _0x4b6fe2.method("set_colorHue").invoke(_0x1388da);
      }
    } catch (_0x1483d4) {}
    try {
      const _0x3639b1 = _0x1dc0b0
        .method("GetComponentsInChildren", 1)
        .inflate(RendererClass)
        .invoke(false);
      if (_0x3639b1 && !_0x3639b1.isNull()) {
        for (let _0x30bb38 = 0; _0x30bb38 < _0x3639b1.length; _0x30bb38++) {
          try {
            const _0x254818 = _0x3639b1.get(_0x30bb38);
            if (!_0x254818 || _0x254818.isNull()) {
              continue;
            }
            const _0x131e90 = _0x254818.method("get_material").invoke();
            if (_0x131e90 && !_0x131e90.isNull()) {
              _0x131e90.method("set_color").invoke([_0x546986, _0x257c37, _0x32cc49, 1]);
            }
          } catch (_0xb65044) {}
        }
      }
    } catch (_0x5f0d25) {}
  }
  function _0x38a8c2(_0x36564e, _0x7a1cb4) {
    const { pos: _0x3e7e46, fwd: _0x464b6c } = _0x3df42e(_0x36564e);
    const _0x3da5a7 = _0x5db48f("InflatedBalloon", _0x3e7e46, QuaternionIdentity);
    if (!_0x3da5a7 || _0x3da5a7.handle.isNull()) {
      return;
    }
    try {
      _0x3da5a7.method("RequestStateAuthority").invoke();
    } catch (_0x4872fc) {}
    _0x3843b2(_0x3da5a7);
    let _0x3dbcd4 = null;
    try {
      _0x3dbcd4 = _0x3da5a7.method("GetComponent", 1).inflate(UnityRigidbodyClass).invoke();
    } catch (_0x5556cb) {}
    if (!_0x3dbcd4 || _0x3dbcd4.isNull()) {
      try {
        _0x3dbcd4 = _0x3da5a7
          .method("GetComponentInChildren", 1)
          .inflate(UnityRigidbodyClass)
          .invoke();
      } catch (_0x5c002a) {}
    }
    if (_0x3dbcd4 && !_0x3dbcd4.isNull()) {
      const _0x105566 = _0x464b6c.field("x").value;
      const _0x53b6f2 = _0x464b6c.field("y").value;
      const _0x56206d = _0x464b6c.field("z").value;
      _0x3dbcd4.method("set_isKinematic").invoke(false);
      _0x3dbcd4.method("WakeUp").invoke();
      _0x3dbcd4
        .method("set_linearVelocity")
        .invoke([_0x105566 * _0x7a1cb4, _0x53b6f2 * _0x7a1cb4, _0x56206d * _0x7a1cb4]);
    }
  }
  function _0x1392d4() {
    var _0x145274;
    if (
      GunLibPointer != null &&
      !((_0x145274 = GunLibPointer.isNull) === null || _0x145274 === undefined
        ? undefined
        : _0x145274.call(GunLibPointer))
    ) {
      return;
    }
    GunLibPointer = _0x4aa64c(Vector3Zero, QuaternionIdentity, [0.2, 0.2, 0.2], 0, [0, 0, 0, 0]);
    try {
      _0x11d2fe(_0x3302f9(GunLibPointer, ColliderClass));
    } catch (_0x396d7a) {}
    try {
      GunLibPointer.method("set_layer").invoke(2);
    } catch (_0x2b4ec4) {}
    const _0x316f6f = _0xe40610(GunLibPointer);
    GunLibTicks = [];
    for (const [_0x2ddeed, _0x4922eb] of [
      [0.5, 0.5],
      [-0.5, 0.5],
      [0.5, -0.5],
      [-0.5, -0.5],
    ]) {
      const _0x231578 = _0x2ddeed > 0 ? 1 : -1;
      const _0x4a89be = _0x4922eb > 0 ? 1 : -1;
      const _0x54af41 = _0x4aa64c(
        Vector3Zero,
        QuaternionIdentity,
        Vector3One,
        3,
        [0.78, 0.22, 1, 1],
        _0x316f6f,
        false,
      );
      try {
        _0x54af41.method("set_layer").invoke(2);
      } catch (_0x3a1554) {}
      {
        const _0x4fb50b = _0xe40610(_0x54af41);
        _0x4fb50b.method("set_localPosition").invoke([_0x2ddeed - _0x231578 * 0.13, _0x4922eb, 0]);
        _0x4fb50b.method("set_localRotation").invoke(QuaternionIdentity);
        _0x4fb50b.method("set_localScale").invoke([0.26, 0.06, 0.06]);
        GunLibTicks.push({
          tf: _0x4fb50b,
          mat: _0x3b4135(_0x54af41),
        });
      }
      const _0x5a556c = _0x4aa64c(
        Vector3Zero,
        QuaternionIdentity,
        Vector3One,
        3,
        [0.78, 0.22, 1, 1],
        _0x316f6f,
        false,
      );
      try {
        _0x5a556c.method("set_layer").invoke(2);
      } catch (_0x4fb48d) {}
      {
        const _0x9df48e = _0xe40610(_0x5a556c);
        _0x9df48e.method("set_localPosition").invoke([_0x2ddeed, _0x4922eb - _0x4a89be * 0.13, 0]);
        _0x9df48e.method("set_localRotation").invoke(QuaternionIdentity);
        _0x9df48e.method("set_localScale").invoke([0.06, 0.26, 0.06]);
        GunLibTicks.push({
          tf: _0x9df48e,
          mat: _0x3b4135(_0x5a556c),
        });
      }
    }
    const _0x5d2a38 = _0x4aa64c(
      Vector3Zero,
      QuaternionIdentity,
      Vector3One,
      3,
      [0.85, 0.3, 1, 1],
      _0x316f6f,
      false,
    );
    try {
      _0x5d2a38.method("set_layer").invoke(2);
    } catch (_0x409a6e) {}
    {
      const _0x2da92e = _0xe40610(_0x5d2a38);
      _0x2da92e.method("set_localPosition").invoke([0, 0, 0]);
      _0x2da92e.method("set_localRotation").invoke(QuaternionIdentity);
      _0x2da92e.method("set_localScale").invoke([0.1, 0.18, 0.06]);
    }
    GunLibDotMat = _0x3b4135(_0x5d2a38);
  }
  function _0x1b5aa7(_0x55afd4, _0x158735, _0x43847c, _0x14e583, _0x4afe9c) {
    var _0x329d3c;
    _0x1392d4();
    if (
      !GunLibPointer ||
      ((_0x329d3c = GunLibPointer.isNull) === null || _0x329d3c === undefined
        ? undefined
        : _0x329d3c.call(GunLibPointer))
    ) {
      return;
    }
    try {
      GunLibPointer.method("SetActive").invoke(true);
      const _0x453d56 =
        Math.sqrt(
          _0x43847c[0] * _0x43847c[0] + _0x43847c[1] * _0x43847c[1] + _0x43847c[2] * _0x43847c[2],
        ) || 1;
      const _0x202875 = [
        _0x43847c[0] / _0x453d56,
        _0x43847c[1] / _0x453d56,
        _0x43847c[2] / _0x453d56,
      ];
      const _0x3f2bed = Math.abs(_0x202875[1]) > 0.92 ? [1, 0, 0] : [0, 1, 0];
      let _0x524d09 = [
        _0x3f2bed[1] * _0x202875[2] - _0x3f2bed[2] * _0x202875[1],
        _0x3f2bed[2] * _0x202875[0] - _0x3f2bed[0] * _0x202875[2],
        _0x3f2bed[0] * _0x202875[1] - _0x3f2bed[1] * _0x202875[0],
      ];
      const _0x94fa0f =
        Math.sqrt(
          _0x524d09[0] * _0x524d09[0] + _0x524d09[1] * _0x524d09[1] + _0x524d09[2] * _0x524d09[2],
        ) || 1;
      _0x524d09 = [_0x524d09[0] / _0x94fa0f, _0x524d09[1] / _0x94fa0f, _0x524d09[2] / _0x94fa0f];
      const _0x448802 = [
        _0x202875[1] * _0x524d09[2] - _0x202875[2] * _0x524d09[1],
        _0x202875[2] * _0x524d09[0] - _0x202875[0] * _0x524d09[2],
        _0x202875[0] * _0x524d09[1] - _0x202875[1] * _0x524d09[0],
      ];
      const _0x49fd61 =
        _0x4afe9c === 3
          ? Math.floor(time * 8) * (Math.PI / 4)
          : time * (_0x4afe9c === 2 ? 3.5 : 1.2);
      const _0x25bce6 = [
        _0x524d09[0] * Math.cos(_0x49fd61) + _0x448802[0] * Math.sin(_0x49fd61),
        _0x524d09[1] * Math.cos(_0x49fd61) + _0x448802[1] * Math.sin(_0x49fd61),
        _0x524d09[2] * Math.cos(_0x49fd61) + _0x448802[2] * Math.sin(_0x49fd61),
      ];
      const _0x4ab2e7 = _0xe40610(GunLibPointer);
      _0x4ab2e7.method("set_position").invoke(_0x158735);
      _0x4ab2e7
        .method("set_rotation")
        .invoke(QuaternionClass.method("LookRotation", 2).invoke(_0x202875, _0x25bce6));
      const _0x3c7ca6 =
        _0x4afe9c === 3
          ? 0.17 + Math.sin(time * 11) * 0.05
          : _0x4afe9c === 2
            ? 0.22
            : _0x4afe9c === 1
              ? 0.34
              : 0.46;
      _0x4ab2e7.method("set_localScale").invoke([_0x3c7ca6, _0x3c7ca6, _0x3c7ca6]);
      for (let _0x6287b5 = 0; _0x6287b5 < GunLibTicks.length; _0x6287b5++) {
        _0x1c1a20(GunLibTicks[_0x6287b5].mat, _0x14e583);
      }
      if (_0x4afe9c === 3) {
        const _0x34003a = time % 0.16 < 0.08;
        _0x1c1a20(GunLibDotMat, _0x34003a ? [0.3, 1, 0.45, 1] : [0.8, 0.25, 1, 1]);
      } else {
        const _0x262c9b = time % 0.9 < 0.45 ? 1 : 0.15;
        _0x1c1a20(GunLibDotMat, [
          _0x14e583[0],
          _0x14e583[1],
          _0x14e583[2],
          (_0x4afe9c >= 1 ? 1 : 0.55) * _0x262c9b,
        ]);
      }
    } catch (_0x3f8205) {
      GunLibPointer = null;
      GunLibTicks = [];
      GunLibDotMat = null;
    }
  }
  function _0x43eae3() {
    var _0x167c83;
    var _0x4b0d0d;
    var _0x396ac9;
    var _0x501988;
    var _0x53333a;
    var _0x1ffbab;
    const _0x4da8e4 = rightHandTransform.method("get_position").invoke();
    const _0x23fa9a = _0x155419();
    const _0x41f435 = _0x4da8e4.field("x").value || 0;
    const _0x505c07 = _0x4da8e4.field("y").value || 0;
    const _0x4763bc = _0x4da8e4.field("z").value || 0;
    const _0x3a0989 = _0x23fa9a.field("x").value || 0;
    const _0x5640f2 = _0x23fa9a.field("y").value || 0;
    const _0x44ff22 = _0x23fa9a.field("z").value || 0;
    const _0x491a0b = [
      _0x41f435 + _0x3a0989 * 0.08,
      _0x505c07 + _0x5640f2 * 0.08,
      _0x4763bc + _0x44ff22 * 0.08,
    ];
    let _0x5475fb = null;
    let _0x59e8da = null;
    let _0x2ec568 = Number.POSITIVE_INFINITY;
    try {
      if (!physicsRaycastAllVec4) {
        physicsRaycastAllVec4 = PhysicsClass.method("RaycastAll").overload(
          "UnityEngine.Vector3",
          "UnityEngine.Vector3",
          "System.Single",
          "System.Int32",
        );
      }
      const _0x2ee3fa = physicsRaycastAllVec4.invoke(_0x491a0b, _0x23fa9a, 512, -1);
      if (_0x2ee3fa && !_0x2ee3fa.isNull() && _0x2ee3fa.length > 0) {
        for (let _0x4dfa69 = 0; _0x4dfa69 < _0x2ee3fa.length; _0x4dfa69++) {
          try {
            const _0xe20d70 = _0x2ee3fa.get(_0x4dfa69);
            if (
              !_0xe20d70 ||
              ((_0x167c83 = _0xe20d70.isNull) === null || _0x167c83 === undefined
                ? undefined
                : _0x167c83.call(_0xe20d70))
            ) {
              continue;
            }
            const _0x353649 = _0xe20d70.method("get_collider").invoke();
            if (!_0x353649 || _0x353649.isNull()) {
              continue;
            }
            const _0x4b31a2 = _0xe20d70.method("get_point").invoke();
            const _0x112aa4 = _0x4b31a2.field("x").value;
            const _0x33cccc = _0x4b31a2.field("y").value;
            const _0x4ecb0c = _0x4b31a2.field("z").value;
            const _0xa4f97e = Math.sqrt(
              (_0x112aa4 - _0x41f435) * (_0x112aa4 - _0x41f435) +
                (_0x33cccc - _0x505c07) * (_0x33cccc - _0x505c07) +
                (_0x4ecb0c - _0x4763bc) * (_0x4ecb0c - _0x4763bc),
            );
            if (_0xa4f97e < 0.08 || _0xa4f97e >= _0x2ec568) {
              continue;
            }
            _0x2ec568 = _0xa4f97e;
            _0x5475fb = _0xe20d70;
            try {
              const _0x251f61 = _0x353649.method("get_gameObject").invoke();
              if (_0x251f61 && !_0x251f61.isNull()) {
                const _0x1f8d88 = _0x251f61
                  .method("GetComponentInParent", 0)
                  .inflate(NetPlayerClass)
                  .invoke();
                if (_0x1f8d88 && !_0x1f8d88.isNull() && !_0x16fc51(_0x1f8d88)) {
                  _0x59e8da = _0x1f8d88;
                }
              }
            } catch (_0x2c98b2) {}
          } catch (_0x2230e0) {}
        }
      }
    } catch (_0x2be037) {}
    if (rightGrab && rightTrigger && _0x59e8da && !_0x59e8da.isNull()) {
      _0x5bc894 = true;
      _0x4b51b9 = _0x59e8da;
    } else if (!rightTrigger) {
      _0x5bc894 = false;
      _0x4b51b9 = null;
    } else if (
      _0x5bc894 &&
      _0x4b51b9 &&
      !((_0x4b0d0d = _0x4b51b9.isNull) === null || _0x4b0d0d === undefined
        ? undefined
        : _0x4b0d0d.call(_0x4b51b9))
    ) {
      _0x59e8da = _0x4b51b9;
    }
    let _0x394f4d = _0x41f435 + _0x3a0989 * 512;
    let _0x1c8cae = _0x505c07 + _0x5640f2 * 512;
    let _0x38bd31 = _0x4763bc + _0x44ff22 * 512;
    if (
      _0x5bc894 &&
      _0x4b51b9 &&
      !((_0x396ac9 = _0x4b51b9.isNull) === null || _0x396ac9 === undefined
        ? undefined
        : _0x396ac9.call(_0x4b51b9))
    ) {
      try {
        const _0x53498d = _0xe40610(_0x4b51b9).method("get_position").invoke();
        _0x394f4d = _0x53498d.field("x").value;
        _0x1c8cae = _0x53498d.field("y").value;
        _0x38bd31 = _0x53498d.field("z").value;
      } catch (_0x525dba) {
        _0x5bc894 = false;
        _0x4b51b9 = null;
      }
    } else if (_0x5475fb) {
      try {
        const _0x4950d5 = _0x5475fb.method("get_point").invoke();
        _0x394f4d = _0x4950d5.field("x").value;
        _0x1c8cae = _0x4950d5.field("y").value;
        _0x38bd31 = _0x4950d5.field("z").value;
      } catch (_0x28faa1) {
        _0x5475fb = null;
      }
    }
    const _0x39facc = [_0x394f4d, _0x1c8cae, _0x38bd31];
    if (
      _0x5bc894 &&
      _0x4b51b9 &&
      !((_0x501988 = _0x4b51b9.isNull) === null || _0x501988 === undefined
        ? undefined
        : _0x501988.call(_0x4b51b9))
    ) {
      gunFxEmit = true;
      gunFxPos = [_0x394f4d, _0x1c8cae, _0x38bd31];
    }
    const _0x39f5b0 =
      _0x5bc894 &&
      rightTrigger &&
      _0x59e8da &&
      !((_0x53333a = _0x59e8da.isNull) === null || _0x53333a === undefined
        ? undefined
        : _0x53333a.call(_0x59e8da));
    const _0x500202 = Math.sin(time * 14) > 0 ? [0.3, 1, 0.45, 1] : [0.8, 0.25, 1, 1];
    const _0x55c1c9 = [0.78, 0.1, 1, 1];
    const _0x45a3a2 = [0.55, 0.22, 0.88, 0.95];
    const _0x358652 = [0.3, 0.08, 0.5, 0.65];
    const _0x373f12 = _0x39f5b0
      ? _0x500202
      : _0x59e8da
        ? _0x55c1c9
        : _0x5475fb
          ? _0x45a3a2
          : _0x358652;
    const _0x150bae = _0x39f5b0 ? 0.03 : _0x59e8da ? 0.026 : _0x5475fb ? 0.014 : 0.01;
    const _0xda9369 = _0x39f5b0 ? 3 : _0x59e8da ? 2 : _0x5475fb ? 1 : 0;
    _0x1b5aa7(
      [_0x41f435, _0x505c07, _0x4763bc],
      _0x39facc,
      [_0x3a0989, _0x5640f2, _0x44ff22],
      _0x373f12,
      _0xda9369,
    );
    if (
      GunLibLine == null ||
      ((_0x1ffbab = GunLibLine.isNull) === null || _0x1ffbab === undefined
        ? undefined
        : _0x1ffbab.call(GunLibLine))
    ) {
      const _0x57293b = _0x4aa64c(Vector3Zero, QuaternionIdentity, Vector3One, 0, [0, 0, 0, 0]);
      GunLibLine = _0x238332(_0x57293b, LineRendererClass);
      try {
        _0x57293b.method("set_layer").invoke(2);
      } catch (_0x1eea40) {}
    } else {
      try {
        GunLibLine.method("get_gameObject").invoke().method("SetActive").invoke(true);
      } catch (_0x1e1d22) {
        GunLibLine = null;
      }
    }
    try {
      const _0x242a7b = GunLibLine.method("get_material").invoke();
      _0x242a7b.method("set_shader").invoke(uiDefaultShader);
      GunLibLine.method("set_startColor").invoke(_0x373f12);
      GunLibLine.method("set_endColor").invoke(_0x373f12);
      GunLibLine.method("set_startWidth").invoke(_0x150bae);
      GunLibLine.method("set_endWidth").invoke(_0x150bae);
      GunLibLine.method("set_useWorldSpace").invoke(true);
      if (rightTrigger && _0x59e8da) {
        const _0x29e13 = 34;
        GunLibLine.method("set_positionCount").invoke(_0x29e13);
        GunLibLine.method("SetPosition").invoke(0, _0x4da8e4);
        const _0x3429de =
          Math.sqrt(_0x3a0989 * _0x3a0989 + _0x5640f2 * _0x5640f2 + _0x44ff22 * _0x44ff22) || 1;
        const _0x226d2a = [_0x3a0989 / _0x3429de, _0x5640f2 / _0x3429de, _0x44ff22 / _0x3429de];
        let _0x4cb1ad = Math.abs(_0x226d2a[1]) > 0.92 ? [1, 0, 0] : [0, 1, 0];
        let _0x3e7c27 = [
          _0x4cb1ad[1] * _0x226d2a[2] - _0x4cb1ad[2] * _0x226d2a[1],
          _0x4cb1ad[2] * _0x226d2a[0] - _0x4cb1ad[0] * _0x226d2a[2],
          _0x4cb1ad[0] * _0x226d2a[1] - _0x4cb1ad[1] * _0x226d2a[0],
        ];
        const _0x366019 =
          Math.sqrt(
            _0x3e7c27[0] * _0x3e7c27[0] + _0x3e7c27[1] * _0x3e7c27[1] + _0x3e7c27[2] * _0x3e7c27[2],
          ) || 1;
        _0x3e7c27 = [_0x3e7c27[0] / _0x366019, _0x3e7c27[1] / _0x366019, _0x3e7c27[2] / _0x366019];
        let _0x1bdc5e = [
          _0x226d2a[1] * _0x3e7c27[2] - _0x226d2a[2] * _0x3e7c27[1],
          _0x226d2a[2] * _0x3e7c27[0] - _0x226d2a[0] * _0x3e7c27[2],
          _0x226d2a[0] * _0x3e7c27[1] - _0x226d2a[1] * _0x3e7c27[0],
        ];
        const _0xf0a8f7 =
          Math.sqrt(
            _0x1bdc5e[0] * _0x1bdc5e[0] + _0x1bdc5e[1] * _0x1bdc5e[1] + _0x1bdc5e[2] * _0x1bdc5e[2],
          ) || 1;
        _0x1bdc5e = [_0x1bdc5e[0] / _0xf0a8f7, _0x1bdc5e[1] / _0xf0a8f7, _0x1bdc5e[2] / _0xf0a8f7];
        const _0x4dd839 = Math.floor(time * 30);
        for (let _0xe52eb7 = 1; _0xe52eb7 < _0x29e13 - 1; _0xe52eb7++) {
          const _0x34c387 = _0xe52eb7 / (_0x29e13 - 1);
          const _0x1df0db = _0x41f435 + (_0x394f4d - _0x41f435) * _0x34c387;
          const _0x1d8472 = _0x505c07 + (_0x1c8cae - _0x505c07) * _0x34c387;
          const _0xe6ca66 = _0x4763bc + (_0x38bd31 - _0x4763bc) * _0x34c387;
          const _0xa23788 = Math.sin(_0xe52eb7 * 12.9898 + _0x4dd839 * 78.233) * 43758.5453;
          const _0x1907be = Math.sin(_0xe52eb7 * 39.346 + _0x4dd839 * 11.135) * 24634.6345;
          const _0x319dd9 = _0xa23788 - Math.floor(_0xa23788) - 0.5;
          const _0x4d4c03 = _0x1907be - Math.floor(_0x1907be) - 0.5;
          const _0x5c813d = Math.sin(_0x34c387 * Math.PI) * 0.045;
          GunLibLine.method("SetPosition").invoke(_0xe52eb7, [
            _0x1df0db + (_0x3e7c27[0] * _0x319dd9 + _0x1bdc5e[0] * _0x4d4c03) * _0x5c813d,
            _0x1d8472 + (_0x3e7c27[1] * _0x319dd9 + _0x1bdc5e[1] * _0x4d4c03) * _0x5c813d,
            _0xe6ca66 + (_0x3e7c27[2] * _0x319dd9 + _0x1bdc5e[2] * _0x4d4c03) * _0x5c813d,
          ]);
        }
        GunLibLine.method("SetPosition").invoke(_0x29e13 - 1, _0x39facc);
      } else {
        GunLibLine.method("set_positionCount").invoke(2);
        GunLibLine.method("SetPosition").invoke(0, _0x4da8e4);
        GunLibLine.method("SetPosition").invoke(1, _0x39facc);
      }
    } catch (_0x15feb2) {}
    return {
      finalRay: _0x5475fb,
      targetPlayer: _0x59e8da,
    };
  }
  function _0x577f7f() {
    var _0x3cc275;
    var _0x25f85a;
    const _0x360a63 = rightHandTransform.method("get_position").invoke();
    const _0x1a7580 = _0x155419();
    const _0x315bce = _0x360a63.field("x").value || 0;
    const _0x39af2b = _0x360a63.field("y").value || 0;
    const _0x3b4e6e = _0x360a63.field("z").value || 0;
    const _0x1ef00e = _0x1a7580.field("x").value || 0;
    const _0x962a56 = _0x1a7580.field("y").value || 0;
    const _0x44e73e = _0x1a7580.field("z").value || 0;
    const _0x5e68f6 = [
      _0x315bce + _0x1ef00e * 0.08,
      _0x39af2b + _0x962a56 * 0.08,
      _0x3b4e6e + _0x44e73e * 0.08,
    ];
    let _0x59d33b = null;
    let _0x5a1b7a = null;
    let _0x39ddbc = Number.POSITIVE_INFINITY;
    try {
      if (!physicsRaycastAllVec4) {
        physicsRaycastAllVec4 = PhysicsClass.method("RaycastAll").overload(
          "UnityEngine.Vector3",
          "UnityEngine.Vector3",
          "System.Single",
          "System.Int32",
        );
      }
      const _0x336fb7 = physicsRaycastAllVec4.invoke(_0x5e68f6, _0x1a7580, 512, -1);
      if (_0x336fb7 && !_0x336fb7.isNull() && _0x336fb7.length > 0) {
        for (let _0x28e5d1 = 0; _0x28e5d1 < _0x336fb7.length; _0x28e5d1++) {
          try {
            const _0x4d239b = _0x336fb7.get(_0x28e5d1);
            if (
              !_0x4d239b ||
              ((_0x3cc275 = _0x4d239b.isNull) === null || _0x3cc275 === undefined
                ? undefined
                : _0x3cc275.call(_0x4d239b))
            ) {
              continue;
            }
            const _0x45613f = _0x4d239b.method("get_collider").invoke();
            if (!_0x45613f || _0x45613f.isNull()) {
              continue;
            }
            const _0x3e1ef2 = _0x4d239b.method("get_point").invoke();
            const _0x4a184e = _0x3e1ef2.field("x").value;
            const _0x24ae49 = _0x3e1ef2.field("y").value;
            const _0x86e943 = _0x3e1ef2.field("z").value;
            const _0x497cae = Math.sqrt(
              (_0x4a184e - _0x315bce) * (_0x4a184e - _0x315bce) +
                (_0x24ae49 - _0x39af2b) * (_0x24ae49 - _0x39af2b) +
                (_0x86e943 - _0x3b4e6e) * (_0x86e943 - _0x3b4e6e),
            );
            if (_0x497cae < 0.08 || _0x497cae >= _0x39ddbc) {
              continue;
            }
            _0x39ddbc = _0x497cae;
            _0x59d33b = _0x4d239b;
            try {
              const _0x28dcd0 = _0x45613f.method("get_gameObject").invoke();
              if (_0x28dcd0 && !_0x28dcd0.isNull()) {
                const _0xbfa102 = _0x28dcd0
                  .method("GetComponentInParent", 0)
                  .inflate(NetPlayerClass)
                  .invoke();
                if (_0xbfa102 && !_0xbfa102.isNull() && !_0x16fc51(_0xbfa102)) {
                  _0x5a1b7a = _0xbfa102;
                }
              }
            } catch (_0x1787f3) {}
          } catch (_0x425f00) {}
        }
      }
    } catch (_0x6bc38c) {}
    let _0x2e7082 = _0x315bce + _0x1ef00e * 512;
    let _0x3961d6 = _0x39af2b + _0x962a56 * 512;
    let _0x4d482f = _0x3b4e6e + _0x44e73e * 512;
    if (_0x59d33b) {
      try {
        const _0x57daa3 = _0x59d33b.method("get_point").invoke();
        _0x2e7082 = _0x57daa3.field("x").value;
        _0x3961d6 = _0x57daa3.field("y").value;
        _0x4d482f = _0x57daa3.field("z").value;
      } catch (_0x480c51) {
        _0x59d33b = null;
      }
    }
    const _0x14b31e = [_0x2e7082, _0x3961d6, _0x4d482f];
    const _0x2ccdfb = [0.78, 0.1, 1, 1];
    const _0x444524 = [0.55, 0.22, 0.88, 0.95];
    const _0x3dadc7 = [0.3, 0.08, 0.5, 0.65];
    const _0x30c0d7 = _0x5a1b7a ? _0x2ccdfb : _0x59d33b ? _0x444524 : _0x3dadc7;
    const _0x43e124 = _0x5a1b7a ? 0.026 : _0x59d33b ? 0.014 : 0.01;
    _0x1b5aa7(
      [_0x315bce, _0x39af2b, _0x3b4e6e],
      _0x14b31e,
      [_0x1ef00e, _0x962a56, _0x44e73e],
      _0x30c0d7,
      _0x5a1b7a ? 2 : _0x59d33b ? 1 : 0,
    );
    if (
      GunLibLine == null ||
      ((_0x25f85a = GunLibLine.isNull) === null || _0x25f85a === undefined
        ? undefined
        : _0x25f85a.call(GunLibLine))
    ) {
      const _0x5bb2fe = _0x4aa64c(Vector3Zero, QuaternionIdentity, Vector3One, 0, [0, 0, 0, 0]);
      GunLibLine = _0x238332(_0x5bb2fe, LineRendererClass);
      try {
        _0x5bb2fe.method("set_layer").invoke(2);
      } catch (_0xbffc3a) {}
    } else {
      try {
        GunLibLine.method("get_gameObject").invoke().method("SetActive").invoke(true);
      } catch (_0x293e23) {
        GunLibLine = null;
      }
    }
    try {
      const _0x1c2e24 = GunLibLine.method("get_material").invoke();
      _0x1c2e24.method("set_shader").invoke(uiDefaultShader);
      GunLibLine.method("set_startColor").invoke(_0x30c0d7);
      GunLibLine.method("set_endColor").invoke(_0x30c0d7);
      GunLibLine.method("set_startWidth").invoke(_0x43e124);
      GunLibLine.method("set_endWidth").invoke(_0x43e124);
      GunLibLine.method("set_useWorldSpace").invoke(true);
      GunLibLine.method("set_positionCount").invoke(2);
      GunLibLine.method("SetPosition").invoke(0, _0x360a63);
      GunLibLine.method("SetPosition").invoke(1, _0x14b31e);
    } catch (_0x569f04) {}
    return {
      finalRay: _0x59d33b,
      targetPlayer: _0x5a1b7a,
    };
  }
  function _0x341207() {
    var _0x16335e;
    var _0xf40537;
    try {
      const _0x21fbc0 = NetPlayerClass.field("playerIDToNetPlayer").value;
      const _0xddb2e2 = _0x21fbc0.method("get_Values").invoke();
      const _0x1114f4 = _0xddb2e2.method("GetEnumerator").invoke();
      while (_0x1114f4.method("MoveNext").invoke()) {
        const _0x29988a = _0x1114f4.method("get_Current").invoke();
        if (!_0x29988a || _0x29988a.handle.isNull()) {
          continue;
        }
        const _0x44df67 = _0x29988a.method("get_gameObject").invoke();
        const _0x2ef64d = _0x44df67.method("get_layer").invoke();
        const _0x4f7fbd = getPlayerName(_0x29988a);
        const _0x54b280 = _0xe40610(_0x44df67);
        const _0x5f1e62 = _0x54b280.method("get_childCount").invoke();
        console.log(
          "[PLAYER DEBUG] " + _0x4f7fbd + " root layer=" + _0x2ef64d + " children=" + _0x5f1e62,
        );
        for (let _0x3c60ea = 0; _0x3c60ea < Math.min(_0x5f1e62, 10); _0x3c60ea++) {
          try {
            const _0x4413df = _0x54b280.method("GetChild").invoke(_0x3c60ea);
            const _0x3c3e9d = _0x4413df.method("get_gameObject").invoke();
            const _0x131f0e = _0x3c3e9d.method("get_layer").invoke();
            const _0x4b0a6b =
              (_0xf40537 =
                (_0x16335e = _0x3c3e9d.method("get_name").invoke()) === null ||
                _0x16335e === undefined
                  ? undefined
                  : _0x16335e.content) !== null && _0xf40537 !== undefined
                ? _0xf40537
                : "?";
            console.log("[PLAYER DEBUG]   child: " + _0x4b0a6b + " layer=" + _0x131f0e);
          } catch (_0x4ba5cc) {}
        }
      }
    } catch (_0x27da82) {
      console.log("[PLAYER DEBUG] error: " + _0x27da82);
    }
  }
  setTimeout(() => {}, 3000);
  function _0x538191() {
    const _0x901c04 = _0xe40610(menu);
    let _0x51d5c1;
    let _0x378fdb;
    if (righthand) {
      _0x51d5c1 = rightHandTransform.method("get_position").invoke();
      _0x378fdb = rightHandTransform.method("get_rotation").invoke();
      _0x378fdb = QuaternionClass.method("op_Multiply").invoke(
        _0x378fdb,
        QuaternionClass.method("Euler").invoke(0, 0, 180),
      );
    } else {
      _0x51d5c1 = leftHandTransform.method("get_position").invoke();
      _0x378fdb = leftHandTransform.method("get_rotation").invoke();
    }
    if (LerpMenu) {
      const _0x13d1aa = _0x901c04.method("get_position").invoke();
      const _0xa84317 = Vector3Class.method("Distance").invoke(_0x13d1aa, Vector3Zero);
      if (_0xa84317 < 1) {
        _0x901c04.method("set_position").invoke(_0x51d5c1);
        _0x901c04.method("set_rotation").invoke(_0x378fdb);
      } else {
        _0x901c04
          .method("set_position")
          .invoke(Vector3Class.method("Lerp").invoke(_0x13d1aa, _0x51d5c1, deltaTime * 15));
        _0x901c04
          .method("set_rotation")
          .invoke(
            QuaternionClass.method("Slerp").invoke(
              _0x901c04.method("get_rotation").invoke(),
              _0x378fdb,
              deltaTime * 15,
            ),
          );
      }
    } else {
      _0x901c04.method("set_position").invoke(_0x51d5c1);
      _0x901c04.method("set_rotation").invoke(_0x378fdb);
    }
  }
  // ===== Menu button model =====
  class ButtonInfo {
    constructor(config) {
      this.buttonText = config.buttonText;
      this.method = config.method;
      this.enableMethod = config.enableMethod;
      this.disableMethod = config.disableMethod;
      this.isTogglable = config.isTogglable ?? true;
      this.toolTip = config.toolTip ?? null;
      this.enabled = config.enabled ?? false;
    }
  }
  function _0x3c6fc9() {
    if (time <= containerFreedomSweepDelay) {
      return;
    }
    containerFreedomSweepDelay = time + 0.45;
    try {
      const _0x48934c = UnityObjectClass.method("FindObjectsByType", 1)
        .inflate(AnimalGrabbableObjectClass)
        .invoke(0);
      for (let _0x7b2597 = 0; _0x7b2597 < _0x48934c.length; _0x7b2597++) {
        try {
          const _0x161a4f = _0x48934c.get(_0x7b2597);
          if (!_0x161a4f || _0x161a4f.isNull()) {
            continue;
          }
          const _0x2de83c = _0x161a4f
            .method("GetComponent", 1)
            .inflate(GrabbableItemClass)
            .invoke();
          if (!_0x2de83c || _0x2de83c.isNull()) {
            continue;
          }
          try {
            _0x2de83c.method("set_allowAddToBag").invoke(true);
          } catch (_0x554635) {}
          try {
            _0x2de83c.field("_allowAddToBag").value = true;
          } catch (_0x16fb29) {}
          try {
            const _0x5962ac = _0x2de83c.method("get_itemData").invoke();
            if (_0x5962ac && !_0x5962ac.isNull()) {
              const _0x1eaaec = _0x5962ac.method("get_flags").invoke();
              if (_0x1eaaec && !_0x1eaaec.isNull()) {
                try {
                  _0x1eaaec.method("set_value").invoke(8190);
                } catch (_0x20f6e2) {}
                try {
                  _0x1eaaec.field("_value").value = 8190;
                } catch (_0xec3550) {}
              }
            }
          } catch (_0x467fb9) {}
        } catch (_0x1749e2) {}
      }
    } catch (_0x1a256d) {}
  }
  function _0x583465(_0x4e5b8c, _0x5e5d8a = 14) {
    try {
      if (!_0x4e5b8c || _0x4e5b8c.isNull()) {
        return false;
      }
      let _0xf15af4 = null;
      let _0x5561b7 = 1;
      try {
        const _0x44c679 = _0x4e5b8c.method("get_rightHandAnchor").invoke();
        if (_0x44c679 && !_0x44c679.isNull()) {
          _0xf15af4 = _0x44c679.method("get_grabbableObject").invoke();
        }
      } catch (_0x11e92d) {}
      if (!_0xf15af4 || _0xf15af4.isNull()) {
        _0x5561b7 = 0;
        try {
          const _0x1bb59b = _0x4e5b8c.method("get_leftHandAnchor").invoke();
          if (_0x1bb59b && !_0x1bb59b.isNull()) {
            _0xf15af4 = _0x1bb59b.method("get_grabbableObject").invoke();
          }
        } catch (_0x2ceb04) {}
      }
      if (!_0xf15af4 || _0xf15af4.isNull()) {
        return false;
      }
      let _0x1a3993 = null;
      try {
        const _0x52c2dd = _0xf15af4.method("GetComponent", 1).inflate(GrabbableItemClass).invoke();
        if (_0x52c2dd && !_0x52c2dd.isNull()) {
          const _0x157383 = _0x52c2dd.method("get_itemID").invoke();
          if (_0x157383) {
            _0x1a3993 = String(_0x157383.content ?? _0x157383);
          }
        }
      } catch (_0x32689c) {}
      if (!_0x1a3993) {
        return false;
      }
      let _0x5b6dae = null;
      try {
        if (_0x5561b7 === 1) {
          _0x5b6dae = rightHandTransform;
        } else {
          _0x5b6dae = leftHandTransform;
        }
      } catch (_0xfa2617) {}
      const _0x10a4c8 = _0x5b6dae
        ? _0x5b6dae.method("get_position").invoke()
        : _0xe40610(_0x4e5b8c).method("get_position").invoke();
      const _0xeb4520 = _0x5db48f(_0x1a3993, _0x10a4c8, QuaternionIdentity);
      if (!_0xeb4520 || _0xeb4520.isNull()) {
        return false;
      }
      try {
        const _0x2dac8c = _0x5b6dae
          ? _0x5b6dae.method("get_forward").invoke()
          : rightHandTransform.method("get_forward").invoke();
        const _0x4e719a = _0x2dac8c.field("x").value * _0x5e5d8a;
        const _0x322258 = _0x2dac8c.field("y").value * _0x5e5d8a;
        const _0x158f6b = _0x2dac8c.field("z").value * _0x5e5d8a;
        const _0x58919a = _0xeb4520.method("GetComponent", 1).inflate(RigidbodyClass).invoke();
        if (_0x58919a && !_0x58919a.isNull()) {
          _0x58919a.method("set_velocity").invoke([_0x4e719a, _0x322258, _0x158f6b]);
        }
      } catch (_0x324d7a) {}
      return true;
    } catch (_0xca246c) {
      return false;
    }
  }
  let _0x3a1bb2 = false;
  function _0x18a723(_0x4796b9) {
    _0x3a1bb2 = true;
    try {
      _0x4796b9();
    } finally {
      _0x3a1bb2 = false;
    }
  }
  function _0x28e89c(_0x2c96e7) {
    var _0xd36d12;
    var _0x2d7c27;
    try {
      const _0x5c1617 = animalImage.class("AnimalCompany.NetSessionRPCs");
      const _0x138060 = _0x5c1617.field("_instance").value;
      if (
        !_0x138060 ||
        ((_0xd36d12 = _0x138060.isNull) === null || _0xd36d12 === undefined
          ? undefined
          : _0xd36d12.call(_0x138060))
      ) {
        return null;
      }
      const _0x9fff5c = _0x2c96e7.field("_userID").value;
      if (
        !_0x9fff5c ||
        ((_0x2d7c27 = _0x9fff5c.isNull) === null || _0x2d7c27 === undefined
          ? undefined
          : _0x2d7c27.call(_0x9fff5c))
      ) {
        return null;
      }
      const _0x39c42f = Il2Cpp.corlib.class("System.Guid").method("Parse").invoke(_0x9fff5c);
      try {
        _0x138060.method("RPC_KickPlayer").invoke(_0x39c42f);
      } catch (_0x4c0fd8) {}
      try {
        _0x5c1617.method("KickPlayer").invoke(_0x9fff5c);
      } catch (_0x3ca5db) {}
    } catch (_0x3185da) {
      smartError("kickPlayer", _0x3185da);
    }
    return null;
  }
  function _0x189507() {
    try {
      let _0x1d5a97 = 0;
      const _0x468fc6 = UnityObjectClass.method("FindObjectsByType", 1)
        .inflate(NetPlayerClass)
        .invoke(0);
      for (let _0x1d4e97 = 0; _0x1d4e97 < _0x468fc6.length; _0x1d4e97++) {
        const _0x3266e6 = _0x468fc6.get(_0x1d4e97);
        if (!_0x3266e6 || _0x3266e6.isNull() || _0x16fc51(_0x3266e6)) {
          continue;
        }
        _0x28e89c(_0x3266e6);
        _0x1d5a97++;
      }
      notify("Kicked " + _0x1d5a97 + " players", false);
    } catch (_0x5e63c9) {
      smartError("kickAllPlayers", _0x5e63c9);
    }
  }
  // ===== Menu pages =====
  const menuPages = [
    [
      new ButtonInfo({
        buttonText: "Settings",
        method: () => {
          currentCategory = 2;
          currentPage = 0;
        },
        isTogglable: false,
        toolTip: "Opens settings.",
      }),
      new ButtonInfo({
        buttonText: "Movement mods",
        method: () => {
          currentCategory = 3;
          currentPage = 0;
        },
        isTogglable: false,
        toolTip: "Opens the player mods category.",
      }),
      new ButtonInfo({
        buttonText: "Player mods",
        method: () => {
          currentCategory = 4;
          currentPage = 0;
        },
        isTogglable: false,
        toolTip: "Opens the movement mods category.",
      }),
      new ButtonInfo({
        buttonText: "Item mods",
        method: () => {
          currentCategory = 6;
          currentPage = 0;
        },
        isTogglable: false,
        toolTip: "Opens the item mods category.",
      }),
      new ButtonInfo({
        buttonText: "Spawning",
        method: () => {
          currentCategory = 7;
          currentPage = 0;
        },
        isTogglable: false,
        toolTip: "Opens the Spawning category.",
      }),
      new ButtonInfo({
        buttonText: "Gun Mods",
        method: () => {
          currentCategory = 8;
          currentPage = 0;
        },
        isTogglable: false,
        toolTip: "Opens the Gun Mods category — all GunLib target guns.",
      }),
      new ButtonInfo({
        buttonText: "Misc",
        method: () => {
          currentCategory = 9;
          currentPage = 0;
        },
        isTogglable: false,
        toolTip: "Opens the misc category.",
      }),
      new ButtonInfo({
        buttonText: "Whitelist",
        method: () => {
          currentCategory = 21;
          currentPage = 0;
        },
        isTogglable: false,
        toolTip: "Opens the Whitelist category — give mods to specific players.",
      }),
      new ButtonInfo({
        buttonText: "Shooters",
        method: () => {
          currentCategory = 17;
          currentPage = 0;
        },
        isTogglable: false,
        toolTip: "Opens the shooters category.",
      }),
      new ButtonInfo({
        buttonText: "Overpowered",
        method: () => {
          currentCategory = 18;
          currentPage = 0;
        },
        isTogglable: false,
        toolTip: "Opens the Overpowered category - mess with all players at once.",
      }),
      new ButtonInfo({
        buttonText: "Experimental",
        method: () => {
          currentCategory = 19;
          currentPage = 0;
        },
        isTogglable: false,
        toolTip: "Opens the Experimental category - unstable or new features.",
      }),
      new ButtonInfo({
        buttonText: "Credits",
        method: () => {
          currentCategory = 13;
          currentPage = 0;
        },
        isTogglable: false,
        toolTip: "Opens the Credits category.",
      }),
      new ButtonInfo({
        buttonText: "Dev Stuff",
        method: () => {
          currentCategory = 20;
          currentPage = 0;
        },
        isTogglable: false,
        toolTip: "Opens Dev Stuff — dump tools and debug utilities.",
      }),
    ],
    [
      new ButtonInfo({
        buttonText: "Disconnect",
        method: () => {
          try {
            const _0x5a0ace = NetworkManagerClass.method("get_instance").invoke();
            if (!_0x5a0ace || _0x5a0ace.isNull()) {
              return;
            }
            _0x5a0ace.method("TryShutdownAndCancelConnecting").invoke();
          } catch (_0x53e05a) {
            smartError("[Disconnect]", _0x53e05a);
          }
        },
        isTogglable: false,
        toolTip: "Disconnects you from the room cleanly.",
      }),
      new ButtonInfo({
        buttonText: "PreviousPage",
        method: () => {
          const _0x5b67c5 = Math.ceil(menuPages[currentCategory].length / 8) - 1;
          currentPage--;
          if (currentPage < 0) {
            currentPage = _0x5b67c5;
          }
        },
        isTogglable: false,
      }),
      new ButtonInfo({
        buttonText: "NextPage",
        method: () => {
          const _0x36bb1f = Math.ceil(menuPages[currentCategory].length / 8) - 1;
          currentPage++;
          currentPage %= _0x36bb1f + 1;
        },
        isTogglable: false,
      }),
      new ButtonInfo({
        buttonText: "GlobalReturn",
        method: () => {
          currentCategory = 0;
          currentPage = 0;
        },
        isTogglable: false,
        toolTip: "Returns you back to the main category.",
      }),
    ],
    [
      new ButtonInfo({
        buttonText: "Exit Settings",
        method: () => {
          currentCategory = 0;
          currentPage = 0;
        },
        isTogglable: false,
        toolTip: "Returns you back to the main category.",
      }),
      new ButtonInfo({
        buttonText: "RPC Protection",
        isTogglable: true,
        enableMethod: () => {
          rpcProtectionEnabled = true;
          notify("RPC Protection ON — you are shielded!", false, 3);
        },
        disableMethod: () => {
          rpcProtectionEnabled = false;
          notify("RPC Protection OFF", false, 2);
        },
        method: () => {},
        toolTip:
          "Hooks all harmful RPCs and drops any call targeting YOU from another client. Your own menu still works normally via the selfRPC bypass.",
      }),
      new ButtonInfo({
        buttonText: "Change Item ID",
        method: () => {
          if (rightGrab) {
            itemIndex--;
          } else {
            itemIndex++;
          }
          itemIndex = ((itemIndex % itemIDs.length) + itemIDs.length) % itemIDs.length;
          console.log(itemIDs[itemIndex]);
          notify(
            "<color=grey>[</color><color=#8000ff>MENU</color><color=grey>]</color> New item index: " +
              itemIDs[itemIndex],
            false,
          );
        },
        isTogglable: false,
        toolTip: "Next item ID (+). Use 'Item ID -' to go back.",
      }),
      new ButtonInfo({
        buttonText: "Item ID -",
        isTogglable: false,
        method: () => {
          itemIndex = (((itemIndex - 1) % itemIDs.length) + itemIDs.length) % itemIDs.length;
          notify(
            "<color=grey>[</color><color=#8000ff>MENU</color><color=grey>]</color> Item: " +
              itemIDs[itemIndex],
            false,
          );
        },
        toolTip: "Previous item ID (-).",
      }),
      new ButtonInfo({
        buttonText: "Change Prefab ID",
        method: () => {
          if (rightGrab) {
            prefabIndex--;
          } else {
            prefabIndex++;
          }
          prefabIndex = ((prefabIndex % prefabIDs.length) + prefabIDs.length) % prefabIDs.length;
          notify(
            "<color=grey>[</color><color=#8000ff>MENU</color><color=grey>]</color> Prefab: " +
              prefabIDs[prefabIndex],
            false,
          );
        },
        isTogglable: false,
        toolTip: "Next prefab (+). Use 'Prefab ID -' to go back.",
      }),
      new ButtonInfo({
        buttonText: "Prefab ID -",
        isTogglable: false,
        method: () => {
          prefabIndex =
            (((prefabIndex - 1) % prefabIDs.length) + prefabIDs.length) % prefabIDs.length;
          notify(
            "<color=grey>[</color><color=#8000ff>MENU</color><color=grey>]</color> Prefab: " +
              prefabIDs[prefabIndex],
            false,
          );
        },
        toolTip: "Previous prefab (-).",
      }),
      new ButtonInfo({
        buttonText: "Refresh Teleport List",
        isTogglable: false,
        method: () => {
          try {
            let _0xaca578 = null;
            try {
              _0xaca578 = PrefabGeneratorClass.field("_instance")
                .value.method("get_runner")
                .invoke();
            } catch (_0x2972dc) {}
            try {
              if (!_0xaca578 || _0xaca578.isNull()) {
                _0xaca578 = NetworkManagerClass.method("get_instance")
                  .invoke()
                  .method("get_currentRunner")
                  .invoke();
              }
            } catch (_0x2138cc) {}
            if (!_0xaca578 || _0xaca578.isNull()) {
              notify("No NetworkRunner found", false);
              return;
            }
            const _0x7b8427 = _0xaca578.method("GetAllNetworkObjects", 0).invoke();
            if (!_0x7b8427 || _0x7b8427.isNull()) {
              notify("No network objects found", false);
              return;
            }
            teleportNetObjList = [];
            const _0x28bfdd = _0x7b8427.method("get_Count").invoke();
            for (let _0x27588b = 0; _0x27588b < _0x28bfdd; _0x27588b++) {
              try {
                const _0x4e7cf6 = _0x7b8427.method("get_Item").invoke(_0x27588b);
                if (!_0x4e7cf6 || _0x4e7cf6.isNull()) {
                  continue;
                }
                try {
                  const _0x270a1b = _0x4e7cf6
                    .method("GetComponent", 1)
                    .inflate(PlayerControllerClass)
                    .invoke();
                  if (_0x270a1b && !_0x270a1b.isNull()) {
                    continue;
                  }
                } catch (_0x4bd208) {}
                const _0x59d84e = _0x4e7cf6.method("get_gameObject").invoke();
                if (!_0x59d84e || _0x59d84e.isNull()) {
                  continue;
                }
                const _0x367275 =
                  _0x59d84e.method("get_name").invoke()?.content ?? "NetObj_" + _0x27588b;
                teleportNetObjList.push({
                  obj: _0x59d84e,
                  name: _0x367275,
                });
              } catch (_0x26d079) {}
            }
            teleportNetObjIndex = 0;
            const _0x400659 = teleportNetObjList.length > 0 ? teleportNetObjList[0].name : "none";
            notify(
              "Teleport list: " + teleportNetObjList.length + " objects. Current: " + _0x400659,
              false,
              5,
            );
          } catch (_0x2373d3) {
            notify("Refresh Teleport List: " + _0x2373d3, false);
          }
        },
        toolTip: "Scans all NetworkObjects (skips players) and builds the teleport target list.",
      }),
      new ButtonInfo({
        buttonText: "Change Teleport Prefab",
        isTogglable: false,
        method: () => {
          if (teleportNetObjList.length === 0) {
            notify("List empty — press Refresh Teleport List first.", false, 4);
            return;
          }
          if (rightGrab) {
            teleportNetObjIndex--;
          } else {
            teleportNetObjIndex++;
          }
          teleportNetObjIndex =
            ((teleportNetObjIndex % teleportNetObjList.length) + teleportNetObjList.length) %
            teleportNetObjList.length;
          const _0x3ebb74 = teleportNetObjList[teleportNetObjIndex];
          notify(
            "<color=grey>[</color><color=#8000ff>MENU</color><color=grey>]</color> Teleport Prefab: " +
              _0x3ebb74.name +
              " [" +
              teleportNetObjIndex +
              "/" +
              (teleportNetObjList.length - 1) +
              "]",
            false,
          );
        },
        toolTip: "Next teleport target (+). Use 'Teleport Prefab -' to go back.",
      }),
      new ButtonInfo({
        buttonText: "Teleport Prefab -",
        isTogglable: false,
        method: () => {
          if (teleportNetObjList.length === 0) {
            notify("List empty — press Refresh Teleport List first.", false, 4);
            return;
          }
          teleportNetObjIndex =
            (((teleportNetObjIndex - 1) % teleportNetObjList.length) + teleportNetObjList.length) %
            teleportNetObjList.length;
          const _0x4b03d0 = teleportNetObjList[teleportNetObjIndex];
          notify(
            "<color=grey>[</color><color=#8000ff>MENU</color><color=grey>]</color> Teleport Prefab: " +
              _0x4b03d0.name +
              " [" +
              teleportNetObjIndex +
              "/" +
              (teleportNetObjList.length - 1) +
              "]",
            false,
          );
        },
        toolTip: "Previous teleport target (-).",
      }),
      new ButtonInfo({
        buttonText: "Change SFX ID",
        method: () => {
          const _0x120b7a = 619;
          if (rightGrab) {
            sfxIndex--;
          } else {
            sfxIndex++;
          }
          sfxIndex = ((sfxIndex % _0x120b7a) + _0x120b7a) % _0x120b7a;
          const _0x1a4b61 = sfxNameMap[sfxIndex] ?? "ID_" + sfxIndex;
          notify(
            "<color=grey>[</color><color=#8000ff>MENU</color><color=grey>]</color> SFX: " +
              _0x1a4b61 +
              " [" +
              sfxIndex +
              "] (grip=down)",
            false,
          );
        },
        isTogglable: false,
        toolTip: "Next SFX ID (+). Use 'SFX ID -' to go back.",
      }),
      new ButtonInfo({
        buttonText: "SFX ID -",
        isTogglable: false,
        method: () => {
          const _0x501ebc = 619;
          sfxIndex = (((sfxIndex - 1) % _0x501ebc) + _0x501ebc) % _0x501ebc;
          const _0x51d995 = sfxNameMap[sfxIndex] ?? "ID_" + sfxIndex;
          notify(
            "<color=grey>[</color><color=#8000ff>MENU</color><color=grey>]</color> SFX: " +
              _0x51d995 +
              " [" +
              sfxIndex +
              "]",
            false,
          );
        },
        toolTip: "Previous SFX ID (-).",
      }),
      new ButtonInfo({
        buttonText: "Change VFX ID",
        method: () => {
          const _0x47dda3 = vfxIDs.indexOf(vfxIndex);
          if (rightGrab) {
            vfxIndex = vfxIDs[(_0x47dda3 - 1 + vfxIDs.length) % vfxIDs.length];
          } else {
            vfxIndex = vfxIDs[(_0x47dda3 + 1) % vfxIDs.length];
          }
          const _0x32e78a = vfxNameMap[vfxIndex] ?? "ID_" + vfxIndex;
          notify(
            "<color=grey>[</color><color=#8000ff>MENU</color><color=grey>]</color> VFX: " +
              _0x32e78a +
              " [" +
              vfxIndex +
              "] (grip=down)",
            false,
          );
        },
        isTogglable: false,
        toolTip: "Next VFX (+). Use 'VFX ID -' to go back.",
      }),
      new ButtonInfo({
        buttonText: "VFX ID -",
        isTogglable: false,
        method: () => {
          const _0x11b2af = vfxIDs.indexOf(vfxIndex);
          vfxIndex = vfxIDs[(((_0x11b2af - 1) % vfxIDs.length) + vfxIDs.length) % vfxIDs.length];
          const _0x563796 = vfxNameMap[vfxIndex] ?? "ID_" + vfxIndex;
          notify(
            "<color=grey>[</color><color=#8000ff>MENU</color><color=grey>]</color> VFX: " +
              _0x563796 +
              " [" +
              vfxIndex +
              "]",
            false,
          );
        },
        toolTip: "Previous VFX (-).",
      }),
    ],
    [
      new ButtonInfo({
        buttonText: "Exit Movement mods",
        method: () => {
          currentCategory = 0;
          currentPage = 0;
        },
        isTogglable: false,
        toolTip: "Returns you back to the main category.",
      }),
      new ButtonInfo({
        buttonText: "Fly",
        method: () => {
          const _0x33050e = localRig
            .method("GetComponent", 1)
            .inflate(UnityRigidbodyClass)
            .invoke();
          if (!_0x33050e) {
            return;
          }
          if (rightTrigger) {
            const _0x141ff2 = rightHandTransform.method("get_forward").invoke();
            const _0x4c5a73 = _0x141ff2.field("x").value;
            const _0x4bd476 = _0x141ff2.field("y").value;
            const _0x1a5bf5 = _0x141ff2.field("z").value;
            const _0x668cf9 = flySpeed * deltaTime;
            _0x33050e
              .method("AddForce", 2)
              .invoke([_0x4c5a73 * _0x668cf9, _0x4bd476 * _0x668cf9, _0x1a5bf5 * _0x668cf9], 2);
          }
          if (leftTrigger) {
            const _0x4d5c52 = leftHandTransform.method("get_forward").invoke();
            const _0x3c01b8 = _0x4d5c52.field("x").value;
            const _0x4035fc = _0x4d5c52.field("y").value;
            const _0x24d0a0 = _0x4d5c52.field("z").value;
            const _0x2f868b = flySpeed * deltaTime;
            _0x33050e
              .method("AddForce", 2)
              .invoke([_0x3c01b8 * _0x2f868b, _0x4035fc * _0x2f868b, _0x24d0a0 * _0x2f868b], 2);
          }
        },
        isTogglable: true,
        toolTip: "Hold triggers to fly where your hands point",
      }),
    ],
    [
      new ButtonInfo({
        buttonText: "Exit Player mods",
        method: () => {
          currentCategory = 0;
          currentPage = 0;
        },
        isTogglable: false,
        toolTip: "Returns you back to the main category.",
      }),
      new ButtonInfo({
        buttonText: "Invisibility",
        enableMethod: () => {
          const _0x3889fc = PlayerControllerClass.method("get_instance").invoke();
          const _0x359b41 = _0x3889fc.method("get_playerView").invoke();
          if (!_0x359b41) {
            return null;
          }
          const _0x6cce5f = _0x359b41.field("_cameraTransform").value;
          if (!_0x6cce5f) {
            return null;
          }
          _0x6cce5f.method("set_position").invoke([0, -99999, 0]);
        },
        disableMethod: () => {
          const _0x448640 = PlayerControllerClass.method("get_instance").invoke();
          const _0x139785 = _0x448640.method("get_playerView").invoke();
          if (!_0x139785) {
            return null;
          }
          const _0x51a434 = _0x139785.field("_cameraTransform").value;
          if (!_0x51a434) {
            return null;
          }
          _0x51a434
            .method("set_position")
            .invoke(_0xe40610(headCollider).method("get_position").invoke());
        },
        isTogglable: true,
        toolTip: "Turns you invisible.",
      }),
      new ButtonInfo({
        buttonText: "Godmode",
        enableMethod: () => {
          try {
            const _0x657cca = NetPlayerClass.method("get_localPlayer").invoke();
            if (!_0x657cca || _0x657cca.handle.isNull()) {
              return;
            }
            _0x657cca.method("set_isInvincible").invoke(true);
            notify("Godmode ON", false, 2);
          } catch (_0x10f7f1) {
            console.error("Godmode enable: " + _0x10f7f1);
          }
        },
        disableMethod: () => {
          try {
            const _0x3c5919 = NetPlayerClass.method("get_localPlayer").invoke();
            if (!_0x3c5919 || _0x3c5919.handle.isNull()) {
              return;
            }
            _0x3c5919.method("set_isInvincible").invoke(false);
            notify("Godmode OFF", false, 2);
          } catch (_0x1deae1) {
            console.error("Godmode disable: " + _0x1deae1);
          }
        },
        isTogglable: true,
        toolTip: "Makes you invincible — no damage, no death.",
      }),
    ],
    [],
    [
      new ButtonInfo({
        buttonText: "Exit Item mods",
        method: () => {
          currentCategory = 0;
          currentPage = 0;
        },
        isTogglable: false,
        toolTip: "Returns you back to the main category.",
      }),
      new ButtonInfo({
        buttonText: "Hue Item",
        method: () => {
          try {
            const _0x16aad2 = NetPlayerClass.method("get_localPlayer").invoke();
            if (!_0x16aad2 || _0x16aad2.handle.isNull()) {
              return;
            }
            const _0x675980 = _0x16aad2.method("GetHandInteractor", 1).invoke(1);
            if (!_0x675980 || _0x675980.handle.isNull()) {
              return;
            }
            const _0x19438d = _0x675980.field("_itemAnchor").value;
            if (!_0x19438d || _0x19438d.handle.isNull()) {
              return;
            }
            const _0x2be685 = _0x19438d.method("get_grabbableObject").invoke();
            if (!_0x2be685 || _0x2be685.handle.isNull()) {
              return;
            }
            if (leftTrigger) {
              hueVal++;
              if (hueVal > 127) {
                hueVal = -127;
              }
            }
            if (leftGrab) {
              hueVal--;
              if (hueVal < -127) {
                hueVal = 127;
              }
            }
            _0x2be685.method("set_colorHue").invoke(hueVal);
          } catch (_0x260ab2) {
            smartError("Custom hue Held Item", _0x260ab2);
          }
        },
        disableMethod: () => {
          hueVal = 0;
          try {
            const _0x23ad36 = NetPlayerClass.method("get_localPlayer").invoke();
            if (!_0x23ad36 || _0x23ad36.handle.isNull()) {
              return;
            }
            const _0x29e1a2 = _0x23ad36.method("GetHandInteractor", 1).invoke(1);
            if (!_0x29e1a2 || _0x29e1a2.handle.isNull()) {
              return;
            }
            const _0x19beea = _0x29e1a2.field("_itemAnchor").value;
            if (!_0x19beea || _0x19beea.handle.isNull()) {
              return;
            }
            const _0x216bc0 = _0x19beea.method("get_grabbableObject").invoke();
            if (!_0x216bc0 || _0x216bc0.handle.isNull()) {
              return;
            }
            _0x216bc0.method("set_colorHue").invoke(0);
          } catch (_0x3d7034) {}
        },
        isTogglable: true,
        toolTip: "Hold item in right hand. Trigger = increase hue, left grip = decrease.",
      }),
      new ButtonInfo({
        buttonText: "Saturation Item",
        method: () => {
          try {
            const _0x39d5d9 = NetPlayerClass.method("get_localPlayer").invoke();
            if (!_0x39d5d9 || _0x39d5d9.handle.isNull()) {
              return;
            }
            const _0x1a734d = _0x39d5d9.method("GetHandInteractor", 1).invoke(1);
            if (!_0x1a734d || _0x1a734d.handle.isNull()) {
              return;
            }
            const _0x549a08 = _0x1a734d.field("_itemAnchor").value;
            if (!_0x549a08 || _0x549a08.handle.isNull()) {
              return;
            }
            const _0x5e7d85 = _0x549a08.method("get_grabbableObject").invoke();
            if (!_0x5e7d85 || _0x5e7d85.handle.isNull()) {
              return;
            }
            if (leftTrigger) {
              satVal++;
              if (satVal > 127) {
                satVal = -127;
              }
            }
            if (leftGrab) {
              satVal--;
              if (satVal < -127) {
                satVal = 127;
              }
            }
            _0x5e7d85.method("set_colorSaturation").invoke(satVal);
          } catch (_0x1cd5e7) {
            smartError("Custom saturation Held Item", _0x1cd5e7);
          }
        },
        disableMethod: () => {
          satVal = 0;
          try {
            const _0x54f50b = NetPlayerClass.method("get_localPlayer").invoke();
            if (!_0x54f50b || _0x54f50b.handle.isNull()) {
              return;
            }
            const _0x54c195 = _0x54f50b.method("GetHandInteractor", 1).invoke(1);
            if (!_0x54c195 || _0x54c195.handle.isNull()) {
              return;
            }
            const _0x4ff951 = _0x54c195.field("_itemAnchor").value;
            if (!_0x4ff951 || _0x4ff951.handle.isNull()) {
              return;
            }
            const _0x5cb127 = _0x4ff951.method("get_grabbableObject").invoke();
            if (!_0x5cb127 || _0x5cb127.handle.isNull()) {
              return;
            }
            _0x5cb127.method("set_colorSaturation").invoke(0);
          } catch (_0x292d5e) {}
        },
        isTogglable: true,
        toolTip: "Hold item in right hand. Trigger = increase saturation, left grip = decrease.",
      }),
      new ButtonInfo({
        buttonText: "Scale Item",
        method: () => {
          try {
            const _0x208b83 = NetPlayerClass.method("get_localPlayer").invoke();
            if (!_0x208b83 || _0x208b83.handle.isNull()) {
              return;
            }
            const _0x398f1d = _0x208b83.method("GetHandInteractor", 1).invoke(1);
            if (!_0x398f1d || _0x398f1d.handle.isNull()) {
              return;
            }
            const _0x446ecb = _0x398f1d.field("_itemAnchor").value;
            if (!_0x446ecb || _0x446ecb.handle.isNull()) {
              return;
            }
            const _0x123497 = _0x446ecb.method("get_grabbableObject").invoke();
            if (!_0x123497 || _0x123497.handle.isNull()) {
              return;
            }
            if (leftTrigger) {
              scaleVal++;
              if (scaleVal > 127) {
                scaleVal = -127;
              }
            }
            if (leftGrab) {
              scaleVal--;
              if (scaleVal < -127) {
                scaleVal = 127;
              }
            }
            _0x123497.method("set_scaleModifier").invoke(scaleVal);
          } catch (_0x4c3684) {
            smartError("Custom Scale Held Item", _0x4c3684);
          }
        },
        disableMethod: () => {
          scaleVal = 0;
          try {
            const _0x4247be = NetPlayerClass.method("get_localPlayer").invoke();
            if (!_0x4247be || _0x4247be.handle.isNull()) {
              return;
            }
            const _0x1dbe49 = _0x4247be.method("GetHandInteractor", 1).invoke(1);
            if (!_0x1dbe49 || _0x1dbe49.handle.isNull()) {
              return;
            }
            const _0x4069e4 = _0x1dbe49.field("_itemAnchor").value;
            if (!_0x4069e4 || _0x4069e4.handle.isNull()) {
              return;
            }
            const _0x2b9a17 = _0x4069e4.method("get_grabbableObject").invoke();
            if (!_0x2b9a17 || _0x2b9a17.handle.isNull()) {
              return;
            }
            _0x2b9a17.method("set_scaleModifier").invoke(0);
          } catch (_0x2fde66) {}
        },
        isTogglable: true,
        toolTip: "Hold item in right hand. Trigger = increase scale, left grip = decrease.",
      }),
      new ButtonInfo({
        buttonText: "Rainbow Held Item",
        disableMethod: () => {
          hueVal = 0;
          satVal = 0;
          try {
            const _0xda7167 = NetPlayerClass.method("get_localPlayer").invoke();
            if (!_0xda7167 || _0xda7167.handle.isNull()) {
              return;
            }
            for (const _0x2307f3 of [0, 1]) {
              try {
                const _0x191763 = _0xda7167.method("GetHandInteractor", 1).invoke(_0x2307f3);
                if (!_0x191763 || _0x191763.handle.isNull()) {
                  continue;
                }
                const _0xbbf04a = _0x191763.field("_itemAnchor").value;
                if (!_0xbbf04a || _0xbbf04a.handle.isNull()) {
                  continue;
                }
                const _0x54830d = _0xbbf04a.method("get_grabbableObject").invoke();
                if (!_0x54830d || _0x54830d.handle.isNull()) {
                  continue;
                }
                _0x54830d.method("set_colorHue").invoke(0);
                _0x54830d.method("set_colorSaturation").invoke(0);
              } catch (_0x180b78) {}
            }
          } catch (_0x515de3) {}
        },
        method: () => {
          try {
            const _0x530596 = NetPlayerClass.method("get_localPlayer").invoke();
            if (!_0x530596 || _0x530596.handle.isNull()) {
              return;
            }
            const _0x399aa0 = Math.round(((time * 1) % 1) * 254 - 127);
            for (const _0x2c7e28 of [0, 1]) {
              try {
                const _0xa84717 = _0x530596.method("GetHandInteractor", 1).invoke(_0x2c7e28);
                if (!_0xa84717 || _0xa84717.handle.isNull()) {
                  continue;
                }
                const _0x726123 = _0xa84717.field("_itemAnchor").value;
                if (!_0x726123 || _0x726123.handle.isNull()) {
                  continue;
                }
                const _0x449bad = _0x726123.method("get_grabbableObject").invoke();
                if (!_0x449bad || _0x449bad.handle.isNull()) {
                  continue;
                }
                _0x449bad.method("set_colorHue").invoke(_0x399aa0);
                _0x449bad.method("set_colorSaturation").invoke(127);
              } catch (_0x2ac521) {}
            }
          } catch (_0x7bed46) {
            smartError("Rainbow Held Item", _0x7bed46);
          }
        },
        isTogglable: true,
        toolTip: "Auto-cycles rainbow on any held item in both hands. No input needed.",
      }),
      new ButtonInfo({
        buttonText: "Rainbow All Items",
        isTogglable: true,
        disableMethod: () => {
          hueVal = 0;
          satVal = 0;
          try {
            if (!cachedItems) {
              return;
            }
            for (let _0x1acd34 = 0; _0x1acd34 < cachedItems.length; _0x1acd34++) {
              const _0x50417b = cachedItems.get(_0x1acd34);
              if (!_0x50417b || _0x50417b.handle.isNull()) {
                continue;
              }
              try {
                _0x50417b.method("set_colorHue").invoke(0);
                _0x50417b.method("set_colorSaturation").invoke(0);
              } catch (_0x277977) {}
            }
          } catch (_0x4112cb) {}
        },
        method: () => {
          try {
            if (frameCount % 60 == 0 || !cachedItems) {
              cachedItems = UnityObjectClass.method("FindObjectsByType", 1)
                .inflate(AnimalGrabbableObjectClass)
                .invoke(0);
            }
            if (frameCount % 2 != 0) {
              return;
            }
            const _0x3b5064 = Math.round(((time * 1) % 1) * 254 - 127);
            if (cachedItems) {
              for (let _0x484680 = 0; _0x484680 < cachedItems.length; _0x484680++) {
                const _0x1bc251 = cachedItems.get(_0x484680);
                if (!_0x1bc251 || _0x1bc251.handle.isNull()) {
                  continue;
                }
                try {
                  _0x1bc251.method("set_colorHue").invoke(_0x3b5064);
                  _0x1bc251.method("set_colorSaturation").invoke(127);
                } catch (_0x1c8ac1) {}
              }
            }
          } catch (_0x3b02a3) {
            console.error("Rainbow All Items: " + _0x3b02a3);
          }
        },
        toolTip: "Auto-cycles all items through the full rainbow spectrum continuously.",
      }),
    ],
    [
      new ButtonInfo({
        buttonText: "Exit Spawning mods",
        method: () => {
          currentCategory = 0;
          currentPage = 0;
        },
        isTogglable: false,
        toolTip: "Returns you back to the main category.",
      }),
      new ButtonInfo({
        buttonText: "Spam Pokemon Cards",
        isTogglable: true,
        method: () => {
          if (!rightGrab) {
            return;
          }
          try {
            const _0x75a9c8 = rightHandTransform.method("get_position").invoke();
            const _0x884109 = rightHandTransform.method("get_rotation").invoke();
            _0xf8bff9("item_rare_card", _0x75a9c8, _0x884109);
          } catch (_0x1aabd6) {}
        },
        toolTip: "Toggle ON then hold grip to rain Pokemon cards from your hand.",
      }),
      new ButtonInfo({
        buttonText: "Spam Cameras",
        isTogglable: true,
        method: () => {
          if (!rightGrab) {
            return;
          }
          try {
            const _0x55c9f1 = rightHandTransform.method("get_position").invoke();
            const _0x312fbc = rightHandTransform.method("get_rotation").invoke();
            _0x5db48f("MetaCameraControls", _0x55c9f1, _0x312fbc);
          } catch (_0x294af3) {
            smartError("Spam Cameras", _0x294af3);
          }
        },
        toolTip: "Toggle ON + hold grip to spam MetaCameraControls prefabs from your hand.",
      }),
      new ButtonInfo({
        buttonText: "Spam Dynamites",
        isTogglable: true,
        method: () => {
          if (!rightGrab) {
            return;
          }
          try {
            const _0x475669 = rightHandTransform.method("get_position").invoke();
            const _0x4c24e1 = rightHandTransform.method("get_rotation").invoke();
            const _0x5c99ac = rightHandTransform.method("get_forward").invoke();
            const _0x5f13a1 = _0x5c99ac.field("x").value;
            const _0x1e60ae = _0x5c99ac.field("y").value;
            const _0x516bcc = _0x5c99ac.field("z").value;
            const _0xd53cb1 = _0xf8bff9("item_dynamite", _0x475669, _0x4c24e1);
            if (!_0xd53cb1 || _0xd53cb1.handle.isNull()) {
              return;
            }
            try {
              const _0x586476 = _0xd53cb1
                .method("GetComponent", 1)
                .inflate(AnimalGrabbableObjectClass)
                .invoke();
              if (_0x586476 && !_0x586476.isNull()) {
                const _0x4beb89 = Vector3Class.method("op_Multiply", 2).invoke(_0x5c99ac, 22);
                _0x586476.method("AddExternalForceVelocity", 1).invoke(_0x4beb89);
                return;
              }
            } catch (_0x35725c) {}
            try {
              let _0x59ac21 = null;
              try {
                _0x59ac21 = _0xd53cb1
                  .method("GetComponent", 1)
                  .inflate(UnityRigidbodyClass)
                  .invoke();
              } catch (_0x4c5362) {}
              if (!_0x59ac21 || _0x59ac21.isNull()) {
                _0x59ac21 = _0xd53cb1
                  .method("GetComponentInChildren", 1)
                  .inflate(UnityRigidbodyClass)
                  .invoke();
              }
              if (_0x59ac21 && !_0x59ac21.isNull()) {
                _0x59ac21.method("set_isKinematic").invoke(false);
                _0x59ac21.method("WakeUp").invoke();
                _0x59ac21
                  .method("set_linearVelocity")
                  .invoke([_0x5f13a1 * 22, _0x1e60ae * 22, _0x516bcc * 22]);
              }
            } catch (_0x5d5b3f) {}
          } catch (_0x5a7603) {}
        },
        toolTip: "Toggle ON then hold grip to launch dynamite from your hand.",
      }),
      new ButtonInfo({
        buttonText: "Spawn Arena Guns",
        isTogglable: true,
        method: () => {
          if (!rightGrab) {
            return;
          }
          try {
            const _0x16f7a5 = _0x2561c6();
            const _0x3ad4af = rightHandTransform.method("get_rotation").invoke();
            const _0x518c68 = rightHandTransform.method("get_forward").invoke();
            const _0x560e28 = _0x518c68.field("x").value;
            const _0x6c465c = _0x518c68.field("y").value;
            const _0x210926 = _0x518c68.field("z").value;
            const _0xb0c862 = _0xf8bff9("item_arena_pistol", _0x16f7a5, _0x3ad4af);
            if (_0xb0c862 && !_0xb0c862.handle.isNull()) {
              try {
                const _0x55ce65 = _0xb0c862
                  .method("GetComponent", 1)
                  .inflate(UnityRigidbodyClass)
                  .invoke();
                if (_0x55ce65 && !_0x55ce65.isNull()) {
                  _0x55ce65.method("set_isKinematic").invoke(false);
                  _0x55ce65.method("WakeUp").invoke();
                  _0x55ce65
                    .method("set_linearVelocity")
                    .invoke([_0x560e28 * 25, _0x6c465c * 25, _0x210926 * 25]);
                }
              } catch (_0x3cf510) {}
            }
          } catch (_0x5116e3) {
            smartError("Spawn Arena Guns", _0x5116e3);
          }
        },
        toolTip: "Hold grip to rain arena pistols out of your hand.",
      }),
      new ButtonInfo({
        buttonText: "Spam Cluster Grenade",
        isTogglable: true,
        method: () => {
          if (!rightGrab) {
            return;
          }
          try {
            const _0x1b8757 = _0x2561c6();
            const _0x5dcccc = rightHandTransform.method("get_rotation").invoke();
            const _0x509607 = rightHandTransform.method("get_forward").invoke();
            const _0x14ce1f = _0x509607.field("x").value;
            const _0x24360b = _0x509607.field("y").value;
            const _0x757382 = _0x509607.field("z").value;
            const _0x4b74a7 = _0xf8bff9("item_cluster_grenade", _0x1b8757, _0x5dcccc);
            if (_0x4b74a7 && !_0x4b74a7.handle.isNull()) {
              let _0x2306ca = null;
              try {
                _0x2306ca = _0x4b74a7
                  .method("GetComponent", 1)
                  .inflate(UnityRigidbodyClass)
                  .invoke();
              } catch (_0x3e1a5c) {}
              if (!_0x2306ca || _0x2306ca.isNull()) {
                try {
                  _0x2306ca = _0x4b74a7
                    .method("GetComponentInChildren", 1)
                    .inflate(UnityRigidbodyClass)
                    .invoke();
                } catch (_0x3faa5a) {}
              }
              if (_0x2306ca && !_0x2306ca.isNull()) {
                _0x2306ca.method("set_isKinematic").invoke(false);
                _0x2306ca.method("WakeUp").invoke();
                _0x2306ca
                  .method("set_linearVelocity")
                  .invoke([_0x14ce1f * 28, _0x24360b * 28, _0x757382 * 28]);
              }
            }
          } catch (_0x5f4663) {
            console.error("Spam Cluster Grenade: " + _0x5f4663);
          }
        },
        toolTip: "Hold grip to spam cluster grenades from your fist.",
      }),
      new ButtonInfo({
        buttonText: "Spam RPG Ammo",
        isTogglable: true,
        method: () => {
          if (!rightGrab) {
            return;
          }
          try {
            const _0x196e37 = rightHandTransform.method("get_position").invoke();
            const _0x27adfd = rightHandTransform.method("get_rotation").invoke();
            _0x5db48f("item_rpg_ammo", _0x196e37, _0x27adfd);
          } catch (_0x292da5) {
            smartError("Spam RPG Ammo", _0x292da5);
          }
        },
        toolTip: "Hold grip to spam RPG ammo pickups at your right hand. No cooldown.",
      }),
      new ButtonInfo({
        buttonText: "Spam Hell Ore",
        isTogglable: true,
        method: () => {
          if (!rightGrab) {
            return;
          }
          try {
            const _0x17588a = _0x2561c6();
            const _0x496383 = rightHandTransform.method("get_rotation").invoke();
            const _0x295395 = rightHandTransform.method("get_forward").invoke();
            const _0x168e99 = _0x295395.field("x").value;
            const _0x1ab086 = _0x295395.field("y").value;
            const _0x21f8f7 = _0x295395.field("z").value;
            const _0x1407ee = _0xf8bff9("item_ore_hell", _0x17588a, _0x496383);
            if (_0x1407ee && !_0x1407ee.handle.isNull()) {
              let _0x2ae617 = null;
              try {
                _0x2ae617 = _0x1407ee
                  .method("GetComponent", 1)
                  .inflate(UnityRigidbodyClass)
                  .invoke();
              } catch (_0x17b8ed) {}
              if (!_0x2ae617 || _0x2ae617.isNull()) {
                try {
                  _0x2ae617 = _0x1407ee
                    .method("GetComponentInChildren", 1)
                    .inflate(UnityRigidbodyClass)
                    .invoke();
                } catch (_0x5a4286) {}
              }
              if (_0x2ae617 && !_0x2ae617.isNull()) {
                _0x2ae617.method("set_isKinematic").invoke(false);
                _0x2ae617.method("WakeUp").invoke();
                _0x2ae617
                  .method("set_linearVelocity")
                  .invoke([_0x168e99 * 25, _0x1ab086 * 25, _0x21f8f7 * 25]);
              }
            }
          } catch (_0x532ec4) {
            console.error("Spam Hell Ore: " + _0x532ec4);
          }
        },
        toolTip: "Hold grip to spam hell ore from your fist.",
      }),
      new ButtonInfo({
        buttonText: "Goopfish Blind",
        isTogglable: true,
        method: () => {
          if (!rightGrab) {
            return;
          }
          try {
            const _0x832a9 = _0x2561c6();
            const _0xbf96ed = rightHandTransform.method("get_rotation").invoke();
            const _0x2fc393 = rightHandTransform.method("get_forward").invoke();
            const _0x141ec4 = _0x2fc393.field("x").value;
            const _0xfcea22 = _0x2fc393.field("y").value;
            const _0x2623fb = _0x2fc393.field("z").value;
            const _0x11f847 = _0xf8bff9("item_goopfish", _0x832a9, _0xbf96ed);
            if (_0x11f847 && !_0x11f847.handle.isNull()) {
              let _0x45f8c9 = null;
              try {
                _0x45f8c9 = _0x11f847
                  .method("GetComponent", 1)
                  .inflate(UnityRigidbodyClass)
                  .invoke();
              } catch (_0x33494f) {}
              if (!_0x45f8c9 || _0x45f8c9.isNull()) {
                try {
                  _0x45f8c9 = _0x11f847
                    .method("GetComponentInChildren", 1)
                    .inflate(UnityRigidbodyClass)
                    .invoke();
                } catch (_0x188568) {}
              }
              if (_0x45f8c9 && !_0x45f8c9.isNull()) {
                _0x45f8c9.method("set_isKinematic").invoke(false);
                _0x45f8c9.method("WakeUp").invoke();
                _0x45f8c9
                  .method("set_linearVelocity")
                  .invoke([_0x141ec4 * 25, _0xfcea22 * 25, _0x2623fb * 25]);
              }
            }
          } catch (_0x165de8) {
            smartError("Goopfish Blind", _0x165de8);
          }
        },
        toolTip: "Hold grip to spray goopfish forward — no cooldown. Blinds players on hit.",
      }),
      new ButtonInfo({
        buttonText: "Change Prefab",
        method: () => {
          if (rightGrab) {
            prefabIndex--;
          } else {
            prefabIndex++;
          }
          prefabIndex = ((prefabIndex % prefabIDs.length) + prefabIDs.length) % prefabIDs.length;
          notify("Prefab: " + prefabIDs[prefabIndex], false);
        },
        isTogglable: false,
        toolTip: "Next prefab (+). Use 'Prefab -' to go back.",
      }),
      new ButtonInfo({
        buttonText: "Prefab -",
        isTogglable: false,
        method: () => {
          prefabIndex =
            (((prefabIndex - 1) % prefabIDs.length) + prefabIDs.length) % prefabIDs.length;
          notify("Prefab: " + prefabIDs[prefabIndex], false);
        },
        toolTip: "Previous prefab (-).",
      }),
      new ButtonInfo({
        buttonText: "Spawn Prefab",
        method: () => {
          try {
            const _0x58d3cd = rightHandTransform.method("get_position").invoke();
            const _0x5608a3 = rightHandTransform.method("get_rotation").invoke();
            const _0x1657f9 = PrefabGeneratorClass.field("_instance")
              .value.method("get_runner")
              .invoke();
            if (!_0x1657f9 || _0x1657f9.isNull()) {
              console.error("runner null");
              return;
            }
            const _0x456b58 = _0x1657f9
              .field("_config")
              .value.field("PrefabTable")
              .value.field("_sources").value;
            const _0x38de42 = _0x456b58.method("get_Count").invoke();
            const _0x2dac9b = prefabIDs[prefabIndex];
            let _0x2ef57a = false;
            for (let _0x4033e9 = 0; _0x4033e9 < _0x38de42; _0x4033e9++) {
              try {
                const _0xee984f = _0x456b58.method("get_Item").invoke(_0x4033e9);
                const _0x289dcc = _0xee984f.method("get_Description").invoke().toString();
                if (_0x289dcc.includes(_0x2dac9b)) {
                  const _0x11e1a8 = _0xee984f.method("WaitForResult").invoke();
                  if (!_0x11e1a8 || _0x11e1a8.isNull()) {
                    console.error("prefab null");
                    return;
                  }
                  const _0x15d3ae = (_0xb2c498) => {
                    if (_0xb2c498.class.isEnum || _0xb2c498.isPrimitive) {
                      return 0;
                    }
                    if (!_0xb2c498.class.isValueType) {
                      return _0x366930;
                    }
                    const _0x57476d = _0xb2c498.class.fields.filter(
                      (_0x4233bc) => !_0x4233bc.isStatic,
                    );
                    if (_0x57476d.length === 0) {
                      return 0;
                    }
                    return _0x57476d.map((_0x5d2f67) => _0x15d3ae(_0x5d2f67.type));
                  };
                  const _0x3d58aa = (_0x3c8cc8, _0x358f6e, _0x21d6d5) => {
                    const _0x216e1a = _0x3c8cc8.class.fields.filter(
                      (_0x189a08) => !_0x189a08.isStatic,
                    );
                    return _0x216e1a.map((_0x3c0f8a) => {
                      const _0x1d6448 = _0x3c0f8a.name.toLowerCase();
                      if (_0x1d6448.includes("hasvalue")) {
                        if (_0x358f6e) {
                          return 1;
                        } else {
                          return 0;
                        }
                      }
                      if (_0x1d6448 === "value") {
                        if (_0x358f6e) {
                          return _0x21d6d5;
                        } else {
                          return _0x15d3ae(_0x3c0f8a.type);
                        }
                      }
                      return _0x15d3ae(_0x3c0f8a.type);
                    });
                  };
                  const _0x1f328f = (_0x1c3741, _0x46e19d) => {
                    if (typeof _0x46e19d === "boolean") {
                      if (_0x46e19d) {
                        return 1;
                      } else {
                        return 0;
                      }
                    }
                    if (_0x46e19d instanceof Il2Cpp.ValueType) {
                      const _0x413d21 = _0x1c3741.class.fields.filter(
                        (_0x2bcc33) => !_0x2bcc33.isStatic,
                      );
                      if (_0x413d21.length === 0) {
                        return 0;
                      }
                      return _0x413d21.map((_0x3d9cb3) =>
                        _0x1f328f(_0x3d9cb3.type, _0x3d9cb3.bind(_0x46e19d).value),
                      );
                    }
                    if (Array.isArray(_0x46e19d)) {
                      return _0x46e19d.map((_0x595e42) => _0x1f328f(_0x1c3741, _0x595e42));
                    }
                    return _0x46e19d;
                  };
                  const _0x26c60c = (_0x330020, _0x2685eb) => {
                    return _0x3d58aa(_0x330020, true, _0x1f328f(_0x2685eb.type, _0x2685eb));
                  };
                  let _0x5d3c81 = null;
                  for (const _0x4f4405 of _0x1657f9.method("Spawn").overloads()) {
                    if (_0x4f4405.parameterCount !== 6 || _0x4f4405.isGeneric) {
                      continue;
                    }
                    const _0x3e09e1 = _0x4f4405.parameters;
                    if (
                      _0x3e09e1[0].type.name.includes("Fusion.NetworkObject") &&
                      _0x3e09e1[1].type.name.startsWith("System.Nullable") &&
                      _0x3e09e1[1].type.name.includes("Vector3") &&
                      _0x3e09e1[2].type.name.startsWith("System.Nullable") &&
                      _0x3e09e1[2].type.name.includes("Quaternion") &&
                      _0x3e09e1[3].type.name.startsWith("System.Nullable") &&
                      _0x3e09e1[3].type.name.includes("PlayerRef") &&
                      _0x3e09e1[4].type.name.includes("OnBeforeSpawned") &&
                      _0x3e09e1[5].type.name.includes("NetworkSpawnFlags")
                    ) {
                      _0x5d3c81 = _0x4f4405;
                      break;
                    }
                  }
                  if (!_0x5d3c81) {
                    console.error("spawn method not found");
                    return;
                  }
                  const _0x5503f6 = _0x26c60c(_0x5d3c81.parameters[1].type, _0x58d3cd);
                  const _0x197b28 = _0x26c60c(_0x5d3c81.parameters[2].type, _0x5608a3);
                  const _0x178a30 = _0x3d58aa(
                    _0x5d3c81.parameters[3].type,
                    false,
                    _0x15d3ae(_0x5d3c81.parameters[3].type),
                  );
                  const _0x340ec5 = _0x5d3c81.parameters[4].type.class.isValueType
                    ? _0x15d3ae(_0x5d3c81.parameters[4].type)
                    : _0x366930;
                  _0x5d3c81
                    .bind(_0x1657f9)
                    .invoke(_0x11e1a8, _0x5503f6, _0x197b28, _0x178a30, _0x340ec5, 0);
                  notify("Spawned: " + _0x2dac9b, false);
                  _0x2ef57a = true;
                  break;
                }
              } catch (_0x220a3c) {}
            }
            if (!_0x2ef57a) {
              notify("Prefab not found: " + _0x2dac9b, false);
            }
          } catch (_0x17df42) {
            console.error("SpawnPrefab error: " + _0x17df42);
          }
        },
        isTogglable: false,
        toolTip: "Spawns selected prefab at right hand.",
      }),
      new ButtonInfo({
        buttonText: "Teleport All Prefabs",
        method: () => {
          try {
            const _0x48aa64 = NetPlayerClass.method("get_localPlayer").invoke();
            if (!_0x48aa64 || _0x48aa64.handle.isNull()) {
              return;
            }
            const _0x2cdcc5 = _0xe40610(_0x48aa64).method("get_position").invoke();
            let _0x380589 = 0;
            try {
              const _0x58f235 = GrabbableItemClass.method("get_allLootItems").invoke();
              if (_0x58f235 && !_0x58f235.isNull()) {
                const _0x2dd64d = _0x58f235.method("GetEnumerator").invoke();
                while (_0x2dd64d.method("MoveNext").invoke()) {
                  try {
                    const _0x89899e = _0x2dd64d.method("get_Current").invoke();
                    if (!_0x89899e || _0x89899e.isNull()) {
                      continue;
                    }
                    _0xe40610(_0x89899e).method("set_position").invoke(_0x2cdcc5);
                    _0x380589++;
                  } catch (_0x1d8f30) {}
                }
              }
            } catch (_0x4598df) {
              smartError("[TeleportAll]", _0x4598df);
            }
            try {
              const _0x3a2a65 = UnityObjectClass.method("FindObjectOfType", 0)
                .inflate(ItemSellingMachineControllerClass)
                .invoke();
              if (_0x3a2a65 && !_0x3a2a65.isNull()) {
                _0xe40610(_0x3a2a65).method("set_position").invoke(_0x2cdcc5);
              }
            } catch (_0x2d48d8) {}
            notify("Teleported " + _0x380589 + " items to you!", false);
          } catch (_0x46680a) {
            notify("Teleport all failed: " + _0x46680a, false);
          }
        },
        isTogglable: false,
        toolTip: "Teleports all loot items to your position.",
      }),
      new ButtonInfo({
        buttonText: "Spawn Items",
        method: () => {
          const _0x580a26 = rightHandTransform;
          if (rightGrab) {
            try {
              const _0x185080 = _0xf8bff9(
                itemIDs[itemIndex],
                _0x580a26.method("get_position").invoke(),
                _0x580a26.method("get_rotation").invoke(),
              );
              if (!_0x185080 || _0x185080.handle.isNull()) {
                notify("Spawn returned null: " + itemIDs[itemIndex], false);
              } else {
                notify("Spawned: " + itemIDs[itemIndex], false);
              }
            } catch (_0x47891a) {
              smartError("Hand spawn error:", _0x47891a);
              notify("Spawn failed: " + _0x47891a, false);
            }
          }
        },
        isTogglable: true,
        toolTip: "Spawns items in your right hand (hold grip).",
      }),
      new ButtonInfo({
        buttonText: "Change Mob",
        isTogglable: false,
        method: () => {
          if (rightGrab) {
            mobIndex--;
          } else {
            mobIndex++;
          }
          mobIndex = ((mobIndex % mobIDs.length) + mobIDs.length) % mobIDs.length;
          notify("Mob: " + mobIDs[mobIndex].name, false, 2);
        },
        toolTip: "Next mob (+). Use 'Mob -' to go back.",
      }),
      new ButtonInfo({
        buttonText: "Mob -",
        isTogglable: false,
        method: () => {
          mobIndex = (((mobIndex - 1) % mobIDs.length) + mobIDs.length) % mobIDs.length;
          notify("Mob: " + mobIDs[mobIndex].name, false, 2);
        },
        toolTip: "Previous mob (-).",
      }),
      new ButtonInfo({
        buttonText: "Mob Gun",
        isTogglable: true,
        disableMethod: () => {
          var _0x684e15;
          try {
            if (
              GunLibPointer &&
              !((_0x684e15 = GunLibPointer.isNull) === null || _0x684e15 === undefined
                ? undefined
                : _0x684e15.call(GunLibPointer))
            ) {
              GunLibPointer.method("SetActive").invoke(false);
            }
          } catch (_0x1df4f2) {}
          try {
            if (GunLibLine) {
              GunLibLine.method("get_gameObject").invoke().method("SetActive").invoke(false);
            }
          } catch (_0x3a43fd) {}
        },
        method: () => {
          var _0x4ff566;
          var _0x13e754;
          if (!rightGrab) {
            try {
              if (
                GunLibPointer &&
                !((_0x4ff566 = GunLibPointer.isNull) === null || _0x4ff566 === undefined
                  ? undefined
                  : _0x4ff566.call(GunLibPointer))
              ) {
                GunLibPointer.method("SetActive").invoke(false);
              }
            } catch (_0x4ee8be) {}
            try {
              if (GunLibLine) {
                GunLibLine.method("get_gameObject").invoke().method("SetActive").invoke(false);
              }
            } catch (_0x543235) {}
            return;
          }
          try {
            const _0x482ab6 = _0x577f7f();
            if (!_0x482ab6 || !rightTrigger) {
              return;
            }
            if (time <= _mobGunDelay) {
              return;
            }
            const { finalRay: _0x21b288 } = _0x482ab6;
            let _0x5af7fb = null;
            if (_0x21b288) {
              try {
                _0x5af7fb = _0x21b288.method("get_point").invoke();
              } catch (_0x14a030) {}
            }
            if (!_0x5af7fb) {
              const _0xac55f9 = rightHandTransform.method("get_position").invoke();
              const _0x21fa3c = rightHandTransform.method("get_forward").invoke();
              _0x5af7fb = [
                _0xac55f9.field("x").value + _0x21fa3c.field("x").value * 8,
                _0xac55f9.field("y").value + _0x21fa3c.field("y").value * 8,
                _0xac55f9.field("z").value + _0x21fa3c.field("z").value * 8,
              ];
            }
            _mobGunDelay = time + 0.3;
            const _0x15fbb9 = mobIDs[mobIndex].name;
            _0x16dc3e();
            const _0x5e0c80 = _0x5db48f(_0x15fbb9 + "Controller", _0x5af7fb, QuaternionIdentity);
            const _0x1d27c3 =
              _0x5e0c80 &&
              !((_0x13e754 = _0x5e0c80.isNull) === null || _0x13e754 === undefined
                ? undefined
                : _0x13e754.call(_0x5e0c80));
            if (!_0x1d27c3) {
              _0xdef527(_0x15fbb9, _0x5af7fb);
            }
            notify(_0x1d27c3 ? "Spawned: " + _0x15fbb9 : "Spawn failed: " + _0x15fbb9, false, 2);
          } catch (_0x350641) {
            smartError("Mob Gun", _0x350641);
          }
        },
        toolTip:
          "Hold grip to aim, pull trigger to spawn the selected mob at your crosshair. Use Change Mob to pick which mob.",
      }),
      new ButtonInfo({
        buttonText: "Spam Mobs",
        isTogglable: true,
        method: () => {
          var _0x5940f9;
          if (!rightGrab) {
            return;
          }
          try {
            const _0xcc3dac = rightHandTransform.method("get_position").invoke();
            const _0x1ff6c3 = rightHandTransform.method("get_rotation").invoke();
            _0x16dc3e();
            const _0x5407da = mobIDs[mobIndex].name;
            const _0x268893 = _0x5db48f(_0x5407da + "Controller", _0xcc3dac, _0x1ff6c3);
            if (
              !_0x268893 ||
              ((_0x5940f9 = _0x268893.isNull) === null || _0x5940f9 === undefined
                ? undefined
                : _0x5940f9.call(_0x268893))
            ) {
              _0xdef527(_0x5407da, _0xcc3dac, _0x1ff6c3);
            }
          } catch (_0x499c57) {
            smartError("Spam Mobs", _0x499c57);
          }
        },
        toolTip: "Toggle ON + hold right grip to repeatedly spawn the selected mob at your hand.",
      }),
      new ButtonInfo({
        buttonText: "Prefab Gun",
        isTogglable: true,
        disableMethod: () => {
          var _0x471f6a;
          try {
            if (
              GunLibPointer &&
              !((_0x471f6a = GunLibPointer.isNull) === null || _0x471f6a === undefined
                ? undefined
                : _0x471f6a.call(GunLibPointer))
            ) {
              GunLibPointer.method("SetActive").invoke(false);
            }
          } catch (_0x148841) {}
          try {
            if (GunLibLine) {
              GunLibLine.method("get_gameObject").invoke().method("SetActive").invoke(false);
            }
          } catch (_0x194ca0) {}
        },
        method: () => {
          var _0x4a8a1a;
          if (!rightGrab) {
            try {
              if (
                GunLibPointer &&
                !((_0x4a8a1a = GunLibPointer.isNull) === null || _0x4a8a1a === undefined
                  ? undefined
                  : _0x4a8a1a.call(GunLibPointer))
              ) {
                GunLibPointer.method("SetActive").invoke(false);
              }
            } catch (_0x4e2548) {}
            try {
              if (GunLibLine) {
                GunLibLine.method("get_gameObject").invoke().method("SetActive").invoke(false);
              }
            } catch (_0x57c212) {}
            return;
          }
          try {
            const _0x429a66 = _0x577f7f();
            if (!_0x429a66) {
              return;
            }
            const { finalRay: _0x4a5aeb } = _0x429a66;
            if (!rightTrigger) {
              return;
            }
            if (time <= _prefabGunDelay) {
              return;
            }
            _prefabGunDelay = time + 0.05;
            let _0x5e15d6;
            if (_0x4a5aeb) {
              try {
                _0x5e15d6 = _0x4a5aeb.method("get_point").invoke();
              } catch (_0x35cb9a) {}
            }
            if (!_0x5e15d6) {
              const _0x546110 = rightHandTransform.method("get_position").invoke();
              const _0x2e243c = rightHandTransform.method("get_forward").invoke();
              const _0x5e9f8f = _0x546110.field("x").value;
              const _0x7a4dbf = _0x546110.field("y").value;
              const _0x5befe3 = _0x546110.field("z").value;
              const _0x4ec83f = _0x2e243c.field("x").value;
              const _0x449cd4 = _0x2e243c.field("y").value;
              const _0x5942ae = _0x2e243c.field("z").value;
              _0x5e15d6 = [
                _0x5e9f8f + _0x4ec83f * 8,
                _0x7a4dbf + _0x449cd4 * 8,
                _0x5befe3 + _0x5942ae * 8,
              ];
            }
            const _0x599ac8 = prefabIDs[prefabIndex];
            let _0x257395 = null;
            try {
              _0x257395 = _0x5db48f(_0x599ac8, _0x5e15d6, QuaternionIdentity);
            } catch (_0xbceb55) {}
            if (!_0x257395 || _0x257395.isNull()) {
              try {
                _0x257395 = _0xf8bff9(_0x599ac8, _0x5e15d6, QuaternionIdentity);
              } catch (_0x3a822d) {}
            }
            if (_0x257395 && !_0x257395.isNull()) {
              notify("Spawned: " + _0x599ac8, false, 2);
            } else {
              notify("Not found: " + _0x599ac8, false, 2);
            }
          } catch (_0xcee2ef) {
            smartError("Prefab Gun", _0xcee2ef);
          }
        },
        toolTip:
          "Hold grip to show the beam, pull trigger to spawn the selected prefab where you aim. No player lock-on — works on walls, floor, anywhere. Use Change Prefab to pick what to spawn.",
      }),
      new ButtonInfo({
        buttonText: "Delete Prefab Gun",
        isTogglable: true,
        disableMethod: () => {
          var _0x191d68;
          try {
            if (
              GunLibPointer &&
              !((_0x191d68 = GunLibPointer.isNull) === null || _0x191d68 === undefined
                ? undefined
                : _0x191d68.call(GunLibPointer))
            ) {
              GunLibPointer.method("SetActive").invoke(false);
            }
          } catch (_0x12d6d6) {}
          try {
            if (GunLibLine) {
              GunLibLine.method("get_gameObject").invoke().method("SetActive").invoke(false);
            }
          } catch (_0x5c99f9) {}
        },
        method: () => {
          var _0x144ced;
          if (!rightGrab) {
            try {
              if (
                GunLibPointer &&
                !((_0x144ced = GunLibPointer.isNull) === null || _0x144ced === undefined
                  ? undefined
                  : _0x144ced.call(GunLibPointer))
              ) {
                GunLibPointer.method("SetActive").invoke(false);
              }
            } catch (_0x331932) {}
            try {
              if (GunLibLine) {
                GunLibLine.method("get_gameObject").invoke().method("SetActive").invoke(false);
              }
            } catch (_0x5a960b) {}
            return;
          }
          try {
            const _0x304d97 = _0x577f7f();
            if (!_0x304d97 || !rightTrigger) {
              return;
            }
            const { finalRay: _0x34db6d } = _0x304d97;
            if (!_0x34db6d) {
              return;
            }
            const _0x5da746 = _0x34db6d.method("get_collider").invoke();
            if (!_0x5da746 || _0x5da746.isNull()) {
              return;
            }
            const _0x17813f = _0x5da746.method("get_gameObject").invoke();
            if (!_0x17813f || _0x17813f.isNull()) {
              return;
            }
            try {
              const _0x32b7ac = _0x17813f
                .method("GetComponentInParent", 0)
                .inflate(NetPlayerClass)
                .invoke();
              if (_0x32b7ac && !_0x32b7ac.isNull()) {
                return;
              }
            } catch (_0x4dd3b5) {}
            const _0x227fa3 = Il2Cpp.domain
              .assembly("Fusion.Runtime")
              .image.class("Fusion.NetworkObject");
            let _0x5822e6 = null;
            try {
              _0x5822e6 = _0x17813f.method("GetComponent", 1).inflate(_0x227fa3).invoke();
            } catch (_0x24824e) {}
            if (!_0x5822e6 || _0x5822e6.isNull()) {
              try {
                _0x5822e6 = _0x17813f.method("GetComponentInParent", 1).inflate(_0x227fa3).invoke();
              } catch (_0x59075d) {}
            }
            if (!_0x5822e6 || _0x5822e6.isNull()) {
              return;
            }
            let _0xfedafb = "prefab";
            try {
              _0xfedafb = _0x17813f.method("get_name").invoke()?.content ?? "prefab";
            } catch (_0x3e46aa) {}
            const _0x3ab253 = PrefabGeneratorClass.field("_instance")
              .value.method("get_runner")
              .invoke();
            if (!_0x3ab253 || _0x3ab253.isNull()) {
              return;
            }
            try {
              _0x5822e6.method("RequestStateAuthority").invoke();
            } catch (_0x40e2de) {}
            _0x3ab253.method("Despawn").invoke(_0x5822e6);
            notify("Deleted: " + _0xfedafb, false, 2);
          } catch (_0x24499e) {
            smartError("Delete Prefab Gun", _0x24499e);
          }
        },
        toolTip:
          "Hold grip to aim, pull trigger to delete whatever network object you're pointing at. Skips players.",
      }),
    ],
    [
      new ButtonInfo({
        buttonText: "Exit Gun Mods",
        method: () => {
          currentCategory = 0;
          currentPage = 0;
        },
        isTogglable: false,
        toolTip: "Returns you back to the main category.",
      }),
      new ButtonInfo({
        buttonText: "Stinky Gun",
        isTogglable: true,
        disableMethod: () => {
          var _0x3ad37d;
          try {
            if (
              GunLibPointer &&
              !((_0x3ad37d = GunLibPointer.isNull) === null || _0x3ad37d === undefined
                ? undefined
                : _0x3ad37d.call(GunLibPointer))
            ) {
              GunLibPointer.method("SetActive").invoke(false);
            }
          } catch (_0x81455f) {}
          try {
            if (GunLibLine) {
              GunLibLine.method("get_gameObject").invoke().method("SetActive").invoke(false);
            }
          } catch (_0x5c4dbb) {}
          _0x5bc894 = false;
          _0x4b51b9 = null;
        },
        method: () => {
          var _0x213153;
          if (!rightGrab) {
            try {
              if (
                GunLibPointer &&
                !((_0x213153 = GunLibPointer.isNull) === null || _0x213153 === undefined
                  ? undefined
                  : _0x213153.call(GunLibPointer))
              ) {
                GunLibPointer.method("SetActive").invoke(false);
              }
            } catch (_0x36335c) {}
            try {
              if (GunLibLine) {
                GunLibLine.method("get_gameObject").invoke().method("SetActive").invoke(false);
              }
            } catch (_0x17318e) {}
            _0x5bc894 = false;
            _0x4b51b9 = null;
            return;
          }
          try {
            const _0x38da25 = _0x43eae3();
            if (!_0x38da25) {
              return;
            }
            const { targetPlayer: _0x92edaf } = _0x38da25;
            if (rightTrigger && _0x92edaf && !_0x92edaf.isNull() && time > _gunLibDelay) {
              _gunLibDelay = time + 0.05;
              _0x92edaf.method("RPC_TagAsStinky").invoke();
              notify("Stinkied!", false, 1);
            }
          } catch (_0x5e97de) {
            smartError("Stinky Gun", _0x5e97de);
          }
        },
        toolTip: "Point at a player and pull trigger to tag them as stinky.",
      }),
      new ButtonInfo({
        buttonText: "Trap Gun",
        isTogglable: true,
        disableMethod: () => {
          var _0x2b04f5;
          try {
            if (
              GunLibPointer &&
              !((_0x2b04f5 = GunLibPointer.isNull) === null || _0x2b04f5 === undefined
                ? undefined
                : _0x2b04f5.call(GunLibPointer))
            ) {
              GunLibPointer.method("SetActive").invoke(false);
            }
          } catch (_0x572ffa) {}
          try {
            if (GunLibLine) {
              GunLibLine.method("get_gameObject").invoke().method("SetActive").invoke(false);
            }
          } catch (_0x3ef42e) {}
          _0x5bc894 = false;
          _0x4b51b9 = null;
        },
        method: () => {
          var _0x491a19;
          if (!rightGrab) {
            try {
              if (
                GunLibPointer &&
                !((_0x491a19 = GunLibPointer.isNull) === null || _0x491a19 === undefined
                  ? undefined
                  : _0x491a19.call(GunLibPointer))
              ) {
                GunLibPointer.method("SetActive").invoke(false);
              }
            } catch (_0x4c35e4) {}
            try {
              if (GunLibLine) {
                GunLibLine.method("get_gameObject").invoke().method("SetActive").invoke(false);
              }
            } catch (_0x12d284) {}
            _0x5bc894 = false;
            _0x4b51b9 = null;
            return;
          }
          try {
            const _0x53d8df = _0x43eae3();
            if (!_0x53d8df) {
              return;
            }
            const { targetPlayer: _0x5143e7 } = _0x53d8df;
            if (rightTrigger && _0x5143e7 && !_0x5143e7.isNull() && time > _gunLibDelay) {
              _gunLibDelay = time + 1;
              const _0x5421a7 = _0xe40610(_0x5143e7);
              const _0x528a00 = _0x5421a7.method("get_position").invoke();
              const _0x44aacf = _0x528a00.field("x").value;
              const _0x1cdd05 = _0x528a00.field("y").value;
              const _0x46771a = _0x528a00.field("z").value;
              const _0x5459af = 8;
              const _0x17a8e6 = 2.7;
              const _0xa356f6 = [];
              for (let _0x5bf8b6 = 0; _0x5bf8b6 < _0x5459af; _0x5bf8b6++) {
                const _0x50b96d = ((Math.PI * 2) / _0x5459af) * _0x5bf8b6;
                _0xa356f6.push([
                  Math.cos(_0x50b96d) * _0x17a8e6,
                  0,
                  Math.sin(_0x50b96d) * _0x17a8e6,
                ]);
              }
              _0xa356f6.push([0, 1.5, 0]);
              _0xa356f6.push([0.6, 2, 0.6]);
              _0xa356f6.push([-0.6, 2, -0.6]);
              _0xa356f6.push([0, 2.5, 0]);
              let _0x5be78d = 0;
              for (const _0x5b90c6 of _0xa356f6) {
                const _0x4e7762 = [
                  _0x44aacf + _0x5b90c6[0],
                  _0x1cdd05 + _0x5b90c6[1],
                  _0x46771a + _0x5b90c6[2],
                ];
                try {
                  const _0x4a56ac = _0x5db48f(
                    "ItemSellingMachineController",
                    _0x4e7762,
                    QuaternionIdentity,
                  );
                  if (_0x4a56ac && !_0x4a56ac.handle.isNull()) {
                    try {
                      _0x4a56ac.method("RequestStateAuthority").invoke();
                    } catch (_0x319baf) {}
                    _0x5be78d++;
                  }
                } catch (_0x1afc5b) {}
              }
              notify("Trapped with " + _0x5be78d + " machines!", false, 2);
            }
          } catch (_0x4147dc) {
            smartError("Trap Gun", _0x4147dc);
          }
        },
        toolTip:
          "Lock on to a player and pull trigger to surround them with 8 machines in a ring + 4 overhead.",
      }),
      new ButtonInfo({
        buttonText: "Jelly Gun",
        isTogglable: true,
        disableMethod: () => {
          var _0x12ede1;
          try {
            if (
              GunLibPointer &&
              !((_0x12ede1 = GunLibPointer.isNull) === null || _0x12ede1 === undefined
                ? undefined
                : _0x12ede1.call(GunLibPointer))
            ) {
              GunLibPointer.method("SetActive").invoke(false);
            }
          } catch (_0x1db243) {}
          try {
            if (GunLibLine) {
              GunLibLine.method("get_gameObject").invoke().method("SetActive").invoke(false);
            }
          } catch (_0x215815) {}
          _0x5bc894 = false;
          _0x4b51b9 = null;
        },
        method: () => {
          var _0x3f6cfe;
          if (!rightGrab) {
            try {
              if (
                GunLibPointer &&
                !((_0x3f6cfe = GunLibPointer.isNull) === null || _0x3f6cfe === undefined
                  ? undefined
                  : _0x3f6cfe.call(GunLibPointer))
              ) {
                GunLibPointer.method("SetActive").invoke(false);
              }
            } catch (_0x440c44) {}
            try {
              if (GunLibLine) {
                GunLibLine.method("get_gameObject").invoke().method("SetActive").invoke(false);
              }
            } catch (_0x2eb217) {}
            return;
          }
          try {
            const _0xb71460 = _0x43eae3();
            if (!_0xb71460) {
              return;
            }
            const { targetPlayer: _0x57fbe0 } = _0xb71460;
            if (rightTrigger && _0x57fbe0 && !_0x57fbe0.isNull() && time > _gunLibDelay) {
              _gunLibDelay = time + 1;
              if (_0x16fc51(_0x57fbe0)) {
                _0x18a723(() => _0x57fbe0.method("RPC_SetJellyEffect").invoke(9999, 10));
              } else {
                _0x57fbe0.method("RPC_SetJellyEffect").invoke(9999, 10);
              }
              notify("Jellified!", false, 1);
            }
          } catch (_0x1d6f12) {
            smartError("Jelly Gun", _0x1d6f12);
          }
        },
        toolTip:
          "Point at a player and pull trigger to turn them into jelly. Purple beam — bright when locked on a player.",
      }),
      new ButtonInfo({
        buttonText: "Unjelly Gun",
        isTogglable: true,
        disableMethod: () => {
          var _0x1b1d5d;
          try {
            if (
              GunLibPointer &&
              !((_0x1b1d5d = GunLibPointer.isNull) === null || _0x1b1d5d === undefined
                ? undefined
                : _0x1b1d5d.call(GunLibPointer))
            ) {
              GunLibPointer.method("SetActive").invoke(false);
            }
          } catch (_0x495de3) {}
          try {
            if (GunLibLine) {
              GunLibLine.method("get_gameObject").invoke().method("SetActive").invoke(false);
            }
          } catch (_0x12a3bf) {}
          _0x5bc894 = false;
          _0x4b51b9 = null;
        },
        method: () => {
          var _0x68dde9;
          if (!rightGrab) {
            try {
              if (
                GunLibPointer &&
                !((_0x68dde9 = GunLibPointer.isNull) === null || _0x68dde9 === undefined
                  ? undefined
                  : _0x68dde9.call(GunLibPointer))
              ) {
                GunLibPointer.method("SetActive").invoke(false);
              }
            } catch (_0x56c36d) {}
            try {
              if (GunLibLine) {
                GunLibLine.method("get_gameObject").invoke().method("SetActive").invoke(false);
              }
            } catch (_0x4c48d8) {}
            _0x5bc894 = false;
            _0x4b51b9 = null;
            return;
          }
          try {
            const _0x1b281c = _0x43eae3();
            if (!_0x1b281c) {
              return;
            }
            const { targetPlayer: _0x119254 } = _0x1b281c;
            if (rightTrigger && _0x119254 && !_0x119254.isNull() && time > _gunLibDelay) {
              _gunLibDelay = time + 0.5;
              _0x119254.method("RPC_SetJellyEffect").invoke(0, 0);
              notify("Unjellified!", false, 1);
            }
          } catch (_0x19f42b) {
            smartError("Unjelly Gun", _0x19f42b);
          }
        },
        toolTip: "Point at a player and pull trigger to remove their jelly effect.",
      }),
      new ButtonInfo({
        buttonText: "Kill Gun",
        isTogglable: true,
        disableMethod: () => {
          var _0x34c82d;
          try {
            if (
              GunLibPointer &&
              !((_0x34c82d = GunLibPointer.isNull) === null || _0x34c82d === undefined
                ? undefined
                : _0x34c82d.call(GunLibPointer))
            ) {
              GunLibPointer.method("SetActive").invoke(false);
            }
          } catch (_0x49efa3) {}
          try {
            if (GunLibLine) {
              GunLibLine.method("get_gameObject").invoke().method("SetActive").invoke(false);
            }
          } catch (_0x4eac91) {}
          _0x5bc894 = false;
          _0x4b51b9 = null;
        },
        method: () => {
          var _0xc409dc;
          if (!rightGrab) {
            try {
              if (
                GunLibPointer &&
                !((_0xc409dc = GunLibPointer.isNull) === null || _0xc409dc === undefined
                  ? undefined
                  : _0xc409dc.call(GunLibPointer))
              ) {
                GunLibPointer.method("SetActive").invoke(false);
              }
            } catch (_0x4e9f86) {}
            try {
              if (GunLibLine) {
                GunLibLine.method("get_gameObject").invoke().method("SetActive").invoke(false);
              }
            } catch (_0x4ae295) {}
            _0x5bc894 = false;
            _0x4b51b9 = null;
            return;
          }
          try {
            const _0x3b1dd8 = _0x43eae3();
            if (!_0x3b1dd8) {
              return;
            }
            const { targetPlayer: _0x4ceadb } = _0x3b1dd8;
            if (rightTrigger && _0x4ceadb && !_0x4ceadb.isNull() && time > _gunLibDelay) {
              _gunLibDelay = time + 0.5;
              try {
                const _0x483fe4 = DamageSourceInfoClass.method("get_Null").invoke();
                const _0x284b50 = _0xe40610(_0x4ceadb).method("get_position").invoke();
                _0x4ceadb
                  .method("RPC_PlayerHit", 5)
                  .invoke(9999, _0x284b50, Vector3Zero, _0x483fe4, false);
              } catch (_0x3a0ed9) {}
              notify("Killed!", false, 1);
            }
          } catch (_0x3b1126) {
            smartError("Kill Gun", _0x3b1126);
          }
        },
        toolTip: "Point at a player and pull trigger to kill them.",
      }),
      new ButtonInfo({
        buttonText: "Fling Gun",
        isTogglable: true,
        disableMethod: () => {
          var _0x411586;
          try {
            if (
              GunLibPointer &&
              !((_0x411586 = GunLibPointer.isNull) === null || _0x411586 === undefined
                ? undefined
                : _0x411586.call(GunLibPointer))
            ) {
              GunLibPointer.method("SetActive").invoke(false);
            }
          } catch (_0x59fb83) {}
          try {
            if (GunLibLine) {
              GunLibLine.method("get_gameObject").invoke().method("SetActive").invoke(false);
            }
          } catch (_0x3dcf58) {}
          _0x5bc894 = false;
          _0x4b51b9 = null;
        },
        method: () => {
          var _0x4934e8;
          if (!rightGrab) {
            try {
              if (
                GunLibPointer &&
                !((_0x4934e8 = GunLibPointer.isNull) === null || _0x4934e8 === undefined
                  ? undefined
                  : _0x4934e8.call(GunLibPointer))
              ) {
                GunLibPointer.method("SetActive").invoke(false);
              }
            } catch (_0x42e38f) {}
            try {
              if (GunLibLine) {
                GunLibLine.method("get_gameObject").invoke().method("SetActive").invoke(false);
              }
            } catch (_0x2c889d) {}
            _0x5bc894 = false;
            _0x4b51b9 = null;
            return;
          }
          try {
            const _0x3a1a2f = _0x43eae3();
            if (!_0x3a1a2f) {
              return;
            }
            const { targetPlayer: _0x5b2f2a } = _0x3a1a2f;
            if (rightTrigger && _0x5b2f2a && !_0x5b2f2a.isNull() && time > _gunLibDelay) {
              _gunLibDelay = time + 0.3;
              _0x5b2f2a.method("RPC_AddForce").invoke([0, 1500, 0]);
              notify("Flung!", false, 1);
            }
          } catch (_0x3c2bf3) {
            smartError("Fling Gun", _0x3c2bf3);
          }
        },
        toolTip: "Point at a player and pull trigger to fling them into the air.",
      }),
      new ButtonInfo({
        buttonText: "Give 1M Gun",
        isTogglable: true,
        disableMethod: () => {
          var _0x1663a1;
          try {
            if (
              GunLibPointer &&
              !((_0x1663a1 = GunLibPointer.isNull) === null || _0x1663a1 === undefined
                ? undefined
                : _0x1663a1.call(GunLibPointer))
            ) {
              GunLibPointer.method("SetActive").invoke(false);
            }
          } catch (_0x488f54) {}
          try {
            if (GunLibLine) {
              GunLibLine.method("get_gameObject").invoke().method("SetActive").invoke(false);
            }
          } catch (_0x43d532) {}
          _0x5bc894 = false;
          _0x4b51b9 = null;
        },
        method: () => {
          var _0x445a2e;
          if (!rightGrab) {
            try {
              if (
                GunLibPointer &&
                !((_0x445a2e = GunLibPointer.isNull) === null || _0x445a2e === undefined
                  ? undefined
                  : _0x445a2e.call(GunLibPointer))
              ) {
                GunLibPointer.method("SetActive").invoke(false);
              }
            } catch (_0x429540) {}
            try {
              if (GunLibLine) {
                GunLibLine.method("get_gameObject").invoke().method("SetActive").invoke(false);
              }
            } catch (_0x217984) {}
            _0x5bc894 = false;
            _0x4b51b9 = null;
            return;
          }
          try {
            const _0xdeab69 = _0x43eae3();
            if (!_0xdeab69) {
              return;
            }
            const { targetPlayer: _0x2e4e1a } = _0xdeab69;
            if (rightTrigger && _0x2e4e1a && !_0x2e4e1a.isNull() && time > _gunLibDelay) {
              _gunLibDelay = time + 0.2;
              _0x2e4e1a.method("RPC_AddPlayerMoney").invoke(1000000);
              notify("Gave 1,000,000!", false, 1);
            }
          } catch (_0x3a19b9) {
            smartError("Give 1M Gun", _0x3a19b9);
          }
        },
        toolTip: "Point at a player and pull trigger to give them 1,000,000 money.",
      }),
      new ButtonInfo({
        buttonText: "Shake Screen Gun",
        isTogglable: true,
        disableMethod: () => {
          var _0x2dda55;
          try {
            if (
              GunLibPointer &&
              !((_0x2dda55 = GunLibPointer.isNull) === null || _0x2dda55 === undefined
                ? undefined
                : _0x2dda55.call(GunLibPointer))
            ) {
              GunLibPointer.method("SetActive").invoke(false);
            }
          } catch (_0x21c2b0) {}
          try {
            if (GunLibLine) {
              GunLibLine.method("get_gameObject").invoke().method("SetActive").invoke(false);
            }
          } catch (_0xbd5ced) {}
          _0x5bc894 = false;
          _0x4b51b9 = null;
        },
        method: () => {
          var _0x5da7ae;
          if (!rightGrab) {
            try {
              if (
                GunLibPointer &&
                !((_0x5da7ae = GunLibPointer.isNull) === null || _0x5da7ae === undefined
                  ? undefined
                  : _0x5da7ae.call(GunLibPointer))
              ) {
                GunLibPointer.method("SetActive").invoke(false);
              }
            } catch (_0x1d23f2) {}
            try {
              if (GunLibLine) {
                GunLibLine.method("get_gameObject").invoke().method("SetActive").invoke(false);
              }
            } catch (_0xd7ba80) {}
            _0x5bc894 = false;
            _0x4b51b9 = null;
            return;
          }
          try {
            const _0x3f73d3 = _0x43eae3();
            if (!_0x3f73d3) {
              return;
            }
            const { targetPlayer: _0x1a8dd3 } = _0x3f73d3;
            if (rightTrigger && _0x1a8dd3 && !_0x1a8dd3.isNull() && time > _gunLibDelay) {
              _gunLibDelay = time + 0.5;
              _0x1a8dd3.method("RPC_ShakeScreen").invoke(8, 0.2, 1, 20, 15);
              notify("Earthquake!", false, 1);
            }
          } catch (_0x2a5216) {
            smartError("Shake Screen Gun", _0x2a5216);
          }
        },
        toolTip:
          "Point at a player and pull trigger to give them a massive earthquake screen shake.",
      }),
      new ButtonInfo({
        buttonText: "TP To Void Gun",
        isTogglable: true,
        disableMethod: () => {
          var _0x251da1;
          try {
            if (
              GunLibPointer &&
              !((_0x251da1 = GunLibPointer.isNull) === null || _0x251da1 === undefined
                ? undefined
                : _0x251da1.call(GunLibPointer))
            ) {
              GunLibPointer.method("SetActive").invoke(false);
            }
          } catch (_0x4c971a) {}
          try {
            if (GunLibLine) {
              GunLibLine.method("get_gameObject").invoke().method("SetActive").invoke(false);
            }
          } catch (_0x309141) {}
          _0x5bc894 = false;
          _0x4b51b9 = null;
        },
        method: () => {
          var _0x253919;
          if (!rightGrab) {
            try {
              if (
                GunLibPointer &&
                !((_0x253919 = GunLibPointer.isNull) === null || _0x253919 === undefined
                  ? undefined
                  : _0x253919.call(GunLibPointer))
              ) {
                GunLibPointer.method("SetActive").invoke(false);
              }
            } catch (_0x58decf) {}
            try {
              if (GunLibLine) {
                GunLibLine.method("get_gameObject").invoke().method("SetActive").invoke(false);
              }
            } catch (_0x964a86) {}
            _0x5bc894 = false;
            _0x4b51b9 = null;
            return;
          }
          try {
            const _0x216898 = _0x43eae3();
            if (!_0x216898) {
              return;
            }
            const { targetPlayer: _0x20a6bc } = _0x216898;
            if (rightTrigger && _0x20a6bc && !_0x20a6bc.isNull() && time > _gunLibDelay) {
              _gunLibDelay = time + 0.5;
              _0x20a6bc.method("RPC_Teleport").invoke([-9999999, -9999999, -9999999]);
              notify("Sent to void!", false, 1);
            }
          } catch (_0x2215bd) {
            smartError("TP To Void Gun", _0x2215bd);
          }
        },
        toolTip: "Point at a player and pull trigger to teleport them to 99999, 99999, 99999.",
      }),
      new ButtonInfo({
        buttonText: "Drop Items Gun",
        isTogglable: true,
        disableMethod: () => {
          var _0x466005;
          try {
            if (
              GunLibPointer &&
              !((_0x466005 = GunLibPointer.isNull) === null || _0x466005 === undefined
                ? undefined
                : _0x466005.call(GunLibPointer))
            ) {
              GunLibPointer.method("SetActive").invoke(false);
            }
          } catch (_0x5aa769) {}
          try {
            if (GunLibLine) {
              GunLibLine.method("get_gameObject").invoke().method("SetActive").invoke(false);
            }
          } catch (_0x1b6410) {}
          _0x5bc894 = false;
          _0x4b51b9 = null;
        },
        method: () => {
          var _0x32e9b5;
          if (!rightGrab) {
            try {
              if (
                GunLibPointer &&
                !((_0x32e9b5 = GunLibPointer.isNull) === null || _0x32e9b5 === undefined
                  ? undefined
                  : _0x32e9b5.call(GunLibPointer))
              ) {
                GunLibPointer.method("SetActive").invoke(false);
              }
            } catch (_0x221c4d) {}
            try {
              if (GunLibLine) {
                GunLibLine.method("get_gameObject").invoke().method("SetActive").invoke(false);
              }
            } catch (_0x3900f5) {}
            _0x5bc894 = false;
            _0x4b51b9 = null;
            return;
          }
          try {
            const _0x25618d = _0x43eae3();
            if (!_0x25618d) {
              return;
            }
            const { targetPlayer: _0x26d1f5 } = _0x25618d;
            if (rightTrigger && _0x26d1f5 && !_0x26d1f5.isNull() && time > _gunLibDelay) {
              _gunLibDelay = time + 0.5;
              try {
                const _0x229120 = PrefabGeneratorClass.field("_instance").value;
                const _0x16b9cc =
                  _0x229120 && !_0x229120.isNull() ? _0x229120.method("get_runner").invoke() : null;
                const _0x3391be = (_0x3d6692) => {
                  if (!_0x3d6692 || _0x3d6692.isNull()) {
                    return;
                  }
                  try {
                    const _0x6c6a5a = _0x3d6692.method("get_grabbableObject").invoke();
                    if (!_0x6c6a5a || _0x6c6a5a.isNull()) {
                      return;
                    }
                    try {
                      const _0x362355 = _0x6c6a5a.method("get_Object").invoke();
                      if (_0x362355 && !_0x362355.isNull()) {
                        _0x362355.method("RequestStateAuthority").invoke();
                      }
                    } catch (_0x4098a0) {}
                    try {
                      _0x3d6692.method("RPC_DropObject").invoke();
                    } catch (_0x8a90bc) {}
                    try {
                      _0x6c6a5a.method("RPC_Release").invoke();
                    } catch (_0x370935) {}
                  } catch (_0x91a92) {}
                };
                try {
                  const _0x16a503 = _0x26d1f5.method("get_anchors").invoke();
                  if (_0x16a503 && !_0x16a503.isNull()) {
                    for (let _0x27ff6c = 0; _0x27ff6c < _0x16a503.length; _0x27ff6c++) {
                      try {
                        _0x3391be(_0x16a503.get(_0x27ff6c));
                      } catch (_0x54392c) {}
                    }
                  }
                } catch (_0x20dffe) {}
                for (const _0x3409c9 of [
                  "get_backItemAttachAnchor",
                  "get_leftHipItemAttachAnchor",
                  "get_rightHipItemAttachAnchor",
                ]) {
                  try {
                    _0x3391be(_0x26d1f5.method(_0x3409c9).invoke());
                  } catch (_0x1fb647) {}
                }
                notify("Dropped their items!", false, 1);
              } catch (_0x2098ff) {}
            }
          } catch (_0x619232) {
            smartError("Drop Items Gun", _0x619232);
          }
        },
        toolTip:
          "Point at a player and pull trigger to force-drop all their held and holstered items.",
      }),
      new ButtonInfo({
        buttonText: "Blind Person Gun",
        isTogglable: true,
        disableMethod: () => {
          var _0x59538f;
          try {
            if (
              GunLibPointer &&
              !((_0x59538f = GunLibPointer.isNull) === null || _0x59538f === undefined
                ? undefined
                : _0x59538f.call(GunLibPointer))
            ) {
              GunLibPointer.method("SetActive").invoke(false);
            }
          } catch (_0x2cf782) {}
          try {
            if (GunLibLine) {
              GunLibLine.method("get_gameObject").invoke().method("SetActive").invoke(false);
            }
          } catch (_0x331dff) {}
          _0x5bc894 = false;
          _0x4b51b9 = null;
        },
        method: () => {
          var _0x5134b0;
          if (!rightGrab) {
            try {
              if (
                GunLibPointer &&
                !((_0x5134b0 = GunLibPointer.isNull) === null || _0x5134b0 === undefined
                  ? undefined
                  : _0x5134b0.call(GunLibPointer))
              ) {
                GunLibPointer.method("SetActive").invoke(false);
              }
            } catch (_0xba34a7) {}
            try {
              if (GunLibLine) {
                GunLibLine.method("get_gameObject").invoke().method("SetActive").invoke(false);
              }
            } catch (_0x3b4884) {}
            _0x5bc894 = false;
            _0x4b51b9 = null;
            return;
          }
          try {
            const _0x3c7cfd = _0x43eae3();
            if (!_0x3c7cfd) {
              return;
            }
            const { targetPlayer: _0x352e45 } = _0x3c7cfd;
            if (rightTrigger && _0x352e45 && !_0x352e45.isNull()) {
              try {
                const _0xae6251 = _0xe40610(_0x352e45).method("get_position").invoke();
                const _0x2f8150 = _0xe40610(_0x352e45).method("get_forward").invoke();
                const _0x42fd52 = Vector3Class.method("get_up").invoke();
                const _0x445b42 = Vector3Class.method("op_Multiply", 2).invoke(_0x42fd52, 0.2);
                const _0xc9141d = Vector3Class.method("op_Multiply", 2).invoke(_0x2f8150, 0.15);
                const _0x5e7d2d = Vector3Class.method("op_Addition", 2).invoke(
                  Vector3Class.method("op_Addition", 2).invoke(_0xae6251, _0x445b42),
                  _0xc9141d,
                );
                const _0x4fff16 = _0xf8bff9("item_goopfish", _0x5e7d2d, QuaternionIdentity);
                if (_0x4fff16 && !_0x4fff16.handle.isNull()) {
                  try {
                    let _0x2f1d3d = null;
                    try {
                      _0x2f1d3d = _0x4fff16
                        .method("GetComponent", 1)
                        .inflate(UnityRigidbodyClass)
                        .invoke();
                    } catch (_0x29b5f7) {}
                    if (!_0x2f1d3d || _0x2f1d3d.isNull()) {
                      try {
                        _0x2f1d3d = _0x4fff16
                          .method("GetComponentInChildren", 1)
                          .inflate(UnityRigidbodyClass)
                          .invoke();
                      } catch (_0x492d83) {}
                    }
                    if (_0x2f1d3d && !_0x2f1d3d.isNull()) {
                      _0x2f1d3d.method("set_isKinematic").invoke(false);
                      _0x2f1d3d.method("WakeUp").invoke();
                      _0x2f1d3d.method("set_linearVelocity").invoke([0, 0, 0]);
                    }
                  } catch (_0x388d8c) {}
                }
              } catch (_0x49d4ec) {}
              notify("Blinded!", false, 1);
            }
          } catch (_0x48997c) {
            smartError("Blind Person Gun", _0x48997c);
          }
        },
        toolTip:
          "Point at a player and pull trigger to spawn a goopfish on their face. Instant blind.",
      }),
      new ButtonInfo({
        buttonText: "Delete Item Gun",
        isTogglable: true,
        disableMethod: () => {
          var _0x5968cf;
          try {
            if (
              GunLibPointer &&
              !((_0x5968cf = GunLibPointer.isNull) === null || _0x5968cf === undefined
                ? undefined
                : _0x5968cf.call(GunLibPointer))
            ) {
              GunLibPointer.method("SetActive").invoke(false);
            }
          } catch (_0x2176a9) {}
          try {
            if (GunLibLine) {
              GunLibLine.method("get_gameObject").invoke().method("SetActive").invoke(false);
            }
          } catch (_0x5ab9d1) {}
        },
        method: () => {
          var _0x53d385;
          if (!rightGrab) {
            try {
              if (
                GunLibPointer &&
                !((_0x53d385 = GunLibPointer.isNull) === null || _0x53d385 === undefined
                  ? undefined
                  : _0x53d385.call(GunLibPointer))
              ) {
                GunLibPointer.method("SetActive").invoke(false);
              }
            } catch (_0x40b69c) {}
            try {
              if (GunLibLine) {
                GunLibLine.method("get_gameObject").invoke().method("SetActive").invoke(false);
              }
            } catch (_0x4101cf) {}
            return;
          }
          try {
            const _0x11909f = _0x577f7f();
            if (!_0x11909f || !rightTrigger) {
              return;
            }
            const { finalRay: _0x5b187e } = _0x11909f;
            if (!_0x5b187e) {
              return;
            }
            const _0xee830c = _0x5b187e.method("get_collider").invoke();
            if (!_0xee830c || _0xee830c.isNull()) {
              return;
            }
            const _0x58580f = _0xee830c.method("get_gameObject").invoke();
            if (!_0x58580f || _0x58580f.isNull()) {
              return;
            }
            let _0x5ee476 = null;
            try {
              _0x5ee476 = _0x58580f
                .method("GetComponent", 1)
                .inflate(AnimalGrabbableObjectClass)
                .invoke();
            } catch (_0x82d8d3) {}
            if (!_0x5ee476 || _0x5ee476.isNull()) {
              try {
                _0x5ee476 = _0x58580f
                  .method("GetComponentInParent", 1)
                  .inflate(AnimalGrabbableObjectClass)
                  .invoke();
              } catch (_0x555253) {}
            }
            if (!_0x5ee476 || _0x5ee476.isNull()) {
              try {
                _0x5ee476 = _0x58580f
                  .method("GetComponentInChildren", 1)
                  .inflate(AnimalGrabbableObjectClass)
                  .invoke();
              } catch (_0x31c6f3) {}
            }
            if (!_0x5ee476 || _0x5ee476.isNull()) {
              notify("No item hit", false, 1);
              return;
            }
            let _0x4173aa = "item";
            try {
              const _0x3879ca = _0x5ee476
                .method("GetComponent", 1)
                .inflate(GrabbableItemClass)
                .invoke();
              if (_0x3879ca && !_0x3879ca.isNull()) {
                const _0x24a174 = _0x3879ca.method("get_itemID").invoke();
                if (_0x24a174 && _0x24a174.content) {
                  _0x4173aa = _0x24a174.content;
                }
              }
            } catch (_0x26b8a2) {}
            let _0x4ac728 = false;
            try {
              const _0x332a47 = _0x5ee476.method("get_Object").invoke();
              if (_0x332a47 && !_0x332a47.isNull()) {
                const _0x5cc0fa = PrefabGeneratorClass.field("_instance")
                  .value.method("get_runner")
                  .invoke();
                if (_0x5cc0fa && !_0x5cc0fa.isNull()) {
                  try {
                    _0x332a47.method("RequestStateAuthority").invoke();
                  } catch (_0x31b49a) {}
                  _0x5cc0fa.method("Despawn").invoke(_0x332a47);
                  _0x4ac728 = true;
                }
              }
            } catch (_0x61ee1b) {}
            if (!_0x4ac728) {
              try {
                UnityObjectClass.method("Destroy", 1).invoke(_0x5ee476);
              } catch (_0x53a076) {}
            }
            notify("Deleted: " + _0x4173aa, false, 2);
          } catch (_0x17ed77) {
            smartError("Delete Item Gun", _0x17ed77);
          }
        },
        toolTip:
          "Hold grip to aim, pull trigger to delete any item you point at — works on items held in hands, on hips, or on the ground.",
      }),
      new ButtonInfo({
        buttonText: "Kidnap Gun",
        isTogglable: true,
        disableMethod: () => {
          var _0xd17e73;
          try {
            if (
              GunLibPointer &&
              !((_0xd17e73 = GunLibPointer.isNull) === null || _0xd17e73 === undefined
                ? undefined
                : _0xd17e73.call(GunLibPointer))
            ) {
              GunLibPointer.method("SetActive").invoke(false);
            }
          } catch (_0x41b4da) {}
          try {
            if (GunLibLine) {
              GunLibLine.method("get_gameObject").invoke().method("SetActive").invoke(false);
            }
          } catch (_0x252464) {}
        },
        method: () => {
          var _0xc29593;
          if (!rightGrab) {
            try {
              if (
                GunLibPointer &&
                !((_0xc29593 = GunLibPointer.isNull) === null || _0xc29593 === undefined
                  ? undefined
                  : _0xc29593.call(GunLibPointer))
              ) {
                GunLibPointer.method("SetActive").invoke(false);
              }
            } catch (_0xf94034) {}
            try {
              if (GunLibLine) {
                GunLibLine.method("get_gameObject").invoke().method("SetActive").invoke(false);
              }
            } catch (_0x145245) {}
            return;
          }
          try {
            const _0x1b3fcc = _0x43eae3();
            if (!_0x1b3fcc) {
              return;
            }
            const { targetPlayer: _0x1f0bb0 } = _0x1b3fcc;
            if (rightTrigger && _0x1f0bb0 && !_0x1f0bb0.isNull() && time > _gunLibDelay) {
              _gunLibDelay = time + 0.8;
              if (_0x16fc51(_0x1f0bb0)) {
                notify("Can't kidnap yourself", false);
                return;
              }
              const _0x468cce = getPlayerName(_0x1f0bb0);
              try {
                const _0x2b0096 = _0xe40610(_0x1f0bb0).method("get_position").invoke();
                const _0x4b59a4 = _0x5db48f("Basketball", _0x2b0096, QuaternionIdentity);
                if (!_0x4b59a4 || _0x4b59a4.isNull()) {
                  notify("Spawn failed", false);
                  return;
                }
                try {
                  const _0x22d347 = _0x4b59a4
                    .method("GetComponent", 1)
                    .inflate(AnimalGrabbableObjectClass)
                    .invoke();
                  if (_0x22d347 && !_0x22d347.isNull()) {
                    _0x22d347.method("set_scaleModifier").invoke(-100);
                  }
                } catch (_0x2387d9) {}
                _0x3218db(_0x1f0bb0, _0x4b59a4);
                notify("Kidnapped: " + _0x468cce, false);
                console.log("[KidnapGun] Kidnapped: " + _0x468cce);
              } catch (_0x10f9f2) {
                notify("Kidnap failed: " + _0x10f9f2, false);
                smartError("[KidnapGun]", _0x10f9f2);
              }
            }
          } catch (_0x5086e0) {
            smartError("[KidnapGun]", _0x5086e0);
          }
        },
        toolTip: "Point at a player and pull trigger to trap them inside a floating basketball.",
      }),
      new ButtonInfo({
        buttonText: "TP All To Gun",
        isTogglable: true,
        disableMethod: () => {
          var _0xbb527c;
          try {
            if (
              GunLibPointer &&
              !((_0xbb527c = GunLibPointer.isNull) === null || _0xbb527c === undefined
                ? undefined
                : _0xbb527c.call(GunLibPointer))
            ) {
              GunLibPointer.method("SetActive").invoke(false);
            }
          } catch (_0x3dde6a) {}
          try {
            if (GunLibLine) {
              GunLibLine.method("get_gameObject").invoke().method("SetActive").invoke(false);
            }
          } catch (_0x2383e1) {}
        },
        method: () => {
          var _0x21b999;
          if (!rightGrab) {
            try {
              if (
                GunLibPointer &&
                !((_0x21b999 = GunLibPointer.isNull) === null || _0x21b999 === undefined
                  ? undefined
                  : _0x21b999.call(GunLibPointer))
              ) {
                GunLibPointer.method("SetActive").invoke(false);
              }
            } catch (_0x39df5e) {}
            try {
              if (GunLibLine) {
                GunLibLine.method("get_gameObject").invoke().method("SetActive").invoke(false);
              }
            } catch (_0x306f2d) {}
            return;
          }
          try {
            const _0x10e41c = _0x577f7f();
            if (!_0x10e41c) {
              return;
            }
            if (!rightTrigger || time <= lagGunDelay) {
              return;
            }
            lagGunDelay = time + 0.8;
            const { finalRay: _0x519903 } = _0x10e41c;
            let _0x155ffc = null;
            if (_0x519903) {
              try {
                _0x155ffc = _0x519903.method("get_point").invoke();
              } catch (_0x5038d8) {}
            }
            if (!_0x155ffc) {
              const _0x5b739f = rightHandTransform.method("get_position").invoke();
              const _0x3169df = rightHandTransform.method("get_forward").invoke();
              _0x155ffc = [
                _0x5b739f.field("x").value + _0x3169df.field("x").value * 10,
                _0x5b739f.field("y").value + _0x3169df.field("y").value * 10,
                _0x5b739f.field("z").value + _0x3169df.field("z").value * 10,
              ];
            }
            const _0x3bdcf0 = UnityObjectClass.method("FindObjectsByType", 1)
              .inflate(NetPlayerClass)
              .invoke(0);
            let _0x41b8d4 = 0;
            for (let _0x269457 = 0; _0x269457 < _0x3bdcf0.length; _0x269457++) {
              const _0x45cfef = _0x3bdcf0.get(_0x269457);
              if (!_0x45cfef || _0x45cfef.isNull() || _0x16fc51(_0x45cfef)) {
                continue;
              }
              try {
                _0x45cfef.method("RPC_Teleport").invoke(_0x155ffc);
                _0x41b8d4++;
              } catch (_0x19af33) {}
            }
            notify("TP'd " + _0x41b8d4 + " player(s) to aim point", false, 2);
          } catch (_0x1c1940) {
            smartError("TP All To Gun", _0x1c1940);
          }
        },
        toolTip:
          "Hold grip to aim, pull trigger to teleport everyone (except you) to your crosshair hit point.",
      }),
      new ButtonInfo({
        buttonText: "Kick Gun",
        isTogglable: true,
        disableMethod: () => {
          var _0x1f1800;
          try {
            if (
              GunLibPointer &&
              !((_0x1f1800 = GunLibPointer.isNull) === null || _0x1f1800 === undefined
                ? undefined
                : _0x1f1800.call(GunLibPointer))
            ) {
              GunLibPointer.method("SetActive").invoke(false);
            }
          } catch (_0x1a36c1) {}
          try {
            if (GunLibLine) {
              GunLibLine.method("get_gameObject").invoke().method("SetActive").invoke(false);
            }
          } catch (_0x284caf) {}
          _0x5bc894 = false;
          _0x4b51b9 = null;
        },
        method: () => {
          var _0x352a15;
          if (!rightGrab) {
            try {
              if (
                GunLibPointer &&
                !((_0x352a15 = GunLibPointer.isNull) === null || _0x352a15 === undefined
                  ? undefined
                  : _0x352a15.call(GunLibPointer))
              ) {
                GunLibPointer.method("SetActive").invoke(false);
              }
            } catch (_0x48abfe) {}
            try {
              if (GunLibLine) {
                GunLibLine.method("get_gameObject").invoke().method("SetActive").invoke(false);
              }
            } catch (_0x41ea02) {}
            _0x5bc894 = false;
            _0x4b51b9 = null;
            return;
          }
          try {
            const _0x2024e2 = _0x43eae3();
            if (!_0x2024e2) {
              return;
            }
            const { targetPlayer: _0x3e4963 } = _0x2024e2;
            if (rightTrigger && _0x3e4963 && !_0x3e4963.isNull() && time > _gunLibDelay) {
              _gunLibDelay = time + 0.8;
              _0x28e89c(_0x3e4963);
              notify("Kicked: " + getPlayerName(_0x3e4963), false);
            }
          } catch (_0xf24c4a) {
            smartError("Kick Gun", _0xf24c4a);
          }
        },
        toolTip: "Lock onto a player and pull trigger to kick them.",
      }),
      new ButtonInfo({
        buttonText: "Rainbow Gun",
        isTogglable: true,
        enableMethod: () => {
          gunRainbowEnabled = true;
          gunStrobeEnabled = false;
          gunRainbowTarget = null;
        },
        disableMethod: () => {
          var _0x2a0c08;
          gunRainbowEnabled = false;
          gunRainbowTarget = null;
          try {
            if (
              GunLibPointer &&
              !((_0x2a0c08 = GunLibPointer.isNull) === null || _0x2a0c08 === undefined
                ? undefined
                : _0x2a0c08.call(GunLibPointer))
            ) {
              GunLibPointer.method("SetActive").invoke(false);
            }
          } catch (_0x5e9dfe) {}
          try {
            if (GunLibLine) {
              GunLibLine.method("get_gameObject").invoke().method("SetActive").invoke(false);
            }
          } catch (_0xc66a26) {}
          _0x5bc894 = false;
          _0x4b51b9 = null;
        },
        method: () => {
          var _0x561e6e;
          if (!gunRainbowEnabled) {
            return;
          }
          if (!rightGrab) {
            try {
              if (
                GunLibPointer &&
                !((_0x561e6e = GunLibPointer.isNull) === null || _0x561e6e === undefined
                  ? undefined
                  : _0x561e6e.call(GunLibPointer))
              ) {
                GunLibPointer.method("SetActive").invoke(false);
              }
            } catch (_0xc4d75d) {}
            try {
              if (GunLibLine) {
                GunLibLine.method("get_gameObject").invoke().method("SetActive").invoke(false);
              }
            } catch (_0x3f08ad) {}
            _0x5bc894 = false;
            _0x4b51b9 = null;
            gunRainbowTarget = null;
            return;
          }
          try {
            const _0x39d495 = _0x43eae3();
            if (!_0x39d495) {
              return;
            }
            const { targetPlayer: _0x5d2a9e } = _0x39d495;
            if (rightTrigger && _0x5d2a9e && !_0x5d2a9e.isNull() && !gunRainbowTarget) {
              gunRainbowTarget = _0x5d2a9e;
              notify("Rainbow → " + getPlayerName(gunRainbowTarget) + "!", false, 1);
            }
            if (!rightTrigger) {
              gunRainbowTarget = null;
            }
            if (gunRainbowTarget && !gunRainbowTarget.isNull()) {
              _gunRainbowHue = (_gunRainbowHue + 0.012) % 1;
              try {
                gunRainbowTarget.method("RPC_SetColorHSV").invoke(0.5, _gunRainbowHue, 1, 1);
              } catch (_0x31c51f) {}
            }
          } catch (_0x1e6bfc) {
            smartError("Rainbow Gun", _0x1e6bfc);
          }
        },
        toolTip:
          "Hold grip to aim, pull trigger to lock on a player and cycle their colour through the full rainbow.",
      }),
      new ButtonInfo({
        buttonText: "Strobe Gun",
        isTogglable: true,
        enableMethod: () => {
          gunStrobeEnabled = true;
          gunRainbowEnabled = false;
          gunStrobeTarget = null;
        },
        disableMethod: () => {
          var _0x26f948;
          gunStrobeEnabled = false;
          gunStrobeTarget = null;
          try {
            if (
              GunLibPointer &&
              !((_0x26f948 = GunLibPointer.isNull) === null || _0x26f948 === undefined
                ? undefined
                : _0x26f948.call(GunLibPointer))
            ) {
              GunLibPointer.method("SetActive").invoke(false);
            }
          } catch (_0x2e6089) {}
          try {
            if (GunLibLine) {
              GunLibLine.method("get_gameObject").invoke().method("SetActive").invoke(false);
            }
          } catch (_0x18acff) {}
          _0x5bc894 = false;
          _0x4b51b9 = null;
        },
        method: () => {
          var _0x6fff02;
          if (!gunStrobeEnabled) {
            return;
          }
          if (!rightGrab) {
            try {
              if (
                GunLibPointer &&
                !((_0x6fff02 = GunLibPointer.isNull) === null || _0x6fff02 === undefined
                  ? undefined
                  : _0x6fff02.call(GunLibPointer))
              ) {
                GunLibPointer.method("SetActive").invoke(false);
              }
            } catch (_0x2d0181) {}
            try {
              if (GunLibLine) {
                GunLibLine.method("get_gameObject").invoke().method("SetActive").invoke(false);
              }
            } catch (_0x379e09) {}
            _0x5bc894 = false;
            _0x4b51b9 = null;
            gunStrobeTarget = null;
            return;
          }
          try {
            const _0x3e05cd = _0x43eae3();
            if (!_0x3e05cd) {
              return;
            }
            const { targetPlayer: _0x50d36 } = _0x3e05cd;
            if (rightTrigger && _0x50d36 && !_0x50d36.isNull() && !gunStrobeTarget) {
              gunStrobeTarget = _0x50d36;
              notify("Strobe → " + getPlayerName(gunStrobeTarget) + "!", false, 1);
            }
            if (!rightTrigger) {
              gunStrobeTarget = null;
            }
            if (gunStrobeTarget && !gunStrobeTarget.isNull() && frameCount % 3 === 0) {
              const _0x4dc983 = Math.floor(time * 20) % 4;
              let _0x5210fd = 0;
              let _0x1732ed = 1;
              let _0x3ed0d8 = 1;
              if (_0x4dc983 === 0) {
                _0x5210fd = 0;
                _0x1732ed = 1;
                _0x3ed0d8 = 1;
              } else if (_0x4dc983 === 1) {
                _0x5210fd = 0.33;
                _0x1732ed = 1;
                _0x3ed0d8 = 1;
              } else if (_0x4dc983 === 2) {
                _0x5210fd = 0.66;
                _0x1732ed = 1;
                _0x3ed0d8 = 1;
              } else {
                _0x5210fd = 0.15;
                _0x1732ed = 0;
                _0x3ed0d8 = 1;
              }
              try {
                gunStrobeTarget
                  .method("RPC_SetColorHSV")
                  .invoke(0.1, _0x5210fd, _0x1732ed, _0x3ed0d8);
              } catch (_0x12a705) {}
            }
          } catch (_0x2b9c43) {
            smartError("Strobe Gun", _0x2b9c43);
          }
        },
        toolTip:
          "Hold grip to aim, pull trigger to lock on a player and strobe their colour Red → Green → Blue → White at 20Hz.",
      }),
      new ButtonInfo({
        buttonText: "All Buffs Gun",
        isTogglable: true,
        disableMethod: () => {
          var _0x37d08d;
          try {
            if (
              GunLibPointer &&
              !((_0x37d08d = GunLibPointer.isNull) === null || _0x37d08d === undefined
                ? undefined
                : _0x37d08d.call(GunLibPointer))
            ) {
              GunLibPointer.method("SetActive").invoke(false);
            }
          } catch (_0x44132e) {}
          try {
            if (GunLibLine) {
              GunLibLine.method("get_gameObject").invoke().method("SetActive").invoke(false);
            }
          } catch (_0x3bba8e) {}
          _0x5bc894 = false;
          _0x4b51b9 = null;
        },
        method: () => {
          var _0x3c5750;
          if (!rightGrab) {
            try {
              if (
                GunLibPointer &&
                !((_0x3c5750 = GunLibPointer.isNull) === null || _0x3c5750 === undefined
                  ? undefined
                  : _0x3c5750.call(GunLibPointer))
              ) {
                GunLibPointer.method("SetActive").invoke(false);
              }
            } catch (_0x134427) {}
            try {
              if (GunLibLine) {
                GunLibLine.method("get_gameObject").invoke().method("SetActive").invoke(false);
              }
            } catch (_0x3cb434) {}
            _0x5bc894 = false;
            _0x4b51b9 = null;
            return;
          }
          try {
            const _0x1ef7c5 = _0x43eae3();
            if (!_0x1ef7c5) {
              return;
            }
            const { targetPlayer: _0x110e16 } = _0x1ef7c5;
            if (rightTrigger && _0x110e16 && !_0x110e16.isNull() && time > _allBufGunDelay) {
              _allBufGunDelay = time + 0.5;
              const _0x2d41c0 = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15];
              for (const _0x295cf6 of _0x2d41c0) {
                try {
                  _0x110e16.method("RPC_ApplyBuff").invoke(_0x295cf6);
                } catch (_0x46fb2a) {}
              }
              notify("All buffs → " + getPlayerName(_0x110e16) + "!", false, 1.5);
            }
          } catch (_0x1c2bcd) {
            smartError("All Buffs Gun", _0x1c2bcd);
          }
        },
        toolTip:
          "Hold grip to aim, pull trigger to apply every buff RPC ID to the targeted player.",
      }),
      new ButtonInfo({
        buttonText: "Camera Gun",
        isTogglable: true,
        disableMethod: () => {
          var _0x4a0e1e;
          try {
            if (
              GunLibPointer &&
              !((_0x4a0e1e = GunLibPointer.isNull) === null || _0x4a0e1e === undefined
                ? undefined
                : _0x4a0e1e.call(GunLibPointer))
            ) {
              GunLibPointer.method("SetActive").invoke(false);
            }
          } catch (_0x3d1bf7) {}
          try {
            if (GunLibLine) {
              GunLibLine.method("get_gameObject").invoke().method("SetActive").invoke(false);
            }
          } catch (_0x41f468) {}
          _0x5bc894 = false;
          _0x4b51b9 = null;
        },
        method: () => {
          var _0x53d297;
          if (!rightGrab) {
            try {
              if (
                GunLibPointer &&
                !((_0x53d297 = GunLibPointer.isNull) === null || _0x53d297 === undefined
                  ? undefined
                  : _0x53d297.call(GunLibPointer))
              ) {
                GunLibPointer.method("SetActive").invoke(false);
              }
            } catch (_0x298c87) {}
            try {
              if (GunLibLine) {
                GunLibLine.method("get_gameObject").invoke().method("SetActive").invoke(false);
              }
            } catch (_0x2f3933) {}
            _0x5bc894 = false;
            _0x4b51b9 = null;
            return;
          }
          try {
            const _0x23d561 = _0x577f7f();
            if (!_0x23d561) {
              return;
            }
            const { finalRay: _0x457c6c } = _0x23d561;
            if (!rightTrigger) {
              return;
            }
            const _0x2d755a = rightHandTransform.method("get_position").invoke();
            let _0x5c1b06 = _0x2d755a;
            if (_0x457c6c) {
              try {
                _0x5c1b06 = _0x457c6c.method("get_point").invoke();
              } catch (_0x2cef17) {}
            }
            const _0x1b8050 = _0x5db48f("MetaCameraControls", _0x5c1b06, QuaternionIdentity);
            if (!_0x1b8050 || _0x1b8050.handle.isNull()) {
              return;
            }
            try {
              _0x1b8050.method("RequestStateAuthority").invoke();
            } catch (_0x5d953a) {}
          } catch (_0x576828) {
            smartError("Camera Gun", _0x576828);
          }
        },
        toolTip:
          "Hold grip to aim, pull trigger to spawn a MetaCameraControls prefab at the hit point.",
      }),
      new ButtonInfo({
        buttonText: "Steal Name Gun",
        isTogglable: true,
        disableMethod: () => {
          var _0x4b80fa;
          try {
            if (
              GunLibPointer &&
              !((_0x4b80fa = GunLibPointer.isNull) === null || _0x4b80fa === undefined
                ? undefined
                : _0x4b80fa.call(GunLibPointer))
            ) {
              GunLibPointer.method("SetActive").invoke(false);
            }
          } catch (_0x1edd1b) {}
          try {
            if (GunLibLine) {
              GunLibLine.method("get_gameObject").invoke().method("SetActive").invoke(false);
            }
          } catch (_0xcea575) {}
          _0x5bc894 = false;
          _0x4b51b9 = null;
          if (_0x52de87) {
            try {
              NetPlayerClass.method("get_displayName").implementation = null;
            } catch (_0x5cce2f) {}
            _0x52de87 = false;
          }
          if (_0x552059 !== null) {
            try {
              const _0x4056b2 = NetPlayerClass.method("get_localPlayer").invoke();
              if (_0x4056b2 && !_0x4056b2.isNull() && _0xf0169e !== null) {
                try {
                  _0x4056b2.method("set_displayName").invoke(Il2Cpp.string(_0xf0169e));
                } catch (_0x40cd4c) {}
              }
            } catch (_0x1b2ecf) {}
            _0x552059 = null;
            _0xf0169e = null;
            notify("Name restored", false, 1);
          }
        },
        method: () => {
          var _0x48fe68;
          if (!rightGrab) {
            try {
              if (
                GunLibPointer &&
                !((_0x48fe68 = GunLibPointer.isNull) === null || _0x48fe68 === undefined
                  ? undefined
                  : _0x48fe68.call(GunLibPointer))
              ) {
                GunLibPointer.method("SetActive").invoke(false);
              }
            } catch (_0x4cef19) {}
            try {
              if (GunLibLine) {
                GunLibLine.method("get_gameObject").invoke().method("SetActive").invoke(false);
              }
            } catch (_0x1e1d4c) {}
            _0x5bc894 = false;
            _0x4b51b9 = null;
            return;
          }
          try {
            const _0xc40976 = _0x43eae3();
            if (!_0xc40976) {
              return;
            }
            const { targetPlayer: _0x5c6b2b } = _0xc40976;
            if (
              rightTrigger &&
              _0x5c6b2b &&
              !_0x5c6b2b.isNull() &&
              !_0x16fc51(_0x5c6b2b) &&
              time > _gunLibDelay
            ) {
              _gunLibDelay = time + 0.5;
              try {
                const _0x527886 = getPlayerName(_0x5c6b2b);
                const _0x4ef79b = NetPlayerClass.method("get_localPlayer").invoke();
                if (!_0x4ef79b || _0x4ef79b.isNull()) {
                  return;
                }
                if (_0xf0169e === null) {
                  _0xf0169e = getPlayerName(_0x4ef79b);
                }
                _0x552059 = _0x527886;
                let _0x12ab56 = false;
                try {
                  _0x4ef79b.method("set_displayName").invoke(Il2Cpp.string(_0x527886));
                  _0x12ab56 = true;
                } catch (_0x718d7f) {}
                if (!_0x12ab56 && !_0x52de87) {
                  const _0x39ca41 = new Map();
                  try {
                    const _0x5c9dae = UnityObjectClass.method("FindObjectsByType", 1)
                      .inflate(NetPlayerClass)
                      .invoke(0);
                    for (let _0x5804cb = 0; _0x5804cb < _0x5c9dae.length; _0x5804cb++) {
                      try {
                        const _0x490b83 = _0x5c9dae.get(_0x5804cb);
                        _0x39ca41.set(_0x490b83.handle.toString(), getPlayerName(_0x490b83));
                      } catch (_0x3e3ae2) {}
                    }
                  } catch (_0x5e6491) {}
                  const _0xe276a5 = _0x4ef79b.handle.toString();
                  NetPlayerClass.method("get_displayName").implementation = function () {
                    if (this.handle.toString() === _0xe276a5) {
                      return Il2Cpp.string(_0x552059 ?? _0x527886);
                    }
                    return Il2Cpp.string(_0x39ca41.get(this.handle.toString()) ?? "Player");
                  };
                  _0x52de87 = true;
                }
                notify("Stole name: " + _0x527886 + "!", false, 2);
              } catch (_0x13e42b) {
                smartError("Steal Name Gun inner", _0x13e42b);
              }
            }
          } catch (_0x5e8d79) {
            smartError("Steal Name Gun", _0x5e8d79);
          }
        },
        toolTip:
          "Aim at a player with GunLib and pull trigger to steal their display name. Toggle off to restore your real name.",
      }),
      new ButtonInfo({
        buttonText: "Steal Item Gun",
        isTogglable: true,
        disableMethod: () => {
          var _0x1d3653;
          try {
            if (
              GunLibPointer &&
              !((_0x1d3653 = GunLibPointer.isNull) === null || _0x1d3653 === undefined
                ? undefined
                : _0x1d3653.call(GunLibPointer))
            ) {
              GunLibPointer.method("SetActive").invoke(false);
            }
          } catch (_0x27e2d2) {}
          try {
            if (GunLibLine) {
              GunLibLine.method("get_gameObject").invoke().method("SetActive").invoke(false);
            }
          } catch (_0x4d6c06) {}
          _0x5bc894 = false;
          _0x4b51b9 = null;
        },
        method: () => {
          var _0x2371bd;
          if (!rightGrab) {
            try {
              if (
                GunLibPointer &&
                !((_0x2371bd = GunLibPointer.isNull) === null || _0x2371bd === undefined
                  ? undefined
                  : _0x2371bd.call(GunLibPointer))
              ) {
                GunLibPointer.method("SetActive").invoke(false);
              }
            } catch (_0x5076ee) {}
            try {
              if (GunLibLine) {
                GunLibLine.method("get_gameObject").invoke().method("SetActive").invoke(false);
              }
            } catch (_0x213e25) {}
            _0x5bc894 = false;
            _0x4b51b9 = null;
            return;
          }
          try {
            const _0xcd16d0 = _0x43eae3();
            if (!_0xcd16d0) {
              return;
            }
            const { targetPlayer: _0x1281e4 } = _0xcd16d0;
            if (
              rightTrigger &&
              _0x1281e4 &&
              !_0x1281e4.isNull() &&
              !_0x16fc51(_0x1281e4) &&
              time > _gunLibDelay
            ) {
              _gunLibDelay = time + 0.5;
              try {
                const _0x48c926 = _0x1281e4.method("get_anchors").invoke();
                if (!_0x48c926 || _0x48c926.isNull()) {
                  notify("Nothing in their hands", false, 1);
                  return;
                }
                let _0x2717a2 = false;
                for (let _0x3bcea6 = 0; _0x3bcea6 < _0x48c926.length; _0x3bcea6++) {
                  try {
                    const _0x6bdf5d = _0x48c926.get(_0x3bcea6);
                    if (!_0x6bdf5d || _0x6bdf5d.isNull()) {
                      continue;
                    }
                    const _0x29ce6f = _0x6bdf5d.method("get_grabbableObject").invoke();
                    if (!_0x29ce6f || _0x29ce6f.isNull()) {
                      continue;
                    }
                    let _0x211fe3 = "";
                    try {
                      const _0x58e4a8 = _0x29ce6f
                        .method("GetComponent", 1)
                        .inflate(GrabbableItemClass)
                        .invoke();
                      if (_0x58e4a8 && !_0x58e4a8.isNull()) {
                        const _0x2d1f1f = _0x58e4a8.method("get_itemID").invoke();
                        if (_0x2d1f1f && _0x2d1f1f.content) {
                          _0x211fe3 = _0x2d1f1f.content;
                        }
                      }
                    } catch (_0x419f64) {}
                    if (!_0x211fe3) {
                      continue;
                    }
                    const _0x32c68f = _0x29ce6f.method("get_Object").invoke();
                    if (!_0x32c68f || _0x32c68f.isNull()) {
                      continue;
                    }
                    const _0x306f73 = PrefabGeneratorClass.field("_instance").value;
                    const _0x25d497 =
                      _0x306f73 && !_0x306f73.isNull()
                        ? _0x306f73.method("get_runner").invoke()
                        : null;
                    if (!_0x25d497 || _0x25d497.isNull()) {
                      continue;
                    }
                    try {
                      _0x32c68f.method("RequestStateAuthority").invoke();
                    } catch (_0x5dd10c) {}
                    _0x25d497.method("Despawn").invoke(_0x32c68f);
                    const _0x43f91b = rightHandTransform.method("get_position").invoke();
                    try {
                      _0xf8bff9(_0x211fe3, _0x43f91b, QuaternionIdentity);
                    } catch (_0x1c1a16) {
                      try {
                        PrefabGeneratorClass.method("SpawnItem", 4).invoke(
                          Il2Cpp.string("item_prefab/" + _0x211fe3),
                          _0x43f91b,
                          QuaternionIdentity,
                          _0x366930,
                        );
                      } catch (_0x5412f6) {}
                    }
                    notify(
                      "Stolen: " + _0x211fe3 + " from " + getPlayerName(_0x1281e4) + "!",
                      false,
                      2,
                    );
                    _0x2717a2 = true;
                    break;
                  } catch (_0x4de91f) {}
                }
                if (!_0x2717a2) {
                  notify("Nothing stealable in their hands", false, 1);
                }
              } catch (_0x2b6b94) {
                smartError("Steal Item Gun inner", _0x2b6b94);
              }
            }
          } catch (_0x14c9e0) {
            smartError("Steal Item Gun", _0x14c9e0);
          }
        },
        toolTip:
          "Aim at a player with GunLib and pull trigger to rip whatever they're holding out of their hand.",
      }),
      new ButtonInfo({
        buttonText: "Pokemon Card Gun",
        isTogglable: true,
        disableMethod: () => {
          var _0x3cfb78;
          try {
            if (
              GunLibPointer &&
              !((_0x3cfb78 = GunLibPointer.isNull) === null || _0x3cfb78 === undefined
                ? undefined
                : _0x3cfb78.call(GunLibPointer))
            ) {
              GunLibPointer.method("SetActive").invoke(false);
            }
          } catch (_0x340f17) {}
          try {
            if (GunLibLine) {
              GunLibLine.method("get_gameObject").invoke().method("SetActive").invoke(false);
            }
          } catch (_0x4979d4) {}
        },
        method: () => {
          var _0x4c45c3;
          if (!rightGrab) {
            try {
              if (
                GunLibPointer &&
                !((_0x4c45c3 = GunLibPointer.isNull) === null || _0x4c45c3 === undefined
                  ? undefined
                  : _0x4c45c3.call(GunLibPointer))
              ) {
                GunLibPointer.method("SetActive").invoke(false);
              }
            } catch (_0x4bc89e) {}
            try {
              if (GunLibLine) {
                GunLibLine.method("get_gameObject").invoke().method("SetActive").invoke(false);
              }
            } catch (_0xe2f5c4) {}
            return;
          }
          try {
            const _0xfd9693 = _0x577f7f();
            if (!_0xfd9693 || !rightTrigger) {
              return;
            }
            if (time <= _pokemonGunDelay) {
              return;
            }
            _pokemonGunDelay = time + 0.1;
            const { finalRay: _0x2ed66b } = _0xfd9693;
            let _0x4fcbe2 = null;
            if (_0x2ed66b) {
              try {
                _0x4fcbe2 = _0x2ed66b.method("get_point").invoke();
              } catch (_0x53274a) {}
            }
            if (!_0x4fcbe2) {
              const _0x53b7c3 = rightHandTransform.method("get_position").invoke();
              const _0x32246c = rightHandTransform.method("get_forward").invoke();
              _0x4fcbe2 = [
                _0x53b7c3.field("x").value + _0x32246c.field("x").value * 8,
                _0x53b7c3.field("y").value + _0x32246c.field("y").value * 8,
                _0x53b7c3.field("z").value + _0x32246c.field("z").value * 8,
              ];
            }
            _0xf8bff9("item_rare_card", _0x4fcbe2, QuaternionIdentity);
          } catch (_0x4c5de7) {
            smartError("Pokemon Card Gun", _0x4c5de7);
          }
        },
        toolTip: "Hold grip to aim, pull trigger to spawn Pokemon cards at your crosshair.",
      }),
    ],
    [
      new ButtonInfo({
        buttonText: "Exit Misc",
        method: () => {
          currentCategory = 0;
          currentPage = 0;
        },
        isTogglable: false,
        toolTip: "Returns you back to the main category.",
      }),
      new ButtonInfo({
        buttonText: "Give Masterclient",
        isTogglable: false,
        method: () => {
          try {
            const _0x4b3f94 = PrefabGeneratorClass.field("_instance").value;
            if (!_0x4b3f94 || _0x4b3f94.isNull()) {
              notify("PrefabGen not ready", false);
              return;
            }
            const _0x276a51 = _0x4b3f94.method("get_runner").invoke();
            if (!_0x276a51 || _0x276a51.isNull()) {
              notify("Runner is null", false);
              return;
            }
            const _0x6cf81f = _0x276a51.method("get_LocalPlayer").invoke();
            if (!_0x6cf81f) {
              notify("LocalPlayer ref null", false);
              return;
            }
            _0x276a51.method("SetMasterClient").invoke(_0x6cf81f);
            notify("You are now the master client!", false);
          } catch (_0x314f4a) {
            notify("Masterclient: " + _0x314f4a, false);
            smartError("[Masterclient]:", _0x314f4a);
          }
        },
        toolTip: "Promotes you to master client / host using NetworkRunner.SetMasterClient.",
      }),
      new ButtonInfo({
        buttonText: "Give Self 1M",
        isTogglable: false,
        method: () => {
          try {
            const _0x43c529 = NetPlayerClass.method("get_localPlayer").invoke();
            if (!_0x43c529 || _0x43c529.handle.isNull()) {
              notify("Local player null", false);
              return;
            }
            _0x18a723(() => _0x43c529.method("RPC_AddPlayerMoney").invoke(1000000));
            notify("Gave self $1,000,000!", false);
          } catch (_0x3e83fc) {
            notify("Give Self 1M: " + _0x3e83fc, false);
            smartError("[GiveSelf1M]", _0x3e83fc);
          }
        },
        toolTip: "Gives yourself $1,000,000 instantly.",
      }),
      new ButtonInfo({
        buttonText: "Give Company Coins",
        isTogglable: false,
        method: () => {
          try {
            const _0x4879ac = NetPlayerClass.field("playerIDToNetPlayer").value;
            const _0x22437e = _0x4879ac.method("get_Values").invoke();
            const _0x39bba9 = _0x22437e.method("GetEnumerator").invoke();
            let _0xcd0ce7 = 0;
            while (_0x39bba9.method("MoveNext").invoke()) {
              const _0x4c81ed = _0x39bba9.method("get_Current").invoke();
              if (!_0x4c81ed || _0x4c81ed.handle.isNull()) {
                continue;
              }
              try {
                if (_0x16fc51(_0x4c81ed)) {
                  _0x18a723(() => _0x4c81ed.method("RPC_AddPlayerMoney").invoke(500));
                } else {
                  _0x4c81ed.method("RPC_AddPlayerMoney").invoke(500);
                }
                _0xcd0ce7++;
              } catch (_0x1238c4) {}
            }
            notify("Gave 500 company coins to " + _0xcd0ce7 + " player(s)!", false);
          } catch (_0x91e50e) {
            notify("Give Company Coins: " + _0x91e50e, false);
            smartError("[GiveCompanyCoins]", _0x91e50e);
          }
        },
        toolTip: "Gives 500 company coins to all players in the session.",
      }),
      new ButtonInfo({
        buttonText: "Give Everyone 1M Loop",
        isTogglable: true,
        enableMethod: () => {
          notify("Give Everyone 1M Loop: ON", false, 2);
        },
        disableMethod: () => {
          notify("Give Everyone 1M Loop: OFF", false, 2);
        },
        method: () => {
          if (frameCount % 60 !== 0) {
            return;
          }
          try {
            const _0x3d83d7 = NetPlayerClass.field("playerIDToNetPlayer").value;
            const _0x1e2ef7 = _0x3d83d7.method("get_Values").invoke();
            const _0x3deeaf = _0x1e2ef7.method("GetEnumerator").invoke();
            let _0x72a742 = 0;
            while (_0x3deeaf.method("MoveNext").invoke()) {
              const _0x6c46c6 = _0x3deeaf.method("get_Current").invoke();
              if (!_0x6c46c6 || _0x6c46c6.handle.isNull()) {
                continue;
              }
              try {
                if (_0x16fc51(_0x6c46c6)) {
                  _0x18a723(() => _0x6c46c6.method("RPC_AddPlayerMoney").invoke(1000000));
                } else {
                  _0x6c46c6.method("RPC_AddPlayerMoney").invoke(1000000);
                }
                _0x72a742++;
              } catch (_0x209ad3) {}
            }
          } catch (_0x87aae6) {}
        },
        toolTip: "Gives every player $1,000,000 once per second while enabled.",
      }),
      new ButtonInfo({
        buttonText: "Spawn Dev Hat",
        isTogglable: false,
        method: () => {
          var _0x534d6f;
          try {
            const _0x4f5b72 = animalImage.class("AnimalCompany.App");
            const _0x7391cd = _0x4f5b72.method("get_state").invoke();
            if (!_0x7391cd || _0x7391cd.isNull()) {
              notify("App state null", false);
              return;
            }
            const _0x40a5be = _0x7391cd.method("get_avatarItems").invoke();
            if (!_0x40a5be || _0x40a5be.isNull()) {
              notify("AvatarItems null", false);
              return;
            }
            const _0x18f703 = _0x40a5be.method("get_all").invoke();
            if (!_0x18f703 || _0x18f703.isNull()) {
              notify("AvatarItems.all null", false);
              return;
            }
            const _0x54cd05 = _0x18f703.method("get_Values").invoke();
            const _0x2fa531 = _0x54cd05.method("GetEnumerator").invoke();
            let _0x3555c8 = 0;
            const _0x2110c0 = ["dev", "developer", "staff"];
            while (_0x2fa531.method("MoveNext").invoke()) {
              try {
                const _0x30606a = _0x2fa531.method("get_Current").invoke();
                if (!_0x30606a || _0x30606a.isNull()) {
                  continue;
                }
                let _0x42537c = "";
                try {
                  const _0x174610 = _0x30606a.method("get_id").invoke();
                  if (
                    _0x174610 &&
                    !((_0x534d6f = _0x174610.isNull) === null || _0x534d6f === undefined
                      ? undefined
                      : _0x534d6f.call(_0x174610))
                  ) {
                    _0x42537c = ("" + _0x174610).toLowerCase();
                  }
                } catch (_0x2ad467) {}
                if (!_0x42537c) {
                  try {
                    _0x42537c = ("" + _0x30606a.method("ToString").invoke()).toLowerCase();
                  } catch (_0x38c458) {}
                }
                let _0xc84714 = false;
                for (let _0x1e85ab = 0; _0x1e85ab < _0x2110c0.length; _0x1e85ab++) {
                  if (_0x42537c.indexOf(_0x2110c0[_0x1e85ab]) !== -1) {
                    _0xc84714 = true;
                    break;
                  }
                }
                if (!_0xc84714) {
                  continue;
                }
                try {
                  const _0x18ec21 = _0x30606a.method("get_isOwned").invoke();
                  if (_0x18ec21 && !_0x18ec21.isNull()) {
                    _0x18ec21.method("set_value").invoke(true);
                  }
                } catch (_0x2be3fd) {}
                try {
                  const _0x46e53e = _0x30606a.method("get_canPurchaseDirectly").invoke();
                  if (_0x46e53e && !_0x46e53e.isNull()) {
                    _0x46e53e.method("set_value").invoke(true);
                  }
                } catch (_0x3d0b64) {}
                _0x3555c8++;
              } catch (_0x45cff3) {}
            }
            notify("Unlocked " + _0x3555c8 + " dev hat(s)/cosmetics!", false);
          } catch (_0x4d9ca6) {
            notify("Spawn Dev Hat: " + _0x4d9ca6, false);
            smartError("[SpawnDevHat]", _0x4d9ca6);
          }
        },
        toolTip: "Unlocks all developer/staff cosmetic items (hats included) for your avatar.",
      }),
      new ButtonInfo({
        buttonText: "Spawn Mod Hat",
        isTogglable: false,
        method: () => {
          var _0x254920;
          try {
            const _0xab6694 = animalImage.class("AnimalCompany.App");
            const _0x1c2d19 = _0xab6694.method("get_state").invoke();
            if (!_0x1c2d19 || _0x1c2d19.isNull()) {
              notify("App state null", false);
              return;
            }
            const _0x28ed74 = _0x1c2d19.method("get_avatarItems").invoke();
            if (!_0x28ed74 || _0x28ed74.isNull()) {
              notify("AvatarItems null", false);
              return;
            }
            const _0x1642fb = _0x28ed74.method("get_all").invoke();
            if (!_0x1642fb || _0x1642fb.isNull()) {
              notify("AvatarItems.all null", false);
              return;
            }
            const _0x7c15f1 = _0x1642fb.method("get_Values").invoke();
            const _0x2a65e2 = _0x7c15f1.method("GetEnumerator").invoke();
            let _0x3742d2 = 0;
            const _0x143b14 = ["mod", "moderator", "admin"];
            while (_0x2a65e2.method("MoveNext").invoke()) {
              try {
                const _0x4b637f = _0x2a65e2.method("get_Current").invoke();
                if (!_0x4b637f || _0x4b637f.isNull()) {
                  continue;
                }
                let _0x8787a7 = "";
                try {
                  const _0x207037 = _0x4b637f.method("get_id").invoke();
                  if (
                    _0x207037 &&
                    !((_0x254920 = _0x207037.isNull) === null || _0x254920 === undefined
                      ? undefined
                      : _0x254920.call(_0x207037))
                  ) {
                    _0x8787a7 = ("" + _0x207037).toLowerCase();
                  }
                } catch (_0x47e1c6) {}
                if (!_0x8787a7) {
                  try {
                    _0x8787a7 = ("" + _0x4b637f.method("ToString").invoke()).toLowerCase();
                  } catch (_0x503aea) {}
                }
                let _0x1a86dc = false;
                for (let _0x21c9ee = 0; _0x21c9ee < _0x143b14.length; _0x21c9ee++) {
                  if (_0x8787a7.indexOf(_0x143b14[_0x21c9ee]) !== -1) {
                    _0x1a86dc = true;
                    break;
                  }
                }
                if (!_0x1a86dc) {
                  continue;
                }
                try {
                  const _0x558dd8 = _0x4b637f.method("get_isOwned").invoke();
                  if (_0x558dd8 && !_0x558dd8.isNull()) {
                    _0x558dd8.method("set_value").invoke(true);
                  }
                } catch (_0x2c7cc4) {}
                try {
                  const _0xa9071b = _0x4b637f.method("get_canPurchaseDirectly").invoke();
                  if (_0xa9071b && !_0xa9071b.isNull()) {
                    _0xa9071b.method("set_value").invoke(true);
                  }
                } catch (_0x5f203a) {}
                _0x3742d2++;
              } catch (_0x2ba26c) {}
            }
            notify("Unlocked " + _0x3742d2 + " mod hat(s)/cosmetics!", false);
          } catch (_0x148f41) {
            notify("Spawn Mod Hat: " + _0x148f41, false);
            smartError("[SpawnModHat]", _0x148f41);
          }
        },
        toolTip: "Unlocks all moderator/admin cosmetic items (hats included) for your avatar.",
      }),
      new ButtonInfo({
        buttonText: "Bring All",
        method: () => {
          try {
            const _0x4c6494 = NetPlayerClass.field("playerIDToNetPlayer").value;
            const _0x16f296 = _0x4c6494.method("get_Values").invoke();
            const _0x37213c = _0x16f296.method("GetEnumerator").invoke();
            let _0x2211d3 = 0;
            while (_0x37213c.method("MoveNext").invoke()) {
              const _0x142a19 = _0x37213c.method("get_Current").invoke();
              if (!_0x142a19 || _0x142a19.handle.isNull()) {
                continue;
              }
              const _0x4ba560 = _0xe40610(headCollider).method("get_position").invoke();
              try {
                _0x142a19.method("RPC_Teleport").invoke(_0x4ba560);
                _0x2211d3++;
              } catch (_0x1a7acd) {}
            }
            notify("Brang " + _0x2211d3 + " players!", false);
          } catch (_0x35937b) {
            notify("TP Void: " + _0x35937b, false);
          }
        },
        isTogglable: false,
        toolTip: "Teleports all other players to the void.",
      }),
      new ButtonInfo({
        buttonText: "Orbit All Players",
        isTogglable: true,
        method: () => {
          if (frameCount % 2 !== 0) {
            return;
          }
          try {
            const _0x46e81d = _0x2d7be3();
            if (!_0x46e81d || _0x46e81d.handle.isNull()) {
              return;
            }
            const _0x1eb66e = _0xe40610(_0x46e81d).method("get_position").invoke();
            const _0x2bb918 = UnityObjectClass.method("FindObjectsByType", 1)
              .inflate(NetPlayerClass)
              .invoke(0);
            const _0x51d852 = [];
            for (let _0x3ff0ad = 0; _0x3ff0ad < _0x2bb918.length; _0x3ff0ad++) {
              const _0x330f0e = _0x2bb918.get(_0x3ff0ad);
              if (_0x330f0e && !_0x330f0e.handle.isNull() && !_0x16fc51(_0x330f0e)) {
                _0x51d852.push(_0x330f0e);
              }
            }
            if (_0x51d852.length === 0) {
              return;
            }
            for (let _0x4407cc = 0; _0x4407cc < _0x51d852.length; _0x4407cc++) {
              const _0x2d9c26 = _0x51d852[_0x4407cc];
              const _0x341498 = time * 1.5 + _0x4407cc * ((Math.PI * 2) / _0x51d852.length);
              const _0x312cd1 = [
                _0x1eb66e.field("x").value + Math.cos(_0x341498) * 4,
                _0x1eb66e.field("y").value + 0.5,
                _0x1eb66e.field("z").value + Math.sin(_0x341498) * 4,
              ];
              _0x5a15dd(_0x2d9c26, _0x312cd1);
            }
          } catch (_0x18ef0c) {}
        },
        toolTip: "Forces all players to spin around you in a circle via Network RPC.",
      }),
      new ButtonInfo({
        buttonText: "Rainbow Self",
        method: () => {
          try {
            const _0x5b6b82 = NetPlayerClass.method("get_localPlayer").invoke();
            if (!_0x5b6b82 || _0x5b6b82.handle.isNull()) {
              return;
            }
            const _0x2ad9f1 = (time * 0.333) % 1;
            _0x5b6b82.method("RPC_SetColorHSV").invoke(0.5, _0x2ad9f1, 1, 1);
          } catch (_0x2a17ae) {
            notify("Rainbow: " + _0x2a17ae, false);
          }
        },
        isTogglable: true,
        toolTip: "Cycles your color through the full rainbow spectrum.",
      }),
      new ButtonInfo({
        buttonText: "Stash Duplicator",
        method: () => (stashDupeEnabled = true),
        disableMethod: () => (stashDupeEnabled = false),
        toolTip: "Lets you eject more times using your stash.",
      }),
      new ButtonInfo({
        buttonText: "Change Eject Dupe Amount",
        method: () => {
          ejectDupeIndex++;
          ejectDupeIndex %= ejectDupeValues.length;
          ejectDupeAmount = ejectDupeValues[ejectDupeIndex];
          notify("[MENU] New eject dupe amount: " + ejectDupeAmount, false);
        },
        isTogglable: false,
        toolTip: "Next dupe amount (+). Use 'Eject Dupe -' to go back.",
      }),
      new ButtonInfo({
        buttonText: "Eject Dupe -",
        isTogglable: false,
        method: () => {
          ejectDupeIndex =
            (((ejectDupeIndex - 1) % ejectDupeValues.length) + ejectDupeValues.length) %
            ejectDupeValues.length;
          ejectDupeAmount = ejectDupeValues[ejectDupeIndex];
          notify("[MENU] New eject dupe amount: " + ejectDupeAmount, false);
        },
        toolTip: "Previous dupe amount (-).",
      }),
      new ButtonInfo({
        buttonText: "Machine Self",
        isTogglable: true,
        enableMethod: () => {
          try {
            try {
              _0x1706ac(machineAvatar);
            } catch (_0x20caca) {}
            const _0x292858 = _0x3e527d(-0.5);
            if (!_0x292858) {
              return;
            }
            const _0x14402b = _0x5db48f(
              "ItemSellingMachineController",
              _0x292858.position,
              _0x292858.rotation,
            );
            if (_0x14402b && !_0x14402b.isNull()) {
              machineAvatar = _0x14402b;
              _0x58bf44(machineAvatar);
              const _0x141c5e = machineAvatar.method("get_transform").invoke();
              try {
                _0x141c5e.method("set_position").invoke(_0x292858.position);
              } catch (_0x162d47) {}
              try {
                _0x141c5e.method("set_rotation").invoke(_0x292858.rotation);
              } catch (_0xabf04b) {}
              const _0x518055 = machineAvatar
                .method("GetComponent", 1)
                .inflate(UnityRigidbodyClass)
                .invoke();
              if (_0x518055) {
                _0x518055.method("set_isKinematic").invoke(true);
              }
              const _0x3d1471 = _0x2d7be3();
              if (_0x3d1471) {
                _0x3d1471.method("RPC_SetHide").invoke(true);
              }
              notify("You have BECOME the Shop!", false);
            }
          } catch (_0x3795cd) {
            console.error("Machine Avatar Error: " + _0x3795cd);
          }
        },
        method: () => {
          try {
            if (!machineAvatar || machineAvatar.isNull()) {
              return;
            }
            const _0x38fdf2 = _0x3e527d(-0.5);
            if (!_0x38fdf2) {
              return;
            }
            _0x58bf44(machineAvatar);
            const _0x1be30b = machineAvatar.method("get_transform").invoke();
            _0x1be30b.method("set_position").invoke(_0x38fdf2.position);
            _0x1be30b.method("set_rotation").invoke(_0x38fdf2.rotation);
            const _0x12d2af = machineAvatar
              .method("GetComponent", 1)
              .inflate(UnityRigidbodyClass)
              .invoke();
            if (_0x12d2af && !_0x12d2af.isNull()) {
              try {
                _0x12d2af.method("set_isKinematic").invoke(true);
              } catch (_0x228c74) {}
              try {
                _0x12d2af.method("set_linearVelocity").invoke(Vector3Zero);
              } catch (_0x324c1f) {}
              try {
                _0x12d2af.method("set_angularVelocity").invoke(Vector3Zero);
              } catch (_0x21a77c) {}
            }
          } catch (_0x5de9b8) {}
        },
        disableMethod: () => {
          if (machineAvatar) {
            try {
              const _0x4200a4 = machineAvatar
                .method("GetComponent", 1)
                .inflate(UnityRigidbodyClass)
                .invoke();
              if (_0x4200a4) {
                _0x4200a4.method("set_isKinematic").invoke(false);
              }
              const _0x56943c = _0x2d7be3();
              if (_0x56943c) {
                _0x56943c.method("RPC_SetHide").invoke(false);
              }
            } catch (_0x541766) {}
            try {
              _0x1706ac(machineAvatar);
            } catch (_0x574f23) {}
          }
          machineAvatar = null;
          notify("Returned to Human form.", false);
        },
        toolTip:
          "Physically attaches the selling machine to your body and hides your player model.",
      }),
      new ButtonInfo({
        buttonText: "Spam Explode Machine",
        isTogglable: true,
        method: () => {
          var _0x231c5f;
          if (!rightGrab || time <= _explodeMachineDelay) {
            return;
          }
          try {
            const _0x3e3839 = UnityObjectClass.method("FindObjectsByType", 1)
              .inflate(ItemSellingMachineControllerClass)
              .invoke(0);
            if (!_0x3e3839 || _0x3e3839.length === 0) {
              notify("No selling machines found", false, 2);
              return;
            }
            for (let _0x3c06b2 = 0; _0x3c06b2 < _0x3e3839.length; _0x3c06b2++) {
              const _0x56091f = _0x3e3839.get(_0x3c06b2);
              if (
                !_0x56091f ||
                ((_0x231c5f = _0x56091f.isNull) === null || _0x231c5f === undefined
                  ? undefined
                  : _0x231c5f.call(_0x56091f))
              ) {
                continue;
              }
              try {
                _0x56091f.method("RPC_ExplodeMachine").invoke();
              } catch (_0x5c92ab) {}
            }
            _explodeMachineDelay = time + 0.1;
          } catch (_0x482e53) {
            smartError("Spam Explode Machine", _0x482e53);
          }
        },
        toolTip:
          "Toggle ON + hold grip to repeatedly explode all selling machines (0.1 s cooldown).",
      }),
      new ButtonInfo({
        buttonText: "Machine All Players",
        isTogglable: true,
        enableMethod: () => {
          _allMachines = [];
          try {
            const _0x38c8d1 = NetPlayerClass.field("playerIDToNetPlayer").value;
            const _0x40c3ab = _0x38c8d1.method("get_Values").invoke();
            const _0x5b6561 = _0x40c3ab.method("GetEnumerator").invoke();
            while (_0x5b6561.method("MoveNext").invoke()) {
              const _0x2398e2 = _0x5b6561.method("get_Current").invoke();
              if (!_0x2398e2 || _0x2398e2.handle.isNull()) {
                continue;
              }
              try {
                const _0x4bf2d6 = _0x2398e2.method("get_gameObject").invoke();
                const _0x4c4d17 = _0xe40610(_0x4bf2d6).method("get_position").invoke();
                const _0x34b144 = _0xe40610(_0x4bf2d6).method("get_rotation").invoke();
                const _0x5b1826 = _0x5db48f("ItemSellingMachineController", _0x4c4d17, _0x34b144);
                if (_0x5b1826 && !_0x5b1826.isNull()) {
                  _0x58bf44(_0x5b1826);
                  try {
                    const _0x1a966e = _0x5b1826
                      .method("GetComponent", 1)
                      .inflate(UnityRigidbodyClass)
                      .invoke();
                    if (_0x1a966e && !_0x1a966e.isNull()) {
                      _0x1a966e.method("set_isKinematic").invoke(true);
                    }
                  } catch (_0x32f6ea) {}
                  _allMachines.push({
                    machine: _0x5b1826,
                    player: _0x2398e2,
                  });
                }
              } catch (_0xf2e8d4) {}
            }
            notify("Spawned " + _allMachines.length + " sell machines!", false);
          } catch (_0x2f5bd8) {
            smartError("Machine All Players", _0x2f5bd8);
          }
        },
        method: () => {
          for (const _0x5dd57f of _allMachines) {
            try {
              if (!_0x5dd57f.machine || _0x5dd57f.machine.isNull()) {
                continue;
              }
              if (!_0x5dd57f.player || _0x5dd57f.player.handle.isNull()) {
                continue;
              }
              const _0x52a16b = _0x5dd57f.player.method("get_gameObject").invoke();
              if (!_0x52a16b || _0x52a16b.isNull()) {
                continue;
              }
              const _0x1b5424 = _0xe40610(_0x52a16b).method("get_position").invoke();
              const _0x17ccf7 = _0x1b5424.field("x").value;
              const _0x55aac8 = _0x1b5424.field("y").value;
              const _0x2bec23 = _0x1b5424.field("z").value;
              _0x58bf44(_0x5dd57f.machine);
              _0x5dd57f.machine
                .method("get_transform")
                .invoke()
                .method("set_position")
                .invoke([_0x17ccf7, _0x55aac8 - 0.5, _0x2bec23]);
              try {
                const _0x48df95 = _0x5dd57f.machine
                  .method("GetComponent", 1)
                  .inflate(UnityRigidbodyClass)
                  .invoke();
                if (_0x48df95 && !_0x48df95.isNull()) {
                  _0x48df95.method("set_isKinematic").invoke(true);
                  _0x48df95.method("set_linearVelocity").invoke(Vector3Zero);
                }
              } catch (_0x5f88a5) {}
            } catch (_0x4fc7fe) {}
          }
        },
        disableMethod: () => {
          for (const _0x5ef38a of _allMachines) {
            try {
              _0x1706ac(_0x5ef38a.machine);
            } catch (_0x81db37) {}
          }
          _allMachines = [];
          notify("All sell machines removed.", false);
        },
        toolTip: "Spawns a selling machine attached to every player in the lobby.",
      }),
      new ButtonInfo({
        buttonText: "Christmas Dome",
        method: () => {
          const _0xb0234d = animalImage
            .class("AnimalCompany.PlayerController")
            .method("get_instance")
            .invoke()
            .method("get_head")
            .invoke();
          function _0x1b1f03() {
            orbiters = [];
            const _0x8a21e1 = [
              {
                count: 1,
                elevation: Math.PI / 2,
                radius: 0,
              },
              {
                count: 8,
                elevation: (Math.PI * 5) / 12,
                radius: 1.5,
              },
              {
                count: 14,
                elevation: Math.PI / 3,
                radius: 2.8,
              },
              {
                count: 18,
                elevation: Math.PI / 4,
                radius: 3.5,
              },
              {
                count: 22,
                elevation: Math.PI / 6,
                radius: 4,
              },
              {
                count: 26,
                elevation: Math.PI / 12,
                radius: 4.3,
              },
              {
                count: 26,
                elevation: 0,
                radius: 4.5,
              },
              {
                count: 22,
                elevation: -Math.PI / 12,
                radius: 4.3,
              },
              {
                count: 18,
                elevation: -Math.PI / 6,
                radius: 4,
              },
              {
                count: 15,
                elevation: -Math.PI / 3,
                radius: 2.8,
              },
            ];
            for (const _0xa7f360 of _0x8a21e1) {
              for (let _0x44875d = 0; _0x44875d < _0xa7f360.count; _0x44875d++) {
                const _0xe84d5b = ((Math.PI * 2) / Math.max(_0xa7f360.count, 1)) * _0x44875d;
                const _0x5c3c26 = Math.cos(_0xe84d5b) * _0xa7f360.radius;
                const _0x28d0bc = Math.sin(_0xa7f360.elevation) * 45;
                const _0x549fc2 = Math.sin(_0xe84d5b) * _0xa7f360.radius;
                const _0x490171 = Vector3Class.alloc();
                _0x490171
                  .method(".ctor")
                  .overload("System.Single", "System.Single", "System.Single")
                  .invoke(_0x5c3c26, _0x28d0bc, _0x549fc2);
                let _0x1d1ec6 = _0xb0234d.method("get_position").invoke();
                let _0x131134 = Vector3Class.method("op_Addition").invoke(_0x1d1ec6, [
                  _0x490171.field("x").value,
                  _0x490171.field("y").value,
                  _0x490171.field("z").value,
                ]);
                let _0x2a5919 = _0x5db48f(
                  "ChristmasBox",
                  _0x131134,
                  QuaternionClass.method("get_identity").invoke(),
                );
                if (!_0x2a5919) {
                  continue;
                }
                orbitprefabs.push(_0x2a5919);
                let _0x108c6f = _0x2a5919.method("get_gameObject").invoke();
                if (!_0x108c6f) {
                  continue;
                }
                let _0x2fc49c = _0x108c6f.method("get_transform").invoke();
                orbiters.push({
                  transform: _0x2fc49c,
                  angle: _0xe84d5b,
                  radius: _0xa7f360.radius,
                  elevation: _0xa7f360.elevation,
                });
              }
            }
          }
          if (orbitprefabs.length < 170) {
            _0x1b1f03();
          }
          let _0x549f26 = TimeClass.method("get_deltaTime").invoke();
          let _0x2e9c13 = _0xb0234d.method("get_position").invoke();
          for (let _0x514153 of orbiters) {
            if (_0x514153.radius > 0.01) {
              _0x514153.angle += _0x549f26 * 1.5;
            }
            const _0x4e392d = Math.cos(_0x514153.angle) * _0x514153.radius;
            const _0x51f423 = Math.sin(_0x514153.elevation) * 45;
            const _0x580692 = Math.sin(_0x514153.angle) * _0x514153.radius;
            const _0x5d4cd3 = Vector3Class.alloc();
            _0x5d4cd3
              .method(".ctor")
              .overload("System.Single", "System.Single", "System.Single")
              .invoke(_0x4e392d, _0x51f423, _0x580692);
            let _0x10733d = Vector3Class.method("op_Addition").invoke(_0x2e9c13, [
              _0x5d4cd3.field("x").value,
              _0x5d4cd3.field("y").value,
              _0x5d4cd3.field("z").value,
            ]);
            _0x514153.transform.method("set_position").invoke(_0x10733d);
          }
        },
        disableMethod: () => {
          for (let _0x16f507 = 0; _0x16f507 < orbitprefabs.length; _0x16f507++) {
            const _0x37898d = orbitprefabs[_0x16f507];
            if (!_0x37898d) {
              return;
            }
            const _0x1feebe = _0x37898d.method("get_Runner").invoke();
            if (_0x1feebe && !_0x1feebe.isNull()) {
              _0x1feebe.method("Despawn").invoke(_0x37898d);
            }
          }
          orbitprefabs = [];
          orbiters = [];
        },
        isTogglable: true,
        toolTip: "Creates 170 XmasBoxes in a full sphere around you.",
      }),
      new ButtonInfo({
        buttonText: "Car Orbit",
        method: () => {
          const _0x1efded = animalImage
            .class("AnimalCompany.PlayerController")
            .method("get_instance")
            .invoke()
            .method("get_head")
            .invoke();
          function _0x2f7888() {
            orbiters = [];
            for (let _0x44e2a8 = 0; _0x44e2a8 < 15; _0x44e2a8++) {
              let _0x1fc48a = ((Math.PI * 2) / 15) * _0x44e2a8;
              const _0x1c548b = Vector3Class.alloc();
              _0x1c548b
                .method(".ctor")
                .overload("System.Single", "System.Single", "System.Single")
                .invoke(Math.cos(_0x1fc48a) * 6.5, 0, Math.sin(_0x1fc48a) * 6.5);
              let _0x5c3b95 = _0x1efded.method("get_position").invoke();
              let _0x35f76b = Vector3Class.method("op_Addition").invoke(_0x5c3b95, [
                _0x1c548b.field("x").value,
                _0x1c548b.field("y").value,
                _0x1c548b.field("z").value,
              ]);
              let _0xb319ed = _0x5db48f(
                "Vehicle_Buggy",
                _0x35f76b,
                QuaternionClass.method("get_identity").invoke(),
              );
              if (!_0xb319ed) {
                continue;
              }
              orbitprefabs.push(_0xb319ed);
              let _0x37a90f = _0xb319ed.method("get_gameObject").invoke();
              if (!_0x37a90f) {
                continue;
              }
              let _0x44bc1d = _0x37a90f.method("get_transform").invoke();
              orbiters.push({
                transform: _0x44bc1d,
                angle: _0x1fc48a,
              });
            }
          }
          if (orbitprefabs.length < 15) {
            _0x2f7888();
          }
          let _0x571e10 = TimeClass.method("get_deltaTime").invoke();
          let _0xc1246c = _0x1efded.method("get_position").invoke();
          for (let _0x360d03 of orbiters) {
            _0x360d03.angle += _0x571e10 * 1.5;
            const _0x7e5f80 = Vector3Class.alloc();
            _0x7e5f80
              .method(".ctor")
              .overload("System.Single", "System.Single", "System.Single")
              .invoke(Math.cos(_0x360d03.angle) * 6.5, 0, Math.sin(_0x360d03.angle) * 6.5);
            let _0x3489aa = Vector3Class.method("op_Addition").invoke(_0xc1246c, [
              _0x7e5f80.field("x").value,
              _0x7e5f80.field("y").value,
              _0x7e5f80.field("z").value,
            ]);
            _0x360d03.transform.method("set_position").invoke(_0x3489aa);
          }
        },
        disableMethod: () => {
          for (let _0x3fc4b2 = 0; _0x3fc4b2 < orbitprefabs.length; _0x3fc4b2++) {
            const _0x3c3a5b = orbitprefabs[_0x3fc4b2];
            if (!_0x3c3a5b) {
              return;
            }
            const _0x3e1c0a = _0x3c3a5b.method("get_Runner").invoke();
            if (_0x3e1c0a && !_0x3e1c0a.isNull()) {
              _0x3e1c0a.method("Despawn").invoke(_0x3c3a5b);
            }
          }
          orbitprefabs = [];
          orbiters = [];
        },
        isTogglable: true,
        toolTip: "Creates 15 Buggy's that orbit you.",
      }),
      new ButtonInfo({
        buttonText: "Sellingmachine Dome",
        method: () => {
          const _0x92e6d6 = animalImage
            .class("AnimalCompany.PlayerController")
            .method("get_instance")
            .invoke()
            .method("get_head")
            .invoke();
          function _0x20d4f3() {
            orbiters = [];
            const _0x2a78e4 = [
              {
                count: 3,
                elevation: Math.PI / 2,
                radius: 0,
              },
              {
                count: 24,
                elevation: (Math.PI * 5) / 12,
                radius: 20,
              },
              {
                count: 42,
                elevation: Math.PI / 3,
                radius: 30,
              },
              {
                count: 54,
                elevation: Math.PI / 6,
                radius: 42,
              },
              {
                count: 48,
                elevation: 0,
                radius: 45,
              },
              {
                count: 42,
                elevation: -Math.PI / 6,
                radius: 42,
              },
              {
                count: 27,
                elevation: -Math.PI / 3,
                radius: 30,
              },
            ];
            for (const _0x3fc475 of _0x2a78e4) {
              for (let _0x4d7fac = 0; _0x4d7fac < _0x3fc475.count; _0x4d7fac++) {
                const _0x84478a = ((Math.PI * 2) / Math.max(_0x3fc475.count, 1)) * _0x4d7fac;
                const _0x45d5e4 = Math.cos(_0x84478a) * _0x3fc475.radius;
                const _0x13fdeb = Math.sin(_0x3fc475.elevation) * 45;
                const _0x55382e = Math.sin(_0x84478a) * _0x3fc475.radius;
                const _0x3c81e6 = Vector3Class.alloc();
                _0x3c81e6
                  .method(".ctor")
                  .overload("System.Single", "System.Single", "System.Single")
                  .invoke(_0x45d5e4, _0x13fdeb, _0x55382e);
                let _0x1487a3 = _0x92e6d6.method("get_position").invoke();
                let _0x36e9c3 = Vector3Class.method("op_Addition").invoke(_0x1487a3, [
                  _0x3c81e6.field("x").value,
                  _0x3c81e6.field("y").value,
                  _0x3c81e6.field("z").value,
                ]);
                let _0x3633e2 = _0x5db48f(
                  "ItemSellingMachineController",
                  _0x36e9c3,
                  QuaternionClass.method("get_identity").invoke(),
                );
                if (!_0x3633e2) {
                  continue;
                }
                orbitprefabs.push(_0x3633e2);
                let _0x34b37c = _0x3633e2.method("get_gameObject").invoke();
                if (!_0x34b37c) {
                  continue;
                }
                let _0x322609 = _0x34b37c.method("get_transform").invoke();
                orbiters.push({
                  transform: _0x322609,
                  angle: _0x84478a,
                  radius: _0x3fc475.radius,
                  elevation: _0x3fc475.elevation,
                });
              }
            }
          }
          if (orbitprefabs.length < 240) {
            _0x20d4f3();
          }
          let _0x24d100 = TimeClass.method("get_deltaTime").invoke();
          let _0x1d439d = _0x92e6d6.method("get_position").invoke();
          for (let _0x2ee6b1 of orbiters) {
            if (_0x2ee6b1.radius > 0.01) {
              _0x2ee6b1.angle += _0x24d100 * 1.5;
            }
            const _0x3db4b0 = Math.cos(_0x2ee6b1.angle) * _0x2ee6b1.radius;
            const _0x5df870 = Math.sin(_0x2ee6b1.elevation) * 45;
            const _0x6e1705 = Math.sin(_0x2ee6b1.angle) * _0x2ee6b1.radius;
            const _0x3da1f6 = Vector3Class.alloc();
            _0x3da1f6
              .method(".ctor")
              .overload("System.Single", "System.Single", "System.Single")
              .invoke(_0x3db4b0, _0x5df870, _0x6e1705);
            let _0x1911bf = Vector3Class.method("op_Addition").invoke(_0x1d439d, [
              _0x3da1f6.field("x").value,
              _0x3da1f6.field("y").value,
              _0x3da1f6.field("z").value,
            ]);
            _0x2ee6b1.transform.method("set_position").invoke(_0x1911bf);
          }
        },
        disableMethod: () => {
          for (let _0x54c87e = 0; _0x54c87e < orbitprefabs.length; _0x54c87e++) {
            const _0x7c794c = orbitprefabs[_0x54c87e];
            if (!_0x7c794c) {
              return;
            }
            const _0xa91a3f = _0x7c794c.method("get_Runner").invoke();
            if (_0xa91a3f && !_0xa91a3f.isNull()) {
              _0xa91a3f.method("Despawn").invoke(_0x7c794c);
            }
          }
          orbitprefabs = [];
          orbiters = [];
        },
        isTogglable: true,
        toolTip: "Creates 240 selling machines in a huge full sphere around you (10x scale).",
      }),
      new ButtonInfo({
        buttonText: "Selling Machine Orbit",
        isTogglable: true,
        disableMethod: () => {
          for (let _0x4b9e50 = 0; _0x4b9e50 < orbitprefabs.length; _0x4b9e50++) {
            const _0x3236d4 = orbitprefabs[_0x4b9e50];
            if (!_0x3236d4) {
              continue;
            }
            try {
              const _0x327372 = _0x3236d4.method("get_Runner").invoke();
              if (_0x327372 && !_0x327372.isNull()) {
                _0x327372.method("Despawn").invoke(_0x3236d4);
              }
            } catch (_0x6c6e75) {}
          }
          orbitprefabs = [];
          orbiters = [];
        },
        method: () => {
          try {
            const _0x262054 = localRig.field("headCollider").value.method("get_transform").invoke();
            const _0x317bbd = 20;
            const _0x31ebbe = 6;
            if (orbitprefabs.length < _0x317bbd) {
              orbiters = [];
              orbitprefabs = [];
              for (let _0x21b340 = 0; _0x21b340 < _0x317bbd; _0x21b340++) {
                const _0x1a8c6a = ((Math.PI * 2) / _0x317bbd) * _0x21b340;
                const _0x544eab = _0x262054.method("get_position").invoke();
                const _0x5e9fd1 = [
                  _0x544eab.field("x").value + Math.cos(_0x1a8c6a) * _0x31ebbe,
                  _0x544eab.field("y").value,
                  _0x544eab.field("z").value + Math.sin(_0x1a8c6a) * _0x31ebbe,
                ];
                const _0xb2615 = _0x5db48f(
                  "ItemSellingMachineController",
                  _0x5e9fd1,
                  QuaternionIdentity,
                );
                if (!_0xb2615 || _0xb2615.handle.isNull()) {
                  continue;
                }
                try {
                  _0xb2615.method("RequestStateAuthority").invoke();
                } catch (_0x5ba266) {}
                orbitprefabs.push(_0xb2615);
                const _0x52fb58 = _0xb2615
                  .method("get_gameObject")
                  .invoke()
                  .method("get_transform")
                  .invoke();
                orbiters.push({
                  transform: _0x52fb58,
                  angle: _0x1a8c6a,
                  radius: _0x31ebbe,
                });
              }
            }
            const _0xbcb27c = TimeClass.method("get_deltaTime").invoke();
            const _0x11c2aa = _0x262054.method("get_position").invoke();
            for (let _0x31d587 of orbiters) {
              _0x31d587.angle += _0xbcb27c * 1.2;
              const _0x573d08 = [
                _0x11c2aa.field("x").value + Math.cos(_0x31d587.angle) * _0x31d587.radius,
                _0x11c2aa.field("y").value,
                _0x11c2aa.field("z").value + Math.sin(_0x31d587.angle) * _0x31d587.radius,
              ];
              try {
                _0x31d587.transform.method("set_position").invoke(_0x573d08);
              } catch (_0x46c4fb) {}
            }
          } catch (_0x311f99) {
            smartError("Selling Machine Orbit", _0x311f99);
          }
        },
        toolTip: "Orbits 20 selling machines around you in a wide ring (radius 6).",
      }),
      new ButtonInfo({
        buttonText: "Car Dome",
        method: () => {
          const _0x3d4c2f = animalImage
            .class("AnimalCompany.PlayerController")
            .method("get_instance")
            .invoke()
            .method("get_head")
            .invoke();
          function _0x288ca9() {
            orbiters = [];
            const _0x12732c = [
              {
                count: 1,
                elevation: Math.PI / 2,
                radius: 0,
              },
              {
                count: 5,
                elevation: (Math.PI * 5) / 12,
                radius: 3.5,
              },
              {
                count: 8,
                elevation: Math.PI / 3,
                radius: 6,
              },
              {
                count: 10,
                elevation: Math.PI / 6,
                radius: 8,
              },
              {
                count: 10,
                elevation: 0,
                radius: 9,
              },
              {
                count: 8,
                elevation: -Math.PI / 6,
                radius: 8,
              },
              {
                count: 5,
                elevation: -Math.PI / 3,
                radius: 6,
              },
            ];
            for (const _0x18af5f of _0x12732c) {
              for (let _0x3923ae = 0; _0x3923ae < _0x18af5f.count; _0x3923ae++) {
                const _0x1b2aa8 = ((Math.PI * 2) / Math.max(_0x18af5f.count, 1)) * _0x3923ae;
                const _0x29ec9a = Math.cos(_0x1b2aa8) * _0x18af5f.radius;
                const _0x53266d = Math.sin(_0x18af5f.elevation) * 7;
                const _0x3531f4 = Math.sin(_0x1b2aa8) * _0x18af5f.radius;
                const _0x107ecd = Vector3Class.alloc();
                _0x107ecd
                  .method(".ctor")
                  .overload("System.Single", "System.Single", "System.Single")
                  .invoke(_0x29ec9a, _0x53266d, _0x3531f4);
                let _0x35afce = _0x3d4c2f.method("get_position").invoke();
                let _0xf9dd2c = Vector3Class.method("op_Addition").invoke(_0x35afce, [
                  _0x107ecd.field("x").value,
                  _0x107ecd.field("y").value,
                  _0x107ecd.field("z").value,
                ]);
                let _0x174bd3 = _0x5db48f(
                  "Vehicle_Buggy",
                  _0xf9dd2c,
                  QuaternionClass.method("get_identity").invoke(),
                );
                if (!_0x174bd3) {
                  continue;
                }
                orbitprefabs.push(_0x174bd3);
                let _0x776f30 = _0x174bd3.method("get_gameObject").invoke();
                if (!_0x776f30) {
                  continue;
                }
                let _0xcf045e = _0x776f30.method("get_transform").invoke();
                orbiters.push({
                  transform: _0xcf045e,
                  angle: _0x1b2aa8,
                  radius: _0x18af5f.radius,
                  elevation: _0x18af5f.elevation,
                });
              }
            }
          }
          if (orbitprefabs.length < 47) {
            _0x288ca9();
          }
          let _0x24d64c = TimeClass.method("get_deltaTime").invoke();
          let _0x4b9997 = _0x3d4c2f.method("get_position").invoke();
          for (let _0x36057d of orbiters) {
            if (_0x36057d.radius > 0.01) {
              _0x36057d.angle += _0x24d64c * 1.5;
            }
            const _0x2a6f3c = Math.cos(_0x36057d.angle) * _0x36057d.radius;
            const _0x25eec4 = Math.sin(_0x36057d.elevation) * 7;
            const _0xb2bf0a = Math.sin(_0x36057d.angle) * _0x36057d.radius;
            const _0x33e695 = Vector3Class.alloc();
            _0x33e695
              .method(".ctor")
              .overload("System.Single", "System.Single", "System.Single")
              .invoke(_0x2a6f3c, _0x25eec4, _0xb2bf0a);
            let _0x35d5fc = Vector3Class.method("op_Addition").invoke(_0x4b9997, [
              _0x33e695.field("x").value,
              _0x33e695.field("y").value,
              _0x33e695.field("z").value,
            ]);
            _0x36057d.transform.method("set_position").invoke(_0x35d5fc);
          }
        },
        disableMethod: () => {
          for (let _0x18dc47 = 0; _0x18dc47 < orbitprefabs.length; _0x18dc47++) {
            const _0x556e2b = orbitprefabs[_0x18dc47];
            if (!_0x556e2b) {
              return;
            }
            const _0x104372 = _0x556e2b.method("get_Runner").invoke();
            if (_0x104372 && !_0x104372.isNull()) {
              _0x104372.method("Despawn").invoke(_0x556e2b);
            }
          }
          orbitprefabs = [];
          orbiters = [];
        },
        isTogglable: true,
        toolTip: "Creates 47 buggies in a full sphere dome around you.",
      }),
      new ButtonInfo({
        buttonText: "Infinite Ammo",
        enableMethod: () => {
          InfAmmo = true;
        },
        disableMethod: () => {
          InfAmmo = false;
        },
        isTogglable: true,
        toolTip: "Infinite ammo",
      }),
      new ButtonInfo({
        buttonText: "No Recoil",
        enableMethod: () => {
          noRecoil = true;
        },
        disableMethod: () => {
          noRecoil = false;
        },
        isTogglable: true,
        toolTip: "Removes recoil force and spread on all guns (Revolver, Shotgun, Arena guns).",
      }),
      new ButtonInfo({
        buttonText: "Play SFX Net",
        isTogglable: true,
        method: () => {
          if (!rightGrab) {
            return;
          }
          if (time > lagGunDelay) {
            lagGunDelay = time + 0.1;
            try {
              const _0x5e5e49 = rightHandTransform.method("get_position").invoke();
              const _0x181619 = animalImage.class("AnimalCompany.RandomSFXSheet");
              const _0x5c757f = _0x181619.method("get_instance").invoke();
              if (!_0x5c757f || _0x5c757f.isNull()) {
                notify("SFX sheet not ready", false, 2);
                return;
              }
              const _0x5f31f9 = _0x5c757f.method("GetLength").invoke();
              const _0x245b45 = sfxIndex % _0x5f31f9;
              const _0x445db3 = _0x5c757f.method("Get").invoke(_0x245b45);
              if (!_0x445db3 || _0x445db3.isNull()) {
                notify("SFX " + sfxIndex + " not found", false, 2);
                return;
              }
              SfxManagerClass.method("PlaySFXNetworked", 4).invoke(_0x445db3, _0x5e5e49, 1, 0);
              const _0xffb0a0 = sfxNameMap[_0x245b45] ?? "ID_" + _0x245b45;
              notify("SFX: " + _0xffb0a0 + " [" + _0x245b45 + "]", false, 2);
            } catch (_0x1eeecf) {
              notify("Play SFX Net: " + _0x1eeecf, false);
            }
          }
        },
        toolTip:
          "Toggle on + hold RIGHT GRIP to play the SFX (set via Settings > Change SFX ID) networked so all players hear it.",
      }),
      new ButtonInfo({
        buttonText: "Spam Random Sounds",
        isTogglable: true,
        method: () => {
          if (!rightGrab) {
            return;
          }
          if (time <= _spamSfxDelay) {
            return;
          }
          _spamSfxDelay = time + 0.05;
          try {
            const _0x5e78d9 = rightHandTransform.method("get_position").invoke();
            const _0x56ed84 = animalImage.class("AnimalCompany.RandomSFXSheet");
            const _0x52bfdd = _0x56ed84.method("get_instance").invoke();
            if (!_0x52bfdd || _0x52bfdd.isNull()) {
              return;
            }
            const _0x1557d2 = _0x52bfdd.method("GetLength").invoke();
            if (_0x1557d2 <= 0) {
              return;
            }
            const _0x5a417e = Math.floor(Math.random() * _0x1557d2);
            const _0x321f1a = _0x52bfdd.method("Get").invoke(_0x5a417e);
            if (!_0x321f1a || _0x321f1a.isNull()) {
              return;
            }
            SfxManagerClass.method("PlaySFXNetworked", 4).invoke(_0x321f1a, _0x5e78d9, 1, 0);
          } catch (_0x2f5634) {}
        },
        toolTip:
          "Toggle ON + hold right grip to spam random SFX every 0.05s, heard by all players.",
      }),
      new ButtonInfo({
        buttonText: "Play VFX Net",
        isTogglable: true,
        method: () => {
          if (!rightGrab) {
            return;
          }
          if (time > vfxGunDelay) {
            vfxGunDelay = time + 0.1;
            try {
              const _0x1cd8f2 = rightHandTransform.method("get_position").invoke();
              let _0x48b77e = false;
              try {
                let _0x3a5a67 = null;
                try {
                  _0x3a5a67 = ParticleManagerAlias.field("_instance").value;
                } catch (_0x3b0b51) {}
                try {
                  if (!_0x3a5a67 || _0x3a5a67.isNull()) {
                    _0x3a5a67 = ParticleManagerAlias.method("get_instance").invoke();
                  }
                } catch (_0x3f3b19) {}
                if (_0x3a5a67 && !_0x3a5a67.isNull()) {
                  try {
                    _0x3a5a67
                      .method("RPC_PlayVFX", 3)
                      .invoke(vfxIndex, _0x1cd8f2, QuaternionIdentity);
                    _0x48b77e = true;
                  } catch (_0x2290cc) {}
                  if (!_0x48b77e) {
                    let _0x339cbf = null;
                    try {
                      _0x339cbf = PrefabGeneratorClass.field("_instance")
                        .value.method("get_runner")
                        .invoke();
                    } catch (_0x552515) {}
                    if (_0x339cbf && !_0x339cbf.isNull()) {
                      try {
                        _0x3a5a67
                          .method("RPC_PlayVFX", 4)
                          .invoke(_0x339cbf, vfxIndex, _0x1cd8f2, QuaternionIdentity);
                        _0x48b77e = true;
                      } catch (_0x5d1d91) {}
                    }
                  }
                }
              } catch (_0x54c572) {}
              if (!_0x48b77e) {
                try {
                  let _0x5db174 = null;
                  try {
                    _0x5db174 = PrefabGeneratorClass.field("_instance")
                      .value.method("get_runner")
                      .invoke();
                  } catch (_0xedc4ae) {}
                  if (_0x5db174 && !_0x5db174.isNull()) {
                    try {
                      ParticleManagerAlias.method("RPC_PlayVFX", 4).invoke(
                        _0x5db174,
                        vfxIndex,
                        _0x1cd8f2,
                        QuaternionIdentity,
                      );
                      _0x48b77e = true;
                    } catch (_0x4549fc) {}
                  }
                } catch (_0x5a5ddf) {}
              }
              if (!_0x48b77e) {
                try {
                  ParticleManagerAlias.method("PlayRemoteOnly", 4).invoke(
                    vfxIndex,
                    _0x1cd8f2,
                    QuaternionIdentity,
                    100,
                  );
                  _0x48b77e = true;
                } catch (_0x41c2c8) {}
              }
              const _0x463509 = vfxNameMap[vfxIndex] ?? "ID_" + vfxIndex;
              notify(
                "VFX: " + _0x463509 + " [" + vfxIndex + "]" + (_0x48b77e ? "" : " (no instance)"),
                false,
                2,
              );
            } catch (_0x43c878) {
              notify("Play VFX Net: " + _0x43c878, false);
            }
          }
        },
        toolTip:
          "Toggle on + hold RIGHT GRIP to play the VFX (set via Settings > Change VFX ID) networked so all players see it.",
      }),
      new ButtonInfo({
        buttonText: "Unlock All",
        isTogglable: false,
        method: () => {
          try {
            const _0x3b025b = animalImage.class("AnimalCompany.App");
            const _0x246e67 = _0x3b025b.method("get_state").invoke();
            if (!_0x246e67 || _0x246e67.isNull()) {
              notify("No app state", false);
              return;
            }
            let _0x214128 = null;
            try {
              const _0x3804c7 = _0x246e67.method("get_user").invoke();
              if (_0x3804c7 && !_0x3804c7.isNull()) {
                const _0x1e8181 = _0x3804c7.method("get_inventory").invoke();
                if (_0x1e8181 && !_0x1e8181.isNull()) {
                  _0x214128 = _0x1e8181.method("get_unlockedGameplayItems").invoke();
                }
              }
            } catch (_0x2dff21) {
              smartError("[UnlockAll] inventory:", _0x2dff21);
            }
            let _0x23fea6 = 0;
            try {
              const _0x21001c = _0x246e67.method("get_gameplayItems").invoke();
              if (_0x21001c && !_0x21001c.isNull()) {
                const _0x65a858 = _0x21001c.method("get_all").invoke();
                if (_0x65a858 && !_0x65a858.isNull()) {
                  const _0x59187c = _0x65a858.method("get_Values").invoke();
                  if (_0x59187c && !_0x59187c.isNull()) {
                    const _0x52a392 = _0x59187c.method("GetEnumerator").invoke();
                    while (_0x52a392.method("MoveNext").invoke()) {
                      try {
                        const _0x1badd4 = _0x52a392.method("get_Current").invoke();
                        if (!_0x1badd4 || _0x1badd4.isNull()) {
                          continue;
                        }
                        try {
                          const _0x93cca1 = _0x1badd4.method("get_isUnlocked").invoke();
                          if (_0x93cca1 && !_0x93cca1.isNull()) {
                            _0x93cca1.method("set_value").invoke(true);
                          }
                        } catch (_0x380e09) {}
                        try {
                          const _0x1d83fd = _0x1badd4
                            .method("get_unlockDependenciesSatisfied")
                            .invoke();
                          if (_0x1d83fd && !_0x1d83fd.isNull()) {
                            _0x1d83fd.method("set_value").invoke(true);
                          }
                        } catch (_0x372382) {}
                        try {
                          const _0x3e8a18 = _0x1badd4.method("get_unlockable").invoke();
                          if (_0x3e8a18 && !_0x3e8a18.isNull()) {
                            _0x3e8a18.method("set_value").invoke(true);
                          }
                        } catch (_0x3c3968) {}
                        try {
                          const _0x3ebedb = _0x1badd4.method("get_id").invoke();
                          if (_0x3ebedb && _0x214128 && !_0x214128.isNull()) {
                            _0x214128.method("Add").invoke(_0x3ebedb);
                          }
                        } catch (_0xa695e2) {}
                        _0x23fea6++;
                      } catch (_0x131a7e) {}
                    }
                  }
                }
              }
            } catch (_0x2365f3) {
              smartError("[UnlockAll] gameplayItems:", _0x2365f3);
            }
            let _0x29faf0 = 0;
            try {
              const _0x1b40c5 = _0x246e67.method("get_avatarItems").invoke();
              if (_0x1b40c5 && !_0x1b40c5.isNull()) {
                const _0x111961 = _0x1b40c5.method("get_all").invoke();
                if (_0x111961 && !_0x111961.isNull()) {
                  const _0x3c6cd2 = _0x111961.method("get_Values").invoke();
                  if (_0x3c6cd2 && !_0x3c6cd2.isNull()) {
                    const _0x56f0e7 = _0x3c6cd2.method("GetEnumerator").invoke();
                    while (_0x56f0e7.method("MoveNext").invoke()) {
                      try {
                        const _0xab7b0f = _0x56f0e7.method("get_Current").invoke();
                        if (!_0xab7b0f || _0xab7b0f.isNull()) {
                          continue;
                        }
                        try {
                          const _0x5e9564 = _0xab7b0f.method("get_isOwned").invoke();
                          if (_0x5e9564 && !_0x5e9564.isNull()) {
                            _0x5e9564.method("set_value").invoke(true);
                          }
                        } catch (_0x378a0c) {}
                        try {
                          const _0x1ff612 = _0xab7b0f.method("get_canPurchaseDirectly").invoke();
                          if (_0x1ff612 && !_0x1ff612.isNull()) {
                            _0x1ff612.method("set_value").invoke(true);
                          }
                        } catch (_0x4ec0ad) {}
                        _0x29faf0++;
                      } catch (_0x2fcba6) {}
                    }
                  }
                }
              }
            } catch (_0x496887) {
              smartError("[UnlockAll] avatarItems:", _0x496887);
            }
            notify("Unlocked " + _0x23fea6 + " items + " + _0x29faf0 + " cosmetics!", false);
          } catch (_0x2e31c8) {
            notify("Unlock All: " + _0x2e31c8, false);
            smartError("[UnlockAll]", _0x2e31c8);
          }
        },
        toolTip: "Unlocks all gameplay + cosmetic items including hidden items.",
      }),
      new ButtonInfo({
        buttonText: "Delete All Items",
        method: () => {
          try {
            const _0x15f7e4 = PrefabGeneratorClass.field("_instance")
              .value.method("get_runner")
              .invoke();
            if (!_0x15f7e4 || _0x15f7e4.isNull()) {
              return;
            }
            const _0x1d0540 = UnityObjectClass.method("FindObjectsByType", 1)
              .inflate(AnimalGrabbableObjectClass)
              .invoke(0);
            let _0x37edf5 = 0;
            for (let _0x32c55d = 0; _0x32c55d < _0x1d0540.length; _0x32c55d++) {
              const _0x14edd1 = _0x1d0540.get(_0x32c55d);
              if (!_0x14edd1 || _0x14edd1.handle.isNull()) {
                continue;
              }
              try {
                const _0x3401d6 = _0x14edd1.method("get_Object").invoke();
                if (!_0x3401d6 || _0x3401d6.isNull()) {
                  continue;
                }
                _0x3401d6.method("RequestStateAuthority").invoke();
                _0x15f7e4.method("Despawn").invoke(_0x3401d6);
                _0x37edf5++;
              } catch (_0x4163fb) {}
            }
            notify("NUCLEAR CLEANUP: Deleted " + _0x37edf5 + " items.", false);
          } catch (_0x1518b9) {
            console.error("Nuclear Delete Error: " + _0x1518b9);
          }
        },
        isTogglable: false,
        toolTip: "Takes authority and deletes EVERY item, including those in players' hands.",
      }),
    ],
    [],
    [],
    [],
    [
      new ButtonInfo({
        buttonText: "Exit Credits",
        method: () => {
          currentCategory = 0;
          currentPage = 0;
        },
        isTogglable: false,
        toolTip: "Returns to main menu.",
      }),
      new ButtonInfo({
        buttonText: "Credits to Pingu",
        method: () => {
          notify("Credits to Pingu!", false, 6);
        },
        isTogglable: false,
        toolTip: "Credits to Pingu.",
      }),
    ],
    [],
    [],
    [],
    [
      new ButtonInfo({
        buttonText: "Exit Shooters",
        method: () => {
          currentCategory = 0;
          currentPage = 0;
        },
        isTogglable: false,
        toolTip: "Returns to main menu.",
      }),
      new ButtonInfo({
        buttonText: "Grenade Shooter",
        isTogglable: true,
        method: () => {
          if (!rightGrab) {
            return;
          }
          try {
            const _0x23c349 = _0x2561c6();
            const _0x1dd57e = rightHandTransform.method("get_rotation").invoke();
            const _0x375ae6 = rightHandTransform.method("get_forward").invoke();
            const _0x191bf4 = _0x375ae6.field("x").value;
            const _0x14747d = _0x375ae6.field("y").value;
            const _0x276cf4 = _0x375ae6.field("z").value;
            const _0x3393e5 = _0x5db48f("GrenadeProjectile", _0x23c349, _0x1dd57e);
            if (_0x3393e5 && !_0x3393e5.handle.isNull()) {
              try {
                _0x3393e5.method("RequestStateAuthority").invoke();
              } catch (_0x11e591) {}
              let _0x338d3f = null;
              try {
                _0x338d3f = _0x3393e5
                  .method("GetComponent", 1)
                  .inflate(UnityRigidbodyClass)
                  .invoke();
              } catch (_0x132d45) {}
              if (!_0x338d3f || _0x338d3f.isNull()) {
                try {
                  _0x338d3f = _0x3393e5
                    .method("GetComponentInChildren", 1)
                    .inflate(UnityRigidbodyClass)
                    .invoke();
                } catch (_0x5a23b8) {}
              }
              if (_0x338d3f && !_0x338d3f.isNull()) {
                _0x338d3f.method("set_isKinematic").invoke(false);
                _0x338d3f.method("WakeUp").invoke();
                _0x338d3f
                  .method("set_linearVelocity")
                  .invoke([_0x191bf4 * 25, _0x14747d * 25, _0x276cf4 * 25]);
              }
            }
          } catch (_0x2655c3) {
            console.error("Grenade Shooter Error: " + _0x2655c3);
          }
        },
        toolTip: "Hold grip to spray grenades forward — no cooldown!",
      }),
      new ButtonInfo({
        buttonText: "All In One Shooter",
        method: () => {
          if (!rightGrab) {
            return;
          }
          try {
            const _0x138bec = _0x2561c6();
            const _0x38d350 = rightHandTransform.method("get_rotation").invoke();
            const _0xbf3243 = rightHandTransform.method("get_forward").invoke();
            const _0x582567 = _0xbf3243.field("x").value;
            const _0xa57ac3 = _0xbf3243.field("y").value;
            const _0x13b74f = _0xbf3243.field("z").value;
            const _0xce4676 = (_0x1bc1d9) => {
              const _0x49df8b = _0x5db48f(_0x1bc1d9, _0x138bec, _0x38d350);
              if (_0x49df8b && !_0x49df8b.handle.isNull()) {
                try {
                  _0x49df8b.method("RequestStateAuthority").invoke();
                } catch (_0x1d64a0) {}
                let _0x55f8e9 = null;
                try {
                  _0x55f8e9 = _0x49df8b
                    .method("GetComponent", 1)
                    .inflate(UnityRigidbodyClass)
                    .invoke();
                } catch (_0x3a9fdf) {}
                if (!_0x55f8e9 || _0x55f8e9.isNull()) {
                  try {
                    _0x55f8e9 = _0x49df8b
                      .method("GetComponentInChildren", 1)
                      .inflate(UnityRigidbodyClass)
                      .invoke();
                  } catch (_0x47c2f0) {}
                }
                if (_0x55f8e9 && !_0x55f8e9.isNull()) {
                  _0x55f8e9.method("set_isKinematic").invoke(false);
                  _0x55f8e9.method("WakeUp").invoke();
                  _0x55f8e9
                    .method("set_linearVelocity")
                    .invoke([_0x582567 * 500, _0xa57ac3 * 500, _0x13b74f * 500]);
                }
              }
            };
            _0xce4676("RobotDogRPG");
            _0xce4676("RPGRocket");
            _0xce4676("RPGRocketEgg");
            _0xce4676("GrenadeProjectile");
          } catch (_0x5a51d2) {
            smartError("All In One Shooter", _0x5a51d2);
          }
        },
        isTogglable: true,
        toolTip:
          "Hold grip — fires RobotDogRPG, RPGRocket, RPGRocketEgg, and GrenadeProjectile at velocity 500.",
      }),
      new ButtonInfo({
        buttonText: "Flare Launcher",
        isTogglable: true,
        method: () => {
          if (!rightGrab) {
            return;
          }
          if (time < _flareLauncherNextShot) {
            return;
          }
          _flareLauncherNextShot = time + 0.1;
          try {
            const _0xdc1747 = _0x2561c6();
            const _0x85bafb = rightHandTransform.method("get_rotation").invoke();
            const _0xc86636 = rightHandTransform.method("get_forward").invoke();
            const _0xc814fc = _0xc86636.field("x").value;
            const _0x5c72a2 = _0xc86636.field("y").value;
            const _0xd18fc9 = _0xc86636.field("z").value;
            const _0x308a42 = _0x5db48f("FlareGunProjectile", _0xdc1747, _0x85bafb);
            if (_0x308a42 && !_0x308a42.handle.isNull()) {
              try {
                _0x308a42.method("RequestStateAuthority").invoke();
              } catch (_0x236580) {}
              let _0x338cef = null;
              try {
                _0x338cef = _0x308a42
                  .method("GetComponent", 1)
                  .inflate(UnityRigidbodyClass)
                  .invoke();
              } catch (_0x52e7cc) {}
              if (!_0x338cef || _0x338cef.isNull()) {
                try {
                  _0x338cef = _0x308a42
                    .method("GetComponentInChildren", 1)
                    .inflate(UnityRigidbodyClass)
                    .invoke();
                } catch (_0x15917a) {}
              }
              if (_0x338cef && !_0x338cef.isNull()) {
                _0x338cef.method("set_isKinematic").invoke(false);
                _0x338cef.method("WakeUp").invoke();
                _0x338cef
                  .method("set_linearVelocity")
                  .invoke([_0xc814fc * 20, _0x5c72a2 * 20, _0xd18fc9 * 20]);
              }
            }
          } catch (_0x283aa4) {
            smartError("Flare Launcher", _0x283aa4);
          }
        },
        toolTip: "Hold grip to shoot flares — 0.1s cooldown, velocity 20.",
      }),
      new ButtonInfo({
        buttonText: "RPG Shooter",
        isTogglable: true,
        method: () => {
          if (!rightGrab) {
            return;
          }
          try {
            const _0x54e0bd = _0x2561c6();
            const _0x2bc249 = rightHandTransform.method("get_rotation").invoke();
            const _0x1f204d = rightHandTransform.method("get_forward").invoke();
            const _0xb60014 = _0x1f204d.field("x").value;
            const _0x2d3965 = _0x1f204d.field("y").value;
            const _0x12159c = _0x1f204d.field("z").value;
            const _0x2fed1c = _0x5db48f("RPGRocket", _0x54e0bd, _0x2bc249);
            if (_0x2fed1c && !_0x2fed1c.handle.isNull()) {
              try {
                _0x2fed1c.method("RequestStateAuthority").invoke();
              } catch (_0x2c6a7b) {}
              let _0x230dc4 = null;
              try {
                _0x230dc4 = _0x2fed1c
                  .method("GetComponent", 1)
                  .inflate(UnityRigidbodyClass)
                  .invoke();
              } catch (_0x2d2896) {}
              if (!_0x230dc4 || _0x230dc4.isNull()) {
                try {
                  _0x230dc4 = _0x2fed1c
                    .method("GetComponentInChildren", 1)
                    .inflate(UnityRigidbodyClass)
                    .invoke();
                } catch (_0x43b1d8) {}
              }
              if (_0x230dc4 && !_0x230dc4.isNull()) {
                _0x230dc4.method("set_isKinematic").invoke(false);
                _0x230dc4.method("WakeUp").invoke();
                _0x230dc4
                  .method("set_linearVelocity")
                  .invoke([_0xb60014 * 500, _0x2d3965 * 500, _0x12159c * 500]);
              }
            }
          } catch (_0x3a823b) {
            console.error("RPG Shooter: " + _0x3a823b);
          }
        },
        toolTip: "Hold grip to shoot RPG rockets from your fist.",
      }),
      new ButtonInfo({
        buttonText: "Boom Spear Shooter",
        isTogglable: true,
        method: () => {
          if (!rightGrab) {
            return;
          }
          try {
            const _0x5a6462 = _0x2561c6();
            const _0x556fc7 = rightHandTransform.method("get_rotation").invoke();
            const _0x1cf171 = rightHandTransform.method("get_forward").invoke();
            const _0x1f981f = _0x1cf171.field("x").value;
            const _0x2f7a42 = _0x1cf171.field("y").value;
            const _0x2411b1 = _0x1cf171.field("z").value;
            const _0x18f035 = _0x5db48f("RPGRocketSpear", _0x5a6462, _0x556fc7);
            if (_0x18f035 && !_0x18f035.handle.isNull()) {
              try {
                _0x18f035.method("RequestStateAuthority").invoke();
              } catch (_0x20ab3d) {}
              let _0x1ce4ab = null;
              try {
                _0x1ce4ab = _0x18f035
                  .method("GetComponent", 1)
                  .inflate(UnityRigidbodyClass)
                  .invoke();
              } catch (_0x134ff3) {}
              if (!_0x1ce4ab || _0x1ce4ab.isNull()) {
                try {
                  _0x1ce4ab = _0x18f035
                    .method("GetComponentInChildren", 1)
                    .inflate(UnityRigidbodyClass)
                    .invoke();
                } catch (_0x248439) {}
              }
              if (_0x1ce4ab && !_0x1ce4ab.isNull()) {
                _0x1ce4ab.method("set_isKinematic").invoke(false);
                _0x1ce4ab.method("WakeUp").invoke();
                _0x1ce4ab
                  .method("set_linearVelocity")
                  .invoke([_0x1f981f * 500, _0x2f7a42 * 500, _0x2411b1 * 500]);
              }
            }
          } catch (_0x45b115) {
            console.error("Boom Spear Shooter: " + _0x45b115);
          }
        },
        toolTip: "Hold grip to shoot explosive spears from your fist.",
      }),
      new ButtonInfo({
        buttonText: "RPG + Boomspear Shooter",
        isTogglable: true,
        method: () => {
          if (!rightGrab) {
            return;
          }
          try {
            const _0x2eb76e = _0x2561c6();
            const _0x5f56f3 = rightHandTransform.method("get_rotation").invoke();
            const _0x826e46 = rightHandTransform.method("get_forward").invoke();
            const _0x1b3ef9 = _0x826e46.field("x").value;
            const _0x2a3ba4 = _0x826e46.field("y").value;
            const _0x2b8fbb = _0x826e46.field("z").value;
            const _0x5e81d5 = (_0x2a1007) => {
              const _0x28a618 = _0x5db48f(_0x2a1007, _0x2eb76e, _0x5f56f3);
              if (_0x28a618 && !_0x28a618.handle.isNull()) {
                try {
                  _0x28a618.method("RequestStateAuthority").invoke();
                } catch (_0x326d64) {}
                let _0x171bb3 = null;
                try {
                  _0x171bb3 = _0x28a618
                    .method("GetComponent", 1)
                    .inflate(UnityRigidbodyClass)
                    .invoke();
                } catch (_0x5cd9ef) {}
                if (!_0x171bb3 || _0x171bb3.isNull()) {
                  try {
                    _0x171bb3 = _0x28a618
                      .method("GetComponentInChildren", 1)
                      .inflate(UnityRigidbodyClass)
                      .invoke();
                  } catch (_0x869d75) {}
                }
                if (_0x171bb3 && !_0x171bb3.isNull()) {
                  _0x171bb3.method("set_isKinematic").invoke(false);
                  _0x171bb3.method("WakeUp").invoke();
                  _0x171bb3
                    .method("set_linearVelocity")
                    .invoke([_0x1b3ef9 * 500, _0x2a3ba4 * 500, _0x2b8fbb * 500]);
                }
              }
            };
            _0x5e81d5("RPGRocket");
            _0x5e81d5("RPGRocketSpear");
          } catch (_0x13c331) {
            console.error("RPG + Boomspear Shooter: " + _0x13c331);
          }
        },
        toolTip: "Hold grip — fires RPGRocket and RPGRocketSpear simultaneously at velocity 500.",
      }),
      new ButtonInfo({
        buttonText: "Egg Shooter",
        isTogglable: true,
        method: () => {
          if (!rightGrab) {
            return;
          }
          try {
            const _0x315fe6 = _0x2561c6();
            const _0x4e299f = rightHandTransform.method("get_rotation").invoke();
            const _0x10766d = rightHandTransform.method("get_forward").invoke();
            const _0x446e03 = _0x10766d.field("x").value;
            const _0x4881cd = _0x10766d.field("y").value;
            const _0x337527 = _0x10766d.field("z").value;
            const _0x374c11 = _0x5db48f("RPGRocketEgg", _0x315fe6, _0x4e299f);
            if (_0x374c11 && !_0x374c11.handle.isNull()) {
              try {
                _0x374c11.method("RequestStateAuthority").invoke();
              } catch (_0x19b232) {}
              let _0x5879bf = null;
              try {
                _0x5879bf = _0x374c11
                  .method("GetComponent", 1)
                  .inflate(UnityRigidbodyClass)
                  .invoke();
              } catch (_0x546bd3) {}
              if (!_0x5879bf || _0x5879bf.isNull()) {
                try {
                  _0x5879bf = _0x374c11
                    .method("GetComponentInChildren", 1)
                    .inflate(UnityRigidbodyClass)
                    .invoke();
                } catch (_0x190cf9) {}
              }
              if (_0x5879bf && !_0x5879bf.isNull()) {
                _0x5879bf.method("set_isKinematic").invoke(false);
                _0x5879bf.method("WakeUp").invoke();
                _0x5879bf
                  .method("set_linearVelocity")
                  .invoke([_0x446e03 * 500, _0x4881cd * 500, _0x337527 * 500]);
              }
            }
          } catch (_0x3691d0) {
            console.error("Egg Shooter: " + _0x3691d0);
          }
        },
        toolTip: "Hold grip to shoot explosive egg rockets from your fist.",
      }),
      new ButtonInfo({
        buttonText: "Car Shooter",
        isTogglable: true,
        method: () => {
          if (rightGrab && time > tagGunDelay) {
            tagGunDelay = time + 0.05;
            try {
              const _0x477d90 = _0x2561c6();
              const _0x252f50 = rightHandTransform.method("get_rotation").invoke();
              const _0x53b54b = rightHandTransform.method("get_forward").invoke();
              const _0x4ebec7 = _0x53b54b.field("x").value;
              const _0x11d31c = _0x53b54b.field("y").value;
              const _0x5b6cda = _0x53b54b.field("z").value;
              const _0x548218 = _0x5db48f("Vehicle_Buggy", _0x477d90, _0x252f50);
              if (_0x548218 && !_0x548218.handle.isNull()) {
                try {
                  _0x548218.method("RequestStateAuthority").invoke();
                } catch (_0x18b8f8) {}
                let _0xd7cb0b = null;
                try {
                  _0xd7cb0b = _0x548218
                    .method("GetComponent", 1)
                    .inflate(UnityRigidbodyClass)
                    .invoke();
                } catch (_0x11db56) {}
                if (!_0xd7cb0b || _0xd7cb0b.isNull()) {
                  try {
                    _0xd7cb0b = _0x548218
                      .method("GetComponentInChildren", 1)
                      .inflate(UnityRigidbodyClass)
                      .invoke();
                  } catch (_0xa52c6a) {}
                }
                if (_0xd7cb0b && !_0xd7cb0b.isNull()) {
                  _0xd7cb0b.method("set_isKinematic").invoke(false);
                  _0xd7cb0b.method("WakeUp").invoke();
                  _0xd7cb0b
                    .method("set_linearVelocity")
                    .invoke([_0x4ebec7 * 30, _0x11d31c * 30, _0x5b6cda * 30]);
                }
              }
            } catch (_0x4c2ac0) {
              console.error("Car Shooter: " + _0x4c2ac0);
            }
          }
        },
        toolTip: "Hold grip to shoot buggies from your fist.",
      }),
      new ButtonInfo({
        buttonText: "Robot Dog Shooter",
        isTogglable: true,
        method: () => {
          if (!rightGrab) {
            return;
          }
          try {
            const _0x4707e5 = _0x2561c6();
            const _0x1d59ef = rightHandTransform.method("get_rotation").invoke();
            const _0x5c2c57 = rightHandTransform.method("get_forward").invoke();
            const _0xbd5519 = _0x5c2c57.field("x").value;
            const _0x58b1f0 = _0x5c2c57.field("y").value;
            const _0x35ea13 = _0x5c2c57.field("z").value;
            const _0x51649f = _0x5db48f("RobotDogRPG", _0x4707e5, _0x1d59ef);
            if (_0x51649f && !_0x51649f.handle.isNull()) {
              try {
                _0x51649f.method("RequestStateAuthority").invoke();
              } catch (_0x241507) {}
              let _0x50af1c = null;
              try {
                _0x50af1c = _0x51649f
                  .method("GetComponent", 1)
                  .inflate(UnityRigidbodyClass)
                  .invoke();
              } catch (_0x12630d) {}
              if (!_0x50af1c || _0x50af1c.isNull()) {
                try {
                  _0x50af1c = _0x51649f
                    .method("GetComponentInChildren", 1)
                    .inflate(UnityRigidbodyClass)
                    .invoke();
                } catch (_0x576ec3) {}
              }
              if (_0x50af1c && !_0x50af1c.isNull()) {
                _0x50af1c.method("set_isKinematic").invoke(false);
                _0x50af1c.method("WakeUp").invoke();
                _0x50af1c
                  .method("set_linearVelocity")
                  .invoke([_0xbd5519 * 500, _0x58b1f0 * 500, _0x35ea13 * 500]);
              }
            }
          } catch (_0x29b432) {
            console.error("Robot Dog Shooter: " + _0x29b432);
          }
        },
        toolTip: "Hold grip to launch robot dog RPGs at velocity 500.",
      }),
      new ButtonInfo({
        buttonText: "Balloon Shooter",
        isTogglable: true,
        method: () => {
          if (!rightGrab) {
            return;
          }
          try {
            const _0x4ad184 = _0x2561c6();
            const _0x1e1e42 = rightHandTransform.method("get_forward").invoke();
            const _0x51200c = _0x5db48f("InflatedBalloon", _0x4ad184, QuaternionIdentity);
            if (!_0x51200c || _0x51200c.handle.isNull()) {
              return;
            }
            try {
              _0x51200c.method("RequestStateAuthority").invoke();
            } catch (_0xc0909e) {}
            _0x3843b2(_0x51200c);
            const _0x2c4d83 = _0x1e1e42.field("x").value;
            const _0x19472d = _0x1e1e42.field("y").value;
            const _0x54de4d = _0x1e1e42.field("z").value;
            let _0x14801f = null;
            try {
              _0x14801f = _0x51200c.method("GetComponent", 1).inflate(UnityRigidbodyClass).invoke();
            } catch (_0x48d22e) {}
            if (!_0x14801f || _0x14801f.isNull()) {
              try {
                _0x14801f = _0x51200c
                  .method("GetComponentInChildren", 1)
                  .inflate(UnityRigidbodyClass)
                  .invoke();
              } catch (_0x4633fd) {}
            }
            if (_0x14801f && !_0x14801f.isNull()) {
              _0x14801f.method("set_isKinematic").invoke(false);
              _0x14801f.method("WakeUp").invoke();
              _0x14801f
                .method("set_linearVelocity")
                .invoke([_0x2c4d83 * 75, _0x19472d * 75, _0x54de4d * 75]);
            }
          } catch (_0x5e3cd8) {
            smartError("Rainbow Balloon Gun", _0x5e3cd8);
          }
        },
        toolTip:
          "Hold grip to fire rainbow balloons from your hand — each balloon is a different colour.",
      }),
    ],
    [
      new ButtonInfo({
        buttonText: "Exit Overpowered",
        method: () => {
          currentCategory = 0;
          currentPage = 0;
        },
        isTogglable: false,
        toolTip: "Returns to main menu.",
      }),
      new ButtonInfo({
        buttonText: "TP All To Void",
        isTogglable: false,
        method: () => {
          try {
            const _0x4b454c = UnityObjectClass.method("FindObjectsByType", 1)
              .inflate(NetPlayerClass)
              .invoke(0);
            let _0x4b488e = 0;
            for (let _0x160579 = 0; _0x160579 < _0x4b454c.length; _0x160579++) {
              const _0x2f5063 = _0x4b454c.get(_0x160579);
              if (!_0x2f5063 || _0x2f5063.isNull() || _0x16fc51(_0x2f5063)) {
                continue;
              }
              try {
                _0x2f5063.method("RPC_Teleport").invoke([-9999999, -9999999, -9999999]);
                _0x4b488e++;
              } catch (_0x396d01) {}
            }
            notify("Voided " + _0x4b488e + " player(s)!", false, 2);
          } catch (_0x2c23c9) {
            smartError("TP All To Void", _0x2c23c9);
          }
        },
        toolTip: "Instantly teleports everyone (except you) to -9999999, -9999999, -9999999.",
      }),
      new ButtonInfo({
        buttonText: "Stinky All",
        isTogglable: true,
        method: () => {
          if (!rightGrab) {
            return;
          }
          if (time <= _stinkyAllDelay) {
            return;
          }
          _stinkyAllDelay = time + 0.05;
          try {
            const _0x568562 = UnityObjectClass.method("FindObjectsByType", 1)
              .inflate(NetPlayerClass)
              .invoke(0);
            for (let _0x817e87 = 0; _0x817e87 < _0x568562.length; _0x817e87++) {
              const _0x52d2ac = _0x568562.get(_0x817e87);
              if (!_0x52d2ac || _0x52d2ac.isNull() || _0x16fc51(_0x52d2ac)) {
                continue;
              }
              try {
                _0x52d2ac.method("RPC_TagAsStinky").invoke();
              } catch (_0x3c721e) {}
            }
          } catch (_0x3bbde6) {
            smartError("Stinky All", _0x3bbde6);
          }
        },
        toolTip: "Toggle ON + hold right grip to spam RPC_TagAsStinky on everyone every 0.05s.",
      }),
      new ButtonInfo({
        buttonText: "Fling All Up",
        isTogglable: false,
        method: () => {
          try {
            const _0x168690 = NetPlayerClass.field("playerIDToNetPlayer").value;
            const _0x2e7da6 = _0x168690.method("get_Values").invoke();
            const _0x32467d = _0x2e7da6.method("GetEnumerator").invoke();
            let _0x5785ba = 0;
            while (_0x32467d.method("MoveNext").invoke()) {
              const _0x36b5fc = _0x32467d.method("get_Current").invoke();
              if (!_0x36b5fc || _0x36b5fc.handle.isNull()) {
                continue;
              }
              try {
                if (_0x16fc51(_0x36b5fc)) {
                  _0x18a723(() => _0x36b5fc.method("RPC_AddForce").invoke([0, 1500, 0]));
                } else {
                  _0x36b5fc.method("RPC_AddForce").invoke([0, 1500, 0]);
                }
                _0x5785ba++;
              } catch (_0x13fdf6) {}
            }
            notify("Flung " + _0x5785ba + " players up!", false);
          } catch (_0x323795) {
            console.error("Fling All Up: " + _0x323795);
          }
        },
        toolTip: "Launches all players straight up into the air.",
      }),
      new ButtonInfo({
        buttonText: "Spaz All Players",
        isTogglable: true,
        method: () => {
          if (!rightGrab) {
            return;
          }
          try {
            const _0x3c064e = NetPlayerClass.field("playerIDToNetPlayer").value;
            const _0x4b4f46 = _0x3c064e.method("get_Values").invoke();
            const _0x1d2bb1 = _0x4b4f46.method("GetEnumerator").invoke();
            while (_0x1d2bb1.method("MoveNext").invoke()) {
              const _0x9ff72c = _0x1d2bb1.method("get_Current").invoke();
              if (!_0x9ff72c || _0x9ff72c.handle.isNull() || _0x16fc51(_0x9ff72c)) {
                continue;
              }
              try {
                const _0x56ec62 = (Math.random() - 0.5) * 4;
                const _0x3b3327 = (Math.random() - 0.5) * 1.5;
                const _0x494e8b = (Math.random() - 0.5) * 4;
                _0x9ff72c.method("RPC_AddForce").invoke([_0x56ec62, _0x3b3327, _0x494e8b]);
              } catch (_0x1de11a) {}
            }
          } catch (_0x256547) {
            console.error("Spaz All: " + _0x256547);
          }
        },
        toolTip: "Continuously applies tiny random forces — players shake/spaz in place.",
      }),
      new ButtonInfo({
        buttonText: "Spin All Players",
        isTogglable: true,
        method: () => {
          if (!rightGrab) {
            return;
          }
          if (frameCount % 2 !== 0) {
            return;
          }
          try {
            const _0x374c0d = time * 2.5;
            const _0x429a43 = Math.cos(_0x374c0d) * 2;
            const _0x1fe66b = Math.sin(_0x374c0d) * 2;
            const _0x2d0d40 = NetPlayerClass.field("playerIDToNetPlayer").value;
            const _0x32e195 = _0x2d0d40.method("get_Values").invoke();
            const _0x7c8455 = _0x32e195.method("GetEnumerator").invoke();
            while (_0x7c8455.method("MoveNext").invoke()) {
              const _0x25ea5e = _0x7c8455.method("get_Current").invoke();
              if (!_0x25ea5e || _0x25ea5e.handle.isNull() || _0x16fc51(_0x25ea5e)) {
                continue;
              }
              try {
                _0x25ea5e.method("RPC_AddForce").invoke([_0x429a43, 0, _0x1fe66b]);
              } catch (_0x519338) {}
            }
          } catch (_0x3a445e) {
            console.error("Spin All Players: " + _0x3a445e);
          }
        },
        toolTip: "Applies a rotating force to all players — makes them spin in circles.",
      }),
      new ButtonInfo({
        buttonText: "Kill All Players",
        isTogglable: false,
        method: () => {
          try {
            const _0x13d8ef = DamageSourceInfoClass.method("get_Null").invoke();
            const _0x22c9df = NetPlayerClass.field("playerIDToNetPlayer").value;
            const _0x1dbc36 = _0x22c9df.method("get_Values").invoke();
            const _0x6511ca = _0x1dbc36.method("GetEnumerator").invoke();
            let _0xc2d37e = 0;
            while (_0x6511ca.method("MoveNext").invoke()) {
              const _0x126a16 = _0x6511ca.method("get_Current").invoke();
              if (!_0x126a16 || _0x126a16.handle.isNull() || _0x16fc51(_0x126a16)) {
                continue;
              }
              try {
                const _0x391d5e = _0xe40610(_0x126a16).method("get_position").invoke();
                _0x126a16
                  .method("RPC_PlayerHit", 5)
                  .invoke(9999, _0x391d5e, Vector3Zero, _0x13d8ef, false);
                _0xc2d37e++;
              } catch (_0x1589aa) {}
            }
            notify("Killed " + _0xc2d37e + " players!", false);
          } catch (_0x530d8b) {
            console.error("Kill All Players: " + _0x530d8b);
          }
        },
        toolTip: "Deals 9999 damage to every other player instantly.",
      }),
      new ButtonInfo({
        buttonText: "Give All 100k",
        isTogglable: false,
        method: () => {
          try {
            const _0x512e3c = NetPlayerClass.field("playerIDToNetPlayer").value;
            const _0xa67165 = _0x512e3c.method("get_Values").invoke();
            const _0x38f740 = _0xa67165.method("GetEnumerator").invoke();
            let _0x5807ad = 0;
            while (_0x38f740.method("MoveNext").invoke()) {
              const _0xc1ff4d = _0x38f740.method("get_Current").invoke();
              if (!_0xc1ff4d || _0xc1ff4d.handle.isNull()) {
                continue;
              }
              try {
                if (_0x16fc51(_0xc1ff4d)) {
                  _0x18a723(() => _0xc1ff4d.method("RPC_AddPlayerMoney").invoke(100000));
                } else {
                  _0xc1ff4d.method("RPC_AddPlayerMoney").invoke(100000);
                }
                _0x5807ad++;
              } catch (_0x554665) {}
            }
            notify("Gave $100,000 to " + _0x5807ad + " players!", false);
          } catch (_0x40146f) {
            console.error("Give All 100k: " + _0x40146f);
          }
        },
        toolTip: "Gives every player in the lobby $100,000 per press.",
      }),
      new ButtonInfo({
        buttonText: "Rainbow All",
        isTogglable: true,
        enableMethod: () => {
          notify("Rainbow All ON", false, 2);
        },
        disableMethod: () => {
          notify("Rainbow All OFF", false, 2);
        },
        method: () => {
          if (frameCount % 2 !== 0) {
            return;
          }
          try {
            const _0x1e9953 = (time * 0.333) % 1;
            const _0x5f2b68 = NetPlayerClass.field("playerIDToNetPlayer").value;
            const _0x48bbe7 = _0x5f2b68.method("get_Values").invoke();
            const _0x1aa83c = _0x48bbe7.method("GetEnumerator").invoke();
            while (_0x1aa83c.method("MoveNext").invoke()) {
              const _0x53461e = _0x1aa83c.method("get_Current").invoke();
              if (!_0x53461e || _0x53461e.handle.isNull()) {
                continue;
              }
              try {
                if (_0x16fc51(_0x53461e)) {
                  _0x18a723(() => _0x53461e.method("RPC_SetColorHSV").invoke(0.5, _0x1e9953, 1, 1));
                } else {
                  _0x53461e.method("RPC_SetColorHSV").invoke(0.5, _0x1e9953, 1, 1);
                }
              } catch (_0x4ef5af) {}
            }
          } catch (_0x35ea06) {
            console.error("Rainbow All: " + _0x35ea06);
          }
        },
        toolTip: "Smoothly cycles all players through the full rainbow spectrum.",
      }),
      new ButtonInfo({
        buttonText: "Strobe All",
        isTogglable: true,
        enableMethod: () => {
          notify("Strobe All ON", false, 2);
        },
        disableMethod: () => {
          notify("Strobe All OFF", false, 2);
        },
        method: () => {
          if (frameCount % 3 !== 0) {
            return;
          }
          try {
            const _0x5920a3 = [
              [0, 1, 1],
              [0.33, 1, 1],
              [0.66, 1, 1],
              [0, 0, 1],
            ];
            const _0x5f1929 = Math.floor(frameCount / 3) % _0x5920a3.length;
            const [_0x48a53a, _0x3ee544, _0x5b566d] = _0x5920a3[_0x5f1929];
            const _0x2f30e7 = NetPlayerClass.field("playerIDToNetPlayer").value;
            const _0xd87bcb = _0x2f30e7.method("get_Values").invoke();
            const _0xc95275 = _0xd87bcb.method("GetEnumerator").invoke();
            while (_0xc95275.method("MoveNext").invoke()) {
              const _0x2c5677 = _0xc95275.method("get_Current").invoke();
              if (!_0x2c5677 || _0x2c5677.handle.isNull()) {
                continue;
              }
              try {
                if (_0x16fc51(_0x2c5677)) {
                  _0x18a723(() =>
                    _0x2c5677
                      .method("RPC_SetColorHSV")
                      .invoke(0.1, _0x48a53a, _0x3ee544, _0x5b566d),
                  );
                } else {
                  _0x2c5677.method("RPC_SetColorHSV").invoke(0.1, _0x48a53a, _0x3ee544, _0x5b566d);
                }
              } catch (_0x8dcfeb) {}
            }
          } catch (_0x3f347e) {
            console.error("Strobe All: " + _0x3f347e);
          }
        },
        toolTip: "Rapidly strobes all players R → G → B → White at ~20Hz.",
      }),
      new ButtonInfo({
        buttonText: "Jelly All Players",
        isTogglable: false,
        method: () => {
          try {
            const _0xaef069 = NetPlayerClass.field("playerIDToNetPlayer").value;
            const _0x4739fc = _0xaef069.method("get_Values").invoke();
            const _0xcca960 = _0x4739fc.method("GetEnumerator").invoke();
            let _0x5b1124 = 0;
            while (_0xcca960.method("MoveNext").invoke()) {
              const _0x279a54 = _0xcca960.method("get_Current").invoke();
              if (!_0x279a54 || _0x279a54.handle.isNull()) {
                continue;
              }
              try {
                if (_0x16fc51(_0x279a54)) {
                  _0x18a723(() => _0x279a54.method("RPC_SetJellyEffect").invoke(9999, 10));
                } else {
                  _0x279a54.method("RPC_SetJellyEffect").invoke(9999, 10);
                }
                _0x5b1124++;
              } catch (_0x4f0aed) {}
            }
            notify("Jellified " + _0x5b1124 + " players!", false);
          } catch (_0x140da2) {
            console.error("Jelly All Players: " + _0x140da2);
          }
        },
        toolTip: "Applies max-strength jelly wobble to all other players.",
      }),
      new ButtonInfo({
        buttonText: "Unjelly All Players",
        isTogglable: false,
        method: () => {
          try {
            const _0x1324a8 = NetPlayerClass.field("playerIDToNetPlayer").value;
            const _0x9a6a0f = _0x1324a8.method("get_Values").invoke();
            const _0x1ff616 = _0x9a6a0f.method("GetEnumerator").invoke();
            let _0x5742e6 = 0;
            while (_0x1ff616.method("MoveNext").invoke()) {
              const _0x28806d = _0x1ff616.method("get_Current").invoke();
              if (!_0x28806d || _0x28806d.handle.isNull()) {
                continue;
              }
              try {
                if (_0x16fc51(_0x28806d)) {
                  _0x18a723(() => _0x28806d.method("RPC_SetJellyEffect").invoke(0, 0));
                } else {
                  _0x28806d.method("RPC_SetJellyEffect").invoke(0, 0);
                }
                _0x5742e6++;
              } catch (_0x48a238) {}
            }
            notify("Unjellified " + _0x5742e6 + " players!", false);
          } catch (_0x16a816) {
            console.error("Unjelly All Players: " + _0x16a816);
          }
        },
        toolTip: "Removes the jelly effect from all other players.",
      }),
      new ButtonInfo({
        buttonText: "Earthquake All",
        isTogglable: false,
        method: () => {
          try {
            const _0x53b081 = NetPlayerClass.field("playerIDToNetPlayer").value;
            const _0x4d3da2 = _0x53b081.method("get_Values").invoke();
            const _0x5db48a = _0x4d3da2.method("GetEnumerator").invoke();
            let _0x371aff = 0;
            while (_0x5db48a.method("MoveNext").invoke()) {
              const _0x39f3e3 = _0x5db48a.method("get_Current").invoke();
              if (!_0x39f3e3 || _0x39f3e3.handle.isNull() || _0x16fc51(_0x39f3e3)) {
                continue;
              }
              try {
                _0x39f3e3.method("RPC_ShakeScreen").invoke(8, 0.2, 1, 20, 15);
                _0x371aff++;
              } catch (_0x20bcc6) {}
            }
            notify("Earthquake on " + _0x371aff + " players!", false);
          } catch (_0xfd0069) {
            console.error("Earthquake All: " + _0xfd0069);
          }
        },
        toolTip: "Massive screen shake on all players for 8 seconds.",
      }),
      new ButtonInfo({
        buttonText: "Radioactive All",
        isTogglable: false,
        method: () => {
          try {
            const _0x1fab38 = NetPlayerClass.field("playerIDToNetPlayer").value;
            const _0x56e573 = _0x1fab38.method("get_Values").invoke();
            const _0x514f5c = _0x56e573.method("GetEnumerator").invoke();
            let _0x2799eb = 0;
            while (_0x514f5c.method("MoveNext").invoke()) {
              const _0x5e4cd7 = _0x514f5c.method("get_Current").invoke();
              if (!_0x5e4cd7 || _0x5e4cd7.handle.isNull() || _0x16fc51(_0x5e4cd7)) {
                continue;
              }
              try {
                _0x5e4cd7.method("RPC_SetRadioActive").invoke(9999, true, 100);
                _0x2799eb++;
              } catch (_0x5e349b) {}
            }
            notify("Nuked " + _0x2799eb + " players!", false);
          } catch (_0x3b60bc) {
            console.error("Radioactive All: " + _0x3b60bc);
          }
        },
        toolTip: "Makes all players permanently radioactive with screen effect.",
      }),
      new ButtonInfo({
        buttonText: "Unradioactive All",
        isTogglable: false,
        method: () => {
          try {
            const _0x160869 = NetPlayerClass.field("playerIDToNetPlayer").value;
            const _0x284d94 = _0x160869.method("get_Values").invoke();
            const _0x59a5ce = _0x284d94.method("GetEnumerator").invoke();
            let _0x309b60 = 0;
            while (_0x59a5ce.method("MoveNext").invoke()) {
              const _0x342ffd = _0x59a5ce.method("get_Current").invoke();
              if (!_0x342ffd || _0x342ffd.handle.isNull()) {
                continue;
              }
              try {
                if (_0x16fc51(_0x342ffd)) {
                  _0x18a723(() => _0x342ffd.method("RPC_SetRadioActive").invoke(0, false, 0));
                } else {
                  _0x342ffd.method("RPC_SetRadioActive").invoke(0, false, 0);
                }
                _0x309b60++;
              } catch (_0xfd17f1) {}
            }
            notify("Cured " + _0x309b60 + " players!", false);
          } catch (_0xb87f18) {
            console.error("Unradioactive All: " + _0xb87f18);
          }
        },
        toolTip: "Removes the radioactive effect from all players.",
      }),
      new ButtonInfo({
        buttonText: "Revive All",
        isTogglable: false,
        method: () => {
          try {
            const _0x409e4d = NetPlayerClass.field("playerIDToNetPlayer").value;
            const _0xf1f957 = _0x409e4d.method("get_Values").invoke();
            const _0xa3417e = _0xf1f957.method("GetEnumerator").invoke();
            let _0x559bad = 0;
            while (_0xa3417e.method("MoveNext").invoke()) {
              const _0x53fd5a = _0xa3417e.method("get_Current").invoke();
              if (!_0x53fd5a || _0x53fd5a.handle.isNull()) {
                continue;
              }
              try {
                if (_0x16fc51(_0x53fd5a)) {
                  _0x18a723(() => _0x53fd5a.method("RPC_DoPlayerDie").invoke(false));
                } else {
                  _0x53fd5a.method("RPC_DoPlayerDie").invoke(false);
                }
                _0x559bad++;
              } catch (_0x5f0a4e) {}
            }
            notify("Revived " + _0x559bad + " player(s)!", false);
          } catch (_0x587068) {
            smartError("Revive All", _0x587068);
          }
        },
        toolTip: "Revives all players in the lobby.",
      }),
      new ButtonInfo({
        buttonText: "VFX Hand Spam",
        isTogglable: true,
        method: () => {
          if (time <= _vfxHandSpamDelay) {
            return;
          }
          _vfxHandSpamDelay = time + 0;
          try {
            const _0x500d86 = [174, 170, 180, 33, 42, 43, 182, 183, 44];
            const _0x3d28c7 = _0x500d86[Math.floor(Math.random() * _0x500d86.length)];
            const _0x23b611 = SfxManagerClass.field("_instance")
              .value.method("get__currentRunner")
              .invoke();
            const _0x86891f = rightHandTransform.method("get_position").invoke();
            try {
              ParticleManagerAlias.method("RPC_PlayVFX", 4).invoke(
                _0x23b611,
                _0x3d28c7,
                _0x86891f,
                QuaternionIdentity,
              );
            } catch (_0x285ef6) {
              try {
                ParticleManagerAlias.method("RPC_PlayVFX", 3).invoke(
                  _0x23b611,
                  _0x3d28c7,
                  _0x86891f,
                );
              } catch (_0x37391e) {}
            }
          } catch (_0x1b78fa) {
            smartError("VFX Hand Spam", _0x1b78fa);
          }
        },
        toolTip: "Spams random VFX effects on your right hand every frame.",
      }),
      new ButtonInfo({
        buttonText: "No Container Restrict",
        isTogglable: true,
        enableMethod: () => {
          containerFreedomAuraEnabled = true;
          notify("No Container Restrictions ON", false);
        },
        disableMethod: () => {
          containerFreedomAuraEnabled = false;
          notify("No Container Restrictions OFF", false);
        },
        toolTip:
          "Force-sets all item flags so items can go into any bag/quiver/container. Sweeps every 0.45s.",
      }),
      new ButtonInfo({
        buttonText: "Right Hand Duper",
        enableMethod: () => {
          heldItemDuplicateDelay = 0;
          notify("Right Hand Duper ON", false);
        },
        disableMethod: () => {
          notify("Right Hand Duper OFF", false);
        },
        isTogglable: true,
        method: () => {
          var _0x306ca5;
          if (time <= heldItemDuplicateDelay) {
            return;
          }
          heldItemDuplicateDelay = time + 0.075;
          try {
            const _0x3ac708 = NetPlayerClass.method("get_localPlayer").invoke();
            if (
              !_0x3ac708 ||
              ((_0x306ca5 = _0x3ac708.isNull) === null || _0x306ca5 === undefined
                ? undefined
                : _0x306ca5.call(_0x3ac708))
            ) {
              return;
            }
            _0x583465(_0x3ac708, 14);
          } catch (_0x36dcb5) {
            console.error("Right Hand Duper:", _0x36dcb5);
          }
        },
        toolTip: "Rapidly duplicates the item in your right hand and throws the copies forward.",
      }),
      new ButtonInfo({
        buttonText: "Speed Boost All",
        isTogglable: false,
        method: () => {
          try {
            const _0x19a8aa = NetPlayerClass.field("playerIDToNetPlayer").value;
            const _0x1ffdb7 = _0x19a8aa.method("get_Values").invoke();
            const _0x59164b = _0x1ffdb7.method("GetEnumerator").invoke();
            let _0x2ab943 = 0;
            while (_0x59164b.method("MoveNext").invoke()) {
              const _0x521383 = _0x59164b.method("get_Current").invoke();
              if (!_0x521383 || _0x521383.handle.isNull()) {
                continue;
              }
              try {
                if (_0x16fc51(_0x521383)) {
                  _0x18a723(() => _0x521383.method("RPC_ApplyBuff").invoke(15));
                } else {
                  _0x521383.method("RPC_ApplyBuff").invoke(15);
                }
                _0x2ab943++;
              } catch (_0x1ff0a5) {}
            }
            notify("Speed boosted " + _0x2ab943 + " players!", false);
          } catch (_0x30be54) {
            console.error("Speed Boost All: " + _0x30be54);
          }
        },
        toolTip: "Applies speed boost buff to all players.",
      }),
      new ButtonInfo({
        buttonText: "No Gravity All",
        isTogglable: false,
        method: () => {
          try {
            const _0x1adea4 = NetPlayerClass.field("playerIDToNetPlayer").value;
            const _0x326584 = _0x1adea4.method("get_Values").invoke();
            const _0x4f6d4d = _0x326584.method("GetEnumerator").invoke();
            let _0x97aa8f = 0;
            while (_0x4f6d4d.method("MoveNext").invoke()) {
              const _0x2973a4 = _0x4f6d4d.method("get_Current").invoke();
              if (!_0x2973a4 || _0x2973a4.handle.isNull()) {
                continue;
              }
              try {
                if (_0x16fc51(_0x2973a4)) {
                  _0x18a723(() => _0x2973a4.method("RPC_ApplyBuff").invoke(14));
                } else {
                  _0x2973a4.method("RPC_ApplyBuff").invoke(14);
                }
                _0x97aa8f++;
              } catch (_0x5ac87f) {}
            }
            notify("No gravity on " + _0x97aa8f + " players!", false);
          } catch (_0x20bc26) {
            console.error("No Gravity All: " + _0x20bc26);
          }
        },
        toolTip: "Removes gravity from all players.",
      }),
      new ButtonInfo({
        buttonText: "Squeaky All",
        isTogglable: false,
        method: () => {
          try {
            const _0x238277 = NetPlayerClass.field("playerIDToNetPlayer").value;
            const _0x118c9e = _0x238277.method("get_Values").invoke();
            const _0x33fab9 = _0x118c9e.method("GetEnumerator").invoke();
            let _0xeba685 = 0;
            while (_0x33fab9.method("MoveNext").invoke()) {
              const _0x29f375 = _0x33fab9.method("get_Current").invoke();
              if (!_0x29f375 || _0x29f375.handle.isNull()) {
                continue;
              }
              try {
                if (_0x16fc51(_0x29f375)) {
                  _0x18a723(() => _0x29f375.method("RPC_SetSqueakyVoiceEnabled").invoke(true));
                } else {
                  _0x29f375.method("RPC_SetSqueakyVoiceEnabled").invoke(true);
                }
                _0xeba685++;
              } catch (_0x40123a) {}
            }
            notify("Squeaked " + _0xeba685 + " players!", false);
          } catch (_0x5064a2) {
            console.error("Squeaky All: " + _0x5064a2);
          }
        },
        toolTip: "Makes all players sound like squeaky toys.",
      }),
      new ButtonInfo({
        buttonText: "Muffled All",
        isTogglable: false,
        method: () => {
          try {
            const _0x215524 = NetPlayerClass.field("playerIDToNetPlayer").value;
            const _0x42d6d6 = _0x215524.method("get_Values").invoke();
            const _0x3630fd = _0x42d6d6.method("GetEnumerator").invoke();
            let _0x27298a = 0;
            while (_0x3630fd.method("MoveNext").invoke()) {
              const _0x49564b = _0x3630fd.method("get_Current").invoke();
              if (!_0x49564b || _0x49564b.handle.isNull()) {
                continue;
              }
              try {
                if (_0x16fc51(_0x49564b)) {
                  _0x18a723(() => _0x49564b.method("RPC_SetMuffledVoiceEnabled").invoke(true));
                } else {
                  _0x49564b.method("RPC_SetMuffledVoiceEnabled").invoke(true);
                }
                _0x27298a++;
              } catch (_0x2cf8ea) {}
            }
            notify("Muffled " + _0x27298a + " players!", false);
          } catch (_0x53189e) {
            console.error("Muffled All: " + _0x53189e);
          }
        },
        toolTip: "Muffles the voices of all other players.",
      }),
      new ButtonInfo({
        buttonText: "Normal Voice All",
        isTogglable: false,
        method: () => {
          try {
            const _0x4b7373 = NetPlayerClass.field("playerIDToNetPlayer").value;
            const _0x2a8da0 = _0x4b7373.method("get_Values").invoke();
            const _0xd378ae = _0x2a8da0.method("GetEnumerator").invoke();
            let _0x357656 = 0;
            while (_0xd378ae.method("MoveNext").invoke()) {
              const _0x42f7c4 = _0xd378ae.method("get_Current").invoke();
              if (!_0x42f7c4 || _0x42f7c4.handle.isNull()) {
                continue;
              }
              try {
                if (_0x16fc51(_0x42f7c4)) {
                  _0x18a723(() => {
                    _0x42f7c4.method("RPC_SetSqueakyVoiceEnabled").invoke(false);
                    _0x42f7c4.method("RPC_SetMuffledVoiceEnabled").invoke(false);
                  });
                } else {
                  _0x42f7c4.method("RPC_SetSqueakyVoiceEnabled").invoke(false);
                  _0x42f7c4.method("RPC_SetMuffledVoiceEnabled").invoke(false);
                }
                _0x357656++;
              } catch (_0xadaaec) {}
            }
            notify("Restored normal voice for " + _0x357656 + " players!", false);
          } catch (_0x47e1f3) {
            console.error("Normal Voice All: " + _0x47e1f3);
          }
        },
        toolTip: "Removes squeaky and muffled voice effects from all players.",
      }),
      new ButtonInfo({
        buttonText: "Sellingmachine Spiral",
        method: () => {
          const _0xb7f2d9 = _0xe40610(headCollider).method("get_position").invoke();
          const _0x364c7f = 80;
          const _0x50080c = 7.5;
          const _0x38fd6c = 6;
          const _0x53c990 = 4;
          const _0x2f37bd = 1.5;
          const _0x47f0db = _0x38fd6c / _0x364c7f;
          if (orbitprefabs.length < _0x364c7f) {
            orbiters = [];
            orbitprefabs = [];
            for (let _0x3bfec0 = 0; _0x3bfec0 < _0x364c7f; _0x3bfec0++) {
              const _0x5aa3ee = ((Math.PI * 2) / _0x364c7f) * _0x3bfec0;
              const _0x22ff83 = (_0x3bfec0 - _0x364c7f / 2) * _0x47f0db;
              const _0x3cff7c = Math.cos(_0x5aa3ee) * _0x50080c;
              const _0x279b6c = Math.sin(_0x5aa3ee) * _0x50080c;
              const _0x420a15 = Vector3Class.method("op_Addition").invoke(_0xb7f2d9, [
                _0x3cff7c,
                _0x22ff83,
                _0x279b6c,
              ]);
              const _0x1b1665 = _0x5db48f(
                "ItemSellingMachineController",
                _0x420a15,
                QuaternionIdentity,
              );
              if (!_0x1b1665 || _0x1b1665.isNull()) {
                continue;
              }
              orbitprefabs.push(_0x1b1665);
              const _0x6ce851 = _0x1b1665.method("get_gameObject").invoke();
              if (!_0x6ce851 || _0x6ce851.isNull()) {
                continue;
              }
              const _0x46da9d = _0xe40610(_0x6ce851);
              orbiters.push({
                transform: _0x46da9d,
                angle: _0x5aa3ee,
                radius: _0x50080c,
                yOffset: _0x22ff83,
              });
            }
          }
          const _0x4d063c = TimeClass.method("get_deltaTime").invoke();
          const _0x748c32 = _0xe40610(headCollider).method("get_position").invoke();
          const _0x5871f8 = Date.now() / 1000;
          for (let _0x140a66 = 0; _0x140a66 < orbiters.length; _0x140a66++) {
            const _0xf11a0b = orbiters[_0x140a66];
            _0xf11a0b.angle += _0x53c990 * _0x4d063c;
            const _0x3b3ccd = Math.cos(_0xf11a0b.angle) * _0xf11a0b.radius;
            const _0x56fcf4 = Math.sin(_0xf11a0b.angle) * _0xf11a0b.radius;
            const _0x4f60ce =
              Math.sin(_0x5871f8 * _0x2f37bd + (_0x140a66 / _0x364c7f) * Math.PI * 2) *
              (_0x38fd6c / 2);
            const _0x5cb99b = Vector3Class.method("op_Addition").invoke(_0x748c32, [
              _0x3b3ccd,
              _0xf11a0b.yOffset + _0x4f60ce,
              _0x56fcf4,
            ]);
            try {
              _0xf11a0b.transform.method("set_position").invoke(_0x5cb99b);
            } catch (_0x563854) {}
          }
        },
        disableMethod: () => {
          for (let _0x59c06c = 0; _0x59c06c < orbitprefabs.length; _0x59c06c++) {
            try {
              const _0xff6efc = orbitprefabs[_0x59c06c];
              if (!_0xff6efc || _0xff6efc.isNull()) {
                continue;
              }
              _0x1706ac(_0xff6efc);
            } catch (_0x2d6354) {}
          }
          orbitprefabs = [];
          orbiters = [];
        },
        isTogglable: true,
        toolTip: "Spawns a spiral helix of selling machines around you.",
      }),
      new ButtonInfo({
        buttonText: "Spam Explode All",
        isTogglable: true,
        method: () => {
          if (!rightGrab) {
            return;
          }
          if (time < _explodeAllDelay) {
            return;
          }
          _explodeAllDelay = time + 0.2;
          try {
            const _0x258d47 = Vector3Class.method("get_up").invoke();
            const _0x15069d = Vector3Class.method("op_Multiply", 2).invoke(_0x258d47, 3);
            const _0x3a46a7 = NetPlayerClass.field("playerIDToNetPlayer").value;
            const _0x3679a2 = _0x3a46a7.method("get_Values").invoke();
            const _0x44ec40 = _0x3679a2.method("GetEnumerator").invoke();
            while (_0x44ec40.method("MoveNext").invoke()) {
              const _0x50848b = _0x44ec40.method("get_Current").invoke();
              if (!_0x50848b || _0x50848b.handle.isNull()) {
                continue;
              }
              try {
                const _0x578ed5 = _0xe40610(_0x50848b).method("get_position").invoke();
                const _0x4da188 = Vector3Class.method("op_Addition", 2).invoke(
                  _0x578ed5,
                  _0x15069d,
                );
                const _0x463c59 = _0x5db48f("RPGRocket", _0x4da188, QuaternionIdentity);
                if (_0x463c59 && !_0x463c59.handle.isNull()) {
                  try {
                    _0x463c59.method("RequestStateAuthority").invoke();
                  } catch (_0x28f2ab) {}
                  let _0x54fcca = null;
                  try {
                    _0x54fcca = _0x463c59
                      .method("GetComponent", 1)
                      .inflate(UnityRigidbodyClass)
                      .invoke();
                  } catch (_0x3a3222) {}
                  if (!_0x54fcca || _0x54fcca.isNull()) {
                    try {
                      _0x54fcca = _0x463c59
                        .method("GetComponentInChildren", 1)
                        .inflate(UnityRigidbodyClass)
                        .invoke();
                    } catch (_0x4345f0) {}
                  }
                  if (_0x54fcca && !_0x54fcca.isNull()) {
                    _0x54fcca.method("set_isKinematic").invoke(false);
                    _0x54fcca.method("WakeUp").invoke();
                    _0x54fcca.method("set_linearVelocity").invoke([0, -50, 0]);
                  }
                }
              } catch (_0x46c280) {}
            }
          } catch (_0x5e1566) {
            smartError("Spam Explode All", _0x5e1566);
          }
        },
        toolTip:
          "Hold grip — spawns RPGRocket above each player's head shooting down. 0.2s cooldown.",
      }),
      new ButtonInfo({
        buttonText: "Drop All Items",
        isTogglable: false,
        method: () => {
          try {
            const _0x1ccfb8 = PrefabGeneratorClass.field("_instance").value;
            if (!_0x1ccfb8 || _0x1ccfb8.isNull()) {
              notify("PrefabGen not ready", false);
              return;
            }
            const _0x491f44 = _0x1ccfb8.method("get_runner").invoke();
            if (!_0x491f44 || _0x491f44.isNull()) {
              notify("Runner is null", false);
              return;
            }
            const _0x1749c8 = NetPlayerClass.field("playerIDToNetPlayer").value;
            const _0x578968 = _0x1749c8.method("get_Values").invoke();
            const _0x53e669 = _0x578968.method("GetEnumerator").invoke();
            let _0x1b3ba1 = 0;
            while (_0x53e669.method("MoveNext").invoke()) {
              const _0x5463c7 = _0x53e669.method("get_Current").invoke();
              if (!_0x5463c7 || _0x5463c7.handle.isNull()) {
                continue;
              }
              const _0x59234a = (_0x52010d) => {
                if (!_0x52010d || _0x52010d.isNull()) {
                  return;
                }
                try {
                  const _0x2abc1b = _0x52010d.method("get_grabbableObject").invoke();
                  if (!_0x2abc1b || _0x2abc1b.isNull()) {
                    return;
                  }
                  try {
                    const _0x4242c8 = _0x2abc1b.method("get_Object").invoke();
                    if (_0x4242c8 && !_0x4242c8.isNull()) {
                      _0x4242c8.method("RequestStateAuthority").invoke();
                    }
                  } catch (_0x5cccfc) {}
                  try {
                    _0x52010d.method("RPC_DropObject").invoke();
                  } catch (_0x2a59af) {}
                  try {
                    _0x2abc1b.method("RPC_Release").invoke();
                  } catch (_0x56edf8) {}
                } catch (_0x2f1baf) {}
              };
              try {
                const _0x4e2e85 = _0x5463c7.method("get_anchors").invoke();
                if (_0x4e2e85 && !_0x4e2e85.isNull()) {
                  for (let _0x2b3442 = 0; _0x2b3442 < _0x4e2e85.length; _0x2b3442++) {
                    try {
                      _0x59234a(_0x4e2e85.get(_0x2b3442));
                    } catch (_0x26c1f0) {}
                  }
                }
              } catch (_0x3fe533) {}
              for (const _0x29e12b of [
                "get_backItemAttachAnchor",
                "get_leftHipItemAttachAnchor",
                "get_rightHipItemAttachAnchor",
              ]) {
                try {
                  _0x59234a(_0x5463c7.method(_0x29e12b).invoke());
                } catch (_0xd843d3) {}
              }
              _0x1b3ba1++;
            }
            notify("Force-dropped items on " + _0x1b3ba1 + " players!", false);
          } catch (_0x2db5ba) {
            smartError("[Drop All Items]", _0x2db5ba);
          }
        },
        toolTip: "Takes authority on each player's held items then force-drops them.",
      }),
      new ButtonInfo({
        buttonText: "Kidnap All",
        isTogglable: false,
        method: () => {
          try {
            const _0x5c8cfb = rightHandTransform.method("get_position").invoke();
            const _0xade861 = _0x5db48f("Basketball", _0x5c8cfb, QuaternionIdentity);
            if (!_0xade861 || _0xade861.isNull()) {
              notify("Spawn failed", false);
              return;
            }
            try {
              const _0x4f4dc8 = _0xade861
                .method("GetComponent", 1)
                .inflate(AnimalGrabbableObjectClass)
                .invoke();
              if (_0x4f4dc8 && !_0x4f4dc8.isNull()) {
                _0x4f4dc8.method("set_scaleModifier").invoke(-100);
              }
            } catch (_0x1efa5b) {}
            const _0x4b151a = UnityObjectClass.method("FindObjectsByType", 1)
              .inflate(NetPlayerClass)
              .invoke(0);
            let _0x1f7f0f = 0;
            for (let _0x539858 = 0; _0x539858 < _0x4b151a.length; _0x539858++) {
              const _0x1d266d = _0x4b151a.get(_0x539858);
              if (!_0x1d266d || _0x1d266d.isNull() || _0x16fc51(_0x1d266d)) {
                continue;
              }
              _0x3218db(_0x1d266d, _0xade861);
              _0x1f7f0f++;
            }
            notify("Kidnapped " + _0x1f7f0f + " player(s)", false);
          } catch (_0x181f74) {
            smartError("Kidnap All", _0x181f74);
          }
        },
        toolTip:
          "Spawns a basketball on your right hand and traps everyone in the lobby inside it.",
      }),
      new ButtonInfo({
        buttonText: "Kick All",
        isTogglable: true,
        method: () => {
          if (!rightGrab) {
            return;
          }
          if (time <= _kickAllDelay) {
            return;
          }
          _kickAllDelay = time + 1;
          _0x189507();
        },
        toolTip: "Toggle ON + hold right grip to kick everyone from the lobby.",
      }),
      new ButtonInfo({
        buttonText: "Kick On Touch",
        isTogglable: true,
        method: () => {
          if (time <= _kickTouchDelay) {
            return;
          }
          try {
            const _0x218431 = rightHandTransform.method("get_position").invoke();
            const _0x458f20 = leftHandTransform.method("get_position").invoke();
            const _0xa79154 = _0x218431.field("x").value;
            const _0x11f946 = _0x218431.field("y").value;
            const _0x5b52cb = _0x218431.field("z").value;
            const _0x4ed735 = _0x458f20.field("x").value;
            const _0x1ab133 = _0x458f20.field("y").value;
            const _0x2b9ca9 = _0x458f20.field("z").value;
            const _0x4e8fa2 = 0.3;
            const _0xeafa31 = UnityObjectClass.method("FindObjectsByType", 1)
              .inflate(NetPlayerClass)
              .invoke(0);
            for (let _0x2dda48 = 0; _0x2dda48 < _0xeafa31.length; _0x2dda48++) {
              const _0x1826ed = _0xeafa31.get(_0x2dda48);
              if (!_0x1826ed || _0x1826ed.isNull() || _0x16fc51(_0x1826ed)) {
                continue;
              }
              const _0x1fcff6 = _0xe40610(_0x1826ed).method("get_position").invoke();
              const _0x8c1156 = _0x1fcff6.field("x").value;
              const _0x430dc0 = _0x1fcff6.field("y").value;
              const _0x2f6e6d = _0x1fcff6.field("z").value;
              const _0x59cc16 = Math.sqrt(
                (_0x8c1156 - _0xa79154) * (_0x8c1156 - _0xa79154) +
                  (_0x430dc0 - _0x11f946) * (_0x430dc0 - _0x11f946) +
                  (_0x2f6e6d - _0x5b52cb) * (_0x2f6e6d - _0x5b52cb),
              );
              const _0x185fd8 = Math.sqrt(
                (_0x8c1156 - _0x4ed735) * (_0x8c1156 - _0x4ed735) +
                  (_0x430dc0 - _0x1ab133) * (_0x430dc0 - _0x1ab133) +
                  (_0x2f6e6d - _0x2b9ca9) * (_0x2f6e6d - _0x2b9ca9),
              );
              if (_0x59cc16 < _0x4e8fa2 || _0x185fd8 < _0x4e8fa2) {
                _0x28e89c(_0x1826ed);
                _kickTouchDelay = time + 1;
                notify("Kicked " + getPlayerName(_0x1826ed) + "!", false, 1.5);
                break;
              }
            }
          } catch (_0x466043) {
            smartError("Kick On Touch", _0x466043);
          }
        },
        toolTip: "Toggle ON — any player within 0.3 m of either hand gets kicked.",
      }),
      new ButtonInfo({
        buttonText: "Kill On Touch",
        isTogglable: true,
        method: () => {
          if (time <= _kickTouchDelay) {
            return;
          }
          try {
            const _0x41bc99 = rightHandTransform.method("get_position").invoke();
            const _0x51062c = leftHandTransform.method("get_position").invoke();
            const _0x2d849f = _0x41bc99.field("x").value;
            const _0x6204f8 = _0x41bc99.field("y").value;
            const _0x517886 = _0x41bc99.field("z").value;
            const _0x1b435a = _0x51062c.field("x").value;
            const _0x3da393 = _0x51062c.field("y").value;
            const _0x389b96 = _0x51062c.field("z").value;
            const _0x5333eb = 0.3;
            const _0x1cc415 = UnityObjectClass.method("FindObjectsByType", 1)
              .inflate(NetPlayerClass)
              .invoke(0);
            for (let _0x980f71 = 0; _0x980f71 < _0x1cc415.length; _0x980f71++) {
              const _0x25b498 = _0x1cc415.get(_0x980f71);
              if (!_0x25b498 || _0x25b498.isNull() || _0x16fc51(_0x25b498)) {
                continue;
              }
              const _0x23f2ad = _0xe40610(_0x25b498).method("get_position").invoke();
              const _0x7eb990 = _0x23f2ad.field("x").value;
              const _0x5a8d92 = _0x23f2ad.field("y").value;
              const _0x6f696a = _0x23f2ad.field("z").value;
              const _0x262c21 = Math.sqrt(
                (_0x7eb990 - _0x2d849f) * (_0x7eb990 - _0x2d849f) +
                  (_0x5a8d92 - _0x6204f8) * (_0x5a8d92 - _0x6204f8) +
                  (_0x6f696a - _0x517886) * (_0x6f696a - _0x517886),
              );
              const _0x5db0a2 = Math.sqrt(
                (_0x7eb990 - _0x1b435a) * (_0x7eb990 - _0x1b435a) +
                  (_0x5a8d92 - _0x3da393) * (_0x5a8d92 - _0x3da393) +
                  (_0x6f696a - _0x389b96) * (_0x6f696a - _0x389b96),
              );
              if (_0x262c21 < _0x5333eb || _0x5db0a2 < _0x5333eb) {
                try {
                  const _0x3e6104 = DamageSourceInfoClass.method("get_Null").invoke();
                  const _0x1085c3 = _0xe40610(_0x25b498).method("get_position").invoke();
                  _0x25b498
                    .method("RPC_PlayerHit", 5)
                    .invoke(9999, _0x1085c3, Vector3Zero, _0x3e6104, false);
                } catch (_0xd82f64) {}
                _kickTouchDelay = time + 0.3;
                notify("Killed " + getPlayerName(_0x25b498) + "!", false, 1.5);
                break;
              }
            }
          } catch (_0x961194) {
            smartError("Kill On Touch", _0x961194);
          }
        },
        toolTip: "Toggle ON — any player within 0.3 m of either hand instantly dies.",
      }),
      new ButtonInfo({
        buttonText: "Magnet All Items",
        isTogglable: true,
        method: () => {
          if (!rightGrab) {
            return;
          }
          if (frameCount % 2 !== 0) {
            return;
          }
          try {
            const _0x439f2e = rightHandTransform.method("get_position").invoke();
            const _0x424fd4 = _0x439f2e.field("x").value;
            const _0x2ca9c1 = _0x439f2e.field("y").value;
            const _0x1b2fd8 = _0x439f2e.field("z").value;
            try {
              const _0x3aa9f5 = NetPlayerClass.field("playerIDToNetPlayer").value;
              if (_0x3aa9f5 && !_0x3aa9f5.isNull()) {
                const _0x55aba7 = _0x3aa9f5.method("get_Values").invoke();
                const _0x340405 = _0x55aba7.method("GetEnumerator").invoke();
                while (_0x340405.method("MoveNext").invoke()) {
                  try {
                    const _0x2f063a = _0x340405.method("get_Current").invoke();
                    if (!_0x2f063a || _0x2f063a.isNull() || _0x16fc51(_0x2f063a)) {
                      continue;
                    }
                    for (const _0x5470c8 of ["get_rightHandAnchor", "get_leftHandAnchor"]) {
                      try {
                        const _0x28558f = _0x2f063a.method(_0x5470c8).invoke();
                        if (!_0x28558f || _0x28558f.isNull()) {
                          continue;
                        }
                        const _0x4c69d8 = _0x28558f.method("get_grabbableObject").invoke();
                        if (!_0x4c69d8 || _0x4c69d8.isNull()) {
                          continue;
                        }
                        try {
                          const _0x1576fd = _0x4c69d8.method("get_Object").invoke();
                          if (_0x1576fd && !_0x1576fd.isNull()) {
                            _0x1576fd.method("RequestStateAuthority").invoke();
                          }
                        } catch (_0x3c2685) {}
                        try {
                          _0x28558f.method("RPC_DropObject").invoke();
                        } catch (_0x2ea80d) {}
                        try {
                          _0x4c69d8.method("RPC_Release").invoke();
                        } catch (_0x47e10f) {}
                      } catch (_0x3c2b56) {}
                    }
                  } catch (_0x6c0cc0) {}
                }
              }
            } catch (_0x1a22bd) {}
            const _0x1c0b6 = UnityObjectClass.method("FindObjectsByType", 1)
              .inflate(AnimalGrabbableObjectClass)
              .invoke(0);
            for (let _0x59478f = 0; _0x59478f < _0x1c0b6.length; _0x59478f++) {
              try {
                const _0x554167 = _0x1c0b6.get(_0x59478f);
                if (!_0x554167 || _0x554167.isNull()) {
                  continue;
                }
                const _0xded320 = _0xe40610(_0x554167);
                if (!_0xded320 || _0xded320.isNull()) {
                  continue;
                }
                const _0x963365 = _0xded320.method("get_position").invoke();
                const _0x58eca7 = _0x963365.field("x").value;
                const _0x5e44d0 = _0x963365.field("y").value;
                const _0x1e13c6 = _0x963365.field("z").value;
                const _0x34321b = _0x424fd4 - _0x58eca7;
                const _0x2c285d = _0x2ca9c1 - _0x5e44d0;
                const _0x4450ba = _0x1b2fd8 - _0x1e13c6;
                const _0x3205ce = Math.sqrt(
                  _0x34321b * _0x34321b + _0x2c285d * _0x2c285d + _0x4450ba * _0x4450ba,
                );
                if (_0x3205ce > 20 || _0x3205ce < 0.4) {
                  continue;
                }
                const _0x111c5f = 1 / _0x3205ce;
                const _0x26a195 = 0.4 + (1 - _0x3205ce / 20) * 0.6;
                _0x554167
                  .method("AddExternalForceVelocity", 1)
                  .invoke([
                    _0x34321b * _0x111c5f * _0x26a195,
                    _0x2c285d * _0x111c5f * _0x26a195,
                    _0x4450ba * _0x111c5f * _0x26a195,
                  ]);
              } catch (_0xd6bc4f) {}
            }
          } catch (_0x235e12) {
            smartError("Magnet All Items", _0x235e12);
          }
        },
        toolTip:
          "Hold grip: force-drops items from other players' hands then pulls everything within 20m toward you.",
      }),
      new ButtonInfo({
        buttonText: "Slow Despawn All Items",
        isTogglable: true,
        method: () => {
          if (!rightGrab) {
            return;
          }
          if (time <= _0x11f92d) {
            return;
          }
          _0x11f92d = time + 0.1;
          try {
            const _0x4ef696 = UnityObjectClass.method("FindObjectsByType", 1)
              .inflate(AnimalGrabbableObjectClass)
              .invoke(0);
            for (let _0x48346f = 0; _0x48346f < _0x4ef696.length; _0x48346f++) {
              try {
                const _0x26cd7d = _0x4ef696.get(_0x48346f);
                if (!_0x26cd7d || _0x26cd7d.isNull()) {
                  continue;
                }
                const _0x51a8e1 = NetPlayerClass.method("get_localPlayer").invoke();
                if (_0x51a8e1 && !_0x51a8e1.isNull()) {
                  try {
                    const _0x308001 = _0x51a8e1.method("get_rightHandAnchor").invoke();
                    const _0x434c0f = _0x51a8e1.method("get_leftHandAnchor").invoke();
                    const _0xbb6d68 =
                      _0x308001 && !_0x308001.isNull()
                        ? _0x308001.method("get_grabbableObject").invoke()
                        : null;
                    const _0xb785f9 =
                      _0x434c0f && !_0x434c0f.isNull()
                        ? _0x434c0f.method("get_grabbableObject").invoke()
                        : null;
                    if (
                      _0xbb6d68 &&
                      !_0xbb6d68.isNull() &&
                      _0xbb6d68.handle.equals(_0x26cd7d.handle)
                    ) {
                      continue;
                    }
                    if (
                      _0xb785f9 &&
                      !_0xb785f9.isNull() &&
                      _0xb785f9.handle.equals(_0x26cd7d.handle)
                    ) {
                      continue;
                    }
                  } catch (_0x13bb3b) {}
                }
                _0x58bf44(_0x26cd7d);
                _0x1706ac(_0x26cd7d);
                break;
              } catch (_0x1321e3) {}
            }
          } catch (_0x3bad6c) {
            smartError("Slow Despawn All Items", _0x3bad6c);
          }
        },
        toolTip:
          "Hold grip: despawns one random item from the map every 0.1s until everything is gone.",
      }),
    ],
    [
      new ButtonInfo({
        buttonText: "Exit Experimental",
        method: () => {
          currentCategory = 0;
          currentPage = 0;
        },
        isTogglable: false,
        toolTip: "Returns to main menu.",
      }),
      new ButtonInfo({
        buttonText: "Telekinesis Gun",
        isTogglable: true,
        disableMethod: () => {
          var _0x272671;
          try {
            if (
              GunLibPointer &&
              !((_0x272671 = GunLibPointer.isNull) === null || _0x272671 === undefined
                ? undefined
                : _0x272671.call(GunLibPointer))
            ) {
              GunLibPointer.method("SetActive").invoke(false);
            }
          } catch (_0x3e0948) {}
          try {
            if (GunLibLine) {
              GunLibLine.method("get_gameObject").invoke().method("SetActive").invoke(false);
            }
          } catch (_0x235142) {}
          telekinesisTarget = null;
        },
        method: (() => {
          let _0x4c424b = false;
          return () => {
            var _0xc67ed;
            var _0x3dede1;
            var _0x1f8532;
            if (!rightGrab) {
              try {
                if (
                  GunLibPointer &&
                  !((_0xc67ed = GunLibPointer.isNull) === null || _0xc67ed === undefined
                    ? undefined
                    : _0xc67ed.call(GunLibPointer))
                ) {
                  GunLibPointer.method("SetActive").invoke(false);
                }
              } catch (_0x4f7e29) {}
              try {
                if (GunLibLine) {
                  GunLibLine.method("get_gameObject").invoke().method("SetActive").invoke(false);
                }
              } catch (_0x4460c9) {}
              telekinesisTarget = null;
              _0x4c424b = false;
              return;
            }
            try {
              const _0x45830e = _0x577f7f();
              let _0x40d447 = null;
              if (_0x45830e?.finalRay) {
                try {
                  _0x40d447 = _0x45830e.finalRay.method("get_point").invoke();
                } catch (_0x1db67f) {}
              }
              if (!_0x40d447) {
                const _0x43507f = rightHandTransform.method("get_position").invoke();
                const _0x5a6caf = rightHandTransform.method("get_forward").invoke();
                const _0x51d33c = _0x43507f.field("x").value || 0;
                const _0x44f19c = _0x43507f.field("y").value || 0;
                const _0x4f491e = _0x43507f.field("z").value || 0;
                const _0x23c2d0 = _0x5a6caf.field("x").value || 0;
                const _0x52c056 = _0x5a6caf.field("y").value || 0;
                const _0x11e1dc = _0x5a6caf.field("z").value || 0;
                _0x40d447 = [
                  _0x51d33c + _0x23c2d0 * 10,
                  _0x44f19c + _0x52c056 * 10,
                  _0x4f491e + _0x11e1dc * 10,
                ];
              }
              const _0x4300a3 = rightTrigger && !_0x4c424b;
              if (
                _0x4300a3 &&
                (!telekinesisTarget ||
                  ((_0x3dede1 = telekinesisTarget.isNull) === null || _0x3dede1 === undefined
                    ? undefined
                    : _0x3dede1.call(telekinesisTarget)))
              ) {
                try {
                  const _0x5ecbda = rightHandTransform.method("get_position").invoke();
                  const _0x45b884 = rightHandTransform.method("get_forward").invoke();
                  const _0x1c251a = PhysicsClass.method("RaycastAll", 4).invoke(
                    _0x5ecbda,
                    _0x45b884,
                    512,
                    -1,
                  );
                  if (_0x1c251a && !_0x1c251a.isNull()) {
                    let _0xeda70e = null;
                    let _0xd56c53 = Infinity;
                    for (let _0x4b6ae3 = 0; _0x4b6ae3 < _0x1c251a.length; _0x4b6ae3++) {
                      try {
                        const _0x46d446 = _0x1c251a.get(_0x4b6ae3);
                        const _0x16175e = _0x46d446.method("get_collider").invoke();
                        if (!_0x16175e || _0x16175e.isNull()) {
                          continue;
                        }
                        const _0x29ab4a = _0x16175e.method("get_gameObject").invoke();
                        if (!_0x29ab4a || _0x29ab4a.isNull()) {
                          continue;
                        }
                        const _0x55e535 = _0x29ab4a
                          .method("GetComponentInParent", 0)
                          .inflate(NetPlayerClass)
                          .invoke();
                        if (!_0x55e535 || _0x55e535.isNull() || _0x16fc51(_0x55e535)) {
                          continue;
                        }
                        const _0x101569 = _0x46d446.method("get_point").invoke();
                        const _0x289e9c = _0x5ecbda.field("x").value;
                        const _0x4b2e00 = _0x5ecbda.field("y").value;
                        const _0x40c9c1 = _0x5ecbda.field("z").value;
                        const _0x344cb0 = _0x101569.field("x").value;
                        const _0x47fdcd = _0x101569.field("y").value;
                        const _0x3ccdf9 = _0x101569.field("z").value;
                        const _0x42bf7a = Math.sqrt(
                          (_0x344cb0 - _0x289e9c) * (_0x344cb0 - _0x289e9c) +
                            (_0x47fdcd - _0x4b2e00) * (_0x47fdcd - _0x4b2e00) +
                            (_0x3ccdf9 - _0x40c9c1) * (_0x3ccdf9 - _0x40c9c1),
                        );
                        if (_0x42bf7a < _0xd56c53) {
                          _0xd56c53 = _0x42bf7a;
                          _0xeda70e = _0x55e535;
                        }
                      } catch (_0xa7faab) {}
                    }
                    if (_0xeda70e && !_0xeda70e.isNull()) {
                      telekinesisTarget = _0xeda70e;
                      notify("Grabbed " + getPlayerName(telekinesisTarget) + "!", false, 1);
                    }
                  }
                } catch (_0x429c26) {}
              }
              if (
                rightTrigger &&
                telekinesisTarget &&
                !((_0x1f8532 = telekinesisTarget.isNull) === null || _0x1f8532 === undefined
                  ? undefined
                  : _0x1f8532.call(telekinesisTarget))
              ) {
                try {
                  telekinesisTarget.method("RPC_Teleport").invoke(_0x40d447);
                } catch (_0x5b0aa4) {}
              }
              if (!rightTrigger && _0x4c424b) {
                telekinesisTarget = null;
              }
            } catch (_0x15d433) {
              smartError("Telekinesis Gun", _0x15d433);
            }
            _0x4c424b = rightTrigger;
          };
        })(),
        toolTip:
          "Hold grip to aim directly at a player and pull trigger to grab them — they follow your gun pointer. Release trigger to drop.",
      }),
      new ButtonInfo({
        buttonText: "Noclip (hold A)",
        isTogglable: true,
        disableMethod: () => {
          if (_noclipActive) {
            try {
              headCollider.method("set_enabled").invoke(true);
            } catch (_0x3ac81b) {}
            try {
              bodyCollider.method("set_enabled").invoke(true);
            } catch (_0x5dfe53) {}
            const _0x5238a5 = (_0x5846d2, _0x13c23e) => {
              try {
                const _0x58350d = _0x5846d2.method("get_gameObject").invoke();
                const _0xd6ab67 = _0x58350d
                  .method("GetComponentsInChildren", 1)
                  .inflate(ColliderClass)
                  .invoke(true);
                for (let _0x1a68bc = 0; _0x1a68bc < _0xd6ab67.length; _0x1a68bc++) {
                  try {
                    _0xd6ab67.get(_0x1a68bc).method("set_enabled").invoke(_0x13c23e);
                  } catch (_0x3e55b5) {}
                }
              } catch (_0x249ae5) {}
            };
            _0x5238a5(_0xe40610(localRig), true);
            _0x5238a5(leftHandTransform, true);
            _0x5238a5(rightHandTransform, true);
            _noclipActive = false;
          }
        },
        method: () => {
          const _0x41104c = (_0x5f3832, _0x1d7c0e) => {
            try {
              const _0x136ed3 = _0x5f3832.method("get_gameObject").invoke();
              const _0x2727c1 = _0x136ed3
                .method("GetComponentsInChildren", 1)
                .inflate(ColliderClass)
                .invoke(true);
              for (let _0x1bd468 = 0; _0x1bd468 < _0x2727c1.length; _0x1bd468++) {
                try {
                  _0x2727c1.get(_0x1bd468).method("set_enabled").invoke(_0x1d7c0e);
                } catch (_0xbd7038) {}
              }
            } catch (_0x2f1d87) {}
          };
          if (rightPrimary && !_noclipActive) {
            try {
              headCollider.method("set_enabled").invoke(false);
            } catch (_0x37f04e) {}
            try {
              bodyCollider.method("set_enabled").invoke(false);
            } catch (_0x3989ac) {}
            _0x41104c(_0xe40610(localRig), false);
            _0x41104c(leftHandTransform, false);
            _0x41104c(rightHandTransform, false);
            _noclipActive = true;
          } else if (!rightPrimary && _noclipActive) {
            try {
              headCollider.method("set_enabled").invoke(true);
            } catch (_0x53a886) {}
            try {
              bodyCollider.method("set_enabled").invoke(true);
            } catch (_0x5cc318) {}
            _0x41104c(_0xe40610(localRig), true);
            _0x41104c(leftHandTransform, true);
            _0x41104c(rightHandTransform, true);
            _noclipActive = false;
          }
        },
        toolTip:
          "Toggle ON, then hold A (right primary) to disable all your rig colliders and phase through objects. Release A to restore.",
      }),
      new ButtonInfo({
        buttonText: "Hand Duper",
        method: () => {
          const _0xd51b44 = rightSecondary && !_handDuperLastX;
          _handDuperLastX = rightSecondary;
          if (!_0xd51b44) {
            return;
          }
          function _0x1012dd(_0x3e8975, _0xff6c5c) {
            return Math.floor(Math.random() * (_0xff6c5c - _0x3e8975 + 1)) + _0x3e8975;
          }
          try {
            const _0x3852e9 = NetPlayerClass.method("get_localPlayer").invoke();
            if (!_0x3852e9 || _0x3852e9.handle.isNull()) {
              notify("Duper: no player", false);
              return;
            }
            const _0x5787cf = _0x3852e9.method("GetHandInteractor", 1).invoke(1);
            if (!_0x5787cf || _0x5787cf.handle.isNull()) {
              notify("Duper: no right interactor", false);
              return;
            }
            const _0x1aa36c = _0x5787cf.field("_itemAnchor").value;
            if (!_0x1aa36c || _0x1aa36c.handle.isNull()) {
              notify("Duper: no item anchor", false);
              return;
            }
            const _0x4e6ac9 = _0x1aa36c.method("get_grabbableObject").invoke();
            if (!_0x4e6ac9 || _0x4e6ac9.isNull()) {
              notify("Duper: nothing in right hand", false);
              return;
            }
            let _0x1a67e3 = "item_treestick";
            try {
              const _0x54923b = _0x4e6ac9
                .method("GetComponent", 1)
                .inflate(GrabbableItemClass)
                .invoke();
              if (_0x54923b && !_0x54923b.isNull()) {
                const _0x3eb2c2 = _0x54923b.method("get_itemID").invoke();
                if (_0x3eb2c2 && !_0x3eb2c2.isNull() && _0x3eb2c2.content) {
                  _0x1a67e3 = _0x3eb2c2.content;
                }
              }
            } catch (_0x3282a4) {}
            const _0x41a7dd = _0x4e6ac9
              .method("GetComponent", 1)
              .inflate(AnimalGrabbableObjectClass)
              .invoke();
            let _0x48a435 = _0x1012dd(-128, 127);
            let _0xc03486 = _0x1012dd(-127, 127);
            let _0x72cc0d = _0x1012dd(-20, 127);
            if (_0x41a7dd && !_0x41a7dd.isNull()) {
              try {
                _0x48a435 = _0x41a7dd.method("get_scaleModifier").invoke();
              } catch (_0x161abf) {}
              try {
                _0xc03486 = _0x41a7dd.method("get_colorHue").invoke();
              } catch (_0x4a67f2) {}
              try {
                _0x72cc0d = _0x41a7dd.method("get_colorSaturation").invoke();
              } catch (_0x34ddc0) {}
            }
            const _0x119ed4 = rightHandTransform.method("get_position").invoke();
            const _0x1fdfe7 = PrefabGeneratorClass.method("SpawnItem", 4).invoke(
              Il2Cpp.string("item_prefab/" + _0x1a67e3),
              _0x119ed4,
              QuaternionIdentity,
              _0x366930,
            );
            if (!_0x1fdfe7 || _0x1fdfe7.isNull()) {
              notify("Spawn failed", false);
              return;
            }
            const _0xba0808 = _0x1fdfe7
              .method("GetComponent", 1)
              .inflate(AnimalGrabbableObjectClass)
              .invoke();
            if (_0xba0808 && !_0xba0808.isNull()) {
              _0xba0808.method("set_scaleModifier").invoke(_0x48a435);
              _0xba0808.method("set_colorHue").invoke(_0xc03486);
              _0xba0808.method("set_colorSaturation").invoke(_0x72cc0d);
            }
            const _0x196b03 = _0x4e6ac9
              .method("GetComponent", 1)
              .inflate(BackpackItemClass)
              .invoke();
            if (_0x196b03 && !_0x196b03.isNull()) {
              const _0x221087 = _0x1fdfe7
                .method("GetComponent", 1)
                .inflate(BackpackItemClass)
                .invoke();
              if (_0x221087 && !_0x221087.isNull()) {
                try {
                  const _0x7746a3 = _0x196b03.method("GetContainedItems").invoke();
                  if (_0x7746a3 && !_0x7746a3.isNull()) {
                    const _0x31840e = _0x7746a3.method("get_Count").invoke();
                    for (let _0x2a8d43 = 0; _0x2a8d43 < _0x31840e; _0x2a8d43++) {
                      try {
                        const _0x42c651 = _0x7746a3.method("get_Item").invoke(_0x2a8d43);
                        if (!_0x42c651 || _0x42c651.isNull()) {
                          continue;
                        }
                        const _0x1fffa7 = _0x42c651.method("get_itemID").invoke();
                        if (!_0x1fffa7 || _0x1fffa7.isNull() || !_0x1fffa7.content) {
                          continue;
                        }
                        let _0x2ddf1c = 0;
                        let _0x2c6a2b = 0;
                        let _0x31dfaa = 0;
                        try {
                          const _0x150b0f = _0x42c651
                            .method("GetComponent", 1)
                            .inflate(AnimalGrabbableObjectClass)
                            .invoke();
                          if (_0x150b0f && !_0x150b0f.isNull()) {
                            _0x2ddf1c = _0x150b0f.method("get_scaleModifier").invoke();
                            _0x2c6a2b = _0x150b0f.method("get_colorHue").invoke();
                            _0x31dfaa = _0x150b0f.method("get_colorSaturation").invoke();
                          }
                        } catch (_0x191145) {}
                        const _0x33015f = PrefabGeneratorClass.method("SpawnItem", 4).invoke(
                          Il2Cpp.string("item_prefab/" + _0x1fffa7.content),
                          _0x119ed4,
                          QuaternionIdentity,
                          _0x366930,
                        );
                        if (!_0x33015f || _0x33015f.isNull()) {
                          continue;
                        }
                        const _0xb31adf = _0x33015f
                          .method("GetComponent", 1)
                          .inflate(AnimalGrabbableObjectClass)
                          .invoke();
                        if (_0xb31adf && !_0xb31adf.isNull()) {
                          _0xb31adf.method("set_scaleModifier").invoke(_0x2ddf1c);
                          _0xb31adf.method("set_colorHue").invoke(_0x2c6a2b);
                          _0xb31adf.method("set_colorSaturation").invoke(_0x31dfaa);
                        }
                        const _0x43072b = _0x33015f
                          .method("GetComponent", 1)
                          .inflate(GrabbableItemClass)
                          .invoke();
                        if (_0x43072b && !_0x43072b.isNull()) {
                          _0x43072b.method("AddToBag").invoke(_0x221087);
                        }
                      } catch (_0x4b60ef) {}
                    }
                    notify("Duped " + _0x1a67e3 + " + " + _0x31840e + " bag items", false);
                    return;
                  }
                } catch (_0x7622b1) {}
              }
            }
            notify("Duped: " + _0x1a67e3, false);
          } catch (_0x2ce57b) {
            smartError("Hand Duper error:", _0x2ce57b);
          }
        },
        isTogglable: true,
        toolTip:
          "Toggle ON, then click B (right controller) to dupe the item in your right hand — same hue/sat/scale + bag contents — dropped by your right hand.",
      }),
      new ButtonInfo({
        buttonText: "Rapid Fire",
        method: () => {
          try {
            const _0x558340 = NetPlayerClass.method("get_localPlayer").invoke();
            if (!_0x558340) {
              return;
            }
            const _0x591c85 = _0x558340.method("GetHandInteractor", 1).invoke(1);
            if (!_0x591c85) {
              return;
            }
            const _0x5b22cc = _0x591c85.field("_itemAnchor").value;
            if (!_0x5b22cc) {
              return;
            }
            const _0x1c5dd0 = _0x5b22cc.method("get_grabbableObject").invoke();
            if (!_0x1c5dd0) {
              return;
            }
            const _0x593a6f = _0x558340.method("GetHandInteractor", 1).invoke(0);
            if (!_0x593a6f) {
              return;
            }
            const _0xe05bf0 = _0x593a6f.field("_itemAnchor").value;
            if (!_0xe05bf0) {
              return;
            }
            const _0x446b1c = _0xe05bf0.method("get_grabbableObject").invoke();
            if (!_0x446b1c) {
              return;
            }
            if (rightTrigger) {
              _0x1c5dd0.method("HandleTriggerUse").invoke();
              try {
                _0x1c5dd0.method("HandleSecondaryUse").invoke();
              } catch (_0x11298a) {}
            }
            if (leftTrigger) {
              _0x446b1c.method("HandleTriggerUse").invoke();
              try {
                _0x446b1c.method("HandleSecondaryUse").invoke();
              } catch (_0x37e8b6) {}
            }
          } catch (_0x17f605) {
            smartError("error", _0x17f605);
          }
        },
        isTogglable: true,
        toolTip:
          "Rapid fire any item — spams trigger use + B (secondary) use while holding the trigger.",
      }),
      new ButtonInfo({
        buttonText: "White Screen All",
        isTogglable: false,
        method: () => {
          try {
            const _0x587c2a = NetPlayerClass.field("playerIDToNetPlayer").value;
            const _0x58b366 = _0x587c2a.method("get_Values").invoke();
            const _0x4b4863 = _0x58b366.method("GetEnumerator").invoke();
            let _0x573d48 = 0;
            while (_0x4b4863.method("MoveNext").invoke()) {
              const _0x5b1307 = _0x4b4863.method("get_Current").invoke();
              if (!_0x5b1307 || _0x5b1307.handle.isNull()) {
                continue;
              }
              try {
                const _0x4be404 = _0xe40610(_0x5b1307).method("get_position").invoke();
                if (_0x16fc51(_0x5b1307)) {
                  _0x18a723(() =>
                    _0x5b1307.method("RPC_PlayerStun").invoke(_0x4be404, 999, 9999, 0),
                  );
                } else {
                  _0x5b1307.method("RPC_PlayerStun").invoke(_0x4be404, 999, 9999, 0);
                }
                _0x573d48++;
              } catch (_0x4aab0d) {}
            }
            notify("White screened " + _0x573d48 + " players!", false);
          } catch (_0x1a244e) {
            console.error("White Screen All: " + _0x1a244e);
          }
        },
        toolTip: "Stuns all players with a 9999-second freeze via RPC.",
      }),
      new ButtonInfo({
        buttonText: "Draw 2HP",
        isTogglable: false,
        method: () => {
          try {
            const _0x38eeb6 = {
              2: [
                [0, 0],
                [1, 0],
                [2, 0],
                [0, 1],
                [0, 2],
                [1, 2],
                [2, 2],
                [2, 3],
                [2, 4],
                [1, 4],
                [0, 4],
              ],
              H: [
                [0, 0],
                [0, 1],
                [0, 2],
                [0, 3],
                [0, 4],
                [1, 2],
                [2, 0],
                [2, 1],
                [2, 2],
                [2, 3],
                [2, 4],
              ],
              P: [
                [0, 0],
                [0, 1],
                [0, 2],
                [0, 3],
                [0, 4],
                [1, 4],
                [2, 4],
                [2, 3],
                [2, 2],
                [1, 2],
              ],
            };
            const _0x1b4410 = "2HP";
            const _0xbaa141 = 0.8;
            const _0x44fb97 = _0x1b4410.length * 4 * _0xbaa141;
            const _0xebb64e = localRig.field("headCollider").value.method("get_transform").invoke();
            const _0x276f0c = _0xebb64e.method("get_position").invoke();
            const _0x1d38fd = _0xebb64e.method("get_forward").invoke();
            const _0x314cd3 = Vector3Class.method("op_Addition", 2).invoke(
              _0x276f0c,
              Vector3Class.method("op_Multiply", 2).invoke(_0x1d38fd, 10),
            );
            let _0x667d9e = 0;
            for (let _0x153ce9 = 0; _0x153ce9 < _0x1b4410.length; _0x153ce9++) {
              const _0x499b5c = _0x38eeb6[_0x1b4410[_0x153ce9]] || [];
              for (const [_0x5461c7, _0x4c81d9] of _0x499b5c) {
                const _0x5c7c6a = (_0x5461c7 + _0x153ce9 * 4) * _0xbaa141 - _0x44fb97 / 2;
                const _0x166a0d = _0x4c81d9 * _0xbaa141;
                const _0x240a18 = Vector3Class.method("op_Addition", 2).invoke(_0x314cd3, [
                  _0x5c7c6a,
                  _0x166a0d,
                  0,
                ]);
                try {
                  _0xf8bff9("item_ore_hell", _0x240a18, QuaternionIdentity);
                  _0x667d9e++;
                } catch (_0x12e703) {}
              }
            }
            notify("Drew 2HP (" + _0x667d9e + " blocks)!", false, 2);
          } catch (_0x1da8fb) {
            smartError("Draw 2HP", _0x1da8fb);
          }
        },
        toolTip:
          "Spawns '2HP' in large pixel art using ore_hell blocks, 10 units in front of your face.",
      }),
      new ButtonInfo({
        buttonText: "Push Back",
        isTogglable: true,
        method: () => {
          if (!rightGrab) {
            return;
          }
          try {
            const _0x492723 = NetPlayerClass.method("get_localPlayer").invoke();
            if (!_0x492723 || _0x492723.isNull()) {
              return;
            }
            const _0x21a979 = _0xe40610(_0x492723);
            if (!_0x21a979 || _0x21a979.isNull()) {
              return;
            }
            const _0x3d1024 = _0x21a979.method("get_position").invoke();
            const _0xc15bc5 = _0x3d1024.field("x").value;
            const _0x1f5ad2 = _0x3d1024.field("y").value;
            const _0x4157dc = _0x3d1024.field("z").value;
            const _0x2baf75 = NetPlayerClass.field("playerIDToNetPlayer").value;
            if (!_0x2baf75 || _0x2baf75.isNull()) {
              return;
            }
            const _0xa5c301 = _0x2baf75.method("get_Values").invoke();
            const _0x3f9e45 = _0xa5c301.method("GetEnumerator").invoke();
            while (_0x3f9e45.method("MoveNext").invoke()) {
              try {
                const _0x5e4dac = _0x3f9e45.method("get_Current").invoke();
                if (!_0x5e4dac || _0x5e4dac.isNull()) {
                  continue;
                }
                if (_0x16fc51(_0x5e4dac)) {
                  continue;
                }
                const _0x103ec8 = _0xe40610(_0x5e4dac);
                if (!_0x103ec8 || _0x103ec8.isNull()) {
                  continue;
                }
                const _0x492ce3 = _0x103ec8.method("get_position").invoke();
                const _0x483556 = _0x492ce3.field("x").value - _0xc15bc5;
                const _0x399c44 = _0x492ce3.field("y").value - _0x1f5ad2;
                const _0x1c94d5 = _0x492ce3.field("z").value - _0x4157dc;
                const _0x4bf086 = Math.sqrt(
                  _0x483556 * _0x483556 + _0x399c44 * _0x399c44 + _0x1c94d5 * _0x1c94d5,
                );
                if (_0x4bf086 > 6 || _0x4bf086 < 0.01) {
                  continue;
                }
                const _0x3ec82b = 1 / _0x4bf086;
                const _0x4da2d4 = 6;
                _0x5e4dac
                  .method("RPC_AddForce")
                  .invoke([
                    _0x483556 * _0x3ec82b * _0x4da2d4,
                    Math.abs(_0x399c44 * _0x3ec82b) * _0x4da2d4 + 2,
                    _0x1c94d5 * _0x3ec82b * _0x4da2d4,
                  ]);
              } catch (_0x4eb03a) {}
            }
          } catch (_0x451f58) {
            smartError("Push Back", _0x451f58);
          }
        },
        toolTip: "Hold grip: blasts all players within 6m away from you every frame.",
      }),
    ],
    [
      new ButtonInfo({
        buttonText: "Exit Dev Stuff",
        method: () => {
          currentCategory = 0;
          currentPage = 0;
        },
        isTogglable: false,
        toolTip: "Returns to main menu.",
      }),
      new ButtonInfo({
        buttonText: "Dev Mode",
        isTogglable: true,
        enableMethod: () => {
          try {
            const _0x4ec534 = animalImage.class("AnimalCompany.App");
            const _0x37b194 = _0x4ec534.method("get_state").invoke().method("get_user").invoke();
            const _0x2de954 = _0x37b194.method("get_isDeveloper").invoke();
            _0x2de954.field("_value").value = true;
          } catch (_0x1372da) {}
          try {
            const _0x433541 = animalImage.class("AnimalCompany.PlayerWatch");
            const _0x47e781 = _0x433541.field("_allWatches").value;
            const _0x1fb920 = _0x47e781.method("GetEnumerator").invoke();
            while (_0x1fb920.method("MoveNext").invoke()) {
              const _0x54905b = _0x1fb920.method("get_Current").invoke();
              if (_0x54905b.method("get_IsMine").invoke()) {
                const _0xe9445e = _0x54905b.field("_devMenuView").value;
                if (_0xe9445e && !_0xe9445e.isNull()) {
                  _0xe9445e.method("get_gameObject").invoke().method("SetActive").invoke(true);
                }
                break;
              }
            }
          } catch (_0x4408aa) {}
        },
        disableMethod: () => {
          try {
            const _0x14eed8 = animalImage.class("AnimalCompany.App");
            const _0xb563ff = _0x14eed8.method("get_state").invoke().method("get_user").invoke();
            _0xb563ff.method("get_isDeveloper").invoke().field("_value").value = false;
          } catch (_0xf99b0) {}
          try {
            const _0x24588b = animalImage.class("AnimalCompany.PlayerWatch");
            const _0x5b9cae = _0x24588b.field("_allWatches").value;
            const _0x8be133 = _0x5b9cae.method("GetEnumerator").invoke();
            while (_0x8be133.method("MoveNext").invoke()) {
              const _0xe84bb5 = _0x8be133.method("get_Current").invoke();
              if (_0xe84bb5.method("get_IsMine").invoke()) {
                const _0x8d3302 = _0xe84bb5.field("_devMenuView").value;
                if (_0x8d3302 && !_0x8d3302.isNull()) {
                  _0x8d3302.method("get_gameObject").invoke().method("SetActive").invoke(false);
                }
                break;
              }
            }
          } catch (_0x484f67) {}
        },
        method: () => {},
        toolTip: "Enables developer mode and shows the dev watch menu.",
      }),
      new ButtonInfo({
        buttonText: "Dump Net Objects",
        method: () => {
          try {
            const _0x4c990c = PrefabGeneratorClass.field("_instance")
              .value.method("get_runner")
              .invoke();
            if (!_0x4c990c || _0x4c990c.isNull()) {
              notify("No runner — join a room first", false, 4);
              return;
            }
            const _0x3bc2da = _0x4c990c
              .field("_config")
              .value.field("PrefabTable")
              .value.field("_sources").value;
            const _0x1b71ac = _0x3bc2da.method("get_Count").invoke();
            console.log("[DumpNetObj] ═══════════════════════════════════════");
            console.log("[DumpNetObj] NetworkObject prefab table — " + _0x1b71ac + " entries:");
            for (let _0x93039b = 0; _0x93039b < _0x1b71ac; _0x93039b++) {
              try {
                const _0x1cf7a6 = _0x3bc2da.method("get_Item").invoke(_0x93039b);
                const _0x5db0ef = _0x1cf7a6.method("get_Description").invoke().toString();
                console.log("[DumpNetObj]  [" + _0x93039b + "] " + _0x5db0ef);
              } catch (_0x2ad264) {
                console.log("[DumpNetObj]  [" + _0x93039b + "] <error>");
              }
            }
            console.log("[DumpNetObj] ═══════════════════════════════════════");
            notify("Dumped " + _0x1b71ac + " net prefabs — see Frida log", false, 5);
          } catch (_0x1c09d7) {
            notify("Dump Net Objects: " + _0x1c09d7, false, 5);
            smartError("[DumpNetObj]", _0x1c09d7);
          }
        },
        isTogglable: false,
        toolTip: "Logs every spawnable NetworkObject prefab to the Frida console.",
      }),
      new ButtonInfo({
        buttonText: "Debug Prefabs",
        method: () => {
          try {
            const _0x4bd590 = PrefabGeneratorClass.field("_instance")
              .value.method("get_runner")
              .invoke();
            if (!_0x4bd590 || _0x4bd590.isNull()) {
              notify("No runner", false);
              return;
            }
            const _0x125f82 = _0x4bd590
              .field("_config")
              .value.field("PrefabTable")
              .value.field("_sources").value;
            const _0x487feb = _0x125f82.method("get_Count").invoke();
            for (let _0x2d39a8 = 0; _0x2d39a8 < 10; _0x2d39a8++) {
              try {
                const _0x3c991d = _0x125f82.method("get_Item").invoke(_0x2d39a8);
                const _0x462d2a = _0x3c991d.method("get_Description").invoke().toString();
                console.log("[Prefab] " + _0x2d39a8 + ": " + _0x462d2a);
              } catch (_0x46915f) {}
            }
            notify("Check console for first 10 prefabs", false);
          } catch (_0xe2364) {
            notify("Debug: " + _0xe2364, false);
          }
        },
        isTogglable: false,
        toolTip: "Logs first 10 prefab descriptions to console.",
      }),
    ],
    [
      new ButtonInfo({
        buttonText: "Back to Main",
        method: () => {
          currentCategory = 0;
          currentPage = 0;
        },
        isTogglable: false,
        toolTip: "Returns to main category.",
      }),
      new ButtonInfo({
        buttonText: "Toggle Whitelist",
        enableMethod: () => {
          whitelistEnabled = true;
          notify("Whitelist ON", false);
        },
        disableMethod: () => {
          whitelistEnabled = false;
          notify("Whitelist OFF", false);
        },
        isTogglable: true,
        toolTip: "Enables or disables the whitelist system.",
      }),
      new ButtonInfo({
        buttonText: "Clear Whitelist",
        method: () => {
          whitelist = [];
          notify("Whitelist cleared!", false);
        },
        isTogglable: false,
        toolTip: "Removes all players from the whitelist.",
      }),
      new ButtonInfo({
        buttonText: "List Whitelist",
        method: () => {
          if (whitelist.length === 0) {
            notify("Whitelist is empty", false);
            return;
          }
          notify("WL: " + whitelist.join(", "), false, 8);
        },
        isTogglable: false,
        toolTip: "Shows all whitelisted players.",
      }),
      new ButtonInfo({
        buttonText: "WL Add Gun",
        disableMethod: () => {
          var _0x50c59e;
          try {
            if (
              GunLibPointer &&
              !((_0x50c59e = GunLibPointer.isNull) === null || _0x50c59e === undefined
                ? undefined
                : _0x50c59e.call(GunLibPointer))
            ) {
              GunLibPointer.method("SetActive").invoke(false);
            }
          } catch (_0x46de3f) {}
          try {
            if (GunLibLine) {
              GunLibLine.method("get_gameObject").invoke().method("SetActive").invoke(false);
            }
          } catch (_0xdc9b73) {}
          _0x5bc894 = false;
          _0x4b51b9 = null;
        },
        method: () => {
          var _0x26cce5;
          if (!rightGrab) {
            try {
              if (
                GunLibPointer &&
                !((_0x26cce5 = GunLibPointer.isNull) === null || _0x26cce5 === undefined
                  ? undefined
                  : _0x26cce5.call(GunLibPointer))
              ) {
                GunLibPointer.method("SetActive").invoke(false);
              }
            } catch (_0x2a5ffa) {}
            try {
              if (GunLibLine) {
                GunLibLine.method("get_gameObject").invoke().method("SetActive").invoke(false);
              }
            } catch (_0x504eea) {}
            _0x5bc894 = false;
            _0x4b51b9 = null;
            return;
          }
          const _0x1a939c = _0x43eae3();
          if (!_0x1a939c) {
            return;
          }
          const { targetPlayer: _0xf16ae5 } = _0x1a939c;
          if (rightTrigger && _0xf16ae5 && !_0xf16ae5.isNull() && time > _gunLibDelay) {
            _gunLibDelay = time + 0.5;
            _0x61c4b1(_0xf16ae5);
            notify("Added " + getPlayerName(_0xf16ae5) + " to whitelist!", false);
          }
        },
        isTogglable: true,
        toolTip: "Aim at a player and pull trigger to add them to the whitelist.",
      }),
      new ButtonInfo({
        buttonText: "WL Remove Gun",
        disableMethod: () => {
          var _0x5ccce9;
          try {
            if (
              GunLibPointer &&
              !((_0x5ccce9 = GunLibPointer.isNull) === null || _0x5ccce9 === undefined
                ? undefined
                : _0x5ccce9.call(GunLibPointer))
            ) {
              GunLibPointer.method("SetActive").invoke(false);
            }
          } catch (_0x1e98c5) {}
          try {
            if (GunLibLine) {
              GunLibLine.method("get_gameObject").invoke().method("SetActive").invoke(false);
            }
          } catch (_0x285112) {}
          _0x5bc894 = false;
          _0x4b51b9 = null;
        },
        method: () => {
          var _0x451d07;
          if (!rightGrab) {
            try {
              if (
                GunLibPointer &&
                !((_0x451d07 = GunLibPointer.isNull) === null || _0x451d07 === undefined
                  ? undefined
                  : _0x451d07.call(GunLibPointer))
              ) {
                GunLibPointer.method("SetActive").invoke(false);
              }
            } catch (_0x15c505) {}
            try {
              if (GunLibLine) {
                GunLibLine.method("get_gameObject").invoke().method("SetActive").invoke(false);
              }
            } catch (_0x31213f) {}
            _0x5bc894 = false;
            _0x4b51b9 = null;
            return;
          }
          const _0xe1d60f = _0x43eae3();
          if (!_0xe1d60f) {
            return;
          }
          const { targetPlayer: _0x535346 } = _0xe1d60f;
          if (rightTrigger && _0x535346 && !_0x535346.isNull() && time > _gunLibDelay) {
            _gunLibDelay = time + 0.5;
            _0x46878f(_0x535346);
            notify("Removed " + getPlayerName(_0x535346) + " from whitelist!", false);
          }
        },
        isTogglable: true,
        toolTip: "Aim at a player and pull trigger to remove them from the whitelist.",
      }),
      new ButtonInfo({
        buttonText: "WL All Fly",
        enableMethod: () => {
          wlAllFlyEnabled = true;
        },
        disableMethod: () => {
          wlAllFlyEnabled = false;
        },
        method: () => {
          if (!wlAllFlyEnabled || !rightGrab || time <= _wlAllFlyDelay) {
            return;
          }
          _wlAllFlyDelay = time + 0.5;
          _0x35af2d((_0x32db6a) => {
            const _0x124926 = _0xe40610(_0x32db6a).method("get_forward").invoke();
            _0x32db6a
              .method("RPC_AddForce")
              .invoke(Vector3Class.method("op_Multiply", 2).invoke(_0x124926, 8));
          });
        },
        isTogglable: true,
        toolTip: "Toggle ON + hold grip to continuously fly-boost all whitelisted players.",
      }),
      new ButtonInfo({
        buttonText: "WL All Rocket",
        enableMethod: () => {
          wlAllRocketEnabled = true;
        },
        disableMethod: () => {
          wlAllRocketEnabled = false;
        },
        method: () => {
          if (!wlAllRocketEnabled || !rightGrab || time <= _wlAllRocketDelay) {
            return;
          }
          _wlAllRocketDelay = time + 0;
          _0x35af2d((_0x146d29) => _0x4ae875(_0x146d29, "RPGRocket", 750));
        },
        isTogglable: true,
        toolTip: "Toggle ON + hold grip to spam rockets from all whitelisted players' hands.",
      }),
      new ButtonInfo({
        buttonText: "WL All Flare",
        enableMethod: () => {
          wlAllFlareEnabled = true;
        },
        disableMethod: () => {
          wlAllFlareEnabled = false;
        },
        method: () => {
          if (!wlAllFlareEnabled || !rightGrab || time <= _wlAllFlareDelay) {
            return;
          }
          _wlAllFlareDelay = time + 0.1;
          _0x35af2d((_0x451e7f) => _0x4ae875(_0x451e7f, "FlareGunProjectile", 25));
        },
        isTogglable: true,
        toolTip: "Toggle ON + hold grip to spam flares from all whitelisted players' hands.",
      }),
      new ButtonInfo({
        buttonText: "WL All Car",
        enableMethod: () => {
          wlAllCarEnabled = true;
        },
        disableMethod: () => {
          wlAllCarEnabled = false;
        },
        method: () => {
          if (!wlAllCarEnabled || !rightGrab || time <= _wlAllCarDelay) {
            return;
          }
          _wlAllCarDelay = time + 0.05;
          _0x35af2d((_0x430bf0) => _0x4ae875(_0x430bf0, "Vehicle_Buggy", 30));
        },
        isTogglable: true,
        toolTip: "Toggle ON + hold grip to spam cars from all whitelisted players' hands.",
      }),
      new ButtonInfo({
        buttonText: "WL All Suitcase",
        enableMethod: () => {
          wlAllSuitcaseEnabled = true;
        },
        disableMethod: () => {
          wlAllSuitcaseEnabled = false;
        },
        method: () => {
          if (!wlAllSuitcaseEnabled || !rightGrab || time <= _wlAllSuitcaseDelay) {
            return;
          }
          _wlAllSuitcaseDelay = time + 0;
          _0x35af2d((_0x29491d) => _0x4f206b(_0x29491d, "item_pelican_case", 50));
        },
        isTogglable: true,
        toolTip: "Toggle ON + hold grip to spam suitcases from all whitelisted players' hands.",
      }),
      new ButtonInfo({
        buttonText: "WL All Boomspear",
        enableMethod: () => {
          wlAllBoomspearEnabled = true;
        },
        disableMethod: () => {
          wlAllBoomspearEnabled = false;
        },
        method: () => {
          if (!wlAllBoomspearEnabled || !rightGrab || time <= _wlAllBoomspearDelay) {
            return;
          }
          _wlAllBoomspearDelay = time + 0;
          _0x35af2d((_0x1a6cf2) => _0x4ae875(_0x1a6cf2, "RPGRocketSpear", 750));
        },
        isTogglable: true,
        toolTip:
          "Toggle ON + hold grip to spam explosive eggs from all whitelisted players' hands.",
      }),
      new ButtonInfo({
        buttonText: "WL All Balloon",
        enableMethod: () => {
          wlAllBalloonEnabled = true;
        },
        disableMethod: () => {
          wlAllBalloonEnabled = false;
        },
        method: () => {
          if (!wlAllBalloonEnabled || !rightGrab || time <= _wlAllBalloonDelay) {
            return;
          }
          _wlAllBalloonDelay = time + 0;
          _0x35af2d((_0x31a1cf) => _0x38a8c2(_0x31a1cf, 75));
        },
        isTogglable: true,
        toolTip: "Toggle ON + hold grip to spam balloons from all whitelisted players' hands.",
      }),
      new ButtonInfo({
        buttonText: "WL All Giveaway",
        enableMethod: () => {
          wlAllGiveawayEnabled = true;
        },
        disableMethod: () => {
          wlAllGiveawayEnabled = false;
        },
        method: () => {
          if (!wlAllGiveawayEnabled || !rightGrab || time <= _wlAllGiveawayDelay) {
            return;
          }
          _wlAllGiveawayDelay = time + 0;
          _0x35af2d((_0x56af62) =>
            _0x4f206b(_0x56af62, itemIDs[Math.floor(Math.random() * itemIDs.length)], 30),
          );
        },
        isTogglable: true,
        toolTip: "Toggle ON + hold grip to rain random items from all whitelisted players' hands.",
      }),
      new ButtonInfo({
        buttonText: "WL All Disintegrate",
        enableMethod: () => {
          wlAllDisintegrateEnabled = true;
        },
        disableMethod: () => {
          wlAllDisintegrateEnabled = false;
        },
        method: () => {
          if (!wlAllDisintegrateEnabled || !rightGrab || time <= _wlAllDisintegrateDelay) {
            return;
          }
          _wlAllDisintegrateDelay = time + 0.5;
          _0x35af2d((_0x1c35cc) => _0x1c35cc.method("RPC_Teleport").invoke([0, -9999999, 0]));
        },
        isTogglable: true,
        toolTip: "Toggle ON + hold grip to disintegrate all whitelisted players.",
      }),
      new ButtonInfo({
        buttonText: "WL All Gun Buff",
        enableMethod: () => {
          wlAllGunBuffEnabled = true;
        },
        disableMethod: () => {
          wlAllGunBuffEnabled = false;
        },
        method: () => {
          if (!wlAllGunBuffEnabled || !rightGrab || time <= _wlAllGunBuffDelay) {
            return;
          }
          _wlAllGunBuffDelay = time + 1;
          _0x35af2d((_0x36651b) => _0x36651b.method("RPC_ApplyBuff").invoke(1));
        },
        isTogglable: true,
        toolTip:
          "Toggle ON + hold grip to continuously give speed buff to all whitelisted players.",
      }),
      new ButtonInfo({
        buttonText: "TP All WL To Me",
        isTogglable: false,
        method: () => {
          try {
            const _0x143f21 = NetPlayerClass.method("get_localPlayer").invoke();
            if (!_0x143f21 || _0x143f21.isNull()) {
              return;
            }
            const _0x4b2012 = _0xe40610(_0x143f21).method("get_position").invoke();
            let _0x44d6cf = 0;
            _0x35af2d((_0xa312fe) => {
              _0xa312fe.method("RPC_Teleport").invoke(_0x4b2012);
              _0x44d6cf++;
            });
            notify("TP'd " + _0x44d6cf + " WL player(s) to you!", false);
          } catch (_0x231728) {
            smartError("TP All WL To Me", _0x231728);
          }
        },
        toolTip: "Teleports all whitelisted players to your position.",
      }),
      new ButtonInfo({
        buttonText: "Kidnap All WL",
        isTogglable: false,
        method: () => {
          try {
            const _0x51d152 = rightHandTransform.method("get_position").invoke();
            const _0x51f27e = _0x5db48f("Basketball", _0x51d152, QuaternionIdentity);
            if (!_0x51f27e || _0x51f27e.isNull()) {
              notify("Spawn failed", false);
              return;
            }
            try {
              const _0x3da69c = _0x51f27e
                .method("GetComponent", 1)
                .inflate(AnimalGrabbableObjectClass)
                .invoke();
              if (_0x3da69c && !_0x3da69c.isNull()) {
                _0x3da69c.method("set_scaleModifier").invoke(-100);
              }
            } catch (_0x15ee33) {}
            let _0x31947b = 0;
            _0x35af2d((_0x5c8cce) => {
              _0x3218db(_0x5c8cce, _0x51f27e);
              _0x31947b++;
            });
            notify("Kidnapped " + _0x31947b + " WL player(s)", false);
          } catch (_0x319d93) {
            smartError("Kidnap All WL", _0x319d93);
          }
        },
        toolTip:
          "Spawns a basketball on your right hand and traps all whitelisted players inside it.",
      }),
    ],
  ];
  let _0x592add = new Map();
  menuPages.flat().forEach((_0x5ddd61) => {
    _0x592add.set(_0x5ddd61.buttonText, _0x5ddd61);
  });
  function _0x39a5e4(_0x4d1fe6) {
    return _0x592add.get(_0x4d1fe6);
  }
  const _0x599faf = ComputerTerminalKeyClass.method("OnTriggerEnter");
  _0x599faf.implementation = function (_0x434124) {
    var _0x316a13;
    var _0x265073;
    var _0xa08e45;
    const _0x55592f = this.method("get_name").invoke().toString();
    if (_0x55592f.length > 1 && _0x55592f[1] == "@") {
      if (_0x434124.handle.equals(referenceCollider.handle)) {
        const _0x5c94af = _0x55592f.substring(2, _0x55592f.length - 1);
        const _0x2b4718 = TimeClass.method("get_time").invoke();
        if (_0x2b4718 > buttonClickDelay) {
          buttonClickDelay = _0x2b4718 + 0.2;
          try {
            const _0x3448f1 = animalImage.class("AnimalCompany.RandomSFXSheet");
            const _0x24f4af = _0x3448f1.method("get_instance").invoke();
            if (_0x24f4af && !_0x24f4af.isNull()) {
              const _0x527542 = _0x24f4af.method("Get").invoke(44);
              if (_0x527542 && !_0x527542.isNull()) {
                const _0x53c815 = NetPlayerClass.method("get_localPlayer").invoke();
                const _0x22593f =
                  _0x53c815 && !_0x53c815.isNull()
                    ? _0xe40610(_0x53c815).method("get_position").invoke()
                    : [0, 0, 0];
                SfxManagerClass.method("PlaySFXNetworked", 4).invoke(_0x527542, _0x22593f, 1, 0);
              }
            }
          } catch (_0xab6ebb) {}
          const _0x7f8f51 = _0x39a5e4(_0x5c94af);
          if (_0x7f8f51) {
            if (_0x7f8f51.isTogglable) {
              _0x7f8f51.enabled = !_0x7f8f51.enabled;
              _0x5b6a19();
              if (_0x7f8f51.enabled) {
                if (_0x7f8f51.toolTip) {
                  notify("[ENABLE] " + _0x7f8f51.toolTip, false);
                }
                if ((_0x316a13 = _0x7f8f51.enableMethod) === null || _0x316a13 === undefined) {
                  undefined;
                } else {
                  _0x316a13.call(_0x7f8f51);
                }
              } else {
                if (_0x7f8f51.toolTip) {
                  notify("[DISABLE] " + _0x7f8f51.toolTip, false);
                }
                if ((_0x265073 = _0x7f8f51.disableMethod) === null || _0x265073 === undefined) {
                  undefined;
                } else {
                  _0x265073.call(_0x7f8f51);
                }
              }
            } else {
              _0x5b6a19();
              if (_0x7f8f51.toolTip) {
                notify(_0x7f8f51.toolTip, false);
              }
              if ((_0xa08e45 = _0x7f8f51.method) === null || _0xa08e45 === undefined) {
                undefined;
              } else {
                _0xa08e45.call(_0x7f8f51);
              }
            }
          }
        }
      }
      return;
    }
    return this.method("OnTriggerEnter").invoke(_0x434124);
  };
  function _0xa48421() {
    const _0x3aebd9 = InputDevicesClass.method("GetDeviceAtXRNode", 1).invoke(4);
    const _0x2c7427 = InputDevicesClass.method("GetDeviceAtXRNode", 1).invoke(5);
    const _0x19756d = Il2Cpp.alloc(1);
    _0x3aebd9
      .method("TryGetFeatureValue", 2)
      .invoke(CommonUsagesClass.field("primaryButton").value, _0x19756d);
    leftPrimary = _0x19756d.readU8() !== 0;
    _0x3aebd9
      .method("TryGetFeatureValue", 2)
      .invoke(CommonUsagesClass.field("secondaryButton").value, _0x19756d);
    leftSecondary = _0x19756d.readU8() !== 0;
    _0x3aebd9
      .method("TryGetFeatureValue", 2)
      .invoke(CommonUsagesClass.field("gripButton").value, _0x19756d);
    leftGrab = _0x19756d.readU8() !== 0;
    _0x3aebd9
      .method("TryGetFeatureValue", 2)
      .invoke(CommonUsagesClass.field("triggerButton").value, _0x19756d);
    leftTrigger = _0x19756d.readU8() !== 0;
    _0x3aebd9
      .method("TryGetFeatureValue", 2)
      .invoke(CommonUsagesClass.field("primary2DAxisClick").value, _0x19756d);
    leftStick = _0x19756d.readU8() !== 0;
    _0x2c7427
      .method("TryGetFeatureValue", 2)
      .invoke(CommonUsagesClass.field("primaryButton").value, _0x19756d);
    rightPrimary = _0x19756d.readU8() !== 0;
    _0x2c7427
      .method("TryGetFeatureValue", 2)
      .invoke(CommonUsagesClass.field("secondaryButton").value, _0x19756d);
    rightSecondary = _0x19756d.readU8() !== 0;
    _0x2c7427
      .method("TryGetFeatureValue", 2)
      .invoke(CommonUsagesClass.field("triggerButton").value, _0x19756d);
    rightTrigger = _0x19756d.readU8() !== 0;
    _0x2c7427
      .method("TryGetFeatureValue", 2)
      .invoke(CommonUsagesClass.field("gripButton").value, _0x19756d);
    rightGrab = _0x19756d.readU8() !== 0;
    _0x2c7427
      .method("TryGetFeatureValue", 2)
      .invoke(CommonUsagesClass.field("primary2DAxisClick").value, _0x19756d);
    rightStick = _0x19756d.readU8() !== 0;
  }
  const _0x712545 = localRig.method("OnLateUpdate");
  _0x712545.implementation = function () {
    try {
      deltaTime = TimeClass.method("get_deltaTime").invoke();
      time = TimeClass.method("get_time").invoke();
      menuAnimTime += deltaTime;
      {
        bgColor = [0.012, 0.004, 0.022, 0.97];
        buttonColor = [0.06, 0.022, 0.11, 0.4];
        textColor = [0.84, 0.7, 1, 1];
        buttonPressedColor = [0.84, 0.2, 1, 1];
        accentColor = [0.78, 0.22, 1, 1];
      }
      for (let _0x5e73e8 = _0x3492fa.length - 1; _0x5e73e8 >= 0; _0x5e73e8--) {
        try {
          const _0x14e260 = _0x3492fa[_0x5e73e8];
          if (!_0x14e260 || _0x14e260.isNull()) {
            _0x3492fa.splice(_0x5e73e8, 1);
            continue;
          }
          _0xe40610(_0x14e260).method("set_position").invoke(_0x14e260._lockedPos);
        } catch (_0x48b4c1) {
          _0x3492fa.splice(_0x5e73e8, 1);
        }
      }
      _0xa48421();
      frameCount++;
      if ((righthand && rightSecondary) || (!righthand && leftSecondary)) {
        if (currentNotification != "" && time > notifactionResetTime) {
          _0x5b6a19();
        }
        if (menu == null) {
          _0x1d8efd();
        } else {
          _0x538191();
          _0x348d63();
        }
      } else if (menu != null) {
        _0x11d2fe(menu);
        menu = null;
      }
      if (menu == null) {
        if (reference != null) {
          _0x11d2fe(reference);
          reference = null;
        }
      } else if (reference == null) {
        _0x21d610();
      }
      try {
        if (_0x5409db != null) {
          if (!_0x5409db.method("get_activeSelf").invoke()) {
            _0x11d2fe(_0x5409db);
            _0x5409db = null;
          } else {
            _0x5409db.method("SetActive").invoke(false);
          }
        }
        let _0x59064f = _0x3046e8.method("get_gameObject").invoke();
        if (_0x59064f != null) {
          if (!_0x59064f.method("get_activeSelf").invoke()) {
            _0x11d2fe(_0x59064f);
            _0x3046e8 = null;
          } else {
            _0x59064f.method("SetActive").invoke(false);
          }
        }
      } catch (_0x168f3b) {}
      gunFxEmit = false;
      if (containerFreedomAuraEnabled) {
        _0x3c6fc9();
      }
      menuPages
        .flat()
        .filter((_0x4bd6dc) => _0x4bd6dc.enabled)
        .forEach((_0x217717) => {
          if (_0x217717.method) {
            try {
              _0x217717.method();
            } catch (_0x3b2a5b) {
              smartError("[OnLateUpdate] " + _0x217717.buttonText, _0x3b2a5b);
            }
          }
        });
      _0x48c9b8();
      return _0x712545.invoke();
    } catch (_0x51d358) {
      try {
        return _0x712545.invoke();
      } catch (_0x20c9a5) {}
    }
  };
  function _0x92eb39() {
    try {
      const _0x32de83 = animalImage.class("AnimalCompany.NetPlayer");
      const _0x3ddb16 = (_0xcd310e) => {
        try {
          return rpcProtectionEnabled && !_0x3a1bb2 && _0xcd310e.method("get_IsMine").invoke();
        } catch (_0xcf6c7b) {
          return false;
        }
      };
      _0x32de83.method("RPC_Teleport").implementation = function (_0x3c2809) {
        try {
          if (this.method("get_IsMine").invoke()) {
            if (_0x3ddb16(this)) {
              return;
            }
            const _0x39b334 = _0x3c2809.field("x").value.toFixed(2);
            const _0x3f0e22 = _0x3c2809.field("y").value.toFixed(2);
            const _0x7b138f = _0x3c2809.field("z").value.toFixed(2);
            console.log(
              "[LOGCAT] Teleport (" + _0x39b334 + "," + _0x3f0e22 + "," + _0x7b138f + ")",
            );
          }
        } catch (_0x8656c2) {}
        return this.method("RPC_Teleport").invoke(_0x3c2809);
      };
      try {
        _0x32de83.method("RPC_AddForce").implementation = function (_0x4993da) {
          if (_0x3ddb16(this)) {
            return;
          }
          return this.method("RPC_AddForce").invoke(_0x4993da);
        };
      } catch (_0x4f100c) {}
      try {
        _0x32de83.method("RPC_SetJellyEffect").implementation = function (_0x2a1c26, _0x1ae26a) {
          if (_0x3ddb16(this)) {
            return;
          }
          return this.method("RPC_SetJellyEffect").invoke(_0x2a1c26, _0x1ae26a);
        };
      } catch (_0x1d08f0) {}
      try {
        _0x32de83.method("RPC_PlayerHit", 5).implementation = function (
          _0x384f05,
          _0x494ca1,
          _0x178e92,
          _0x4667bf,
          _0x459912,
        ) {
          if (_0x3ddb16(this)) {
            return;
          }
          return this.method("RPC_PlayerHit", 5).invoke(
            _0x384f05,
            _0x494ca1,
            _0x178e92,
            _0x4667bf,
            _0x459912,
          );
        };
      } catch (_0x52f129) {}
      try {
        _0x32de83.method("RPC_ShakeScreen").implementation = function (
          _0x229f6c,
          _0x3b1ee2,
          _0x22c482,
          _0x4fd0b9,
          _0x49a32d,
        ) {
          if (_0x3ddb16(this)) {
            return;
          }
          return this.method("RPC_ShakeScreen").invoke(
            _0x229f6c,
            _0x3b1ee2,
            _0x22c482,
            _0x4fd0b9,
            _0x49a32d,
          );
        };
      } catch (_0x249117) {}
      try {
        _0x32de83.method("RPC_SetColorHSV").implementation = function (
          _0x440a1b,
          _0x2cc8fa,
          _0x899c94,
          _0x30d0d8,
        ) {
          if (_0x3ddb16(this)) {
            return;
          }
          return this.method("RPC_SetColorHSV").invoke(_0x440a1b, _0x2cc8fa, _0x899c94, _0x30d0d8);
        };
      } catch (_0x459246) {}
      try {
        _0x32de83.method("RPC_DoPlayerDie").implementation = function (_0x30e822) {
          if (_0x3ddb16(this)) {
            return;
          }
          return this.method("RPC_DoPlayerDie").invoke(_0x30e822);
        };
      } catch (_0x26740e) {}
      try {
        _0x32de83.method("RPC_PlayerStun").implementation = function (
          _0x293e2f,
          _0x7377e6,
          _0x1e3db2,
          _0x5a8ebd,
        ) {
          if (_0x3ddb16(this)) {
            return;
          }
          return this.method("RPC_PlayerStun").invoke(_0x293e2f, _0x7377e6, _0x1e3db2, _0x5a8ebd);
        };
      } catch (_0x5976f1) {}
      try {
        _0x32de83.method("RPC_TagAsStinky").implementation = function () {
          if (_0x3ddb16(this)) {
            return;
          }
          return this.method("RPC_TagAsStinky").invoke();
        };
      } catch (_0x1c0d2c) {}
      try {
        _0x32de83.method("RPC_SetTeam").implementation = function (_0x208515) {
          if (_0x3ddb16(this)) {
            return;
          }
          return this.method("RPC_SetTeam").invoke(_0x208515);
        };
      } catch (_0x20d4cc) {}
    } catch (_0x5dba26) {
      smartError("[LOGCAT] RPC_Teleport:", _0x5dba26);
    }
    try {
      const _0x1ff813 = animalImage.class("AnimalCompany.PlayerController");
      _0x1ff813.method("PlayerDie").implementation = function (_0x4f271f, _0x233ab2, _0x325363) {
        try {
          console.log("[LOGCAT] PlayerDie hitName=" + (_0x233ab2?.content ?? "?"));
        } catch (_0x585e29) {}
        return this.method("PlayerDie").invoke(_0x4f271f, _0x233ab2, _0x325363);
      };
    } catch (_0x4492aa) {
      smartError("[LOGCAT] PlayerDie:", _0x4492aa);
    }
    console.log("[LOGCAT] installed");
  }
  _0x92eb39();
  function _0x4ca575() {
    let _0x3e6aac = false;
    try {
      GrabbableItemClass.method("get_canAddToBag").implementation = function () {
        return true;
      };
    } catch (_0x4ddd61) {}
    try {
      GrabbableItemClass.method("get_allowAddToBag").implementation = function () {
        return true;
      };
    } catch (_0xa29ba8) {}
    try {
      GrabbableItemClass.method("get_allowAttachToItem").implementation = function () {
        return true;
      };
    } catch (_0x38d765) {}
    try {
      GrabbableItemClass.method("get_allowAddToQuiver").implementation = function () {
        return true;
      };
    } catch (_0x2635b3) {}
    try {
      GrabbableItemClass.method("CanBeAddedToContainer").implementation = function (_0x288088) {
        return true;
      };
    } catch (_0x198bf2) {}
    try {
      GrabbableItemClass.method("get_isContainable").implementation = function () {
        return true;
      };
    } catch (_0x4b319c) {}
    try {
      GrabbableItemClass.method("get_canBePickedUp").implementation = function () {
        return true;
      };
    } catch (_0x3cf23c) {}
    try {
      const _0xf7ca99 = animalImage.class("AnimalCompany.GameplayItemState");
      function _0x54d2e6(_0x49463d) {
        try {
          const _0x1990d2 = _0x49463d.method("get_id").invoke();
          if (!_0x1990d2 || _0x1990d2.isNull()) {
            return false;
          }
          const _0x51ac84 = _0x1990d2.content ?? "";
          return (
            _0x51ac84.indexOf("stash") !== -1 ||
            _0x51ac84.indexOf("quiver") !== -1 ||
            _0x51ac84.indexOf("crossbow") !== -1 ||
            _0x51ac84.indexOf("heart_gun") !== -1 ||
            _0x51ac84.indexOf("grenade_launcher") !== -1 ||
            _0x51ac84.indexOf("salmoncannon") !== -1 ||
            _0x51ac84.indexOf("salmon_cannon") !== -1
          );
        } catch (_0x560b11) {
          return false;
        }
      }
      try {
        const _0x32249c = _0xf7ca99.method("get_isBag");
        _0xf7ca99.method("get_isBag").implementation = function () {
          if (_0x54d2e6(this)) {
            return true;
          }
          return _0x32249c.invoke.call(this);
        };
      } catch (_0x2aa6d0) {}
      try {
        const _0x58816 = _0xf7ca99.method("get_baseCapacity");
        _0xf7ca99.method("get_baseCapacity").implementation = function () {
          if (_0x54d2e6(this)) {
            try {
              const _0x313426 = _0x58816.invoke.call(this);
              if (_0x313426 && !_0x313426.isNull()) {
                try {
                  _0x313426.field("_value").value = 9999;
                } catch (_0x7bc5b6) {}
                try {
                  _0x313426.field("value").value = 9999;
                } catch (_0x21654d) {}
              }
              return _0x313426;
            } catch (_0x49f0a2) {}
          }
          return _0x58816.invoke.call(this);
        };
      } catch (_0x2543db) {}
      try {
        const _0x388491 = _0xf7ca99.method("get_totalCurrCapacity");
        _0xf7ca99.method("get_totalCurrCapacity").implementation = function () {
          if (_0x54d2e6(this)) {
            return 9999;
          }
          return _0x388491.invoke.call(this);
        };
      } catch (_0x3274ce) {}
      try {
        _0xf7ca99.method("get_allowAddToQuiver").implementation = function () {
          return true;
        };
      } catch (_0x4d4c51) {}
      try {
        _0xf7ca99.method("get_allowAddToBag").implementation = function () {
          return true;
        };
      } catch (_0x3fec39) {}
      try {
        _0xf7ca99.method("get_allowAttachToItem").implementation = function () {
          return true;
        };
      } catch (_0x2164b6) {}
      try {
        _0xf7ca99.method("get_allowAttachToBack").implementation = function () {
          return true;
        };
      } catch (_0x101805) {}
      try {
        _0xf7ca99.method("get_allowAttachToHip").implementation = function () {
          return true;
        };
      } catch (_0x39bde4) {}
      try {
        _0xf7ca99.method("get_containerCapacity").implementation = function () {
          if (_0x54d2e6(this)) {
            return 9999;
          } else {
            return 0;
          }
        };
      } catch (_0x3d4aae) {}
      try {
        _0xf7ca99.method("get_maxContainerCapacity").implementation = function () {
          if (_0x54d2e6(this)) {
            return 9999;
          } else {
            return 0;
          }
        };
      } catch (_0xf9fc7e) {}
    } catch (_0x96234f) {}
    try {
      BackpackItemClass.method("get__baseCapacity").implementation = function () {
        return 9999;
      };
    } catch (_0x3e4f82) {}
    try {
      BackpackItemClass.method("get_capacity").implementation = function () {
        return 9999;
      };
    } catch (_0x1877ca) {}
    try {
      BackpackItemClass.method("set_capacity").implementation = function (_0x13ab0a) {};
    } catch (_0x33d538) {}
    try {
      BackpackItemClass.method("get_isFull").implementation = function () {
        return false;
      };
    } catch (_0x4deae1) {}
    try {
      BackpackItemClass.method("get_canGrabContainedItems").implementation = function () {
        return true;
      };
    } catch (_0x458049) {}
    try {
      const _0x55d654 = new NativeFunction(
        ptr(BackpackItemClass.method("HandleAddItemTrigger").virtualAddress.toString()),
        "void",
        ["pointer", "pointer"],
      );
      BackpackItemClass.method("HandleAddItemTrigger").implementation = function (_0x1edb2a) {
        try {
          this.method("set_isOpen").invoke(true);
        } catch (_0x31266a) {}
        try {
          _0x55d654(this.handle, _0x1edb2a.handle);
        } catch (_0x3e25c5) {}
      };
    } catch (_0x45c7b9) {}
    try {
      const _0x3066a5 = new NativeFunction(
        ptr(BackpackItemClass.method("TryAddItem").virtualAddress.toString()),
        "pointer",
        ["pointer", "pointer"],
      );
      BackpackItemClass.method("TryAddItem").implementation = function (_0x4eb08) {
        try {
          this.field("_capacity").value = 9999;
        } catch (_0x2fcbb0) {}
        try {
          this.method("set_capacity").invoke(255);
        } catch (_0x1bb2b1) {}
        try {
          this.method("set_isOpen").invoke(true);
        } catch (_0x5329ee) {}
        try {
          _0x3066a5(this.handle, _0x4eb08.handle);
        } catch (_0x12867a) {}
      };
    } catch (_0x33b8ce) {
      smartError("[quiverHook] BackpackItem.TryAddItem:", _0x33b8ce);
    }
    try {
      QuiverClass.method("CheckToAddItem").implementation = function (_0x30665e) {
        try {
          const _0x58a013 = _0x30665e.method("GetComponent", 1).inflate(QuiverClass).invoke();
          if (_0x58a013 && !_0x58a013.isNull()) {
            return false;
          }
        } catch (_0x39b187) {}
        try {
          const _0x39cf82 = _0x30665e.field("equippingConfig").value;
          if (_0x39cf82 && !_0x39cf82.isNull()) {
            try {
              _0x39cf82.field("allowAddToQuiver").value = true;
            } catch (_0x45e0a4) {}
            try {
              _0x39cf82.field("allowAddToBag").value = true;
            } catch (_0x1d1f4a) {}
          }
        } catch (_0x19fd06) {}
        return this.method("CheckToAddItem").invoke(_0x30665e);
      };
    } catch (_0x55f541) {
      smartError("[quiverHook] Quiver.CheckToAddItem:", _0x55f541);
    }
    try {
      QuiverClass.method("CanAddItem").implementation = function (_0x165a2b) {
        try {
          const _0xfd2f5c = _0x165a2b.method("GetComponent", 1).inflate(QuiverClass).invoke();
          if (_0xfd2f5c && !_0xfd2f5c.isNull()) {
            return false;
          }
        } catch (_0x4bdb6a) {}
        return true;
      };
    } catch (_0x3fb8c8) {}
    try {
      const _0x553970 = new NativeFunction(
        ptr(QuiverClass.method("TryAddItem").virtualAddress.toString()),
        "pointer",
        ["pointer", "pointer"],
      );
      QuiverClass.method("TryAddItem").implementation = function (_0x11be6c) {
        try {
          this.field("_capacity").value = 9999;
        } catch (_0x5d0b2d) {}
        try {
          this.method("set_capacity").invoke(255);
        } catch (_0x235102) {}
        try {
          _0x553970(this.handle, _0x11be6c.handle);
        } catch (_0x5d4213) {}
      };
    } catch (_0x4c8f1a) {}
    try {
      QuiverClass.method("get__baseCapacity").implementation = function () {
        return 9999;
      };
    } catch (_0x32412a) {}
    try {
      QuiverClass.method("get_capacity").implementation = function () {
        return 9999;
      };
    } catch (_0x5950d3) {}
    try {
      QuiverClass.method("get_isFull").implementation = function () {
        return false;
      };
    } catch (_0x30c144) {}
    if (CrossbowClass) {
      try {
        CrossbowClass.method("CheckToAddItem").implementation = function (_0x42973a) {
          return true;
        };
      } catch (_0x467cce) {}
      try {
        CrossbowClass.method("CanAddItem").implementation = function (_0x1ca3dc) {
          return true;
        };
      } catch (_0x65ee1d) {}
      try {
        CrossbowClass.method("get_capacity").implementation = function () {
          return 9999;
        };
      } catch (_0x7283a4) {}
      try {
        CrossbowClass.method("get__baseCapacity").implementation = function () {
          return 9999;
        };
      } catch (_0x5586da) {}
      try {
        CrossbowClass.method("get_isFull").implementation = function () {
          return false;
        };
      } catch (_0x3c35f2) {}
      try {
        CrossbowClass.method("get_canGrabContainedItems").implementation = function () {
          return true;
        };
      } catch (_0xc7e41) {}
      try {
        CrossbowClass.method("AddToBagAck").implementation = function (_0x150797) {
          if (_0x3e6aac) {
            return true;
          }
          _0x3e6aac = true;
          try {
            try {
              this.field("_capacity").value = 9999;
            } catch (_0x43aed5) {}
            try {
              this.method("set_capacity").invoke(255);
            } catch (_0x15c0b8) {}
            return this.method("AddToBagAck").invoke(_0x150797);
          } catch (_0x210dc8) {
            return true;
          } finally {
            _0x3e6aac = false;
          }
        };
      } catch (_0x3e3100) {}
    }
    if (HeartGunClass) {
      try {
        HeartGunClass.method("CheckToAddItem").implementation = function (_0x5a193a) {
          return true;
        };
      } catch (_0x10ae4e) {}
      try {
        HeartGunClass.method("CanAddItem").implementation = function (_0x4ac29d) {
          return true;
        };
      } catch (_0x5c345e) {}
      try {
        HeartGunClass.method("get_capacity").implementation = function () {
          return 9999;
        };
      } catch (_0x53a442) {}
      try {
        HeartGunClass.method("get__baseCapacity").implementation = function () {
          return 9999;
        };
      } catch (_0x4ab67c) {}
      try {
        HeartGunClass.method("get_isFull").implementation = function () {
          return false;
        };
      } catch (_0x4515f9) {}
      try {
        HeartGunClass.method("get_canGrabContainedItems").implementation = function () {
          return true;
        };
      } catch (_0x5bbf41) {}
      try {
        HeartGunClass.method("get_isBackpack").implementation = function () {
          return true;
        };
      } catch (_0x4efb8f) {}
      try {
        HeartGunClass.method("AddToBagAck").implementation = function (_0x21abe0) {
          if (_0x3e6aac) {
            return true;
          }
          _0x3e6aac = true;
          try {
            try {
              this.field("_capacity").value = 9999;
            } catch (_0xe480bf) {}
            try {
              this.method("set_capacity").invoke(255);
            } catch (_0x581553) {}
            return this.method("AddToBagAck").invoke(_0x21abe0);
          } catch (_0xfca088) {
            return true;
          } finally {
            _0x3e6aac = false;
          }
        };
      } catch (_0x2c6428) {}
    }
    if (GrenadeLauncherClass) {
      try {
        GrenadeLauncherClass.method("CheckToAddItem").implementation = function (_0x534bdf) {
          return true;
        };
      } catch (_0x322ed7) {}
      try {
        GrenadeLauncherClass.method("get_capacity").implementation = function () {
          return 9999;
        };
      } catch (_0x1f7f50) {}
      try {
        GrenadeLauncherClass.method("set_capacity").implementation = function (_0x5ab173) {};
      } catch (_0x45a0a8) {}
      try {
        GrenadeLauncherClass.method("get_cappedCapacity").implementation = function () {
          return 9999;
        };
      } catch (_0x18bdc4) {}
    }
    console.log("[quiverHook] v5 — bags openable, grenade/salmon as bags, no quiver-in-quiver");
  }
  _0x4ca575();
  function _0x2f6d25() {
    const _0x477062 = animalImage
      .class("AnimalCompany.ArenaItemKiller")
      .method("DespawnIfNecessary");
    _0x477062.implementation = function () {
      return;
    };
  }
  const _0x18379a = animalImage.class("AnimalCompany.FlareGun").method("get_hasAmmo");
  _0x18379a.implementation = function () {
    if (InfAmmo) {
      return true;
    }
    return this.method("get_hasAmmo").invoke();
  };
  const _0x4b621c = animalImage.class("AnimalCompany.Revolver").method("get_ammoLoaded");
  _0x4b621c.implementation = function () {
    if (InfAmmo) {
      return 255;
    }
    return this.method("get_ammoLoaded").invoke();
  };
  const _0x315c58 = animalImage.class("AnimalCompany.Revolver").method("get_isHammerCocked");
  _0x315c58.implementation = function () {
    if (InfAmmo) {
      return true;
    }
    return this.method("get_isHammerCocked").invoke();
  };
  const _0x1b2986 = animalImage.class("AnimalCompany.ZiplineGun").method("get_isLoaded");
  _0x1b2986.implementation = function () {
    if (InfAmmo) {
      return true;
    }
    return this.method("get_isLoaded").invoke();
  };
  const _0x200eb2 = animalImage.class("AnimalCompany.Shotgun").method("get__ammoLeft");
  _0x200eb2.implementation = function () {
    if (InfAmmo) {
      return 255;
    }
    return this.method("get__ammoLeft").invoke();
  };
  const _0x41e32f = animalImage.class("AnimalCompany.RPG").method("get_loadedState");
  _0x41e32f.implementation = function () {
    const _0x35201a = this.method("get_loadedState").invoke();
    if (InfAmmo) {
      _0x35201a.field("isLoaded").value = true;
      this.method("set_loadedState").invoke(_0x35201a);
    }
    return _0x35201a;
  };
  try {
    animalImage.class("AnimalCompany.BoomSpear").method("get_loadedState").implementation =
      function () {
        const _0x2efb35 = this.method("get_loadedState").invoke();
        if (InfAmmo) {
          _0x2efb35.field("isLoaded").value = true;
          try {
            this.method("set_loadedState").invoke(_0x2efb35);
          } catch (_0x288484) {}
        }
        return _0x2efb35;
      };
  } catch (_0x5cd4e) {}
  try {
    animalImage.class("AnimalCompany.BoomSpear").method("get_hasAmmo").implementation =
      function () {
        if (InfAmmo) {
          return true;
        }
        return this.method("get_hasAmmo").invoke();
      };
  } catch (_0x347a83) {}
  try {
    animalImage.class("AnimalCompany.RPGSpear").method("get_loadedState").implementation =
      function () {
        const _0xa0ff7 = this.method("get_loadedState").invoke();
        if (InfAmmo) {
          _0xa0ff7.field("isLoaded").value = true;
          try {
            this.method("set_loadedState").invoke(_0xa0ff7);
          } catch (_0x10e3ec) {}
        }
        return _0xa0ff7;
      };
  } catch (_0x357c9f) {}
  try {
    animalImage.class("AnimalCompany.SpearRPG").method("get_hasAmmo").implementation = function () {
      if (InfAmmo) {
        return true;
      }
      return this.method("get_hasAmmo").invoke();
    };
  } catch (_0x3813ef) {}
  try {
    animalImage.class("AnimalCompany.EggRPG").method("get_loadedState").implementation =
      function () {
        const _0xfb011c = this.method("get_loadedState").invoke();
        if (InfAmmo) {
          _0xfb011c.field("isLoaded").value = true;
          try {
            this.method("set_loadedState").invoke(_0xfb011c);
          } catch (_0xd851bf) {}
        }
        return _0xfb011c;
      };
  } catch (_0x382801) {}
  try {
    animalImage.class("AnimalCompany.EggRPG").method("get_hasAmmo").implementation = function () {
      if (InfAmmo) {
        return true;
      }
      return this.method("get_hasAmmo").invoke();
    };
  } catch (_0xea9b2e) {}
  try {
    animalImage.class("AnimalCompany.RPGEgg").method("get_loadedState").implementation =
      function () {
        const _0x2e701a = this.method("get_loadedState").invoke();
        if (InfAmmo) {
          _0x2e701a.field("isLoaded").value = true;
          try {
            this.method("set_loadedState").invoke(_0x2e701a);
          } catch (_0x4be963) {}
        }
        return _0x2e701a;
      };
  } catch (_0x5e2683) {}
  try {
    animalImage.class("AnimalCompany.EasterEggRPG").method("get_hasAmmo").implementation =
      function () {
        if (InfAmmo) {
          return true;
        }
        return this.method("get_hasAmmo").invoke();
      };
  } catch (_0x3b3b53) {}
  const _0x3ba782 = animalImage.class("AnimalCompany.AutoReloadGun").method("get__ammoLeft");
  _0x3ba782.implementation = function () {
    if (InfAmmo) {
      return 255;
    }
    return this.method("get__ammoLeft").invoke();
  };
  const _0x972fb9 = animalImage.class("AnimalCompany.JetpackHandy").method("RPC_UseJetpack");
  _0x972fb9.implementation = function () {
    if (InfAmmo) {
      this.method("RPC_UseJetpack").invoke();
      this.field("_isUsed").value = false;
    } else {
      this.method("RPC_UseJetpack").invoke();
    }
  };
  const _0x57217e = animalImage
    .class("AnimalCompany.StashMachine.StashMachineTrashChuteView")
    .method("EjectItem");
  _0x57217e.implementation = function (_0x2ade58) {
    if (stashDupeEnabled) {
      for (let _0x4faf48 = 0; _0x4faf48 < ejectDupeAmount; _0x4faf48++) {
        this.method("EjectItem").invoke(_0x2ade58);
      }
    } else {
      this.method("EjectItem").invoke(_0x2ade58);
    }
  };
  try {
    const _0x127555 = animalImage.class("AnimalCompany.Gun");
    const _0xead9c1 = _0x127555.method("Shoot");
    _0xead9c1.implementation = function () {
      if (noRecoil || infDamage) {
        try {
          const _0x301ef7 = this.method("get_config").invoke();
          if (_0x301ef7 && !_0x301ef7.isNull()) {
            const _0x5cae09 = _0x301ef7.field("recoilForceMag").value;
            const _0x500326 = _0x301ef7.field("handRecoilForceMag").value;
            const _0x8191fb = _0x301ef7.field("shotSpread").value;
            let _0x4b9fe6 = null;
            if (noRecoil) {
              _0x301ef7.field("recoilForceMag").value = 0;
              _0x301ef7.field("handRecoilForceMag").value = 0;
              _0x301ef7.field("shotSpread").value = 0;
            }
            if (infDamage) {
              try {
                _0x4b9fe6 = _0x301ef7.field("damage").value;
                _0x301ef7.field("damage").value = 999999;
              } catch (_0x40c396) {}
              try {
                _0x301ef7.field("bulletDamage").value = 999999;
              } catch (_0x3f3763) {}
              try {
                _0x301ef7.field("damagePerBullet").value = 999999;
              } catch (_0x466560) {}
              try {
                _0x301ef7.field("hitDamage").value = 999999;
              } catch (_0x2253a5) {}
            }
            const _0x386822 = this.method("Shoot").invoke();
            if (noRecoil) {
              _0x301ef7.field("recoilForceMag").value = 0;
              _0x301ef7.field("handRecoilForceMag").value = 0;
              _0x301ef7.field("shotSpread").value = 0;
            }
            if (infDamage) {
              try {
                if (_0x4b9fe6 !== null) {
                  _0x301ef7.field("damage").value = 2147483648;
                }
              } catch (_0x5ef44f) {}
              try {
                _0x301ef7.field("bulletDamage").value = 2147483648;
              } catch (_0xb22298) {}
              try {
                _0x301ef7.field("damagePerBullet").value = 2147483648;
              } catch (_0x563827) {}
              try {
                _0x301ef7.field("hitDamage").value = 2147483648;
              } catch (_0xd18bff) {}
            }
            return _0x386822;
          }
        } catch (_0x3e8992) {}
      }
      return this.method("Shoot").invoke();
    };
  } catch (_0x1caa6b) {
    smartError("[Gun.Shoot hook failed]:", _0x1caa6b);
  }
  try {
    GrabbableItemClass.method("HandleHit").implementation = function (_0x157e41, _0x99079a) {
      if (infDamage) {
        try {
          const _0x582369 = this.field("_hitDamage").value;
          this.field("_hitDamage").value = 2147483648;
          const _0x3f556f = this.method("HandleHit").invoke(_0x157e41, _0x99079a);
          this.field("_hitDamage").value = _0x582369;
          return _0x3f556f;
        } catch (_0x1393d1) {}
      }
      return this.method("HandleHit").invoke(_0x157e41, _0x99079a);
    };
  } catch (_0x89d680) {}
  try {
    const _0x3034c7 = animalImage.class("AnimalCompany.GameplayItemState");
    try {
      _0x3034c7.method("get_allowBlueprintSaving").implementation = function () {
        return true;
      };
    } catch (_0x1371a8) {}
    try {
      _0x3034c7.method("get_maxInBlueprint").implementation = function () {
        return 9999;
      };
    } catch (_0x563811) {}
    try {
      _0x3034c7.method("get_isPurchasable").implementation = function () {
        return true;
      };
    } catch (_0x5dbd65) {}
    try {
      _0x3034c7.method("get_isResearchable").implementation = function () {
        return true;
      };
    } catch (_0x26fee1) {}
    try {
      _0x3034c7.method("get_canBeSavedToLoadoutTemplate").implementation = function () {
        return true;
      };
    } catch (_0x2c63f9) {}
    try {
      _0x3034c7.method("get_flags").implementation = function () {
        const _0x27baf9 = this.method("get_flags").invoke();
        try {
          if (_0x27baf9 && !_0x27baf9.isNull()) {
            const _0x201771 = _0x27baf9.method("get_value").invoke();
            const _0x45948b = _0x201771 | 4;
            if (_0x201771 !== _0x45948b) {
              try {
                _0x27baf9.method("set_value").invoke(_0x45948b);
              } catch (_0x4327a6) {}
            }
          }
        } catch (_0x562896) {}
        return _0x27baf9;
      };
    } catch (_0x16bbf4) {
      smartError("[Blueprint] get_flags hook failed:", _0x16bbf4);
    }
    console.log(
      "[Blueprint] GameplayItemState hooks installed - all items blueprintable, purchasable",
    );
  } catch (_0x302e7b) {
    smartError("[Blueprint] hook failed:", _0x302e7b);
  }
  try {
    const _0x596ab5 = animalImage.class("AnimalCompany.DamageAttribute");
    _0x596ab5.method("GetDamage").implementation = function (_0x316799) {
      if (infDamage) {
        return 2147483647;
      }
      return this.method("GetDamage").invoke(_0x316799);
    };
    console.log("[InfDamage] DamageAttribute.GetDamage hooked");
  } catch (_0x296040) {
    smartError("[InfDamage] DamageAttribute.GetDamage hook failed:", _0x296040);
  }
  try {
    const _0x1f7f51 = animalImage.class("AnimalCompany.Shotgun");
    const _0x199e61 = _0x1f7f51.method("OnUpdate");
    _0x199e61.implementation = function () {
      if (noShotgunCooldown) {
        try {
          this.field("_reloadTimer").value = 0;
        } catch (_0x26850c) {}
      }
      return this.method("OnUpdate").invoke();
    };
  } catch (_0x2695e7) {
    smartError("[NoShotgunCooldown] Shotgun.OnUpdate hook failed:", _0x2695e7);
  }
  try {
    const _0x5a19ea = animalImage.class("AnimalCompany.Shotgun");
    const _0x386260 = _0x5a19ea.method("HandleUse");
    _0x386260.implementation = function () {
      if (noShotgunCooldown) {
        try {
          this.field("_reloadTimer").value = 0;
        } catch (_0x2a4494) {}
      }
      return this.method("HandleUse").invoke();
    };
  } catch (_0x3e81a0) {}
  try {
    animalImage.class("AnimalCompany.SafeZone").method("IsInZone").implementation = function () {
      if (noSafeZone) {
        return false;
      }
      return this.method("IsInZone").invoke();
    };
  } catch (_0x442470) {}
  try {
    NetPlayerClass.method("get_isInSafeZone").implementation = function () {
      if (noSafeZone) {
        return false;
      }
      return this.method("get_isInSafeZone").invoke();
    };
  } catch (_0x216581) {}
  try {
    animalImage.class("AnimalCompany.SafeZone").method("IsPlayerInZone").implementation = function (
      _0x4d5498,
    ) {
      if (noSafeZone) {
        return false;
      }
      return this.method("IsPlayerInZone").invoke(_0x4d5498);
    };
  } catch (_0x420cc7) {}
  console.log("[SafeZone] hooks installed");
  try {
    const _0x37771a = animalImage.class("AnimalCompany.Revolver");
    _0x37771a.method("HandleTriggerUse").implementation = function () {
      if (aimbotEnabled) {
        try {
          const _0x5e933f = NetPlayerClass.method("get_localPlayer").invoke();
          const _0x5315c8 = _0xe40610(_0x5e933f).method("get_position").invoke();
          const _0x2576c0 = _0x5315c8.field("x").value;
          const _0x2f5d91 = _0x5315c8.field("y").value;
          const _0x4bef27 = _0x5315c8.field("z").value;
          const _0x12075a = NetPlayerClass.field("playerIDToNetPlayer").value;
          const _0x52c8f8 = _0x12075a.method("get_Values").invoke();
          const _0x4a3737 = _0x52c8f8.method("GetEnumerator").invoke();
          let _0x97b5a5 = 999999;
          let _0x5a1ebf = null;
          while (_0x4a3737.method("MoveNext").invoke()) {
            const _0x8dbb64 = _0x4a3737.method("get_Current").invoke();
            if (!_0x8dbb64 || _0x8dbb64.handle.isNull() || _0x16fc51(_0x8dbb64)) {
              continue;
            }
            const _0xdae490 = _0xe40610(_0x8dbb64).method("get_position").invoke();
            const _0x5d44ac = _0xdae490.field("x").value - _0x2576c0;
            const _0xa3a9bb = _0xdae490.field("y").value - _0x2f5d91;
            const _0x1e9657 = _0xdae490.field("z").value - _0x4bef27;
            const _0x23adbf = Math.sqrt(
              _0x5d44ac * _0x5d44ac + _0xa3a9bb * _0xa3a9bb + _0x1e9657 * _0x1e9657,
            );
            if (_0x23adbf < _0x97b5a5) {
              _0x97b5a5 = _0x23adbf;
              _0x5a1ebf = _0x8dbb64;
            }
          }
          if (_0x5a1ebf) {
            const _0x67683d = _0xe40610(_0x5a1ebf).method("get_position").invoke();
            const _0x471c68 = DamageSourceInfoClass.method("get_Null").invoke();
            _0x5a1ebf
              .method("RPC_PlayerHit", 5)
              .invoke(50, _0x67683d, Vector3Zero, _0x471c68, false);
          }
        } catch (_0x1cd764) {}
      }
      return this.method("HandleTriggerUse").invoke();
    };
    console.log("[RapidFire/Aimbot] Revolver.HandleTriggerUse hooked");
  } catch (_0x473725) {
    smartError("[RapidFire/Aimbot] Revolver.HandleTriggerUse hook failed:", _0x473725);
  }
  function _0xd0b39e() {
    function _0x5ed8e7(_0x52b4df) {
      try {
        return _0x52b4df.method("get_IsMine").invoke();
      } catch (_0x528b6d) {
        return false;
      }
    }
    function _0x13850f(_0x216fe6) {
      return rpcProtectionEnabled && _0x5ed8e7(_0x216fe6) && !_0x3a1bb2;
    }
    const _0x538042 = animalImage.class("AnimalCompany.NetPlayer");
    try {
      _0x538042.method("RPC_AddForce").implementation = function (_0x397a5c) {
        if (_0x13850f(this)) {
          return;
        }
        return this.method("RPC_AddForce").invoke(_0x397a5c);
      };
    } catch (_0x4abc72) {
      smartError("[blockrpc] RPC_AddForce:", _0x4abc72);
    }
    try {
      _0x538042.method("RPC_Teleport").implementation = function (_0x116998) {
        if (_0x13850f(this)) {
          return;
        }
        return this.method("RPC_Teleport").invoke(_0x116998);
      };
    } catch (_0x3e9522) {
      smartError("[blockrpc] RPC_Teleport:", _0x3e9522);
    }
    try {
      _0x538042.method("RPC_PlayerStun").implementation = function (
        _0x1d1d26,
        _0x55ef98,
        _0x3d0843,
        _0x3e6e7c,
      ) {
        if (_0x13850f(this)) {
          return;
        }
        return this.method("RPC_PlayerStun").invoke(_0x1d1d26, _0x55ef98, _0x3d0843, _0x3e6e7c);
      };
    } catch (_0x6ddc55) {
      smartError("[blockrpc] RPC_PlayerStun:", _0x6ddc55);
    }
    try {
      _0x538042.method("RPC_PlayerHit", 5).implementation = function (
        _0x253d36,
        _0x4a9fc5,
        _0x6c7d02,
        _0x16ef4d,
        _0x30582c,
      ) {
        if (_0x13850f(this)) {
          return;
        }
        return this.method("RPC_PlayerHit", 5).invoke(
          _0x253d36,
          _0x4a9fc5,
          _0x6c7d02,
          _0x16ef4d,
          _0x30582c,
        );
      };
    } catch (_0x46e9c0) {
      smartError("[blockrpc] RPC_PlayerHit:", _0x46e9c0);
    }
    try {
      _0x538042.method("RPC_DoPlayerDie").implementation = function (_0x2c7d4d) {
        if (_0x13850f(this)) {
          return;
        }
        return this.method("RPC_DoPlayerDie").invoke(_0x2c7d4d);
      };
    } catch (_0x28b086) {
      smartError("[blockrpc] RPC_DoPlayerDie:", _0x28b086);
    }
    try {
      _0x538042.method("RPC_TagAsStinky").implementation = function () {
        if (_0x13850f(this)) {
          return;
        }
        return this.method("RPC_TagAsStinky").invoke();
      };
    } catch (_0x1aee85) {
      smartError("[blockrpc] RPC_TagAsStinky:", _0x1aee85);
    }
    try {
      _0x538042.method("RPC_SetColorHSV").implementation = function (
        _0x24989e,
        _0x413a4a,
        _0x3a8828,
        _0x2098dc,
      ) {
        if (_0x13850f(this)) {
          return;
        }
        return this.method("RPC_SetColorHSV").invoke(_0x24989e, _0x413a4a, _0x3a8828, _0x2098dc);
      };
    } catch (_0x529db6) {
      smartError("[blockrpc] RPC_SetColorHSV:", _0x529db6);
    }
    try {
      _0x538042.method("RPC_ApplyBuff").implementation = function (_0xfaa15) {
        if (_0x13850f(this)) {
          return;
        }
        return this.method("RPC_ApplyBuff").invoke(_0xfaa15);
      };
    } catch (_0x1cc6ef) {
      smartError("[blockrpc] RPC_ApplyBuff:", _0x1cc6ef);
    }
    try {
      _0x538042.method("RPC_SetTeam").implementation = function (_0x2177a9) {
        if (_0x13850f(this)) {
          return;
        }
        return this.method("RPC_SetTeam").invoke(_0x2177a9);
      };
    } catch (_0x352bac) {
      smartError("[blockrpc] RPC_SetTeam:", _0x352bac);
    }
    try {
      _0x538042.method("RPC_SetHide").implementation = function (_0x365606) {
        if (_0x13850f(this)) {
          return;
        }
        return this.method("RPC_SetHide").invoke(_0x365606);
      };
    } catch (_0x493765) {
      smartError("[blockrpc] RPC_SetHide:", _0x493765);
    }
    try {
      _0x538042.method("RPC_AddPlayerMoney").implementation = function (_0x4e49ee) {
        if (_0x13850f(this)) {
          return;
        }
        return this.method("RPC_AddPlayerMoney").invoke(_0x4e49ee);
      };
    } catch (_0x1c2e54) {
      smartError("[blockrpc] RPC_AddPlayerMoney:", _0x1c2e54);
    }
    try {
      _0x538042.method("RPC_AttachToGiantHand").implementation = function (
        _0x3aae8c,
        _0x9dc372,
        _0x54c26c,
        _0x5ad6e7,
      ) {
        if (_0x13850f(this)) {
          return;
        }
        return this.method("RPC_AttachToGiantHand").invoke(
          _0x3aae8c,
          _0x9dc372,
          _0x54c26c,
          _0x5ad6e7,
        );
      };
    } catch (_0x3c7f26) {
      smartError("[blockrpc] RPC_AttachToGiantHand:", _0x3c7f26);
    }
    try {
      _0x538042.method("RPC_AwardKill").implementation = function () {
        if (_0x13850f(this)) {
          return;
        }
        return this.method("RPC_AwardKill").invoke();
      };
    } catch (_0x4e0a39) {
      smartError("[blockrpc] RPC_AwardKill:", _0x4e0a39);
    }
    try {
      _0x538042.method("RPC_ShakeScreen").implementation = function (
        _0x2800b9,
        _0x1fdf1e,
        _0x3737b7,
        _0x4c44da,
        _0x1fd1c7,
      ) {
        if (_0x13850f(this)) {
          return;
        }
        return this.method("RPC_ShakeScreen").invoke(
          _0x2800b9,
          _0x1fdf1e,
          _0x3737b7,
          _0x4c44da,
          _0x1fd1c7,
        );
      };
    } catch (_0x2395b4) {
      smartError("[blockrpc] RPC_ShakeScreen:", _0x2395b4);
    }
    try {
      _0x538042.method("RPC_SetRadioActive").implementation = function (
        _0x125cc7,
        _0x428a27,
        _0x2ad9e3,
      ) {
        if (_0x13850f(this)) {
          return;
        }
        return this.method("RPC_SetRadioActive").invoke(_0x125cc7, _0x428a27, _0x2ad9e3);
      };
    } catch (_0x15f7c2) {
      smartError("[blockrpc] RPC_SetRadioActive:", _0x15f7c2);
    }
    try {
      _0x538042.method("RPC_SetJellyEffect").implementation = function (_0x14ca25, _0x4f6091) {
        if (_0x13850f(this)) {
          return;
        }
        return this.method("RPC_SetJellyEffect").invoke(_0x14ca25, _0x4f6091);
      };
    } catch (_0x1f4ced) {
      smartError("[blockrpc] RPC_SetJellyEffect:", _0x1f4ced);
    }
    try {
      _0x538042.method("RPC_AttachTo").implementation = function (
        _0x14794e,
        _0x4b4cd0,
        _0x5b5859,
        _0x2f9bf0,
      ) {
        if (_0x13850f(this)) {
          return;
        }
        return this.method("RPC_AttachTo").invoke(_0x14794e, _0x4b4cd0, _0x5b5859, _0x2f9bf0);
      };
    } catch (_0x177499) {
      smartError("[blockrpc] RPC_AttachTo:", _0x177499);
    }
    try {
      _0x538042.method("RPC_DetachFromAttachable").implementation = function () {
        if (_0x13850f(this)) {
          return;
        }
        return this.method("RPC_DetachFromAttachable").invoke();
      };
    } catch (_0x1ac138) {
      smartError("[blockrpc] RPC_DetachFromAttachable:", _0x1ac138);
    }
    try {
      _0x538042.method("RPC_AttachToAttachable").implementation = function (
        _0x5725b9,
        _0x3ae8c2,
        _0x229c13,
        _0x48dd53,
      ) {
        if (_0x13850f(this)) {
          return;
        }
        return this.method("RPC_AttachToAttachable").invoke(
          _0x5725b9,
          _0x3ae8c2,
          _0x229c13,
          _0x48dd53,
        );
      };
    } catch (_0x4ef694) {
      smartError("[blockrpc] RPC_AttachToAttachable:", _0x4ef694);
    }
    try {
      _0x538042.method("RPC_SetMuffledVoiceEnabled").implementation = function (_0x57f325) {
        if (_0x13850f(this)) {
          return;
        }
        return this.method("RPC_SetMuffledVoiceEnabled").invoke(_0x57f325);
      };
    } catch (_0x5d318a) {
      smartError("[blockrpc] RPC_SetMuffledVoiceEnabled:", _0x5d318a);
    }
    try {
      _0x538042.method("RPC_SetSqueakyVoiceEnabled").implementation = function (_0x4d26e3) {
        if (_0x13850f(this)) {
          return;
        }
        return this.method("RPC_SetSqueakyVoiceEnabled").invoke(_0x4d26e3);
      };
    } catch (_0x359173) {
      smartError("[blockrpc] RPC_SetSqueakyVoiceEnabled:", _0x359173);
    }
    console.log(
      "[blockrpc] installed - blocking all 22 hostile RPCs on self, self-RPCs allowed via bypass",
    );
  }
  _0x2f6d25();
  _0xd0b39e();
  let _0x2837b6 = false;
  const _0x4b955c = NetPlayerClass.method("get_maxHealth");
  _0x4b955c.implementation = function () {
    if (_0x2837b6 && this.method("get_IsMine").invoke()) {
      return 999999;
    }
    return this.method("get_maxHealth").invoke();
  };
  const _0x2cf8f8 = animalImage.class("AnimalCompany.MiningLaser");
  _0x2cf8f8.method("get__fuel").implementation = function () {
    return this.field("_maxFuel").value;
  };
  _0x2cf8f8.method("get__didOverheat").implementation = function () {
    return false;
  };
  _0x2cf8f8.method("ProcessFuelConsumption").implementation = function () {};
  try {
    const _0x189fdc = animalImage.class("AnimalCompany.AntiCheatSystem");
    _0x189fdc.method("OnUpdate").implementation = function () {};
    console.log("[VPN] AntiCheatSystem.OnUpdate hooked — VPN detection disabled");
  } catch (_0x479388) {
    smartError("[VPN] AntiCheatSystem.Update hook failed:", _0x479388);
  }
  try {
    const _0x466ce5 = animalImage.class("AnimalCompany.AppState");
    _0x466ce5.method("get_isVPNActive").implementation = function () {
      const _0x203db0 = this.method("get_isVPNActive").invoke();
      if (_0x203db0 && !_0x203db0.isNull()) {
        try {
          _0x203db0.field("_value").value = false;
        } catch (_0x232b19) {}
        try {
          _0x203db0.field("value").value = false;
        } catch (_0x55be1e) {}
      }
      return _0x203db0;
    };
    console.log("[VPN] AppState.get_isVPNActive hooked — always returns false");
  } catch (_0x2cc1a6) {
    smartError("[VPN] AppState.get_isVPNActive hook failed:", _0x2cc1a6);
  }
  const _0x5276f6 = Il2Cpp.domain.assembly("AnimalCompany").image;
  const _0x4bb29a = [
    "item_fish_diamond_jade_koi",
    "item_fish_nebula_fish",
    "item_fish_rainbow_trout",
  ];
  try {
    const _0x10f629 = _0x5276f6.class("AnimalCompany.Fishing.GameplayFishConfig");
    _0x10f629.method("GetRandomFishSize").implementation = function () {
      return 127;
    };
    _0x10f629.method("GetPriceByScaleModifier").implementation = function (_0xba4d0a, _0x3cee17) {
      return this.method("GetPriceByScaleModifier").invoke(_0xba4d0a, 127);
    };
    _0x10f629.method("GetRandomMovementInterval").implementation = function () {
      return 99999;
    };
    _0x10f629.method("GetRandomSpeed").implementation = function () {
      return 0;
    };
  } catch (_0xda0b29) {
    smartError("[Fishing] GameplayFishConfig hooks:", _0xda0b29);
  }
  try {
    const _0x3a660d = _0x5276f6.class("AnimalCompany.Fishing.FishingBobberView");
    _0x3a660d.method("RPC_GrantClaimItem").implementation = function (
      _0x395900,
      _0xc08085,
      _0x2339f4,
    ) {
      const _0xac0f01 = _0x4bb29a[Math.floor(Math.random() * _0x4bb29a.length)];
      return this.method("RPC_GrantClaimItem").invoke(_0x395900, Il2Cpp.string(_0xac0f01), 127);
    };
    _0x3a660d.method("get_hasCaughtFish").implementation = function () {
      return true;
    };
  } catch (_0x2a0024) {
    smartError("[Fishing] FishingBobberView hooks:", _0x2a0024);
  }
  try {
    const _0x5ad779 = animalImage.class("AnimalCompany.MiningLaser");
    _0x5ad779.method("Spawned").implementation = function () {
      this.method("Spawned").invoke();
      try {
        this.field("_maxDistance").value = 9999;
      } catch (_0x12b1f7) {}
    };
  } catch (_0x4495eb) {
    smartError("[MiningLaser] Spawned distance hook:", _0x4495eb);
  }
  try {
    const _0xf430ca = animalImage.class("AnimalCompany.Weapons.SalmonCannon");
    _0xf430ca.method("CheckIsFishAttached").implementation = function (_0x11166f) {
      return true;
    };
    console.log("[SalmonCannon] CheckIsFishAttached hooked — any item can be loaded");
  } catch (_0x3fd2a6) {
    smartError("[SalmonCannon] CheckIsFishAttached hook failed:", _0x3fd2a6);
  }
  try {
    const _0x4605e6 = animalImage.class("AnimalCompany.HeartGun");
    try {
      _0x4605e6.method("get_charge").implementation = function () {
        if (InfAmmo) {
          return 1;
        }
        return this.method("get_charge").invoke();
      };
    } catch (_0x685f0d) {}
    try {
      _0x4605e6.method("get_isCharging").implementation = function () {
        if (InfAmmo) {
          return true;
        }
        return this.method("get_isCharging").invoke();
      };
    } catch (_0x1af958) {}
    try {
      _0x4605e6.method("HandleValidateGrab").implementation = function (_0x2e210e) {
        return true;
      };
    } catch (_0x134dd1) {}
    console.log("[HeartGun] charge/isCharging/HandleValidateGrab hooked");
  } catch (_0x337c81) {
    smartError("[HeartGun] hooks failed:", _0x337c81);
  }
  try {
    const _0x175df3 = animalImage.class("AnimalCompany.VPNDetector");
    try {
      _0x175df3.method("Update").implementation = function () {};
    } catch (_0x313555) {}
    try {
      _0x175df3.method("CheckVPNIsActive").implementation = function () {};
    } catch (_0xd7065e) {}
  } catch (_0x251ebe) {
    smartError("[VPN] VPNDetector hook failed:", _0x251ebe);
  }
  console.log(
    "\n██╗      ██╗   ██╗███╗   ███╗██╗███╗   ██╗ ██████╗ ██╗  ██╗\n██║      ██║   ██║████╗ ████║██║████╗  ██║██╔═══██╗╚██╗██╔╝\n██║      ██║   ██║██╔████╔██║██║██╔██╗ ██║██║   ██║ ╚███╔╝\n██║      ██║   ██║██║╚██╔╝██║██║██║╚██╗██║██║   ██║ ██╔██╗\n███████╗ ╚██████╔╝██║ ╚═╝ ██║██║██║ ╚████║╚██████╔╝██╔╝ ██╗\n╚══════╝  ╚═════╝ ╚═╝     ╚═╝╚═╝╚═╝  ╚═══╝ ╚═════╝ ╚═╝  ╚═╝\n    made by Pingu  |  v" +
      version +
      "\n",
  );
}, "main");
  }, 0);
}, "main");
